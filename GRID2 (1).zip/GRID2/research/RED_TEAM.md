# Red Team — Attack the Emerging Architecture

Assumption: every recommendation may be wrong.

## Attack 1: The field abstraction becomes a second node system

If `FieldSource`, `FieldLink`, `ParameterModulator`, `graphRouting` and post modulation all coexist, RE will have four routing models. Adding a universal field contract without deleting the others increases complexity.

**Required before implementation:** one schema, one runtime evaluator, one UI projection. Otherwise reject.

## Attack 2: Mutation is a random button, not a creative system

Current mutation randomly samples values/edges. Without perceptual novelty, local continuity or an archive, users will press AGAIN until something looks good, then lose it. The loop is closer to a slot machine than cultivation.

**Required:** local mutation (near current value), structural proposals with visual coherence, stable seed replay, a visible lineage capture.

## Attack 3: Shared Look IDs remain a source of corruption

Make Unique clones modifier IDs and field links, but runtime caches, post targets and mutation records reference IDs. Any missed remap can make one object mutate another.

**Required:** stable ownership keys `(lookId, modifierId)` or globally unique IDs; migration; runtime cache invalidation.

## Attack 4: Save format cannot reproduce the organism

`Project` saves configuration only. RD patterns, post history, physics, TAA and camera are runtime. “Reload exact visual state” is false. Mutation lineage stores before/after configs but not temporal state.

**Required:** explicitly name persistence levels A/B/C and do not market B/C until checkpoints exist.

## Attack 5: A runtime export will be enormous and unstable

The runtime currently includes editor UI, plan editor, DMX, Three.js legacy, shaders, assets and React. A “runtime” built by hiding panels is not a runtime.

**Required:** separate entrypoint and dependency graph; delete dead Three.js; lazy-load editors; measure bundle.

## Attack 6: The MVP is still the old editor plus new features

Plan editor, patch, power, catalog, timeline, Shader Lab, graph, mutation, RD, post and 90 modifiers are all in the same product. This is not an MVP; it is a laboratory with no product boundary.

**Required:** choose RE:GRID or RE:MORPH; hide the other.

## Attack 7: GPU field routing is not uniform

RD field links work for two modifier types and post shaders; CPU modulation uses a readback for scalar. The “one field model” is not real for all consumers. A general graph proposal may overpromise.

**Required:** enumerate supported GPU consumers; define field adapter compilation; reject unsupported edges at creation.

## Attack 8: Extreme values will continue to cause renderer survival bugs

The system intentionally allows extreme values, but bounds, camera, shader compile, RD allocation and post format can fail. Local fallback is not consistently implemented.

**Required:** per-system budgets and fallback tests; no global “safety clamp” that kills expression.

## Attack 9: The graph editor is already the wrong primary UX

The advanced graph is useful, but the product’s value is not node authoring. If users must understand nodes to get emergence, RE becomes a worse TouchDesigner.

**Required:** condition-first UX (Time/Entropy/Relation/Field/Simulation), graph only for inspection/advanced.

## Attack 10: Performance assumptions are untested

No hardware benchmark exists. RD at 1024²×64, 200 clones, 5 RGBA16F post passes and TAA may be unusable on laptops. A WebGL2-only strategy may be correct, but it needs measurement.

**Required:** hardware matrix and budgets before expanding systems.

## What should be deleted

- Dead Three.js/R3F stack.
- Plan/patch/DMX/power surfaces if RE:MORPH is chosen.
- Unused 90-modifier catalog entries that are not visually verified.
- Duplicate graph/routing models.
- Full before/after JSON snapshots in localStorage.
- Double-click camera focus path (already removed).
- Legacy stage identity/docs if another product.
