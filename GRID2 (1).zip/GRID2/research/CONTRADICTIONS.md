# Contradictions Map

| # | Position A | Position B | Evidence | Human decision |
| --- | --- | --- | --- | --- |
| C1 | RE is a stage/lighting planner (README, DMX/power tests, catalog). | RE is a self-organizing visual instrument (RD, mutation, fields, shaders). | Both are in the repo and UI. | Choose product identity or explicitly define two modes. |
| C2 | Mutation lineage should persist in project for reproducibility. | Lineage snapshots are 13 MB/project and localStorage cannot hold them. | `Project.mutation.accepted`, before/after strings, 700ms whole-workspace save. | Move lineage to IndexedDB/session or implement compact diffs/checkpoints. |
| C3 | Advanced graph should be the real dataflow. | Normal users should not author a giant node graph. | Graph dialog exists but most routing is inline; post/mutation bypass parts. | Keep graph advanced; compile one real model underneath. |
| C4 | One additional simulation will strengthen emergence. | Don’t add simulations until RD/perf/runtime are stable. | R07 vs R15. | Defer until field contract + hardware baseline. |
| C5 | RD scalar readback is acceptable for global modulation. | Synchronous GPU readback is a stall and should be eliminated/throttled. | `sampleOutput` 3×3 readback; cached once/frame. | Keep opt-in global only; throttle/benchmark. |
| C6 | Runtime/editor split is necessary for deployment. | Runtime is too coupled to split now. | Monolithic runtime; no entrypoint. | Extract pure libs/resources first; split after MVP. |
| C7 | Shared Look is the primary reusable organism. | Shared Look ID/field-link ownership is still fragile. | Make Unique ID cloning added; runtime caches implicit. | Define ownership keys before expanding Looks. |
| C8 | Post stack is a CameraFrame effect and stable. | Failed-pass mapping/history/lifecycle still fragile. | `RendererPostEffect` stack vs built index; no destroy call. | Fix pass mapping/destroy before more post features. |
| C9 | Pointer ownership is handled by runtime. | Plan/timeline/dialog overlays have independent owners. | No global owner; fixed modal list in App. | Build global input ownership registry. |
| C10 | Timeline is the time authority. | Tempus should be canonical; Timeline is a view. | timelineClock, animTime, frame.time, RD dt diverge. | Adopt Tempus with Timeline derived. |
| C11 | Camera framing was fixed by hardening bounds. | Legacy focus/double-click paths remain callable. | `onFocus`, `focusObject`, `pickAt(focus)`. | Remove or gate all non-explicit focus paths. |
| C12 | Opaque displacement is fixed. | Source-transparent materials still intentionally transparent; user image may persist. | opacity chunk selective, material guard. | Ask for exact material if still reproducible; don’t disable intentional transparency. |
