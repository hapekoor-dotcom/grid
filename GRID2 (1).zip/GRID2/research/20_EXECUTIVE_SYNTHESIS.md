# 20 — Executive Synthesis

Date: 2026-11-12
Evidence base: repository at `6964523`, specialist reports, cross-review, red team, competitive research.
Audience: senior architecture team.

---

## 1. Verdict

RE is a **pre-MVP experimental visual instrument trapped inside a stage-lighting editor**, implemented as a single large PlayCanvas runtime over a single large Zustand project store.

The genuinely valuable core is real:

- one shared GPU Gray–Scott field;
- field-driven geometry/material/post;
- modifier composition;
- signals/modulation/typed adapters;
- seeded mutation with a four-action creative loop;
- immediate visual feedback.

The recurring instability is not random. It comes from four architectural choices:

1. **Runtime state is much larger than project state and is not explicitly owned.**
2. **Invalidation is inferred from JSON signatures instead of explicit events.**
3. **One monolithic runtime owns input, rendering, materials, shaders, physics, picking, camera and diagnostics.**
4. **Two product identities and two rendering stacks coexist.**

The next phase should not add features. It should:

- make an explicit product-identity decision (not assume RE:MORPH);
- delete the dead Three.js stack and separate non-MVP domains;
- define explicit runtime/session/resource ownership;
- fix invalidation and destruction;
- make one canonical time model;
- make mutation trustworthy;
- formalize one field/connection contract;
- then add at most one contrasting simulation.

---

## 2. What RE actually is today

FACT:

- React 19 + Vite + Zustand editor.
- PlayCanvas 2.24 owns the 3D viewport.
- A legacy Three.js/R3F stage stack remains installed but is not imported by the app shell.
- `PlayCanvasRuntime` is ~4,368 lines and owns WebGL init, scene construction, materials, lights, modifiers, shaders, picking, input, physics, camera and diagnostics.
- `workspaceStore` is ~1,342 lines and owns projects, Undo/Redo, object/material/Look operations, shaders, post stack, signals, RD config, persistence and mutation.
- One `Project` JSON is the configuration authority; runtime/GPU/temporal state is separate and largely invisible.
- The UI brand and README still say RE:GRID / stage planning; the experimental work says RE:MORPH / self-organizing visuals.

This is not a clean architecture with a feature backlog. It is an evolving engine whose product boundary has not been decided.

---

## 3. Architecture map

```text
React shell
  ├─ Workspace store (projects, Undo, persistence)
  ├─ UI store (selection, mode, modals, panels)
  ├─ Plan editor (2D stage/DMX/power)
  └─ Lazy 3D viewport
        └─ PlayCanvasRuntime (monolith)
              ├─ PlayCanvas AppBase / camera / CameraFrame
              │     ├─ TAA, bloom, fog, color enhance, dither
              │     └─ RendererPostEffect (custom post + history)
              ├─ ReactionDiffusionRuntime (raw WebGL2 ping-pong)
              ├─ modifier shader chunks / materials
              ├─ physics (cannon-es)
              ├─ picking / camera / input / selection
              └─ diagnostics
```

Dependency direction is blurred: the runtime imports UI/project concepts; the store imports UI store; post imports signals/timeline/custom shaders; RD uses a module-global sample provider.

---

## 4. Why the recurring bugs happen

### 4.1 Renderer magic refresh

`setProject` uses JSON signatures. When a signature misses a dependency, a later unrelated control changes another signature and triggers `cameraFrame.update()` or a rebuild, “repairing” the visual. Haze historically did this. The fix is explicit invalidation events, not another signature.

### 4.2 Pointer death

There is no global pointer owner. Runtime, plan editor, timeline, gizmos, dialogs, graph, Shader Lab, RD paint and overlays each have local state. Modal flags in App shortcuts are a fixed list. Invisible overlays and camera input blocking can consume LMB. The runtime state machine is better than before (marquee, lost capture, Escape), but it is still one owner among many.

### 4.3 Temporal poisoning

RD, post history, TAA, physics, spring motion and clones are stateful but not owned as temporal resources. `rebuild()` resets TAA and `animTime` but does not reset RD/post. Project switch can retain textures/history. RD step count depends on frame rate because it uses `iterations` per frame with a `dt`-scaled step, not an accumulator.

### 4.4 Shader/post instability

The post/CameraFrame path had a real format and history bug: RG11B10F intermediates and an unbound `uSource` history copy. The current implementation pins linear RGBA16F, binds both uniforms, and passthrough identity passes. But failed pass indexing still mismatches stack vs built passes; `postEffect`/RD destruction is not explicit; shader chunk generation is large and fragile.

### 4.5 Geometry regression

Ordered geometry previously bound `uGeoOps[16]`/`uGeoOpCount` as int uniforms; the shader effectively saw zero/first op while `uOrderActive` disabled fallback blocks. Fixed with scalar `uGeoOp0..15` and a float count. This is a class of bug: generated shader + PlayCanvas uniform binding is under-tested.

### 4.6 State leakage

`destroy()` omits `rd.destroy()` and `postEffect.destroy()`. `reactionField` is a module singleton. Runtime caches are not project-scoped. Mode switch destroys the app/device but not every resource. `Project.mutation` snapshots live in localStorage.

### 4.7 Material transparency

Unconditional opacity chunk installation on every shader effect could make opaque displacement materials transparent; fixed with conditional chunk installation and opaque source guard. Genuine transparent materials remain transparent by design.

---

## 5. State ownership

Authoritative project state is reasonably clear; **authoritative runtime state is not**.

Critical duplicates:

- selection (`uiStore` vs runtime)
- hover (`uiStore` vs runtime)
- material state (project override vs Look vs cloned material vs shader material)
- shader targets (`shaderEffectTargets`, `materialTargets`)
- graph (modulators vs field links vs post values)
- time (animTime, timeline, frame time, RD, physics)
- RD sample provider (global vs instance)

Recommendation:

- `Project` = configuration only.
- `RuntimeSession` = explicit owner of camera, GPU resources, physics, post history, RD state, diagnostics.
- `Capture`/`Checkpoint` = optional persisted runtime state for reproducibility.
- One `InputArbiter` = pointer/modal ownership.
- One `Clock`/`Tempus` = canonical time.
- One `Graph` = compiled connections; UI views project it.

---

## 6. Render and temporal architecture

Verified path:

```text
Scene → CameraFrame HDR
      → TAA (optional)
      → RendererPostEffect custom passes (RGBA16F, history copy)
      → scene.texture replaced
      → bloom/fog/color enhance/vignette
      → ACES tone mapping
      → dither
      → backbuffer
```

Passthrough identity is now tested: 0% changed pixels, max channel delta 3. Keep this invariant.

Post resource issues:

- failed pass dropped but stack index retained;
- resize scheduling and history;
- no explicit post destroy;
- history copy one-frame design is fragile;
- only pixel identity tested, not numeric HDR.

Temporal design:

- one art clock with rate/offset/phase/pause/loop;
- fixed simulation step + accumulator;
- TAA/post history have epochs/reset reasons;
- RD/physics checkpoints for exact state;
- Timeline derives from Tempus, not duplicated.

---

## 7. Fields, signals, graph and RD

Current reality:

- RD simulation is a single shared RGBA16F ping-pong Gray–Scott.
- It samples chemical A (`.r`) in shaders; CPU `sampleOutput` reads chemical B (`.g`). **This is a semantic inconsistency that must be resolved.**
- Scalar sampling is cached 3×3 readback, opt-in; spatial field routing is GPU-native.
- `ParameterModulator`, `FieldLink`, post values and mutation create edges in different models.
- The graph UI edits project records, but not a single compiled graph.

Recommendation:

- Define one typed connection schema: source node/port, target node/port, adapter chain, execution domain, owner, stable ID.
- Separate value ports and field ports.
- Compile/caches topology; validate cycles before mutation.
- Resolve RD channel contract (A vs B) and expose channel selection.
- Make automatic consumers explicit generated edges.

Field research: the highest-value near-term change is **two-species Gray–Scott in the existing RGBA16F channels**, with a channel/output selector, before adding a new simulation. Spatial parameter maps/anisotropy/flow are cheaper and more expressive than another simulation family. Physarum/Lenia/NCA/differential growth remain experimental.

---

## 8. Mutation and Tempus

Mutation currently has the right interaction primitive and a weak implementation:

- seed display is not seed control;
- “Again” is a new seed, not a replay;
- 64 full before/after snapshots can exhaust localStorage;
- accepted history is never read by UI;
- value sampling is global-range, not local;
- scope and structure mutations are limited;
- no material/light/post/signal mutation;
- no fixed-step/checkpoint coupling.

Recommendation:

- Make seed immutable/replayable; id = hash(seed, base hash, ops).
- Store compact op lists + base hash, not full project snapshots; move lineage out of the project or use IndexedDB.
- Split amount vs structure depth.
- Local perturbation by default; structural proposals validated.
- Branch creates a distinct lineage with compact ancestry.
- Mutation record includes clock/step policy if it claims temporal reproducibility.

Tempus should own:

- playing, signed rate, offset, phase, loop/hold/pingpong, bpm;
- fixed artistic tick + accumulator;
- per-domain derived times;
- epoch/reset reason;
- checkpoint descriptors.

It must not own render loop, timeline data/evaluation, simulation coefficients, TAA jitter format, quality policy or mutation lineage storage.

---

## 9. Input / selection

Marquee selection and effect-aware picking are now real:

- LMB empty drag → marquee;
- inside/intersect rules;
- Shift add / Alt subtract;
- effective screen bounds + hover wireframe;
- clone clicks select parent;
- camera LMB not stolen;
- double-click camera navigation removed;
- F / Shift+F explicit framing, hardened bounds.

Remaining systemic risk: no global pointer arbitration. The input arbiter and stress tests are MVP-level.

---

## 10. Product and UX

The current product identity is unresolved. The senior team must choose:

A. RE:GRID — stage/lighting planner. Remove morphogenesis from MVP.
B. RE:MORPH — self-organizing visual instrument. Relegate stage/DMX/power to an advanced scene source or delete.
C. Two explicit products sharing a scene model.

Recommendation: this is a **business/product decision**, not a research conclusion. **B** fits the stated RE:MORPH philosophy; **A** fits the repository’s stage/DMX/power domain and tests. A split product is viable. Do not continue implicit C.

For RE:MORPH, the normal UX should be:

```text
Seed / Conditions
  Time · Entropy · Relation · Field · Simulation
  MUTATE
  Observe → Keep / Again / Branch / Revert
  Capture
```

Graph and Shader Lab belong in advanced/developer mode. The normal user should not author nodes.

---

## 11. MVP

CORE:

- one stage/world and one organism;
- one RD field with canonical channel, presets and GPU consumers;
- one geometry deformation, one material, one post/feedback;
- one art clock + fixed simulation step;
- MUTATE/KEEP/AGAIN/REVERT/BRANCH with trustworthy seed;
- one pointer owner;
- project-scoped runtime cleanup;
- save/export configuration; optional RD/post checkpoint;
- passthrough identity and geometry opacity invariants.

NEAR-TERM:

- two-species RD or spatial parameter maps;
- Shared Look as organism recipe;
- checkpoint capture;
- runtime export;
- audio→field;
- adaptive quality.

EXPERIMENTAL:

- Physarum/Lenia/NCA/differential growth;
- graph topology mutation;
- temporal branching;
- WebGPU compute.

DELETE / DEFER:

- legacy Three.js/R3F stack;
- plan/DMX/power/catalog from the RE:MORPH MVP; retain them only if RE:GRID is chosen or as a separate scene-source mode;
- 90-modifier catalog without visual verification;
- full mutation snapshots in localStorage;
- permanent giant node graph;
- non-explicit camera focus paths.

---

## 12. Technical debt order

1. Runtime decomposition and lifecycle/destruction.
2. Explicit invalidation + resource ownership.
3. Post pass mapping/history and RD channel contract.
4. Canonical time and fixed-step simulation.
5. One connection/field model.
6. Global input arbiter.
7. Product identity and deletion of non-MVP domains.
8. Persistence overhaul (IndexedDB/compact diffs).
9. Mutation determinism/lineage.
10. Performance budgets/hardware matrix.

---

## 13. Risks

Highest:

- pointer death;
- renderer magic refresh;
- temporal/project leakage;
- post pass index/history;
- shader/format/chunk failures;
- localStorage quota;
- product identity drift.

Mitigation: explicit ownership, invariants/tests, local fallback, budgets, deletion.

---

## 14. Final recommendation

Do not add another feature until the following are true:

- RE has one product identity.
- The legacy renderer is deleted.
- `RuntimeSession` owns and destroys every GPU resource.
- A single explicit invalidation model replaces signature repair.
- Post passthrough identity and failed-pass behavior are invariant.
- One clock drives art/simulation.
- Mutation seed can be replayed and lineage is compact/persistent safely.
- RD A/B channel semantics are resolved.
- Pointer ownership is global.
- Hardware budgets are measured.

Then, and only then, the most valuable next experiment is **two-species RD or spatial parameter maps on the existing field**, not a broader feature catalog.

The core principle:

> The graph is not the product. The simulation is not the product. The product is the loop of creating conditions, observing emergence, mutating, and keeping what appears. Everything else must earn its place around that loop.


---

## 15. Post-Critique Revisions

The independent critique identified five overreaches; this synthesis is revised accordingly.

1. **Identity is a decision, not a finding.** The repository supports both RE:GRID and RE:MORPH. The research does not choose the business. The senior team must choose, split, or explicitly support two modes. The MVP analysis is conditional on RE:MORPH.
2. **Do not delete plan/DMX/power without an audit.** They are core to RE:GRID. Separate them from the RE:MORPH runtime or keep them behind an advanced scene-source boundary.
3. **Resource ownership is unverified, not proven leaking.** `CameraFrame.destroy()` may clean child effects. The immediate requirement is explicit ownership/tests, not a claim of a confirmed leak.
4. **RD channel semantics come before new simulations.** Resolve A/B sampling and expose a channel contract. Then compare two-species RD against spatial parameter maps/anisotropy with visual tests. Do not add a second simulation family first.
5. **Mutation storage estimates are bounds, not measurements.** The architectural risk is full snapshots in localStorage; the exact MB depends on project size. Move lineage to a compact/IndexedDB/session model or prove the budget.

Additional gaps acknowledged: no hardware benchmark, no mobile/touch/accessibility audit, no licensing audit, no user research, no WebGL context-loss test, and no cost estimate for a runtime split. These belong in the next validation phase.

The core recommendation remains: **stabilize ownership, time, invalidation and one field contract before expanding the system.** The product decision remains human.

---

## 16. Recommendation Register

Compact form of the required recommendation schema. Primary reports contain full detail.

| # | Finding | Type | Evidence | Current | Proposed | Benefit | Cost | Risk | MVP |
| ---: | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Runtime owns too much and lacks explicit session ownership | FACT/INFERENCE | `PlayCanvasRuntime` fields/methods, destroy | Monolith; no RD/post destroy call | Extract pure libs, resource registry, RuntimeSession | Testability/lifecycle | L | Big-bang rewrite | CORE |
| 2 | Signature invalidation causes rebuilds/missed updates | FACT | `setProject`, `projectGeometrySignature`, `applyFog` | JSON signatures + rebuild | Explicit dirty events | Stability/perf | M | Missing event | CORE |
| 3 | RD A/B semantic mismatch | FACT | shader `.r`; sampleOutput `.g` | Two chemicals | Channel contract + selector | Correctness | S | Consumer break | CORE |
| 4 | Post failed-pass index mismatch | FACT | `createPasses` built vs stack | Shifted uniforms/history | Carry original instance per built pass | Correct bypass | S | Low | CORE |
| 5 | No canonical clock; RD frame-rate dependent | FACT | animTime/timeline/frame/dt | Split clocks | Tempus + fixed step | Reproducibility | M | Migration | CORE |
| 6 | Mutation seed not replayable; lineage storage bomb | FACT | MutationBar/record/localStorage | Random seed, full snapshots | Seed pin, compact ops/hash, IndexedDB/session | Trustworthy creation | M | Schema change | CORE |
| 7 | Pointer ownership distributed | FACT | runtime/plan/timeline/modal listeners | Local owners | Global InputArbiter | Kills LMB class | M | UI regressions | CORE |
| 8 | Two render stacks / two identities | FACT | dead Three files; README vs RE:MORPH | Implicit dual product | Human identity decision; delete dead stack | Coherence | M/L | Business decision | CORE |
| 9 | Field routing fragmented | FACT/INFERENCE | modulators/fieldLinks/post | Multiple models | One typed connection schema | Extensibility | M | Over-abstraction | NEAR-TERM |
| 10 | Two-species/spatial maps before new simulation | EXTERNAL/INFERENCE | R07, R18 | One Gray–Scott | Channel contract then evaluate | Novelty/cost | M | Parameter complexity | NEAR-TERM |
| 11 | Runtime embed | PROPOSAL | R16 | Single app bundle | Separate runtime entry | Deployment | L | Premature split | NEAR-TERM |
| 12 | Checkpoint capture | PROPOSAL | R09/R10/R14 | Config only | RD/post/camera/clock checkpoint | Exact state/branching | L | GPU readback/storage | NEAR-TERM |
