# RE:MORPH Research Package

Read-only investigation of the application at commit `6964523`. No application source, config, assets, tests or project data were modified. All writes are under `research/`.

## Start here

1. `20_EXECUTIVE_SYNTHESIS.md` — 10–15 page summary, revised after critique.
2. `01_ARCHITECTURE_CURRENT.md` — real runtime/store/module map.
3. `02_STATE_OWNERSHIP.md` — source-of-truth matrix.
4. `03_RENDER_PIPELINE.md` — scene→pixel path and resources.
5. `05_INPUT_POINTER_AUDIT.md` — pointer ownership/regression model.
6. `15_MVP_RECOMMENDATION.md` — proposed boundary.
7. `PRODUCT_IDENTITY.md` — RE:GRID vs RE:MORPH decision.
8. `CONTRADICTIONS.md` — unresolved human decisions.
9. `RED_TEAM.md` — attack on recommendations.
10. `21_SYNTHESIS_CRITIQUE.md` — independent critique.

## Strongest verified findings

- The active 3D path is one monolithic PlayCanvas runtime (~4.4k lines) over one Zustand project store (~1.3k lines).
- The legacy Three.js/R3F stage stack remains installed but is not imported by the app shell.
- Runtime state is not explicitly owned as a session; RD and post effect destruction are not called from `PlayCanvasRuntime.destroy()` (ownership unverified; likely incomplete).
- Project geometry signatures are incomplete/over-broad; shader/Look assignment can trigger a full world rebuild; transform edits use a fast path.
- Post passthrough identity is now tested (0% pixels, max delta 3) after pinning RGBA16F and fixing the history copy uniform.
- **RD shaders sample chemical A (`.r`), while CPU `sampleOutput` reads chemical B (`.g`).** This is a semantic inconsistency, not a cosmetic difference.
- Mutation has the right interaction primitive but seed replay, local perturbation, compact lineage and storage safety are incomplete.
- No canonical Tempus clock; `animTime` resets on rebuild and RD stepping is frame-rate dependent.
- No global pointer arbiter; recurring LMB failures are systemic, not isolated.

## Evidence classification

FACT = verified in current source.
INFERENCE = derived from source.
EXTERNAL RESEARCH = cited external docs/papers in investigator reports.
PROPOSAL = recommendation, not current behavior.

## Directory

```text
research/
  00_RESEARCH_TEAM.md
  01..21 primary reports
  PRODUCT_IDENTITY.md
  RED_TEAM.md
  OPPORTUNITIES.md
  CROSS_REVIEW.md
  CONTRADICTIONS.md
  investigators/
    R07_generative_systems.md
    R09_R10_mutation_time.md
    R18_competitive.md
    R01..R22 focused reports
```

## Scope warning

The research package does not implement fixes, does not judge business viability beyond evidence, and does not claim exact visual reproducibility. The next implementation phase should begin with the human decisions in `19_OPEN_QUESTIONS.md`.
