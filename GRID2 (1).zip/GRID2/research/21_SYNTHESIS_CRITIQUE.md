# 21 — Independent Synthesis Critique

The critic was not a primary synthesis author. This review attacks overconfidence, omitted evidence and scope creep.

## 1. What the synthesis gets right

- The runtime/project/GPU/UI state split is the central architectural problem.
- The monolith and missing explicit invalidation explain the recurring bug classes better than any single bug.
- The two product identities and two rendering stacks are real repository facts.
- Passthrough identity and geometry opacity fixes are verified and should be invariants.
- Mutation seed/lineage and Tempus are coupled; the synthesis correctly refuses to claim exact replay.

## 2. Overconfident claims

### “Choose RE:MORPH”
The repository’s README, catalog, DMX/power tests and domain model are substantial. The research prompt describes RE:MORPH, but that is not user/business evidence that the stage product should be abandoned. The synthesis should present a decision, not assume B. A split product or RE:GRID-first strategy remains viable.

### “Delete plan/DMX/power”
This is a proposal, not an evidence-backed conclusion. If RE:GRID is the commercial product, those are the core. The correct recommendation is to **separate** the products or choose one, not delete without a business decision.

### “RuntimeSession”
A clean concept, but no cost estimate or migration path. `PlayCanvasRuntime` is 4.4k lines with intertwined input/render/material/physics. Incremental extraction (pure libs, resource registry, input arbiter) is safer than a big-bang session rewrite.

### “Post destroy missing”
`PlayCanvasRuntime.destroy()` does not call `rd.destroy()` or `postEffect.destroy()` directly. However, `cameraFrame.destroy()` may destroy registered effects or PlayCanvas may release child resources. The claim “leak confirmed” is too strong; it should be “ownership unverified and likely incomplete.”

### “Two-species RD is next”
R07 identifies a semantic bug: shaders sample chemical A, CPU readback samples B. Adding a second species before resolving that would multiply ambiguity. Spatial parameter maps/anisotropy may be cheaper and more valuable. The synthesis should put **channel contract first**, then choose two-species vs spatial maps with visual tests.

### “Mutation lineage is 13 MB”
The estimate assumes a 104 KB project and 64 records with two full snapshots. That is a valid upper-bound risk, not a universal measurement. Some projects are smaller; some are much larger. The architectural point (unbounded snapshots in localStorage) stands.

### “90 modifiers should be deleted”
The catalog is large but some modules are genuinely implemented and tested. A visual audit should classify modules into core/near-term/experimental/lab; mass deletion without audit would destroy value.

## 3. Omitted evidence / dependencies

- Licensing and third-party notices for PlayCanvas/Three.js/fonts were not audited.
- No user research or analytics; product identity claims come from the brief, not observed users.
- No cost estimates for WebGPU/OffscreenCanvas/worker migration.
- No mobile/touch/accessibility audit; Russian UI/localization is not discussed.
- No security/deployment audit; the app is offline/local, which is a strength.
- No test of WebGL context loss or GPU resource exhaustion.
- No benchmark on real hardware; all performance statements are structural.
- No evaluation of whether the stage/lighting domain is the actual business moat.

## 4. Contradictions the synthesis should expose more clearly

- R09 recommends lineage out of `Project`; current product stores it in `Project` to survive reload.
- R07 recommends two-species RD; R15 warns against new simulation cost; R07 itself says spatial maps first.
- R18 says explicit feedback edge is the best contract; current feedback is a post shader + history copy, not a first-class edge.
- R20/MVP cuts plan/DMX; repository tests and README treat them as core.
- R19 wants compact sources; R08 wants one graph; both can be true only if graph is advanced projection, not primary UX.

## 5. Recommendations that need validation before implementation

- Measure current frame cost across hardware tiers before changing RD/post budgets.
- Verify `CameraFrame.destroy()` resource behavior in the installed PlayCanvas version.
- Prototype one explicit invalidation event and one resource registry before rewriting lifecycle.
- Prototype seed replay and compaction before changing mutation schema.
- Test two-species RD visual output and channel selector before committing to it.
- Ask the product owner to choose identity/business model.

## 6. What should be deleted from the synthesis

- Any implication that RE:MORPH is already the chosen product.
- Any claim that all dead code is harmless; the legacy stack has build/mental cost.
- Any recommendation to add simulations before field/channel/perf stabilization.

## Verdict

The synthesis is directionally correct and evidence-rich, but it should be revised to:

1. present identity as a decision with options;
2. distinguish unverified resource ownership from confirmed leaks;
3. put RD chemical/channel contract before new simulation features;
4. avoid mass deletion without catalog audit;
5. add hardware/licensing/mobile gaps;
6. qualify replay/persistence estimates.
