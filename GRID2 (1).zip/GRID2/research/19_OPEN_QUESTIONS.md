# 19 — Open Questions for Senior Human Decisions

## P0 — Identity

1. Is the product **RE:GRID** (stage planning), **RE:MORPH** (self-organizing visual instrument), or an umbrella with two explicit modes?
2. If RE:MORPH, what happens to plan editor, DMX, power, patch and equipment catalog? Hide behind advanced mode, keep as scene/world import, or delete?
3. Is the stage/rig domain a differentiator or legacy baggage?

## P0 — Runtime model

4. Should the PlayCanvas runtime become a long-lived scene service instead of being destroyed on every plan↔3D switch?
5. Should project switching reuse one runtime and reset explicit subsystems, rather than rebuild the world?
6. What is the lifecycle boundary for GPU resources: runtime session, project, or capture?

## P0 — State and reproducibility

7. Is mutation lineage part of the artwork or the workspace/session?
8. Do we need “same current visual state” (checkpoint) in the MVP, or only “same configuration”?
9. Is deterministic future evolution a product promise? If yes, RD/physics/post need fixed-step checkpoints and seed/PRNG state.
10. Which stateful systems may reset on project switch, and which must survive?

## P1 — Time

11. Should Tempus replace `animTime`, `timelineClock`, `frame.time` and RD time as the authoritative art clock?
12. Is reverse playback required? If yes, checkpoint-based stateful systems are mandatory.
13. Does Timeline become a view/transport over Tempus, or a separate performance timeline?
14. What does “loop” mean for stateful simulations: config loop, phase loop, or checkpoint loop?

## P1 — Graph/UX

15. Is the graph the primary authoring model or an advanced inspector over compact source concepts (Time/Entropy/Relation/Field/Simulation)?
16. Should automatic RD consumers appear as generated graph edges with stable IDs? (Recommendation: yes.)
17. Is Shader Lab a normal-user surface or developer mode?
18. How much parameter provenance should normal users see? “Why is this changing?” on demand vs always?
19. Should mutation expose one depth slider or separate amount/structure controls in advanced mode?

## P1 — Simulation

20. Is two-species Gray–Scott the next step, or should spatial parameter maps/anisotropy/flow come first?
21. Which second simulation family is justified: Physarum, Lenia, Gierer–Meinhardt, differential growth?
22. Is RD a **field** or a **material organism**? The current shader samples chemical A while CPU readback samples chemical B; which channel is canonical?
23. Do we support spatial parameter maps painted by the user? If yes, that is a new field layer and UI.

## P1 — Performance

24. What hardware classes are in scope (mobile, iGPU, discrete, installation GPU)?
25. What are acceptable frame budgets for RD, post, clones and TAA at each tier?
26. Is WebGL2 sufficient for MVP, or is WebGPU compute required for the simulation roadmap?
27. How many clones are allowed in the saveable organism vs runtime visual?

## P2 — Runtime / deployment

28. Is RE Runtime a real product deliverable in this cycle?
29. What is the artifact users share: project JSON, seed, checkpoint, video, or embed link?
30. Are external inputs (audio/MIDI/OSC/DMX) MVP, near-term, or installation-only?

## P2 — Shared Looks / ownership

31. Is a Shared Look the primary organism recipe? If so, do shader/modifier/field IDs need global uniqueness?
32. What happens when a Look is mutated while 10 objects use it? Confirm desired shared behavior.
33. Should `Make Unique` clone temporal state or only configuration?

## P2 — Safety / expression

34. What extreme values are allowed per system, and what is local fallback vs global clamp?
35. What is the policy for source-transparent materials vs accidental transparency?
36. What diagnostics must always be available in developer mode?
