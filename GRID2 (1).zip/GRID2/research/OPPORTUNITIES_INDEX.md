# Opportunity Index

See `18_OPPORTUNITIES.md` and `OPPORTUNITIES.md`.

Top opportunities:

1. resolve RD A/B channel contract;
2. two-species RD or spatial parameter maps;
3. Shared Look as organism recipe;
4. mutation seed/replay/compact lineage;
5. checkpoint capture;
6. runtime embed;
7. physics→field→material chain;
8. field-driven light/clone distributions.
