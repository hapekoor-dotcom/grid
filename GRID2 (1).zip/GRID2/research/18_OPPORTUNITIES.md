# 18 — Opportunities

Ranked by leverage, not novelty.

## 1. One field contract across simulations

**Finding:** RD is a field source with a texture, scalar/mask/gradient/normal/vector outputs and consumers. A second simulation can reuse this contract.
**Type:** INFERENCE / PROPOSAL.
**Benefit:** Add a new organism without a new routing system.
**Cost:** Define `FieldSource`, GPU texture ownership, output enum, checkpoint interface.
**Risk:** Premature abstraction before RD is excellent.
**MVP:** NEAR-TERM.

## 2. RD as a “material organism” layer

RD already drives emission, opacity, base color, roughness, metallic and displacement. A small set of **looks** that combine these into recognizable organisms (coral, chrome, skin, smoke, membrane) is higher value than more knobs.
**Benefit:** User sees emergence, not parameter engineering.
**MVP:** CORE.

## 3. Mutation as the primary discovery loop

The current MutationBar is a seed of a strong interaction. Make MUTATE a first-class mode: one large gesture, no parameter explanation, KEEP/AGAIN/BRANCH/REVERT, compact lineage.
**Benefit:** Differentiation from node editors.
**Risk:** Mutation without perceptual quality control produces noise.
**MVP:** CORE.

## 4. Shared Look as an organism recipe

A Look can own material + modifier stack + shader + RD consumers. Make it the reusable “species” that can be applied to many objects and mutated once.
**Benefit:** Fits “10 objects share one organism” and avoids per-object copy drift.
**Cost:** Fix ownership/ID leakage, runtime look state, mutation scope.
**MVP:** CORE.

## 5. Temporal checkpointing

Capture RD texture, post history, camera, clock phase and mutation seed into a checkpoint. Enables “same current visual state” and branchable evolution.
**Benefit:** Reproducibility and performance/live installation.
**Cost:** GPU readback/encode, state schema, asset packaging.
**MVP:** NEAR-TERM.

## 6. Audio → field, not audio → scale

Use FFT/onset to inject chemicals, advect a field, or modulate simulation parameters; then use the resulting field for geometry/material/post. This creates systemic audio reactivity rather than beat-scale cliché.
**MVP:** EXPERIMENTAL / NEAR-TERM.

## 7. Physics → RD → material

Collision injection already exists. Make it a visible causal chain: impacts seed the organism, the organism changes material and geometry, post feedback accumulates. This is a strong installation narrative.
**MVP:** NEAR-TERM.

## 8. Multi-species RD in the unused B/A channels

RGBA16F has unused channels. Two coupled species could create territories/boundaries at low extra bandwidth.
**Benefit:** High novelty per cost.
**Risk:** Consumer channel/output model.
**MVP:** EXPERIMENTAL.

## 9. Web runtime as “organism embed”

Export a seed + config + checkpoint + shader/asset package for a website/installation. The editor becomes the incubator; the runtime is the organism.
**Benefit:** Product category and deployment story.
**Cost:** runtime/editor split, asset packaging, quality profiles.
**MVP:** NEAR-TERM.

## 10. Field-driven light

RD/material currently drives objects; light intensity/color/beam could consume the same field. This connects stage lighting and organism visuals without keeping the whole DMX product.
**MVP:** EXPERIMENTAL.

## 11. Clone distributions as organism morphology

Radial/grid/spiral/sphere clones exist. Let a field modulate clone scale/rotation/position and use mutation to explore distributions. This is a direct “growth” primitive.
**MVP:** NEAR-TERM.

## 12. Capture as a first-class output

A screenshot/video/checkpoint bundle with seed, mutation lineage and config. This is the artifact users share, not a project file.
**MVP:** CORE for product identity.
