# Cross Review

This review checks specialist reports for contradictions, missed dependencies and unsupported claims.

## Consensus

- RD is the strongest implemented organism primitive.
- One shared field contract is valuable.
- Current state ownership is fragmented between project, runtime, GPU and UI.
- The runtime lifecycle/resource cleanup is weak.
- Two product identities and two rendering stacks coexist.
- Pointer ownership is too distributed.
- Mutation is directionally strong but not yet trustworthy.
- The post/CameraFrame surface has improved (passthrough identity) but remains fragile.

## Contradictions / conflicts

1. **Persistence of mutation lineage**: R09 recommends moving lineage out of `Project` to a session/workspace store to avoid quota; current implementation persists in `Project` for reload survival. Human decision: is lineage part of the artwork or the workspace?
2. **MVP scope**: R20/MVP recommends cutting plan/DMX/power; existing tests and README make them the product. Human decision required.
3. **Graph prominence**: R19 recommends hidden/contextual graph; R08 recommends one compiled graph model; current `ModifierGraphDialog` exposes a structured graph. They agree on one model, disagree on primary UX.
4. **Additional simulations**: R07 encourages one contrasting simulation; R15 performance warns against expanding before RD/perf budgets. Agreement: not MVP.
5. **RD scalar readback**: R07 accepts cached 3×3 readback for global modulation; R15/R06 warn it is still a synchronous GPU stall and must be opt-in/throttled. Agreement: keep only for global values, never spatial.
6. **Runtime split**: R11 says separate runtime; R01 warns `PlayCanvasRuntime` is too coupled to split cheaply. Agreement: split after extracting pure libs, not by hiding UI.
7. **Mutation depth**: R09 wants near-current/local mutation; current engine samples full range. R20 sees mutation as core. Need implementation change before identity claim.
8. **Shader Lab**: R04 supports advanced editing; R19 warns it exposes complexity. Could be advanced mode only.

## Missing dependencies found in review

- No `rd.destroy()` / `postEffect.destroy()` call in runtime destroy; resource leakage.
- `postEffect.createPasses` uses stack index after dropping failed passes.
- `projectGeometrySignature` does not exclude `shaders`/`lookId`; shader/Look assignment can rebuild world.
- `localStorage` autosave serializes whole workspace after every project change; mutation snapshots amplify quota risk.
- `reactionField` is a module singleton; multiple runtimes/projects can conflict.
- `Project.mutation` is not read by any history UI.
- Dead Three.js stack remains in dependencies and build.
- Post passthrough identity test is pixel-based; numeric HDR identity still missing.

## Unsupported claims to reject

- “Same seed reproduces the same visual state” — false without temporal checkpoints and deterministic fixed step.
- “Graph is the actual dataflow for all systems” — false; post modulation and mutation bypass parts of it.
- “200 clones are GPU-instanced” — false; they are runtime entities.
- “Runtime/editor split exists” — false; one app bundle and shared state.
- “RD is stable at arbitrary resolution/iterations” — bounded but untested on hardware.

## Review verdict

The direction is coherent, but the repository is pre-MVP: two products, two renderers, multiple routing models, incomplete state ownership. The next phase must delete and stabilize before adding simulations/features.
