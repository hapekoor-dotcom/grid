# Opportunity Team Report

Ranked by leverage and coherence with RE's loop.

| Rank | Opportunity | Why | MVP |
| ---: | --- | --- | --- |
| 1 | RD channel contract + two-species RD or spatial parameter maps | Highest novelty per GPU line; existing RGBA16F has unused channels; current A/B semantics are inconsistent. | NEAR-TERM |
| 2 | Shared Look as reusable organism recipe | One mutation controls 10 objects; fits “species”/Look identity. | CORE |
| 3 | Mutation as primary discovery loop | Differentiates from node editors; current bar is a strong seed. | CORE |
| 4 | Checkpoint capture (RD/post/camera/clock) | Enables exact visual state and branchable evolution. | NEAR-TERM |
| 5 | Web runtime embed (“organism”) | Converts editor into incubator for sites/installations. | NEAR-TERM |
| 6 | Physics → RD → material visible chain | Existing collision injection can become a narrative causal system. | NEAR-TERM |
| 7 | Audio → field (not audio → scale) | Systemic reactivity vs cliché. | EXPERIMENTAL |
| 8 | Field-driven light | Connects stage lighting to organism field without full DMX product. | EXPERIMENTAL |
| 9 | Clone distribution × field | Field controls clone scale/rotation/position; direct morphology. | NEAR-TERM |
| 10 | Capture artifact (seed + lineage + checkpoint + video) | Shareable output beyond project JSON. | CORE |

## Highest-leverage combination

`Shared Look + Mutation + Checkpoint Capture + Runtime Embed` forms a coherent product: create one organism, mutate it across a population of objects, capture the state, embed it. This is more differentiated than adding more modifiers or simulations.

## Avoid

- Multi-simulation marketplace before one organism is excellent.
- A permanent node graph as the product surface.
- Feature parity with TouchDesigner/Houdini.
- Generic 3D editor features unrelated to emergence.
