# Research, reconstruction and browser workflows

Use each dependency for the task it serves. Reuse existing evidence and authorization; do not repeat setup or ask for decisions already supplied. A missing tool limits the corresponding check, not unrelated authorized work.

## Agent Reach: public content access

Read `agent-reach` through the skill catalog or `~/.agents/skills/agent-reach/SKILL.md`. Prefer existing search, browser and connected-source tools. When they fail or omit needed page bodies, comments or subtitles, use Agent Reach's matching read-only channel. Discover supported actions with `agent-reach channels` before guessing commands.

Report the content actually retrieved: snippets, full text, comments and subtitles are different evidence. Keep public results if a platform needs login. Adding an optional channel, copying a browser session or accessing an account requires scope beyond identifying a URL; do not do it automatically. Preserve the upstream handling of login, verification and rate-limit responses. Never post or send messages through a reading workflow.

Source: [Panniantong/Agent-Reach](https://github.com/Panniantong/Agent-Reach).

## Replica: reconstruct the requested behavior

Resolve the `replica-*` skills through the catalog or sibling skill directories. For requested recreation, start with `replica-recon` and the supplied scope. Record sources, screens, flows, required states and a feature matrix. Apply `replica-architect`, `replica-design`, `replica-build`, `replica-backend`, `replica-test` and `replica-diff` when their stages are needed. `replica-entrepreneur`, `replica-brand`, `replica-launch` and `replica-deploy` apply only when that business, branding, launch or deployment work is requested.

Use public documentation, screenshots and observed behavior for Replica's reconstruction. Do not read bundles, decompile targets or copy private endpoints within its clean-room workflow. A separately requested REA investigation must retain its own evidence provenance; do not silently mix those findings into a clean-room claim. Reference screenshots remain references rather than shipped assets.

Preserve the approved project name, licensed fonts, tokens, compact Maksim type and existing stack. Replica's generic font scales, Tailwind mapping, rebranding and landing-page outline are starting points where no approved choice exists. They do not require replacing Lay Grotesk, adding a three-step section, inventing pricing or writing an FAQ without evidence. Keep `$text`, unslop and antislop active. A feature or layout comparison does not establish exact visual fidelity; report what was measured.

Source: [Jakeschincariol/replica-skill](https://github.com/Jakeschincariol/replica-skill).

## Context7: verify implementation APIs

Read the installed `context7-mcp` skill from the Context7 plugin. Use `resolve-library-id` to select the official library, then `query-docs` for the specific concept. Match the version installed in the project, rather than assuming current documentation applies to older code. Resolve an identified library once and reuse it for focused queries. Do not send credentials or unrelated private project data in queries.

If the relevant documentation is unavailable, authentication is required or a limit is reached, state the limitation and consult the library's official documentation. Do not claim Context7 verified a detail it did not return. Skip it for changes that do not depend on an API or library behavior.

Source: [Context7](https://context7.com/).

## Chrome DevTools: verify the running interface

Read `chrome-devtools` before using the `chrome-devtools` MCP server. Use its current tool list, `list_pages` and returned page IDs. Inspect a fresh snapshot before acting on element IDs. Use screenshots for visual judgment, page inspection for structure, console and network evidence for failures, and measured traces for performance questions.

Prefer the configured isolated browser. Connect to an existing user session only when the task requires it, preserve unsaved work and keep interactions inside the authorized task. Use `a11y-debugging`, `cookie-debugging`, `debug-optimize-lcp` or `memory-leak-debugging` when those issues arise; use `troubleshooting` for connection failures. The `chrome-devtools-cli` skill is the command-line alternative when MCP is unavailable. Resolve all these skills from the installed catalog or sibling directories.

Verify the changed UI at relevant viewport sizes and exercise affected interactions. Record what ran and what remains unverified. Keep telemetry and sending trace URLs to external field-data services disabled unless requested. A browser result establishes the tested state only; it does not establish deployment or field performance. Use this evidence for antislop's Delivery Gate rather than duplicating the same checks.

Source: [ChromeDevTools/chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp).
