---
name: maksim
description: "Use for $maksim, or when building or editing websites in Maksim’s portfolio style: monochrome surfaces, Lay Grotesk typography, precise spacing and restrained motion. Applies to personal and client websites; not unrelated writing or backend work."
metadata:
  short-description: "Maksim design with required research, build and review tools"
---

# Maksim

Maksim Orel’s approved portfolio is the master design reference. Read [the complete master brief](references/website-brief.md) before applying the style. It replaces the earlier Ollama / SF Pro Rounded and brandplur defaults. The brief is bundled; do not ask the user to attach it again.

## Scope and priorities

Current user instructions and an existing project’s approved identity take precedence. For new websites in Maksim’s style, use the master’s neutral palette, Lay Grotesk typography, compact hierarchy, thin borders and deliberate spacing. Transfer the visual principles; do not copy personal biography, portfolio projects or the animated hero into unrelated client products automatically.

The master is the approved local portfolio described in the brief. Its production address is https://maksim.plurrr.ee/; that deployment may lag behind the working version. Do not treat a stale live page as an instruction to revert approved work. Ravi Klaassens, Jose Ocando and Jonas Brinkhoff are secondary references, consulted when a specific question calls for them. Reuse observations already verified in the conversation.

Invoking this skill does not authorize replacing finished assets, scenes, architecture or content wholesale. Preserve everything outside the requested scope. Retain the existing stack and adapt the design to it.

## Required Caveman workflow

On every `$maksim` invocation, automatically read and apply **caveman:caveman** (`$caveman`) before starting work. This dependency is mandatory unless the user explicitly disables it or requests normal mode. Resolve it through the installed skill catalog or the enabled Caveman plugin's current directory; do not pin a versioned cache path. If it cannot be read, name the missing dependency and do not claim Caveman was applied.

Use Caveman for concise chat responses and task coordination. Preserve the user's language, technical substance, facts, qualifications and required progress updates. Clarity takes priority over compression. Customer-facing UI copy, saved documents, code comments and other reusable artifacts keep normal prose and the required `$text` review. Caveman does not replace unslop, antislop or verification. Load other Caveman skills only when their task scope applies.

## Required reference investigation with REA

When a `$maksim` task depends on understanding a supplied external website or app, a shipped JavaScript bundle or package, or behavior not established by available source, automatically read and apply **reverse-engineer-anything (REA)**. REA is mandatory for these investigations. Resolve it through the installed skill catalog or the Codex personal skill directory at `~/.agents/skills/reverse-engineer-anything/SKILL.md`. Use normal repository tools for ordinary work with complete source; do not run REA diagnostics for unrelated UI or copy edits.

Choose the tools from the actual target and the connected server's available schemas. Read only the relevant REA references: runtime observation for browser interactions, JavaScript applications for bundles, and evidence workflows for comparisons. Start with a focused question and summary results; reuse collected evidence. Distinguish observed behavior, static findings, inference and unknowns. Use the findings to implement the requested behavior within the approved project identity; they do not authorize copying an entire product or replacing the Maksim design.

Runtime actions must stay within the requested target and task. Preserve unsaved work in existing tabs; prefer an isolated browser session when a scenario needs navigation. If tools or a required analysis engine are unavailable, report the specific limitation and use supported work without claiming the missing analysis ran. Resolve registration through its actual installation owner; do not create duplicate REA servers or install unrelated analysis engines.

Source: [morluto/rea](https://github.com/morluto/rea), MIT. REA supplies investigation evidence; unslop, antislop and `$text` retain their required roles below.

## Required research, reconstruction and browser tools

Before the corresponding work, read [the tool workflows](references/tool-workflows.md) and apply these dependencies:

- **Agent Reach** for public source content that the available search, browser or connector tools cannot retrieve completely.
- **Replica** for requested reconstruction of an app, screen or user flow from external references. Load the stages the task needs.
- **Context7** for library and framework APIs, configuration and version-dependent implementation decisions.
- **Chrome DevTools MCP** for running, inspecting and verifying changed web interfaces, including browser interactions, console errors and relevant layout checks.

These tools are mandatory within their stated scope. Load their installed skills and actual tool schemas; report unavailable access or checks without claiming they ran. They supplement the required Caveman, REA, unslop, antislop and `$text` workflows. Ordinary copy edits do not require a full investigation or reconstruction pipeline.

Replica reconstructs from public documentation and observed behavior. Keep that workflow separate from REA investigations of source, bundles or binaries; never label source-derived work as a clean-room reconstruction. Current user instructions, approved identity and the existing stack retain priority over generic templates in these skills.

## Required UI foundation

For UI creation, edits and reviews, automatically read and apply **unslop by Damir Sokolovsky** as the mandatory UI foundation, together with **antislop by miqdadbadjuber** as the additional quality filter. Maksim supplies the visual identity. These dependencies are part of this workflow, not optional suggestions.

Resolve `unslop` through the installed skill catalog or [the sibling skill](../unslop/SKILL.md). Read its audit signs and tokens, then the references needed for the requested passes. Resolve the enabled `antislop@anti-slop` plugin through the catalog or its current installed directory; do not pin a versioned cache path. Load its `antislop`, `antislop-ui` and `antislop-human` skills for UI work, `antislop-layoutmobile` for responsive layout, `antislop-copywriting` when changing copy and `antislop-code` when changing comments. Load only the relevant modules. If a required dependency cannot be read, name it and report the review as incomplete.

For `$maksim` implementation tasks, apply antislop while working (`during`) and before delivery. An audit-only request stays read-only; an explicit user choice of `after` uses that mode. This workflow choice is local to `$maksim`; do not write a global antislop mode preference. Current user instructions and existing authorization take precedence over the dependencies' default questions.

Use the master brief or the project's approved identity as the supplied design direction. It satisfies antislop's direction requirement without a new `DESIGN.md`. Derive unslop's five direction lines and antislop's Design Read from that identity; do not reopen settled choices. Ask only when a material design decision remains unresolved. Audit the actual screen, choose the change scope from the findings, then apply the relevant unslop passes in order: spacing, color, icons, copy, type, layout, details, visuals and motion.

Keep the master's neutral palette, licensed Lay Grotesk, compact type scale and deliberate spacing. The approved 21px hero, centered short introduction, 12px works container and animated hero remain intentional choices. Generic rules about accent colors, large headlines, generated scenes or removing animation do not authorize replacing them. Use unslop's tokens where the project has no approved value. Preserve features, section order, assets and the existing stack within the requested scope. Sample data must be identified as sample data; never turn it into a real product claim.

Before delivery, run unslop's checklist and antislop's applicable Delivery Gate checks against the changed UI. Verify rendering, responsive behavior, keyboard access and affected interactions. Report evidence, approved exceptions and anything unverified; never claim a pass from code inspection alone when runtime behavior is required. Keep reports outside the interface.

Sources: [Damir's unslop](https://github.com/heydamir/unslop/tree/main/skills/unslop), CC BY 4.0; [miqdadbadjuber's anti-slop](https://github.com/miqdadbadjuber/anti-slop), MIT. Retain upstream attribution and licenses when copying or adapting their material.

## Required typography workflow

When choosing, styling or reviewing interface text, automatically read and apply **uisize** through [the sibling skill](../uisize/SKILL.md) or the installed skill catalog. This dependency is mandatory for font selection, text sizes, line heights, line lengths, tracking, hierarchy and responsive readability. Apply the user's supplied typography guidance through that skill before choosing values and again when verifying the rendered result. If it cannot be read, name the missing dependency and report the typography review as incomplete.

Use its numerical ranges as starting points where approved values are absent. Preserve the master’s licensed Lay Grotesk, approved 21px hero and project identity; evaluate actual legibility before proposing changes. `$uisize` supplements unslop and antislop and does not replace the required `$text` workflow for wording. A prose-only edit does not require an unrelated typography redesign.

## Required writing workflow

Automatically use the available **text** skill when writing or revising prose, including UI labels, page copy, metadata and explanations. Read its instructions and active references; complete humanize, the nine-category ai-check and factual review. Scale the report to the text and keep it outside the customer-facing interface.

Resolve `$text` through the installed skill catalog, or the sibling `text/SKILL.md`. If it cannot be read, explain the missing dependency and ask for `text-skill.zip`; do not claim its full review was completed. Do not silently install or rewrite that dependency.

Unslop's copy pass and antislop-copywriting supplement `$text`; they do not replace its humanize, nine-category ai-check or factual review. Apply their generic wording rules in the context of the user's approved voice.

## Implementation boundaries

Confirm actual font files and web-use rights; the master’s local WOFF2 is not a license for every new project. Use a disclosed sans-serif fallback when unavailable. Desktop layout accounts for height as well as width. Preserve natural content flow, keyboard access, reduced motion and the static fallback.

Use tools and services required by the task. Do not enable analytics, sound, sensors or paid services merely because a reference uses them. Keep requested UI changes focused and verify their observable behavior. Report actual checks and limitations. Publishing is a separate action requiring authorization.
