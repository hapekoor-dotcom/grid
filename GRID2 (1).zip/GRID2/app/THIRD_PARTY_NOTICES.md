# Third-party notices

RE:GRID bundles the following open-source packages. Their licenses remain with their authors.

- React, React DOM — MIT
- Three.js — MIT
- @react-three/fiber, @react-three/drei, @react-three/postprocessing — MIT
- postprocessing — MIT
- Zustand — MIT
- lucide-react — ISC
- Vite, Vitest, Playwright — MIT / Apache-2.0 (Playwright)
- IBM Plex Sans, IBM Plex Mono — SIL Open Font License 1.1
  Bundled via Fontsource; the font files retain their license terms.

Catalog evidence is derived from the saved Rig Grid research set. Manufacturer documentation URLs
and verification statuses are preserved per device in `src/data/catalog.json`; they are not relicensed
as RE:GRID claims.
