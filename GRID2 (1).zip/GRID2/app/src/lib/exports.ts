import type { Project, SceneObject } from '../types/project';
import { getDevice, verificationLabel } from './catalog';
import { computeDmxPatch } from './dmx';
import { computePower } from './power';
import { effectiveWatts, objectDims } from './objects';
import { formatDate } from './id';

function csvEscape(value: unknown): string {
  const text = value === null || value === undefined ? '' : String(value);
  if (/[";\n\r]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

export function toCsv(rows: (string | number | null | undefined)[][]): string {
  return `\ufeff${rows.map((row) => row.map(csvEscape).join(';')).join('\r\n')}`;
}

export function downloadText(content: string, filename: string, mime = 'text/plain;charset=utf-8'): void {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function safeName(name: string): string {
  return name.trim().replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').slice(0, 60) || 'regrid';
}

export function exportEquipmentCsv(project: Project): void {
  const patch = computeDmxPatch(project);
  const rows: (string | number | null)[][] = [
    ['Object', 'Model', 'Manufacturer', 'Category', 'Type', 'DMX mode', 'Channels', 'Universe', 'Address', 'Start–end', 'Power, W', 'Power basis', 'Data check', 'X, m', 'Z, m', 'Height, m', 'Rotation', 'Note'],
  ];
  for (const object of [...project.objects].sort((a, b) => a.name.localeCompare(b.name, 'ru'))) {
    if (!object.deviceId || object.type === 'room') continue;
    const device = getDevice(object.deviceId);
    const dmx = patch.rows.find((row) => row.objectId === object.id);
    const status = device ? verificationLabel(device) : { label: 'Model not found' };
    const dims = objectDims(object);
    rows.push([
      object.name,
      device?.name || object.deviceId,
      device?.brand || '',
      device?.category || '',
      device?.kind || object.type,
      dmx?.mode?.label || '—',
      dmx?.channels ?? '',
      dmx?.universe ?? '',
      dmx?.address ?? '',
      dmx?.address && dmx?.end ? `${dmx.address}–${dmx.end}` : '',
      effectiveWatts(object) ?? '',
      device?.wattsBasis || '',
      status.label,
      object.position.x.toFixed(2),
      object.position.z.toFixed(2),
      object.elevation.toFixed(2),
      object.rotation,
      object.notes,
    ]);
    void dims;
  }
  downloadText(toCsv(rows), `${safeName(project.name)}-equipment.csv`, 'text/csv;charset=utf-8');
}

export function exportDmxCsv(project: Project): void {
  const patch = computeDmxPatch(project);
  const rows: (string | number | null)[][] = [
    ['Fixture', 'Model', 'Mode', 'Channels', 'Universe', 'Address', 'End', 'Manual address', 'Source', 'Status'],
  ];
  for (const row of patch.rows) {
    rows.push([
      row.name,
      row.device.name,
      row.mode?.label || '—',
      row.channels ?? '',
      row.universe ?? '',
      row.address ?? '',
      row.end ?? '',
      row.manual ? 'yes' : 'no',
      row.root?.sourceName || 'no line',
      row.status === 'patched' ? 'patched' : row.status === 'unpatched' ? 'unpatched' : 'error',
    ]);
  }
  downloadText(toCsv(rows), `${safeName(project.name)}-dmx-patch.csv`, 'text/csv;charset=utf-8');
}

export function exportPowerCsv(project: Project): void {
  const power = computePower(project);
  const rows: (string | number | null)[][] = [
    ['Fixture', 'Power, W', 'Basis', 'Source', 'Phase', 'Circuit', 'Status'],
  ];
  for (const row of power.rows) {
    rows.push([
      row.name,
      row.watts ?? '',
      row.wattsBasis,
      row.chain?.sourceName || (row.internalBattery ? 'internal battery' : 'no power'),
      row.chain?.phase || '',
      row.chain ? row.chain.chain.map((id) => project.objects.find((object) => object.id === id)?.name || id).join(' → ') : '',
      row.status,
    ]);
  }
  rows.push([]);
  rows.push(['Source', 'Phase', 'Load, W', 'Budget, W', 'Unknown, qty', 'Circuit']);
  for (const phase of power.phases) {
    rows.push([phase.sourceName, phase.phase, Math.round(phase.watts), phase.limit ?? '', phase.unknownCount, phase.circuitId]);
  }
  rows.push([]);
  rows.push(['Total known, W', Math.round(power.totalWatts)]);
  rows.push(['Unknown load, fixtures', power.unknownCount]);
  rows.push(['Generated', formatDate(new Date().toISOString())]);
  downloadText(toCsv(rows), `${safeName(project.name)}-power.csv`, 'text/csv;charset=utf-8');
}

export function exportConnectionsCsv(project: Project): void {
  const rows: (string | number | null)[][] = [
    ['Type', 'From object', 'Output', 'To object', 'Input', 'Note'],
  ];
  for (const connection of project.connections) {
    const from = project.objects.find((object) => object.id === connection.from);
    const to = project.objects.find((object) => object.id === connection.to);
    rows.push([connection.type, from?.name || connection.from, connection.fromPort, to?.name || connection.to, connection.toPort, connection.note]);
  }
  downloadText(toCsv(rows), `${safeName(project.name)}-connections.csv`, 'text/csv;charset=utf-8');
}

export function exportProjectReport(project: Project): void {
  const patch = computeDmxPatch(project);
  const power = computePower(project);
  const equipment = new Map<string, { device: string; count: number; watts: number | null }>();
  for (const object of project.objects) {
    if (!object.deviceId || object.type === 'room') continue;
    const device = getDevice(object.deviceId);
    const key = object.deviceId;
    const entry = equipment.get(key) || { device: device?.name || object.deviceId, count: 0, watts: effectiveWatts(object) };
    entry.count += 1;
    equipment.set(key, entry);
  }
  const lines = [
    `RE:GRID — technical report`,
    `Project: ${project.name}`,
    `Updated: ${formatDate(project.updatedAt)}`,
    '',
    `Objects: ${project.objects.length}`,
    `Connections: ${project.connections.length}`,
    `DMX: ${patch.patchedCount} fixtures patched, ${patch.universes.length} Universes`,
    `Power: ${Math.round(power.totalWatts)} W confirmed load, ${power.unknownCount} fixtures with unknown power`,
    '',
    'Equipment:',
    ...[...equipment.values()].sort((a, b) => a.device.localeCompare(b.device, 'ru')).map((entry) => `  ${entry.count} × ${entry.device}${entry.watts !== null ? ` · ${entry.watts} W` : ' · power unverified'}`),
    '',
    'DMX Patch:',
    ...patch.rows.map((row) => `  ${row.name}: ${row.root ? `U${row.universe} ${row.address ?? '—'}–${row.end ?? '—'}` : 'no line'} · ${row.mode?.label || 'mode not selected'}`),
    '',
    'Power by phase:',
    ...power.phases.map((phase) => `  ${phase.sourceName} / ${phase.phase}: ${Math.round(phase.watts)} W${phase.limit !== null ? ` of ${phase.limit} W` : ' · budget not set'}`),
    '',
    'Important: calculations are based on the data entered and do not replace an electrician\'s review, structural load calculations, or certification. Virtual light is not transmitted to equipment.',
  ];
  downloadText(lines.join('\n'), `${safeName(project.name)}-report.txt`, 'text/plain;charset=utf-8');
}

export function sceneObjectsForExport(project: Project): SceneObject[] {
  return project.objects.filter((object) => object.visible);
}

export function exportSceneJson(project: Project): void {
  const payload = {
    application: 'RE:GRID',
    format: 'scene-json',
    version: 1,
    units: 'meters',
    coordinateSystem: { up: 'Y', forward: 'Z', note: 'x — right, z — from audience to stage, y — height' },
    project: { id: project.id, name: project.name, updatedAt: project.updatedAt },
    objects: project.objects.map((object) => ({
      id: object.id,
      name: object.name,
      type: object.type,
      deviceId: object.deviceId,
      transform: {
        position: { x: object.position.x, y: object.elevation, z: object.position.z },
        rotationY: (-object.rotation * Math.PI) / 180,
        size: object.size || null,
      },
      mount: object.mount,
      dmx: object.fixture ? {
        modeId: object.fixture.modeId,
        universe: object.fixture.universe,
        address: object.fixture.address,
        manualAddress: object.fixture.manualAddress,
        customChannels: object.fixture.customChannels,
      } : null,
      light: object.light,
    })),
    connections: project.connections.map((connection) => ({
      id: connection.id,
      type: connection.type,
      from: { objectId: connection.from, port: connection.fromPort },
      to: { objectId: connection.to, port: connection.toPort },
    })),
    lighting: {
      groups: project.lighting.groups,
      presets: project.lighting.presets,
      master: project.lighting.master,
      haze: project.lighting.haze,
    },
    note: 'Geometry and connections in meters. Lighting is a virtual state, not a DMX stream.',
  };
  downloadText(JSON.stringify(payload, null, 2), `${safeName(project.name)}-scene.json`, 'application/json');
}

const PLAN_EXPORT_TOKENS = `
:root{
--bg-0:#0d0e10;--bg-1:#111214;--text-1:#cfcbc3;--text-2:#a7a39b;--text-3:#7f8587;--text-4:#5e676f;
--accent:#e8b40a;--line-2:rgba(207,203,195,0.11);--line-3:rgba(207,203,195,0.18);
--power:#e58a32;--dmx:#7fb26a;--ethernet:#7e94a3;--video:#c06a3c;--usb:#b8b2a7;
}
.plan-object [stroke] { vector-effect: non-scaling-stroke; }
`;

export function exportPlanSvg(project: Project): boolean {
  const source = document.querySelector<SVGSVGElement>('[data-plan-svg]');
  if (!source) return false;
  const clone = source.cloneNode(true) as SVGSVGElement;
  const removeSelectors = [
    '[data-ui="ports"]', '[data-ui="selection"]', '[data-ui="marquee"]', '[data-ui="snap"]',
    '[data-ui="draft"]', '[data-ui="cable-preview"]', '[data-ui="cable-actions"]', '[data-ui="handle"]',
    '[data-ui="guides"]', '[data-ui="cable-dot"]', '[data-ui="background"]',
  ];
  for (const selector of removeSelectors) {
    clone.querySelectorAll(selector).forEach((element) => element.remove());
  }
  clone.querySelectorAll('[tabindex]').forEach((element) => element.removeAttribute('tabindex'));
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
  const width = clone.getAttribute('width') || '1600';
  const height = clone.getAttribute('height') || '900';
  const style = document.createElementNS('http://www.w3.org/2000/svg', 'style');
  style.textContent = PLAN_EXPORT_TOKENS;
  const background = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  background.setAttribute('x', '0');
  background.setAttribute('y', '0');
  background.setAttribute('width', width);
  background.setAttribute('height', height);
  background.setAttribute('fill', '#0d0e10');
  const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
  title.textContent = `${project.name} — RE:GRID Plan`;
  clone.insertBefore(background, clone.firstChild);
  clone.insertBefore(style, background.nextSibling);
  clone.insertBefore(title, clone.firstChild);
  const markup = `<?xml version="1.0" encoding="UTF-8"?>\n${new XMLSerializer().serializeToString(clone)}`;
  downloadText(markup, `${safeName(project.name)}-plan.svg`, 'image/svg+xml;charset=utf-8');
  return true;
}

export function download3dPng(project: Project): boolean {
  const canvas = document.querySelector<HTMLCanvasElement>('.viewport3d canvas');
  if (!canvas) return false;
  canvas.toBlob((blob) => {
    if (blob) downloadBlob(blob, `${safeName(project.name)}-3d.png`);
  }, 'image/png');
  return true;
}
