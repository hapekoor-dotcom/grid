import type { MaterialMapChannel, MaterialMapKind, MaterialTextureLayer, ObjectMaterial, SceneObject } from '../types/project';

export interface MaterialMapDefinition {
  kind: MaterialMapKind;
  label: string;
  property: string;
  uvProperty: string;
  tilingProperty: string;
  offsetProperty: string;
  rotationProperty: string;
  channelProperty?: string;
  channels?: MaterialMapChannel[];
  srgb?: boolean;
  defaultChannel?: MaterialMapChannel;
}

export const MATERIAL_MAP_DEFINITIONS: MaterialMapDefinition[] = [
  { kind: 'baseColor', label: 'Base Color Map', property: 'diffuseMap', uvProperty: 'diffuseMapUv', tilingProperty: 'diffuseMapTiling', offsetProperty: 'diffuseMapOffset', rotationProperty: 'diffuseMapRotation', channelProperty: 'diffuseMapChannel', channels: ['rgb', 'r', 'g', 'b', 'a'], srgb: true, defaultChannel: 'rgb' },
  { kind: 'metalness', label: 'Metalness Map', property: 'metalnessMap', uvProperty: 'metalnessMapUv', tilingProperty: 'metalnessMapTiling', offsetProperty: 'metalnessMapOffset', rotationProperty: 'metalnessMapRotation', channelProperty: 'metalnessMapChannel', channels: ['r', 'g', 'b', 'a'], defaultChannel: 'r' },
  { kind: 'roughness', label: 'Roughness / Gloss Map', property: 'glossMap', uvProperty: 'glossMapUv', tilingProperty: 'glossMapTiling', offsetProperty: 'glossMapOffset', rotationProperty: 'glossMapRotation', channelProperty: 'glossMapChannel', channels: ['r', 'g', 'b', 'a'], defaultChannel: 'r' },
  { kind: 'normal', label: 'Normal Map', property: 'normalMap', uvProperty: 'normalMapUv', tilingProperty: 'normalMapTiling', offsetProperty: 'normalMapOffset', rotationProperty: 'normalMapRotation' },
  { kind: 'emissive', label: 'Emissive Map', property: 'emissiveMap', uvProperty: 'emissiveMapUv', tilingProperty: 'emissiveMapTiling', offsetProperty: 'emissiveMapOffset', rotationProperty: 'emissiveMapRotation', channelProperty: 'emissiveMapChannel', channels: ['rgb', 'r', 'g', 'b', 'a'], srgb: true, defaultChannel: 'rgb' },
  { kind: 'opacity', label: 'Opacity Map', property: 'opacityMap', uvProperty: 'opacityMapUv', tilingProperty: 'opacityMapTiling', offsetProperty: 'opacityMapOffset', rotationProperty: 'opacityMapRotation', channelProperty: 'opacityMapChannel', channels: ['r', 'g', 'b', 'a'], defaultChannel: 'a' },
  { kind: 'ao', label: 'AO Map', property: 'aoMap', uvProperty: 'aoMapUv', tilingProperty: 'aoMapTiling', offsetProperty: 'aoMapOffset', rotationProperty: 'aoMapRotation', channelProperty: 'aoMapChannel', channels: ['r', 'g', 'b', 'a'], defaultChannel: 'r' },
];

export const MATERIAL_MAP_BY_KIND = new Map(MATERIAL_MAP_DEFINITIONS.map((definition) => [definition.kind, definition]));

export function normalizeTextureLayer(raw: unknown): MaterialTextureLayer | null {
  if (!raw || typeof raw !== 'object') return null;
  const source = raw as Record<string, unknown>;
  const layer: MaterialTextureLayer = {};
  if (typeof source.assetId === 'string') layer.assetId = source.assetId;
  else if (source.assetId === null) layer.assetId = null;
  if (typeof source.assetName === 'string') layer.assetName = source.assetName.slice(0, 240);
  if (Number.isFinite(Number(source.uv))) layer.uv = Math.max(0, Math.min(7, Math.round(Number(source.uv))));
  const tiling = source.tiling as Record<string, unknown> | undefined;
  if (tiling && Number.isFinite(Number(tiling.x)) && Number.isFinite(Number(tiling.y))) layer.tiling = { x: Number(tiling.x), y: Number(tiling.y) };
  const offset = source.offset as Record<string, unknown> | undefined;
  if (offset && Number.isFinite(Number(offset.x)) && Number.isFinite(Number(offset.y))) layer.offset = { x: Number(offset.x), y: Number(offset.y) };
  if (Number.isFinite(Number(source.rotation))) layer.rotation = Number(source.rotation);
  if (['r', 'g', 'b', 'a', 'rgb'].includes(String(source.channel))) layer.channel = source.channel as MaterialMapChannel;
  if (typeof source.invert === 'boolean') layer.invert = source.invert;
  if (Number.isFinite(Number(source.intensity)) && Number(source.intensity) >= 0) layer.intensity = Number(source.intensity);
  return layer;
}

export function normalizeMaterial(raw: unknown): ObjectMaterial | null {
  if (!raw || typeof raw !== 'object') return null;
  const source = raw as Record<string, unknown>;
  const material: ObjectMaterial = {};
  if (typeof source.color === 'string') material.color = source.color;
  if (Number.isFinite(Number(source.roughness))) material.roughness = Number(source.roughness);
  if (Number.isFinite(Number(source.metalness))) material.metalness = Number(source.metalness);
  if (typeof source.emissive === 'string') material.emissive = source.emissive;
  if (Number.isFinite(Number(source.emissiveIntensity))) material.emissiveIntensity = Number(source.emissiveIntensity);
  if (Number.isFinite(Number(source.opacity))) material.opacity = Number(source.opacity);
  if (typeof source.doubleSided === 'boolean') material.doubleSided = source.doubleSided;
  for (const key of ['baseColorGain', 'saturation', 'contrast', 'specularGain', 'reflectionGain', 'normalStrength', 'roughnessRemap', 'roughnessContrast', 'metalnessResponseGain', 'emissiveGain'] as const) {
    if (Number.isFinite(Number(source[key]))) material[key] = Number(source[key]);
  }
  if (source.maps && typeof source.maps === 'object') {
    const maps: Partial<Record<MaterialMapKind, MaterialTextureLayer>> = {};
    for (const definition of MATERIAL_MAP_DEFINITIONS) {
      const layer = normalizeTextureLayer((source.maps as Record<string, unknown>)[definition.kind]);
      if (layer) maps[definition.kind] = layer;
    }
    material.maps = maps;
  }
  return material;
}

export function normalizeMaterialOverrides(raw: unknown): Record<string, ObjectMaterial> {
  if (!raw || typeof raw !== 'object') return {};
  const result: Record<string, ObjectMaterial> = {};
  for (const [slot, value] of Object.entries(raw as Record<string, unknown>)) {
    const material = normalizeMaterial(value);
    if (material) result[slot] = material;
  }
  return result;
}

export function collectMaterialTextureAssetIds(objects: SceneObject[]): string[] {
  const ids = new Set<string>();
  for (const object of objects) {
    for (const material of [object.material, ...Object.values(object.materialOverrides || {})]) {
      if (!material?.maps) continue;
      for (const layer of Object.values(material.maps)) {
        if (layer?.assetId) ids.add(layer.assetId);
      }
    }
  }
  return [...ids];
}

export interface MaterialSourceMapInfo {
  present: boolean;
  thumbnail?: string;
}

export interface MaterialSourceSlotInfo {
  slot: string;
  maps: Partial<Record<MaterialMapKind, MaterialSourceMapInfo>>;
}
