import { describe, expect, it } from 'vitest';
import { catalog, devices, getDevice } from './catalog';
import { createDemoProject } from './demo';
import { computeDmxPatch, applyAutoPatch, isDmxFixture, resolveDmxRoot } from './dmx';
import { computePower } from './power';
import { computeDiagnostics } from './diagnostics';
import { createSceneObject, getObjectPorts, placePorts } from './objects';
import { routeAll, routeConnection } from './routing';
import { createProject } from './project';
import { fixtureAimPoint, fixtureMountY, getRoomBounds } from './stage3d';
import { barEmitter, opticalProfile } from './lightOptics';
import { getQualityProfile } from './renderQuality';
import { collectVolumetrics } from './volumetrics';
import { migrateLegacy } from './migration';
import { exportProjectJson, parseProjectFile } from './migration';

function cloneProject() {
  return structuredClone(createDemoProject());
}

describe('catalog', () => {
  it('contains unique device ids and valid modes', () => {
    const ids = new Set(devices.map((device) => device.id));
    expect(ids.size).toBe(devices.length);
    for (const device of devices) {
      for (const mode of device.modes) {
        expect(mode.channels).toBeGreaterThanOrEqual(1);
        expect(mode.channels).toBeLessThanOrEqual(512);
        expect(Number.isInteger(mode.channels)).toBe(true);
      }
      if (device.modes.length) {
        expect(device.modes.some((mode) => mode.id === device.defaultModeId)).toBe(true);
      }
    }
  });

  it('keeps documented Focus Flex modes and footprint', () => {
    const device = getDevice('snl-444');
    expect(device).not.toBeNull();
    expect(device!.modes.map((mode) => mode.channels)).toContain(25);
    expect(device!.modes.find((mode) => mode.label.includes('CMY'))?.channels).toBe(25);
    expect(device!.dims.source).toBe('manufacturer');
    expect(device!.watts).toBe(340);
  });

  it('does not turn the distro into an independent power source', () => {
    const device = getDevice('distro');
    expect(device?.sourceType).toBe(false);
    expect(device?.consumes).toBe(true);
  });

  it('exposes bidirectional configurable XND ports with out defaults', () => {
    const device = getDevice('xnd8')!;
    const outputs = device.signalPorts.filter((port) => port.type === 'dmx');
    expect(outputs).toHaveLength(8);
    expect(outputs.every((port) => port.direction === 'out')).toBe(true);
    expect(outputs.every((port) => port.configurable)).toBe(true);
  });

  it('has a generated planning catalog note', () => {
    expect(catalog.schemaVersion).toBe(1);
    expect(catalog.note).toContain('planning');
  });
});

describe('DEMO project', () => {
  it('has unified objects in metres and a room', () => {
    const project = cloneProject();
    expect(project.schemaVersion).toBe(5);
    expect(project.objects.some((object) => object.type === 'room')).toBe(true);
    expect(project.objects.filter((object) => object.light)).toHaveLength(10);
    expect(project.connections.length).toBeGreaterThan(10);
    expect(project.objects.every((object) => Number.isFinite(object.position.x) && Number.isFinite(object.position.z))).toBe(true);
  });
});

describe('DMX patch', () => {
  it('patches ten fixtures across three universes in order', () => {
    const project = cloneProject();
    const patch = computeDmxPatch(project);
    expect(patch.rows).toHaveLength(10);
    const focus = patch.rows.filter((row) => row.objectId === project.objects.find((object) => object.name === 'Focus Flex 01')!.id);
    expect(focus[0].universe).toBe(1);
    expect(focus[0].address).toBe(1);
    expect(focus[0].channels).toBe(25);
    expect(focus[0].end).toBe(25);
    const expected = [1, 26, 51, 76];
    const focusRows = project.objects.filter((object) => object.name.startsWith('Focus Flex')).map((object) => patch.rows.find((row) => row.objectId === object.id)!);
    expect(focusRows.map((row) => row.address)).toEqual(expected);
    expect(focusRows.every((row) => row.root?.sourceName === 'Swisson XND-8')).toBe(true);
    expect(focusRows.every((row) => row.universe === 1)).toBe(true);
    const bars = project.objects.filter((object) => object.name.startsWith('UBL12H')).map((object) => patch.rows.find((row) => row.objectId === object.id)!);
    expect(bars.map((row) => row.address)).toEqual([1, 12, 23, 34]);
    expect(bars.every((row) => row.universe === 2)).toBe(true);
  });

  it('reports manual overlap and preserves the manual address', () => {
    const project = cloneProject();
    const focus = project.objects.filter((object) => object.name.startsWith('Focus Flex'));
    focus[0].fixture!.manualAddress = true;
    focus[0].fixture!.address = 1;
    focus[1].fixture!.manualAddress = true;
    focus[1].fixture!.address = 20;
    const patch = computeDmxPatch(project);
    expect(patch.diagnostics.some((diagnostic) => diagnostic.code === 'address-overlap')).toBe(true);
    expect(patch.rows.find((row) => row.objectId === focus[0].id)?.address).toBe(1);
  });

  it('rejects addresses beyond 512 channels', () => {
    const project = cloneProject();
    const focus = project.objects.find((object) => object.name === 'Focus Flex 01')!;
    focus.fixture!.manualAddress = true;
    focus.fixture!.address = 500;
    const patch = computeDmxPatch(project);
    expect(patch.diagnostics.some((diagnostic) => diagnostic.code === 'address-range' || diagnostic.code === 'address-overlap')).toBe(true);
  });

  it('keeps auto addresses after applying autopatch', () => {
    const project = cloneProject();
    const objects = applyAutoPatch(project);
    const focus = objects.find((object) => object.name === 'Focus Flex 02')!;
    expect(focus.fixture?.address).toBe(26);
    expect(focus.fixture?.manualAddress).toBe(false);
  });

  it('resolves a chained DMX root through fixtures', () => {
    const project = cloneProject();
    const focus3 = project.objects.find((object) => object.name === 'Focus Flex 03')!;
    expect(isDmxFixture(focus3)).toBe(true);
    const root = resolveDmxRoot(project, focus3);
    expect(root?.universe).toBe(1);
    expect(root?.sourceName).toBe('Swisson XND-8');
  });

  it('supports manual channel footprints for unprofiled devices', () => {
    const project = cloneProject();
    const node = project.objects.find((object) => object.name === 'Swisson XND-8')!;
    const generic = createSceneObject('generic-par', { x: 1, z: 1 }, { name: 'Generic PAR' });
    generic.fixture = { modeId: null, customChannels: 4, universe: 1, address: null, manualAddress: false, wattsOverride: 100, powerOn: true };
    generic.light = { on: true, intensity: 0.5, color: '#ff0000', colorTemp: 5600, pan: 0, tilt: 0, zoom: 20, strobe: 0, focus: 0.5 };
    project.objects.push(generic);
    project.connections.push({ id: 'test-conn', type: 'dmx', from: node.id, fromPort: 'out8', to: generic.id, toPort: 'dmxIn', waypoints: [], note: '' });
    const patch = computeDmxPatch(project);
    const row = patch.rows.find((entry) => entry.objectId === generic.id);
    expect(row?.channels).toBe(4);
    expect(row?.root?.universe).toBe(8);
    expect(row?.address).toBe(1);
  });
});

describe('power', () => {
  it('counts one source phase and known loads once', () => {
    const project = cloneProject();
    const power = computePower(project);
    expect(power.phases).toHaveLength(1);
    expect(power.phases[0].sourceName).toBe('Сеть 230 В · A');
    expect(power.phases[0].phase).toBe('L1');
    expect(Math.round(power.totalWatts)).toBe(2373);
    expect(power.unknownCount).toBe(1);
    expect(power.phases[0].limit).toBe(3680);
    expect(power.phases[0].overload).toBe(false);
  });

  it('does not treat the distro as a source', () => {
    const project = cloneProject();
    const power = computePower(project);
    expect(power.phases.some((phase) => phase.sourceName === 'Распределитель сцены')).toBe(false);
    const focus = project.objects.find((object) => object.name === 'Focus Flex 01')!;
    const row = power.rows.find((entry) => entry.objectId === focus.id)!;
    expect(row.chain?.sourceName).toBe('Сеть 230 В · A');
  });

  it('flags a phase overload when the entered budget is exceeded', () => {
    const project = cloneProject();
    const source = project.objects.find((object) => object.name === 'Сеть 230 В · A')!;
    source.powerLimits = { L1: 1000 };
    const power = computePower(project);
    expect(power.phases[0].overload).toBe(true);
    expect(power.diagnostics.some((diagnostic) => diagnostic.code === 'phase-overload')).toBe(true);
  });

  it('calculates distro output loads and limits', () => {
    const project = cloneProject();
    const power = computePower(project);
    const distro = project.objects.find((object) => object.name === 'Распределитель сцены')!;
    const output1 = power.distros.find((entry) => entry.objectId === distro.id && entry.port === 'power1');
    const output2 = power.distros.find((entry) => entry.objectId === distro.id && entry.port === 'power2');
    expect(Math.round(output1?.watts || 0)).toBe(1360);
    expect(Math.round(output2?.watts || 0)).toBe(244);
    expect(output1?.limit).toBe(1800);
  });

  it('does not count unknown load as zero', () => {
    const project = cloneProject();
    const power = computePower(project);
    const consoleRow = power.rows.find((entry) => entry.device?.kind === 'console');
    expect(consoleRow?.status).toBe('unknown');
    expect(power.totalWatts).toBeLessThan(2500);
    expect(power.diagnostics.some((diagnostic) => diagnostic.code === 'unknown-watts')).toBe(true);
  });
});

describe('routing', () => {
  it('starts and ends at the physical port anchors', () => {
    const project = cloneProject();
    for (const connection of project.connections) {
      const result = routeConnection(project, connection);
      const from = project.objects.find((object) => object.id === connection.from)!;
      const to = project.objects.find((object) => object.id === connection.to)!;
      const start = placePorts(from).find((port) => port.id === connection.fromPort)!;
      const end = placePorts(to).find((port) => port.id === connection.toPort)!;
      expect(result.points.length).toBeGreaterThan(1);
      expect(Math.hypot(result.points[0].x - start.x, result.points[0].z - start.z)).toBeLessThan(0.01);
      const last = result.points[result.points.length - 1];
      expect(Math.hypot(last.x - end.x, last.z - end.z)).toBeLessThan(0.01);
    }
  });

  it('keeps cables inside the room when both ports are inside', () => {
    const project = cloneProject();
    const room = project.objects.find((object) => object.type === 'room')!;
    const roomRect = { minX: room.position.x - (room.size?.w || 0) / 2, maxX: room.position.x + (room.size?.w || 0) / 2, minZ: room.position.z - (room.size?.d || 0) / 2, maxZ: room.position.z + (room.size?.d || 0) / 2 };
    for (const connection of project.connections) {
      const result = routeConnection(project, connection);
      for (const point of result.points) {
        expect(point.x).toBeGreaterThanOrEqual(roomRect.minX - 1);
        expect(point.x).toBeLessThanOrEqual(roomRect.maxX + 1);
        expect(point.z).toBeGreaterThanOrEqual(roomRect.minZ - 1);
        expect(point.z).toBeLessThanOrEqual(roomRect.maxZ + 1);
      }
    }
  });
});

describe('diagnostics', () => {
  it('includes power and DMX diagnostics without crashing', () => {
    const project = cloneProject();
    const diagnostics = computeDiagnostics(project);
    expect(diagnostics.length).toBeGreaterThan(0);
    expect(diagnostics.every((diagnostic) => diagnostic.id && diagnostic.message)).toBe(true);
  });
});

describe('legacy migration and validation', () => {
  it('converts legacy nodes, ports, areas and edges into schema 5', () => {
    const legacy = {
      version: 4,
      nodes: [
        { id: 'n1', model: 'xnd8', name: 'XND', x: 0, y: 0, outputs: 8, kind: 'node', category: 'node' },
        { id: 'n2', model: 'focusflex', name: 'Focus', x: 240, y: 240, kind: 'head', category: 'light', modeId: 'standard-rgbw-25', channels: 25, rotation: 0 },
        { id: 'n3', model: 'outlet', name: 'Power', x: 480, y: 0, kind: 'outlet', category: 'power', outputs: 4 },
      ],
      edges: [
        { id: 'e1', type: 'dmx', from: 'n1', port: 'out1', to: 'n2', toPort: 'dmxIn' },
        { id: 'e2', type: 'power', from: 'n3', port: 'power1', to: 'n2', toPort: 'powerIn' },
      ],
      areas: [{ id: 'a1', type: 'stage', name: 'Main', x: 0, y: 0, w: 480, h: 240 }],
      guides: [{ axis: 'x', value: 240 }],
    };
    const result = migrateLegacy(legacy);
    expect(result.project.schemaVersion).toBe(5);
    expect(result.project.objects.length).toBeGreaterThanOrEqual(4);
    expect(result.project.connections).toHaveLength(2);
    expect(result.project.objects.some((object) => object.type === 'stage')).toBe(true);
    expect(result.project.objects.some((object) => object.type === 'room')).toBe(true);
    expect(result.warnings.length).toBeGreaterThan(0);
  });

  it('round-trips an exported v5 project', () => {
    const project = cloneProject();
    const json = exportProjectJson(project);
    const parsed = parseProjectFile(json);
    expect(parsed.project.objects.length).toBe(project.objects.length);
    expect(parsed.project.connections.length).toBe(project.connections.length);
    expect(parsed.warnings).toHaveLength(0);
    expect(parsed.project.name).toBe(project.name);
  });

  it('drops invalid connections and reports them', () => {
    const project = cloneProject();
    const json = JSON.parse(exportProjectJson(project));
    json.project.connections.push({ id: 'bad', type: 'dmx', from: 'missing', to: 'also-missing', fromPort: 'x', toPort: 'y' });
    const parsed = parseProjectFile(JSON.stringify(json));
    expect(parsed.project.connections.length).toBe(project.connections.length);
    expect(parsed.warnings.some((warning) => warning.toLowerCase().includes('cable'))).toBe(true);
  });
});

describe('DMX topology helpers', () => {
  it('traces through a splitter to the upstream node', () => {
    const project = createDemoProject();
    project.objects = project.objects.filter((object) => !['Focus Flex', 'UBL', '18P'].some((name) => object.name.startsWith(name)));
    project.connections = [];
    const node = createSceneObject('xnd8', { x: -2, z: 1 }, { name: 'Node' });
    const splitter = createSceneObject('splitter', { x: 0, z: 1 }, { name: 'Split' });
    const fixture = createSceneObject('snl-444', { x: 2, z: 1 }, { name: 'Head' });
    project.objects.push(node, splitter, fixture);
    project.connections.push(
      { id: 's1', type: 'dmx', from: node.id, fromPort: 'out4', to: splitter.id, toPort: 'dmxA', waypoints: [], note: '' },
      { id: 's2', type: 'dmx', from: splitter.id, fromPort: 'out2', to: fixture.id, toPort: 'dmxIn', waypoints: [], note: '' },
    );
    const root = resolveDmxRoot(project, fixture);
    expect(root?.sourceId).toBe(node.id);
    expect(root?.universe).toBe(4);
    const patch = computeDmxPatch(project);
    expect(patch.rows.find((row) => row.objectId === fixture.id)?.address).toBe(1);
  });

  it('traces a wireless transmitter and receiver chain', () => {
    const project = createDemoProject();
    project.objects = [];
    project.connections = [];
    const node = createSceneObject('xnd8', { x: -3, z: 1 }, { name: 'Node' });
    const transmitter = createSceneObject('transmitter', { x: -1, z: 1 }, { name: 'TX' });
    const receiver = createSceneObject('receiver', { x: 2, z: 1 }, { name: 'RX' });
    const fixture = createSceneObject('snl-444', { x: 3, z: 1 }, { name: 'Head' });
    project.objects.push(node, transmitter, receiver, fixture);
    project.connections.push(
      { id: 'w1', type: 'dmx', from: node.id, fromPort: 'out2', to: transmitter.id, toPort: 'dmxIn', waypoints: [], note: '' },
      { id: 'w2', type: 'wireless', from: transmitter.id, fromPort: 'wirelessOut', to: receiver.id, toPort: 'wirelessIn', waypoints: [], note: '' },
      { id: 'w3', type: 'dmx', from: receiver.id, fromPort: 'dmxOut', to: fixture.id, toPort: 'dmxIn', waypoints: [], note: '' },
    );
    const root = resolveDmxRoot(project, fixture);
    expect(root?.sourceId).toBe(node.id);
    expect(root?.universe).toBe(2);
  });
});

describe('three-phase power assignment', () => {
  it('assigns branch phases from source output phases and checks budgets', () => {
    const project = cloneProject();
    const source = project.objects.find((object) => object.name === 'Сеть 230 В · A')!;
    source.portPhasesThreePhase = true;
    source.portPhases = { power1: 'L1', power2: 'L2', power3: 'L3' };
    source.powerLimits = { L1: 3000, L2: 1000, L3: 1000 };
    const power = computePower(project);
    expect(power.phases.length).toBe(3);
    const l1 = power.phases.find((phase) => phase.phase === 'L1')!;
    const l2 = power.phases.find((phase) => phase.phase === 'L2')!;
    const l3 = power.phases.find((phase) => phase.phase === 'L3')!;
    expect(l1.watts).toBeGreaterThan(1000);
    expect(l2.watts).toBe(154);
    expect(l3.watts).toBe(154);
    expect(l1.limit).toBe(3000);
    expect(l2.overload).toBe(false);
    expect(power.phases.every((phase) => phase.sourceName === 'Сеть 230 В · A')).toBe(true);
  });
});

describe('unified stage geometry', () => {
  it('keeps 3D mount and aim derived from the same 2D object', () => {
    const project = cloneProject();
    const fixture = project.objects.find((object) => object.name === 'Focus Flex 01')!;
    const firstAim = fixtureAimPoint(fixture, project);
    fixture.light!.pan = 35;
    fixture.light!.tilt = 18;
    const secondAim = fixtureAimPoint(fixture, project);
    expect(secondAim[0]).not.toBe(firstAim[0]);
    expect(secondAim[2]).not.toBe(firstAim[2]);
    expect(fixtureMountY(fixture)).toBeLessThan(fixture.elevation);
    const bounds = getRoomBounds(project);
    expect(bounds.height).toBe(5.2);
    expect(bounds.maxX - bounds.minX).toBeCloseTo(14, 3);
  });

  it('gives bar, spot and wash distinct optical profiles', () => {
    const project = createDemoProject();
    const bar = project.objects.find((object) => object.name === 'UBL12H 01')!;
    const spot = project.objects.find((object) => object.name === 'Focus Flex 01')!;
    const wash = project.objects.find((object) => object.name === '18P-HEX 01')!;
    expect(opticalProfile(bar).family).toBe('bar');
    expect(opticalProfile(spot).family).toBe('spot');
    expect(opticalProfile(wash).family).toBe('wash');
    expect(opticalProfile(wash).fieldAngle).toBeGreaterThan(opticalProfile(spot).fieldAngle);
    expect(opticalProfile(bar).area).toBe(true);
    expect(opticalProfile(spot).area).toBe(false);
  });

  it('supports beam, panel and strobe optical families', () => {
    const project = createProject('Optics');
    const beam = createSceneObject('snl-445', { x: 0, z: 0 });
    const panel = createSceneObject('snl-414', { x: 0, z: 0 });
    const strobe = createSceneObject('snl-506', { x: 0, z: 0 });
    expect(opticalProfile(beam).family).toBe('beam');
    expect(opticalProfile(beam).beamAngle).toBeLessThanOrEqual(20);
    expect(opticalProfile(panel).family).toBe('panel');
    expect(opticalProfile(panel).area).toBe(true);
    expect(opticalProfile(strobe).family).toBe('strobe');
    expect(opticalProfile(strobe).area).toBe(true);
    expect(project.objects.length).toBe(1);
  });

  it('starts bar light at the lens row and rotates its optical axis with the body', () => {
    const project = createDemoProject();
    const bar = project.objects.find((object) => object.name === 'UBL12H 02')!;
    const emitter = barEmitter(bar, project);
    expect(emitter.lenses.length).toBeGreaterThanOrEqual(3);
    expect(emitter.lenses.every((lens) => lens[1] > 0)).toBe(true);
    expect(emitter.forward[0]).toBeLessThan(-0.9);
    const lens = emitter.lenses[0];
    const target = emitter.targets[0];
    expect(target[0]).toBeLessThan(lens[0]);
    expect(target[1]).toBeGreaterThan(lens[1]);
    const mirrored = { ...bar, rotation: 270 as const };
    expect(barEmitter(mirrored, project).forward[0]).toBeGreaterThan(0.9);
  });

  it('keeps room color, work light and segment state through JSON validation', () => {
    const project = createDemoProject();
    const room = project.objects.find((object) => object.type === 'room')!;
    room.room = { ...room.room!, wallColor: '#334455' };
    project.lighting.workLight = false;
    const bar = project.objects.find((object) => object.name === 'UBL12H 01')!;
    bar.light = { ...bar.light!, segments: [{ intensity: 0 }, { intensity: 1, color: '#ff00aa' }] };
    const parsed = parseProjectFile(exportProjectJson(project));
    expect(parsed.project.objects.find((object) => object.type === 'room')?.room?.wallColor).toBe('#334455');
    expect(parsed.project.lighting.workLight).toBe(false);
    expect(parsed.project.objects.find((object) => object.id === bar.id)?.light?.segments?.[0].intensity).toBe(0);
  });
});

describe('cinematic render configuration', () => {
  it('maps quality tiers to real sample, AA and AO differences', () => {
    const low = getQualityProfile('low');
    const high = getQualityProfile('high');
    const photo = getQualityProfile('photo');
    expect(low.raymarch).toBe(false);
    expect(high.raymarch).toBe(true);
    expect(high.volumetricSamples).toBeGreaterThan(low.volumetricSamples);
    expect(photo.volumetricSamples).toBeGreaterThan(high.volumetricSamples);
    expect(photo.dpr).not.toBe(high.dpr);
    expect(photo.msaa).toBeGreaterThanOrEqual(high.msaa);
    expect(photo.contactShadows).toBe(true);
  });

  it('activates the red/blue cinema preset and exposes only the active light emitters', () => {
    const project = createDemoProject();
    const active = project.lighting.presets.find((preset) => preset.id === project.lighting.activePresetId);
    expect(active?.name).toContain('Кино');
    const volumes = collectVolumetrics(project);
    expect(volumes.spots).toHaveLength(4);
    expect(volumes.bars).toHaveLength(4);
    expect(volumes.spots.every((spot) => spot.energy > 0)).toBe(true);
    expect(project.lighting.anisotropy).toBeGreaterThan(0);
  });
});

describe('legacy area migration', () => {
  it('keeps room, stage and seating areas as their real scene types', () => {
    const { project } = migrateLegacy({
      version: 4,
      nodes: [],
      edges: [],
      areas: [
        { id: 'room', type: 'room', name: 'Зал', x: -720, y: -540, w: 1440, h: 1080 },
        { id: 'stage', type: 'stage', name: 'Сцена', x: -480, y: -1080, w: 960, h: 480 },
        { id: 'seats', type: 'seating', name: 'Партер', x: -600, y: 0, w: 1200, h: 720 },
      ],
      previewSettings: { haze: 0.4, master: 0.8, ambient: 0.3 },
    });
    expect(project.objects.filter((object) => object.type === 'room')).toHaveLength(1);
    expect(project.objects.filter((object) => object.type === 'stage')).toHaveLength(1);
    expect(project.objects.filter((object) => object.type === 'seating')).toHaveLength(1);
    expect(project.objects.find((object) => object.type === 'stage')?.size?.h).toBe(0.45);
  });
});

describe('cable routing geometry', () => {
  it('returns only orthogonal segments, cleanly separated by cable type', () => {
    const project = createDemoProject();
    const routes = routeAll(project);
    expect(routes.size).toBe(project.connections.length);
    for (const [connectionId, points] of routes) {
      expect(points.length, connectionId).toBeGreaterThan(1);
      for (let index = 1; index < points.length; index++) {
        const a = points[index - 1];
        const b = points[index];
        const horizontal = Math.abs(a.z - b.z) < 1e-6;
        const vertical = Math.abs(a.x - b.x) < 1e-6;
        expect(horizontal || vertical, `${connectionId} has a diagonal`).toBe(true);
      }
    }
  });

  it('keeps routes inside the room when both ports are inside', () => {
    const project = createDemoProject();
    const room = project.objects.find((object) => object.type === 'room')!;
    const minX = room.position.x - (room.size!.w / 2);
    const maxX = room.position.x + (room.size!.w / 2);
    const minZ = room.position.z - (room.size!.d / 2);
    const maxZ = room.position.z + (room.size!.d / 2);
    for (const [connectionId, points] of routeAll(project)) {
      for (const point of points) {
        expect(point.x, connectionId).toBeGreaterThanOrEqual(minX - 1e-5);
        expect(point.x, connectionId).toBeLessThanOrEqual(maxX + 1e-5);
        expect(point.z, connectionId).toBeGreaterThanOrEqual(minZ - 1e-5);
        expect(point.z, connectionId).toBeLessThanOrEqual(maxZ + 1e-5);
      }
    }
  });
});
