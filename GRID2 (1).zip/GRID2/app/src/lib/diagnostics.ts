import type { Project } from '../types/project';
import { getDevice } from './catalog';
import { computeDmxPatch, type Diagnostic, type DmxPatchResult } from './dmx';
import { computePower, type PowerResult } from './power';
import { getObjectPorts } from './objects';

export function computeDiagnostics(project: Project, dmxResult?: DmxPatchResult, powerResult?: PowerResult): Diagnostic[] {
  const dmx = dmxResult || computeDmxPatch(project);
  const power = powerResult || computePower(project);
  const diagnostics: Diagnostic[] = [...dmx.diagnostics, ...power.diagnostics];

  for (const connection of project.connections) {
    const from = project.objects.find((object) => object.id === connection.from);
    const to = project.objects.find((object) => object.id === connection.to);
    if (!from || !to) {
      diagnostics.push({
        id: `conn-missing-${connection.id}`,
        severity: 'error',
        area: 'connection',
        code: 'connection-object-missing',
        message: 'Cable references a deleted object',
        objectIds: [],
        connectionId: connection.id,
      });
      continue;
    }
    const fromPort = getObjectPorts(from).find((port) => port.id === connection.fromPort);
    const toPort = getObjectPorts(to).find((port) => port.id === connection.toPort);
    if (!fromPort || !toPort) {
      diagnostics.push({
        id: `conn-port-${connection.id}`,
        severity: 'error',
        area: 'connection',
        code: 'connection-port-missing',
        message: `${connection.type.toUpperCase()}: port not found on ${!fromPort ? from.name : to.name}`,
        objectIds: [from.id, to.id],
        connectionId: connection.id,
        hint: 'The port may have been reassigned or deleted. Delete the cable and reconnect.',
      });
      continue;
    }
    if (fromPort.type !== connection.type || toPort.type !== connection.type) {
      diagnostics.push({
        id: `conn-type-${connection.id}`,
        severity: 'error',
        area: 'connection',
        code: 'connection-type-mismatch',
        message: `Cable type does not match the ports: ${from.name} · ${fromPort.id}`,
        objectIds: [from.id, to.id],
        connectionId: connection.id,
      });
    }

    // Power chains must terminate at a source. Report dangling branches once.
    const connectorTokens = (value: string) => new Set((value.match(/(?:3-pin|5-pin|RJ45|HDMI|SDI|DisplayPort|DVI|XLR|powerCON|TRUE1|Schuko|USB-[AC]|USB)/gi) || []).map((token) => token.toUpperCase().replace('TRUE1', 'POWERCON')));
    if (fromPort.connector && toPort.connector) {
      const fromTokens = connectorTokens(fromPort.connector);
      const toTokens = connectorTokens(toPort.connector);
      if (connection.type === 'dmx' && fromTokens.size && toTokens.size && ![...fromTokens].some((token) => toTokens.has(token))) {
        diagnostics.push({
          id: `connector-dmx-${connection.id}`,
          severity: 'warning',
          area: 'connection',
          code: 'dmx-connector-mismatch',
          message: `DMX connectors differ: ${fromPort.connector} → ${toPort.connector}`,
          objectIds: [from.id, to.id],
          connectionId: connection.id,
          hint: 'Check whether a 3-pin / 5-pin / RJ45 adapter is needed.',
        });
      }
      if (connection.type === 'video' && fromTokens.size && toTokens.size && ![...fromTokens].some((token) => toTokens.has(token))) {
        diagnostics.push({
          id: `connector-video-${connection.id}`,
          severity: 'info',
          area: 'connection',
          code: 'video-connector-adapter',
          message: `Video connectors differ: ${fromPort.connector} → ${toPort.connector}`,
          objectIds: [from.id, to.id],
          connectionId: connection.id,
          hint: 'Check that an adapter is available and supported; the cable does not confirm signal transmission.',
        });
      }
    }
    if (connection.type === 'power' && fromPort.domain && toPort.domain && fromPort.domain !== toPort.domain) {
      diagnostics.push({
        id: `connector-domain-${connection.id}`,
        severity: 'error',
        area: 'connection',
        code: 'power-domain-mismatch',
        message: `AC and DC connected directly: ${from.name} → ${to.name}`,
        objectIds: [from.id, to.id],
        connectionId: connection.id,
        hint: 'Direct AC–DC connection is not allowed. Check the source and converter.',
      });
    }

    if (connection.type === 'power') {
      const fromDevice = getDevice(from.deviceId);
      const toDevice = getDevice(to.deviceId);
      if (fromDevice && fromPort.direction === 'in' && toPort.direction === 'out') {
        diagnostics.push({
          id: `conn-direction-${connection.id}`,
          severity: 'warning',
          area: 'connection',
          code: 'connection-direction',
          message: `${from.name} → ${to.name}: cable connected input → output`,
          objectIds: [from.id, to.id],
          connectionId: connection.id,
        });
      }
    }
  }

  // Duplicate names make the patch table ambiguous.
  const names = new Map<string, number>();
  for (const object of project.objects) {
    if (object.type !== 'device') continue;
    names.set(object.name, (names.get(object.name) || 0) + 1);
  }
  for (const [name, count] of names) {
    if (count < 2) continue;
    const ids = project.objects.filter((object) => object.name === name).map((object) => object.id);
    diagnostics.push({
      id: `name-duplicate-${name}`,
      severity: 'info',
      area: 'project',
      code: 'duplicate-name',
      message: `Multiple objects are named "${name}"`,
      objectIds: ids,
      hint: 'Unique names make the DMX Patch and cable chains easier to read.',
    });
  }

  if (!project.objects.some((object) => object.type === 'room')) {
    diagnostics.push({
      id: 'project-no-room',
      severity: 'info',
      area: 'project',
      code: 'no-room',
      message: 'The project has no venue',
      objectIds: [],
      hint: 'Add a venue with the Venue tool to see walls and scale.',
    });
  }

  const rank = { error: 0, warning: 1, info: 2 } as const;
  return diagnostics
    .filter((diagnostic, index, list) => list.findIndex((entry) => entry.id === diagnostic.id) === index)
    .sort((a, b) => rank[a.severity] - rank[b.severity] || a.message.localeCompare(b.message, 'ru'));
}

export interface DiagnosticCounts {
  error: number;
  warning: number;
  info: number;
}

export function countDiagnostics(diagnostics: Diagnostic[]): DiagnosticCounts {
  return diagnostics.reduce(
    (counts, diagnostic) => ({ ...counts, [diagnostic.severity]: counts[diagnostic.severity] + 1 }),
    { error: 0, warning: 0, info: 0 },
  );
}
