import type { Project, SceneObject } from '../types/project';
import type { TimelineClip, TimelineEasing, TimelineKeyframe, TimelineState, TimelineTrack } from '../types/timeline';
import { sampleGroupEffects } from './groupEffects';

export type TimelineValue = number | string | boolean;

export function sortKeyframes(keyframes: TimelineKeyframe[]): TimelineKeyframe[] {
  return [...keyframes].sort((a, b) => a.time - b.time);
}

export function easingValue(easing: TimelineEasing, t: number): number {
  const x = Math.max(0, Math.min(1, t));
  if (easing === 'easeIn') return x * x;
  if (easing === 'easeOut') return 1 - (1 - x) * (1 - x);
  if (easing === 'easeInOut') return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
  if (easing === 'step') return 0;
  return x;
}

function hexToRgb(value: string): [number, number, number] | null {
  const match = /^#?([0-9a-f]{6})$/i.exec(value.trim());
  if (!match) return null;
  const n = Number.parseInt(match[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mix(a: TimelineValue, b: TimelineValue, t: number): TimelineValue {
  if (typeof a === 'number' && typeof b === 'number') return a + (b - a) * t;
  if (typeof a === 'string' && typeof b === 'string') {
    const ca = hexToRgb(a);
    const cb = hexToRgb(b);
    if (ca && cb) {
      const c = ca.map((v, i) => Math.round(v + (cb[i] - v) * t));
      return `#${c.map((v) => v.toString(16).padStart(2, '0')).join('')}`;
    }
  }
  return t >= 1 ? b : a;
}

export function evaluateKeyframes(keyframes: TimelineKeyframe[], time: number): TimelineValue | undefined {
  if (!keyframes.length) return undefined;
  const ordered = sortKeyframes(keyframes);
  if (time <= ordered[0].time) return ordered[0].value;
  if (time >= ordered[ordered.length - 1].time) return ordered[ordered.length - 1].value;
  for (let i = 0; i < ordered.length - 1; i += 1) {
    const a = ordered[i];
    const b = ordered[i + 1];
    if (time >= a.time && time <= b.time) {
      const span = Math.max(0.00001, b.time - a.time);
      const raw = (time - a.time) / span;
      if (a.easing === 'step') return a.value;
      return mix(a.value, b.value, easingValue(a.easing, raw));
    }
  }
  return ordered[ordered.length - 1].value;
}

export function objectPathValue(object: SceneObject, path: string): TimelineValue | undefined {
  const parts = path.split('.');
  if (parts[0] === 'position') return parts[1] === 'x' ? object.position.x : parts[1] === 'y' ? object.elevation : object.position.z;
  if (parts[0] === 'rotation') return parts[1] === 'x' ? object.rotationX || 0 : parts[1] === 'y' ? object.rotation : object.rotationZ || 0;
  if (parts[0] === 'scale') return (object.scale || { x: 1, y: 1, z: 1 })[parts[1] as 'x' | 'y' | 'z'];
  if (parts[0] === 'light') return (object.light as unknown as Record<string, TimelineValue> | null)?.[parts[1]];
  if (parts[0] === 'material') return (object.material as unknown as Record<string, TimelineValue> | null)?.[parts[1]];
  if (parts[0] === 'modifier') {
    const modifier = object.modifiers?.find((entry) => entry.id === parts[1]);
    return modifier?.params[parts[2]] as TimelineValue | undefined;
  }
  return undefined;
}

export function baseValue(project: Project, objectId: string | null, path: string): TimelineValue | undefined {
  if (path.startsWith('simulation.reaction.')) {
    const key = path.slice(20) as keyof NonNullable<Project['reactionDiffusion']>;
    return project.reactionDiffusion?.[key] as TimelineValue | undefined;
  }
  if (path.startsWith('scene.')) {
    const key = path.slice(6);
    if (key.startsWith('post.')) {
      const [, shaderId, param] = key.split('.');
      return project.postShaders?.find((instance) => (instance.id || instance.shaderId) === shaderId)?.values[param] as TimelineValue | undefined;
    }
    return (project.lighting as unknown as Record<string, TimelineValue>)[key];
  }
  if (path.startsWith('look.')) {
    const [, lookId, section, key, nested] = path.split('.');
    const look = project.looks?.find((entry) => entry.id === lookId);
    if (!look) return undefined;
    if (section === 'material') return (look.material as unknown as Record<string, TimelineValue>)[key];
    if (section === 'effect') return look.modifiers?.find((effect) => effect.id === key)?.params[nested] as TimelineValue | undefined;
    if (section === 'shader') return look.shaders?.find((instance) => instance.shaderId === key)?.values[nested] as TimelineValue | undefined;
    return undefined;
  }
  if (path.startsWith('field.')) {
    const [, fieldId, key] = path.split('.');
    return project.fields?.find((field) => field.id === fieldId)?.params[key] as TimelineValue | undefined;
  }
  if (path.startsWith('effect.')) {
    const [, effectId, key] = path.split('.');
    return project.effects?.find((effect) => effect.id === effectId)?.params[key] as TimelineValue | undefined;
  }
  const object = project.objects.find((entry) => entry.id === objectId);
  return object ? objectPathValue(object, path) : undefined;
}

export function clipValue(clip: TimelineClip, time: number, base: TimelineValue | undefined): TimelineValue | undefined {
  if (!clip.enabled || time < clip.start || time > clip.end) return undefined;
  const params = clip.params || {};
  const local = Math.max(0, time - clip.start);
  const frequency = Number(params.frequency ?? 1);
  const phase = Number(params.phase ?? 0);
  const waveform = String(params.waveform || 'sine');
  let wave = Math.sin((local * frequency + phase) * Math.PI * 2);
  if (waveform === 'triangle') wave = 2 * Math.abs(2 * (local * frequency + phase - Math.floor(local * frequency + phase + 0.5))) - 1;
  if (waveform === 'square') wave = wave >= 0 ? 1 : -1;
  const fadeIn = Math.max(0, Number(clip.fadeIn ?? 0));
  const fadeOut = Math.max(0, Number(clip.fadeOut ?? 0));
  const fade = Math.min(fadeIn > 0 ? Math.min(1, local / fadeIn) : 1, fadeOut > 0 ? Math.min(1, (clip.end - time) / fadeOut) : 1);
  let value: TimelineValue | undefined;
  if (clip.type === 'pulse') {
    const min = Number(params.min ?? 0);
    const max = Number(params.max ?? 1);
    value = min + (max - min) * ((wave + 1) / 2);
  } else if (clip.type === 'wave') {
    const baseNumber = typeof base === 'number' ? base : Number(params.offset ?? 0);
    value = baseNumber + wave * Number(params.amplitude ?? 0.5) + Number(params.offset ?? 0);
  } else if (clip.type === 'rotate') {
    const baseNumber = typeof base === 'number' ? base : 0;
    value = baseNumber + local * Number(params.speed ?? 30) * Number(params.direction ?? 1);
  } else if (clip.type === 'noise') {
    const baseNumber = typeof base === 'number' ? base : 0;
    const seed = Number(params.seed ?? 1);
    const n = Math.sin(Math.sin((local * Number(params.speed ?? 1) + seed) * 12.9898) * 43758.5453);
    value = baseNumber + n * Number(params.amount ?? 0.2);
  }
  if (value === undefined) return undefined;
  if (typeof value === 'number' && fade < 1) {
    const baseNumber = typeof base === 'number' ? base : 0;
    value = baseNumber + (value - baseNumber) * fade;
  }
  return value;
}

export function sampleTimeline(project: Project, time: number): Map<string, TimelineValue> {
  const result = new Map<string, TimelineValue>();
  const timeline = project.timeline;
  if (!timeline) return result;
  for (const track of timeline.tracks || []) {
    const value = evaluateKeyframes(track.keyframes, time);
    if (value !== undefined) result.set(`${track.objectId || 'scene'}:${track.propertyPath}`, value);
  }
  for (const clip of timeline.clips || []) {
    const key = `${clip.objectId || 'scene'}:${clip.propertyPath}`;
    const base = baseValue(project, clip.objectId, clip.propertyPath);
    const value = clipValue(clip, time, base);
    if (value !== undefined) result.set(key, value);
  }
  sampleGroupEffects(project, time, result);
  return result;
}

export function applyTimelineToProject(project: Project, overrides: Map<string, TimelineValue>): Project {
  if (!overrides.size) return project;
  const objects = project.objects.map((object) => {
    let next = object;
    const ensureObject = () => {
      if (next === object) next = { ...object, position: { ...object.position }, scale: object.scale ? { ...object.scale } : undefined, light: object.light ? { ...object.light } : null, material: object.material ? { ...object.material } : null, modifiers: object.modifiers ? object.modifiers.map((modifier) => ({ ...modifier, params: { ...modifier.params } })) : [] };
      return next;
    };
    for (const [key, value] of overrides) {
      const [objectId, path] = key.split(':');
      if (objectId !== object.id) continue;
      const parts = path.split('.');
      const target = ensureObject();
      if (parts[0] === 'position') {
        if (parts[1] === 'y') target.elevation = Number(value); else target.position[parts[1] as 'x' | 'z'] = Number(value);
      } else if (parts[0] === 'rotation') {
        if (parts[1] === 'x') target.rotationX = Number(value); else if (parts[1] === 'y') target.rotation = Number(value); else target.rotationZ = Number(value);
      } else if (parts[0] === 'scale' && target.scale) {
        target.scale[parts[1] as 'x' | 'y' | 'z'] = Number(value);
      } else if (parts[0] === 'light' && target.light) {
        (target.light as unknown as Record<string, TimelineValue>)[parts[1]] = value;
      } else if (parts[0] === 'material') {
        target.material = { ...(target.material || {}), [parts[1]]: value } as typeof target.material;
      } else if (parts[0] === 'modifier') {
        const modifier = target.modifiers?.find((entry) => entry.id === parts[1]);
        if (modifier) modifier.params[parts[2]] = value;
      }
    }
    return next;
  });
  let lighting = project.lighting;
  let effects = project.effects;
  let fields = project.fields;
  let looks = project.looks;
  let postShaders = project.postShaders;
  let reactionDiffusion = project.reactionDiffusion;
  for (const [key, value] of overrides) {
    if (!key.startsWith('scene:')) continue;
    const rawProperty = key.slice(6);
    const property = rawProperty.startsWith('scene.') ? rawProperty.slice(6) : rawProperty;
    if (property.startsWith('effect.')) {
      const [, effectId, param] = property.split('.');
      effects = (effects || []).map((effect) => effect.id === effectId ? { ...effect, params: { ...effect.params, [param]: value } } : effect);
    } else if (property.startsWith('field.')) {
      const [, fieldId, param] = property.split('.');
      fields = (fields || []).map((field) => field.id === fieldId ? { ...field, params: { ...field.params, [param]: value } } : field);
    } else if (property.startsWith('simulation.reaction.')) {
      const key = property.slice(20);
      if (reactionDiffusion) reactionDiffusion = { ...reactionDiffusion, [key]: value };
    } else if (property.startsWith('post.')) {
      const [, shaderId, param] = property.split('.');
      postShaders = (postShaders || []).map((instance) => (instance.id || instance.shaderId) === shaderId ? { ...instance, values: { ...instance.values, [param]: value as number | number[] | boolean } } : instance);
    } else if (property.startsWith('look.')) {
      const [, lookId, section, key, nested] = property.split('.');
      looks = (looks || []).map((look) => {
        if (look.id !== lookId) return look;
        if (section === 'material') return { ...look, material: { ...look.material, [key]: value } };
        if (section === 'effect') return { ...look, modifiers: (look.modifiers || []).map((effect) => effect.id === key ? { ...effect, params: { ...effect.params, [nested]: value } } : effect) };
        if (section === 'shader') return { ...look, shaders: (look.shaders || []).map((instance) => instance.shaderId === key ? { ...instance, values: { ...instance.values, [nested]: value as number | number[] | boolean } } : instance) };
        return look;
      });
    } else {
      lighting = { ...lighting, [property.startsWith('scene.') ? property.slice(6) : property]: value };
    }
  }
  return { ...project, objects, lighting, effects, fields, looks, postShaders, reactionDiffusion };
}

export function propertyLabel(path: string): string {
  return path.replace(/^scene\./, '').replace(/^modifier\.([^.]+)\./, 'modifier $1 ').replace(/\./g, ' · ').replace(/\b\w/g, (c) => c.toUpperCase());
}

export function groupObjects(project: Project, tracks: TimelineTrack[], clips: TimelineClip[]): { id: string | null; name: string; tracks: TimelineTrack[]; clips: TimelineClip[] }[] {
  const ids = [...new Set([...tracks.map((track) => track.objectId), ...clips.map((clip) => clip.objectId)])];
  return ids.map((id) => {
    const object = id ? project.objects.find((entry) => entry.id === id) : null;
    return {
      id,
      name: object?.name || (id ? id : 'Scene'),
      tracks: tracks.filter((track) => track.objectId === id),
      clips: clips.filter((clip) => clip.objectId === id),
    };
  });
}
