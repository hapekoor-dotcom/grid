import type { CatalogDevice } from '../types/catalog';
import type { Project, SceneObject } from '../types/project';
import { getDevice } from './catalog';
import { getObjectPorts, isPowerSource, effectiveWatts } from './objects';
import type { Diagnostic } from './dmx';

export interface PowerChain {
  sourceId: string;
  sourceName: string;
  sourcePort: string;
  phase: string;
  chain: string[];
}

export interface PowerRow {
  objectId: string;
  name: string;
  device: CatalogDevice | null;
  watts: number | null;
  wattsBasis: string;
  chain: PowerChain | null;
  internalBattery: boolean;
  status: 'ok' | 'unknown' | 'unpowered';
}

export interface PhaseSummary {
  sourceId: string;
  sourceName: string;
  phase: string;
  watts: number;
  unknownCount: number;
  limit: number | null;
  circuitId: string;
  overload: boolean;
}

export interface PortSummary {
  sourceId: string;
  sourceName: string;
  port: string;
  phase: string;
  watts: number;
  unknownCount: number;
  limit: number | null;
  overload: boolean;
}

export interface DistroSummary {
  objectId: string;
  name: string;
  port: string;
  watts: number;
  limit: number | null;
  overload: boolean;
}

export interface PowerResult {
  rows: PowerRow[];
  phases: PhaseSummary[];
  ports: PortSummary[];
  distros: DistroSummary[];
  diagnostics: Diagnostic[];
  totalWatts: number;
  unknownCount: number;
}

function sourcePhase(source: SceneObject, portId: string, index: number): string {
  const device = getDevice(source.deviceId);
  const configured = source.portPhases[portId];
  if (configured) return configured;
  if (device?.kind === 'battery' || device?.kind === 'solar') return 'DC';
  if (source.portPhasesThreePhase) return ['L1', 'L2', 'L3'][index % 3];
  return 'L1';
}

function incomingPower(project: Project, objectId: string): { parent: SceneObject; portId: string; toPort: string } | null {
  const connection = project.connections.find((entry) => entry.to === objectId && entry.type === 'power');
  if (!connection) return null;
  const parent = project.objects.find((object) => object.id === connection.from);
  if (!parent) return null;
  return { parent, portId: connection.fromPort, toPort: connection.toPort };
}

export function resolvePowerChain(project: Project, object: SceneObject, visited = new Set<string>()): PowerChain | null {
  if (visited.has(object.id)) return null;
  visited.add(object.id);
  const incoming = incomingPower(project, object.id);
  if (!incoming) return null;
  let cursor = incoming.parent;
  let portId = incoming.portId;
  const chain = [object.id, cursor.id];
  let guard = 0;
  while (guard++ < 24) {
    if (isPowerSource(cursor)) {
      const device = getDevice(cursor.deviceId);
      const port = getObjectPorts(cursor).find((entry) => entry.id === portId) || null;
      const outputs = getObjectPorts(cursor).filter((entry) => entry.type === 'power' && entry.direction !== 'in');
      const index = port ? outputs.findIndex((entry) => entry.id === port.id) : 0;
      return {
        sourceId: cursor.id,
        sourceName: cursor.name,
        sourcePort: portId,
        phase: sourcePhase(cursor, portId, Math.max(0, index)),
        chain,
      };
    }
    const next = incomingPower(project, cursor.id);
    if (!next) {
      // A powered device without an upstream source is not a valid root.
      const device = getDevice(cursor.deviceId);
      return device?.internalBattery
        ? { sourceId: cursor.id, sourceName: cursor.name, sourcePort: portId, phase: 'BATT', chain }
        : null;
    }
    if (visited.has(cursor.id)) return null;
    visited.add(cursor.id);
    cursor = next.parent;
    portId = next.portId;
    chain.push(cursor.id);
  }
  return null;
}

function reachableIds(project: Project, fromId: string, portId: string): string[] {
  const result = new Set<string>();
  const walk = (objectId: string, sourcePort: string) => {
    for (const connection of project.connections) {
      if (connection.type !== 'power') continue;
      if (connection.from !== objectId || connection.fromPort !== sourcePort) continue;
      if (result.has(connection.to)) continue;
      result.add(connection.to);
      const target = project.objects.find((object) => object.id === connection.to);
      if (!target || isPowerSource(target)) continue;
      for (const port of getObjectPorts(target)) {
        if (port.type === 'power' && port.direction !== 'in') walk(target.id, port.id);
      }
    }
  };
  walk(fromId, portId);
  return [...result];
}

export function computePower(project: Project): PowerResult {
  const diagnostics: Diagnostic[] = [];
  const rows: PowerRow[] = [];
  const phaseMap = new Map<string, PhaseSummary>();
  const portMap = new Map<string, PortSummary>();
  const distros: DistroSummary[] = [];
  let totalWatts = 0;
  let unknownCount = 0;

  const consumers = project.objects.filter((object) => {
    const device = getDevice(object.deviceId);
    return !!device && device.consumes && !isPowerSource(object);
  });

  for (const object of consumers) {
    const device = getDevice(object.deviceId)!;
    const chain = resolvePowerChain(project, object);
    const watts = effectiveWatts(object);
    const powered = object.fixture?.powerOn !== false;
    const internalBattery = device.internalBattery;
    const rowWatts = powered ? (watts ?? 0) : 0;
    let status: PowerRow['status'] = 'ok';
    if (!chain && !internalBattery) status = 'unpowered';
    if (watts === null && device.consumes) status = 'unknown';
    rows.push({
      objectId: object.id,
      name: object.name,
      device,
      watts,
      wattsBasis: device.wattsBasis,
      chain,
      internalBattery,
      status,
    });
    if (!powered) continue;
    if (!chain && !internalBattery) {
      diagnostics.push({
        id: `power-none-${object.id}`,
        severity: 'warning',
        area: 'power',
        code: 'no-power',
        message: `${object.name}: no power`,
        objectIds: [object.id],
        hint: 'Connect the power input to a source or distro.',
      });
      continue;
    }
    if (watts === null) {
      unknownCount += 1;
      diagnostics.push({
        id: `power-unknown-${object.id}`,
        severity: 'warning',
        area: 'power',
        code: 'unknown-watts',
        message: `${object.name}: power draw unverified`,
        objectIds: [object.id],
        hint: 'Unknown load is not counted as zero. Enter the wattage from the documentation or manually.',
      });
      continue;
    }
    totalWatts += watts;
    if (chain) {
      const phaseKey = `${chain.sourceId}:${chain.phase}`;
      const phase = phaseMap.get(phaseKey) || {
        sourceId: chain.sourceId,
        sourceName: chain.sourceName,
        phase: chain.phase,
        watts: 0,
        unknownCount: 0,
        limit: null,
        circuitId: '',
        overload: false,
      };
      phase.watts += rowWatts;
      phaseMap.set(phaseKey, phase);

      const portKey = `${chain.sourceId}:${chain.sourcePort}`;
      const port = portMap.get(portKey) || {
        sourceId: chain.sourceId,
        sourceName: chain.sourceName,
        port: chain.sourcePort,
        phase: chain.phase,
        watts: 0,
        unknownCount: 0,
        limit: null,
        overload: false,
      };
      port.watts += rowWatts;
      portMap.set(portKey, port);
    }
    if (device.wattsBasis === 'typical') {
      diagnostics.push({
        id: `power-typical-${object.id}`,
        severity: 'info',
        area: 'power',
        code: 'typical-watts',
        message: `${object.name}: using typical wattage`,
        objectIds: [object.id],
        hint: 'Maximum power draw is unverified.',
      });
    }
  }

  // Phase budgets and circuit IDs.
  for (const summary of phaseMap.values()) {
    const source = project.objects.find((object) => object.id === summary.sourceId);
    if (!source) continue;
    const limit = source.powerLimits[summary.phase];
    summary.limit = Number.isFinite(limit) && limit > 0 ? limit : null;
    summary.circuitId = source.circuitId || '';
    if (summary.limit !== null && summary.watts > summary.limit) {
      summary.overload = true;
      diagnostics.push({
        id: `power-overload-${summary.sourceId}-${summary.phase}`,
        severity: 'error',
        area: 'power',
        code: 'phase-overload',
        message: `${summary.sourceName} / ${summary.phase}: ${Math.round(summary.watts)} W > ${summary.limit} W`,
        objectIds: [summary.sourceId],
        hint: 'Reduce the load or split the circuit. The budget value is user-entered.',
      });
    } else if (summary.limit === null) {
      diagnostics.push({
        id: `power-limit-missing-${summary.sourceId}-${summary.phase}`,
        severity: 'info',
        area: 'power',
        code: 'limit-missing',
        message: `${summary.sourceName} / ${summary.phase}: power budget not set`,
        objectIds: [summary.sourceId],
        hint: 'Overload checks are not possible without a budget.',
      });
    }
  }

  // Output port limits.
  for (const summary of portMap.values()) {
    const source = project.objects.find((object) => object.id === summary.sourceId);
    if (!source) continue;
    const port = getObjectPorts(source).find((entry) => entry.id === summary.port);
    const userLimit = source.outputLimits[summary.port];
    const hardwareLimit = port?.maxWatts;
    const limit = Number.isFinite(userLimit) && userLimit > 0 ? userLimit : hardwareLimit;
    summary.limit = Number.isFinite(limit) && (limit as number) > 0 ? Number(limit) : null;
    if (summary.limit !== null && summary.watts > summary.limit) {
      summary.overload = true;
      diagnostics.push({
        id: `power-port-overload-${summary.sourceId}-${summary.port}`,
        severity: 'error',
        area: 'power',
        code: 'port-overload',
        message: `${summary.sourceName} / ${summary.port}: ${Math.round(summary.watts)} W > ${summary.limit} W`,
        objectIds: [summary.sourceId],
      });
    }
  }

  // Distro total limits and per-output limits.
  for (const object of project.objects) {
    const device = getDevice(object.deviceId);
    if (!device || device.kind !== 'distro') continue;
    const outputs = getObjectPorts(object).filter((port) => port.type === 'power' && port.direction !== 'in');
    for (const port of outputs) {
      const ids = reachableIds(project, object.id, port.id);
      const watts = ids.reduce((sum, id) => {
        const target = project.objects.find((entry) => entry.id === id);
        return sum + (target ? effectiveWatts(target) ?? 0 : 0);
      }, 0);
      const limit = object.outputLimits[port.id] ?? port.maxWatts ?? null;
      if (limit !== null && watts > limit) {
        diagnostics.push({
          id: `power-distro-port-${object.id}-${port.id}`,
          severity: 'error',
          area: 'power',
          code: 'distro-output-overload',
          message: `${object.name} / output ${port.label || port.id}: ${Math.round(watts)} W > ${limit} W`,
          objectIds: [object.id],
        });
      }
      distros.push({ objectId: object.id, name: object.name, port: port.id, watts, limit: limit || null, overload: limit !== null && watts > limit });
    }
    if (object.totalPowerLimit !== null) {
      const all = outputs.flatMap((port) => reachableIds(project, object.id, port.id));
      const unique = [...new Set(all)];
      const watts = unique.reduce((sum, id) => {
        const target = project.objects.find((entry) => entry.id === id);
        return sum + (target ? effectiveWatts(target) ?? 0 : 0);
      }, 0);
      if (watts > object.totalPowerLimit) {
        diagnostics.push({
          id: `power-distro-total-${object.id}`,
          severity: 'error',
          area: 'power',
          code: 'distro-total-overload',
          message: `${object.name}: ${Math.round(watts)} W > ${object.totalPowerLimit} W`,
          objectIds: [object.id],
        });
      }
    }
  }

  // Shared circuit IDs across independent sources.
  const byCircuit = new Map<string, PhaseSummary[]>();
  for (const summary of phaseMap.values()) {
    if (!summary.circuitId) continue;
    const list = byCircuit.get(summary.circuitId) || [];
    list.push(summary);
    byCircuit.set(summary.circuitId, list);
  }
  for (const [circuit, list] of byCircuit) {
    if (list.length < 2) continue;
    const watts = list.reduce((sum, item) => sum + item.watts, 0);
    const limits = list.map((item) => item.limit).filter((value): value is number => value !== null);
    const limit = limits.length ? Math.min(...limits) : null;
    if (limit !== null && watts > limit) {
      diagnostics.push({
        id: `power-circuit-${circuit}`,
        severity: 'error',
        area: 'power',
        code: 'circuit-overload',
        message: `Circuit ${circuit}: ${Math.round(watts)} W > ${limit} W`,
        objectIds: list.map((item) => item.sourceId),
      });
    }
    if (limit === null) {
      diagnostics.push({
        id: `power-circuit-limit-${circuit}`,
        severity: 'info',
        area: 'power',
        code: 'circuit-limit-missing',
        message: `Circuit ${circuit}: budget not set`,
        objectIds: list.map((item) => item.sourceId),
      });
    }
  }

  for (const source of project.objects.filter(isPowerSource)) {
    const device = getDevice(source.deviceId);
    const outputs = getObjectPorts(source).filter((port) => port.type === 'power' && port.direction !== 'in');
    if (source.portPhasesThreePhase) {
      const unassigned = outputs.filter((port) => !source.portPhases[port.id]);
      if (unassigned.length) {
        diagnostics.push({
          id: `power-phases-${source.id}`,
          severity: 'warning',
          area: 'power',
          code: 'phases-unassigned',
          message: `${source.name}: assign phases for ${unassigned.length} outputs`,
          objectIds: [source.id],
          hint: 'Each output defaults to L1; this does not confirm phase distribution.',
        });
      }
    }
    if (device?.kind === 'outlet' && !source.circuitId) {
      diagnostics.push({
        id: `power-circuit-missing-${source.id}`,
        severity: 'info',
        area: 'power',
        code: 'circuit-missing',
        message: `${source.name}: electrical circuit ID not set`,
        objectIds: [source.id],
        hint: 'The ID groups multiple sources on one circuit.',
      });
    }
  }

  return {
    rows,
    phases: [...phaseMap.values()].sort((a, b) => a.sourceName.localeCompare(b.sourceName, 'ru') || a.phase.localeCompare(b.phase)),
    ports: [...portMap.values()],
    distros,
    diagnostics,
    totalWatts,
    unknownCount,
  };
}
