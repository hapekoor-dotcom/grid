import { describe, expect, it } from 'vitest';
import type { Project, SceneObject } from '../types/project';
import { createModifier } from './modifiers';
import { effectiveModifiers, modulatedParams, normalizeEffectGroups, normalizeSignals, signalValue } from './signals';

const object = { id: 'o1', type: 'model', name: 'Object', deviceId: null, position: { x: 0, z: 0 }, rotation: 0, elevation: 0 } as SceneObject;

function project(): Project {
  return {
    id: 'p', name: 'Test', schemaVersion: 5, createdAt: '', updatedAt: '', settings: {} as Project['settings'],
    objects: [object], connections: [], guides: [], lighting: {} as Project['lighting'], view: {} as Project['view'],
    migration: null, timeline: { duration: 10, loop: true, tracks: [], clips: [], groupEffects: [] },
    signals: [], effects: [], effectGroups: [],
  };
}

describe('signal engine', () => {
  it('evaluates periodic signals', () => {
    const sine = normalizeSignals([{ id: 's', name: 'Sine', kind: 'sine', enabled: true, params: { speed: 1, amplitude: 1, offset: 0, phase: 0 } }])[0];
    expect(signalValue(sine, project(), 0)).toBeCloseTo(0, 5);
    expect(signalValue(sine, project(), 0.25)).toBeCloseTo(1, 5);
    expect(signalValue(sine, project(), 0.75)).toBeCloseTo(-1, 5);
  });

  it('applies modulators without mutating the base parameter', () => {
    const base = createModifier('domainWarp');
    base.params.strength = 0.5;
    base.modulators = { strength: { sourceId: 's', amount: 0.5, offset: 0, enabled: true } };
    const p = project();
    p.signals = normalizeSignals([{ id: 's', name: 'Sine', kind: 'sine', enabled: true, params: { speed: 1, amplitude: 1, phase: 0 } }]);
    expect(Number(modulatedParams(base, p, 0).strength)).toBeCloseTo(0.5, 5);
    expect(Number(modulatedParams(base, p, 0.25).strength)).toBeCloseTo(1, 5);
    expect(base.params.strength).toBe(0.5);
  });

  it('shares one modifier stack across group targets', () => {
    const p = project();
    p.effectGroups = normalizeEffectGroups([{ id: 'g', name: 'Shared', enabled: true, targetIds: ['o1'], modifiers: [createModifier('liquidChrome')] }]);
    expect(effectiveModifiers(object, p)).toHaveLength(1);
    expect(effectiveModifiers(object, p)[0].type).toBe('liquidChrome');
  });

  it('normalizes legacy signal data', () => {
    expect(normalizeSignals(null)).toEqual([]);
    expect(normalizeEffectGroups([{ id: 'g', targetIds: ['o1'], modifiers: [{ type: 'melt', enabled: true, params: {} }] }])[0].modifiers[0].type).toBe('melt');
  });
});

it('evaluates modifier output modulation sources', async () => {
  const { modulatedParams, defaultModulator } = await import('./signals');
  const { createModifier } = await import('./modifiers');
  const { modifierOutputValue } = await import('./modifierOutputs');
  const project = {
    objects: [{ id: 'o', type: 'model', position: { x: 0, z: 0 }, elevation: 0, lookId: undefined, modifiers: [] }],
    effects: [],
    looks: [],
    signals: [],
  } as any;
  const attractor = { ...createModifier('attractorField'), id: 'attractor', enabled: true, params: { ...createModifier('attractorField').params, pointX: 3, pointY: 0, pointZ: 4, radius: 10, strength: 1, falloff: 1 } };
  project.objects[0].modifiers = [attractor];
  const target = { ...createModifier('ripple'), id: 'ripple', enabled: true, params: { ...createModifier('ripple').params, strength: 0.2 }, modulators: { strength: { ...defaultModulator('attractor', 'modifier', 'distance'), amount: 0.01 } } };
  expect(modifierOutputValue(attractor, 'distance', project, 0, project.objects[0])).toBe(5);
  expect(Number(modulatedParams(target, project, 0, project.objects[0]).strength)).toBeCloseTo(0.25, 5);
});

it('applies graph adapters before modulation amount', async () => {
  const { modulatedParams, defaultModulator } = await import('./signals');
  const { createModifier } = await import('./modifiers');
  const modifier = { ...createModifier('twist'), id: 'twist', enabled: true, params: { ...createModifier('twist').params, amount: 10 }, modulators: { amount: { ...defaultModulator('s1'), amount: 1, adapter: { kind: 'multiply', params: { factor: 2 } } } } };
  const project = { signals: [{ id: 's1', name: 'Sine', kind: 'sine', enabled: true, params: { frequency: 1, amplitude: 0.5, phase: 0 } }], objects: [], effects: [], looks: [] } as any;
  const value = Number(modulatedParams(modifier, project, 0.25, null).amount);
  expect(value).not.toBe(10);
});
