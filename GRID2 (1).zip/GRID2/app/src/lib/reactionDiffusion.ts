import type { Project, ReactionDiffusionConfig } from '../types/project';
import { findSignal, signalValue } from './signals';

export const RD_PRESETS: Record<string, { label: string; feed: number; kill: number; diffusionA: number; diffusionB: number }> = {
  cells: { label: 'Cells', feed: 0.0367, kill: 0.0649, diffusionA: 1, diffusionB: 0.5 },
  coral: { label: 'Coral', feed: 0.0545, kill: 0.062, diffusionA: 1, diffusionB: 0.5 },
  worms: { label: 'Worms', feed: 0.078, kill: 0.061, diffusionA: 1, diffusionB: 0.5 },
  maze: { label: 'Maze', feed: 0.029, kill: 0.057, diffusionA: 1, diffusionB: 0.5 },
  spots: { label: 'Spots', feed: 0.03, kill: 0.062, diffusionA: 1, diffusionB: 0.5 },
  waves: { label: 'Waves', feed: 0.014, kill: 0.054, diffusionA: 1, diffusionB: 0.5 },
  skin: { label: 'Skin', feed: 0.02, kill: 0.05, diffusionA: 1, diffusionB: 0.5 },
  cracks: { label: 'Cracks', feed: 0.039, kill: 0.058, diffusionA: 1, diffusionB: 0.5 },
  organism: { label: 'Organism', feed: 0.046, kill: 0.063, diffusionA: 1, diffusionB: 0.5 },
  chaos: { label: 'Chaos', feed: 0.026, kill: 0.051, diffusionA: 1, diffusionB: 0.5 },
};

export function defaultReactionDiffusion(): ReactionDiffusionConfig {
  return {
    id: 'rd_main',
    enabled: true,
    paused: false,
    preset: 'cells',
    ...RD_PRESETS.cells,
    timeStep: 1,
    speed: 12,
    iterations: 8,
    resolution: 256,
    seed: 1,
    contrast: 1.2,
    threshold: 0.22,
    invert: false,
    injection: 0,
    injectionRadius: 0.12,
    paintChemical: 'B',
    resetToken: 0,
  };
}

export function normalizeReactionDiffusion(value: unknown): ReactionDiffusionConfig {
  const base = defaultReactionDiffusion();
  if (!value || typeof value !== 'object') return base;
  const raw = value as Partial<ReactionDiffusionConfig>;
  return {
    ...base,
    ...raw,
    feed: finite(raw.feed, base.feed, 0, 0.1),
    kill: finite(raw.kill, base.kill, 0, 0.1),
    diffusionA: finite(raw.diffusionA, base.diffusionA, 0.05, 2),
    diffusionB: finite(raw.diffusionB, base.diffusionB, 0.05, 1.5),
    timeStep: finite(raw.timeStep, base.timeStep, 0.1, 2),
    speed: finite(raw.speed, base.speed, 0, 120),
    iterations: Math.round(finite(raw.iterations, base.iterations, 1, 64)),
    resolution: [64, 128, 192, 256, 384, 512, 768, 1024].includes(Number(raw.resolution)) ? Number(raw.resolution) : base.resolution,
    contrast: finite(raw.contrast, base.contrast, 0.1, 8),
    threshold: finite(raw.threshold, base.threshold, 0, 1),
    injection: finite(raw.injection, base.injection, 0, 1),
    injectionRadius: finite(raw.injectionRadius, base.injectionRadius, 0.01, 1),
  };
}

function finite(value: unknown, fallback: number, min: number, max: number): number {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
}

const RD_RANGES: Record<string, [number, number]> = {
  feed: [0, 0.1], kill: [0, 0.1], diffusionA: [0.05, 2], diffusionB: [0.05, 1.5], timeStep: [0.1, 2], speed: [0, 120], iterations: [1, 64], contrast: [0.1, 8], threshold: [0, 1], injection: [0, 1], injectionRadius: [0.01, 1],
};

export function modulatedReactionDiffusion(config: ReactionDiffusionConfig, project: Project | null, time: number): ReactionDiffusionConfig {
  if (!config.modulators || !Object.keys(config.modulators).length) return config;
  const next = { ...config };
  for (const [key, modulator] of Object.entries(config.modulators)) {
    if (!modulator?.enabled) continue;
    const source = findSignal(project, modulator.sourceId);
    const range = RD_RANGES[key];
    if (!source || !range) continue;
    const base = Number((next as unknown as Record<string, number>)[key] ?? 0);
    const value = base + Number(modulator.offset ?? 0) + signalValue(source, project, time, null) * Number(modulator.amount ?? 0);
    (next as unknown as Record<string, number>)[key] = Math.max(range[0], Math.min(range[1], value));
  }
  return next;
}

export function rdPreset(preset: string): ReactionDiffusionConfig {
  const definition = RD_PRESETS[preset] || RD_PRESETS.cells;
  return { ...defaultReactionDiffusion(), preset, feed: definition.feed, kill: definition.kill, diffusionA: definition.diffusionA, diffusionB: definition.diffusionB };
}
