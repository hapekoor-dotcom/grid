let sampleProvider: ((output: string) => number) | null = null;

export function setReactionSampleProvider(provider: ((output: string) => number) | null): void {
  sampleProvider = provider;
}

export function sampleReactionOutput(output: string): number {
  return sampleProvider ? sampleProvider(output) : 0;
}
