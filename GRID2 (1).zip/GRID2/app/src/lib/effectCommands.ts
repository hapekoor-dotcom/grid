import type { EffectGroup, ParameterModulator, Project, SceneModifier, SignalSourceKind } from '../types/project';
import { useWorkspaceStore } from '../store/workspaceStore';
import { createModifier, modifierDefinition } from './modifiers';
import { defaultModulator, defaultSignal } from './signals';
import { EFFECT_PRESETS } from './effectPresets';

function projectOf(): Project | undefined {
  const state = useWorkspaceStore.getState();
  return state.projects.find((entry) => entry.id === state.activeId);
}

function edit(recipe: (project: Project) => void): void {
  useWorkspaceStore.getState().mutate(recipe);
}

export const effectCommands = {
  addSignal(kind: SignalSourceKind = 'sine', name?: string): string {
    const signal = defaultSignal(kind);
    if (name) signal.name = name;
    edit((draft) => { draft.signals = [...(draft.signals || []), signal]; });
    return signal.id;
  },

  updateSignal(signalId: string, patch: { name?: string; enabled?: boolean; kind?: SignalSourceKind; params?: Record<string, number | string | boolean> }): void {
    edit((draft) => { draft.signals = (draft.signals || []).map((signal) => signal.id === signalId ? { ...signal, ...patch, params: patch.params || signal.params } : signal); });
  },

  removeSignal(signalId: string): void {
    edit((draft) => {
      draft.signals = (draft.signals || []).filter((signal) => signal.id !== signalId);
      for (const modifier of [...(draft.effects || []), ...(draft.effectGroups || []).flatMap((group) => group.modifiers)]) {
        if (!modifier.modulators) continue;
        for (const [key, modulator] of Object.entries(modifier.modulators)) if (modulator.sourceId === signalId) delete modifier.modulators[key];
      }
      for (const object of draft.objects) for (const modifier of object.modifiers || []) {
        if (!modifier.modulators) continue;
        for (const [key, modulator] of Object.entries(modifier.modulators)) if (modulator.sourceId === signalId) delete modifier.modulators[key];
      }
    });
  },

  bindModulator(target: { objectId?: string; groupId?: string; sceneEffectId?: string }, modifierId: string, param: string, sourceId: string, amount = 0.25, offset = 0): void {
    edit((draft) => {
      let modifier: SceneModifier | undefined;
      if (target.groupId) modifier = draft.effectGroups?.find((group) => group.id === target.groupId)?.modifiers.find((entry) => entry.id === modifierId);
      else if (target.sceneEffectId) modifier = draft.effects?.find((entry) => entry.id === target.sceneEffectId);
      else modifier = draft.objects.find((object) => object.id === target.objectId)?.modifiers?.find((entry) => entry.id === modifierId);
      if (!modifier) return;
      const modulator: ParameterModulator = { ...defaultModulator(sourceId), amount, offset };
      modifier.modulators = { ...(modifier.modulators || {}), [param]: modulator };
    });
  },

  unbindModulator(target: { objectId?: string; groupId?: string; sceneEffectId?: string }, modifierId: string, param: string): void {
    edit((draft) => {
      const modifier = target.groupId
        ? draft.effectGroups?.find((group) => group.id === target.groupId)?.modifiers.find((entry) => entry.id === modifierId)
        : target.sceneEffectId
          ? draft.effects?.find((entry) => entry.id === target.sceneEffectId)
          : draft.objects.find((object) => object.id === target.objectId)?.modifiers?.find((entry) => entry.id === modifierId);
      if (modifier?.modulators) delete modifier.modulators[param];
    });
  },

  setEffectParam(target: { objectId?: string; groupId?: string; sceneEffectId?: string }, modifierId: string, param: string, value: number | string | boolean): void {
    edit((draft) => {
      const modifier = target.groupId
        ? draft.effectGroups?.find((group) => group.id === target.groupId)?.modifiers.find((entry) => entry.id === modifierId)
        : target.sceneEffectId
          ? draft.effects?.find((entry) => entry.id === target.sceneEffectId)
          : draft.objects.find((object) => object.id === target.objectId)?.modifiers?.find((entry) => entry.id === modifierId);
      if (modifier) modifier.params = { ...modifier.params, [param]: value };
    });
  },

  addField(type: string): string {
    const modifier = createModifier(type);
    edit((draft) => { draft.fields = [...(draft.fields || []), modifier]; });
    return modifier.id;
  },

  setFieldParam(fieldId: string, param: string, value: number | string | boolean): void {
    edit((draft) => {
      const field = draft.fields?.find((entry) => entry.id === fieldId);
      if (field) field.params = { ...field.params, [param]: value };
    });
  },

  createSharedStack(targetIds: string[], name = 'Shared effect'): string {
    const group: EffectGroup = { id: `grp_${crypto.randomUUID()}`, name, enabled: true, targetIds: [...targetIds], modifiers: [] };
    edit((draft) => { draft.effectGroups = [...(draft.effectGroups || []), group]; });
    return group.id;
  },

  addEffectToStack(groupId: string, type: string): string {
    const modifier = createModifier(type);
    edit((draft) => {
      const group = draft.effectGroups?.find((entry) => entry.id === groupId);
      if (group) group.modifiers = [...group.modifiers, modifier];
    });
    return modifier.id;
  },

  applyPreset(targetIds: string[], presetId: string): string {
    const preset = EFFECT_PRESETS.find((entry) => entry.id === presetId);
    const group: EffectGroup = {
      id: `grp_${crypto.randomUUID()}`,
      name: preset?.label || 'Preset',
      enabled: true,
      targetIds: [...targetIds],
      modifiers: (preset?.stack || []).map((entry) => ({ ...createModifier(entry.type), params: { ...modifierDefinition(entry.type).defaults, ...(entry.params || {}) } })),
    };
    edit((draft) => { draft.effectGroups = [...(draft.effectGroups || []), group]; });
    return group.id;
  },

  sharedStack(groupId: string): EffectGroup | undefined {
    return projectOf()?.effectGroups?.find((group) => group.id === groupId);
  },
};
