import { normalizeMaterial, normalizeMaterialOverrides } from './materialMaps';
import { normalizeGroupEffects } from './groupEffects';
import { normalizeEffectGroups, normalizeModifiers, normalizeSignals } from './signals';
import { normalizeCollision, normalizeObjectPhysics, normalizePhysics } from './physics';
import { normalizeReactionDiffusion } from './reactionDiffusion';
import { normalizeCustomShaders } from './customShaders';
import type { Connection, LightState, Project, SceneObject, WorkspaceFile } from '../types/project';
import { getDevice, getMode, portsOf } from './catalog';
import { uid } from './id';
import { DEFAULT_LIGHTING, DEFAULT_SETTINGS } from './project';
import { createRoom, createSceneObject, createSeating, createStage, snapObjectToGrid } from './objects';

const LEGACY_SCALE = 120; // legacy 24 px = 200 mm → 120 px per metre

const LEGACY_AREA_TYPES: Record<string, string> = {
  stage: 'Stage',
  dancefloor: 'Dancefloor',
  bar: 'Bar',
  ledWall: 'LED wall',
  sound: 'Sound',
  hall: 'Hall',
  foh: 'FOH',
  backstage: 'Backstage',
};

function legacyCardSize(node: any): { w: number; h: number } {
  const outputs = Math.max(1, Number(node.outputs) || 1);
  if (node.kind === 'battery') return { w: (outputs + 1) * 24, h: 120 };
  if (node.kind === 'console') return { w: Math.max(192, outputs * 24 + 72), h: 168 };
  if (['bar', 'pixel', 'strobe'].includes(node.kind)) return { w: 72, h: 168 };
  if (node.model === 'wall-outlet') return { w: 72, h: 72 };
  if (node.kind === 'outlet') return { w: 48 * Math.ceil(outputs / 4), h: (Math.min(4, outputs) + 3) * 24 };
  if (['node', 'switch', 'splitter', 'interface'].includes(node.kind)) return { w: Math.max(264, (outputs + 3) * 24), h: 168 };
  return { w: 192, h: 168 };
}

function legacyGroupId(): string {
  return uid('mig');
}

export interface MigrationResult {
  project: Project;
  warnings: string[];
}

export function migrateLegacy(raw: any, fallbackName = 'Imported project'): MigrationResult {
  const warnings: string[] = [];
  if (!raw || !Array.isArray(raw.nodes)) throw new Error('The file has no object array');
  const now = new Date().toISOString();
  const gridSize = [0.1, 0.25, 0.5, 1].includes(raw.settings?.gridSize) ? raw.settings.gridSize : DEFAULT_SETTINGS.gridSize;
  const objects: SceneObject[] = [];
  const objectIds = new Map<string, string>();
  const groupId = legacyGroupId();

  for (const node of raw.nodes) {
    if (!node || typeof node.id !== 'string') {
      warnings.push('Skipped an object without an ID.');
      continue;
    }
    const deviceId = node.model || ({ bar: 'ubl12h', head: 'focusflex', node: 'xnd8', power: 'outlet' } as Record<string, string>)[node.type];
    const device = getDevice(deviceId);
    if (!device) {
      warnings.push(`Model "${deviceId}" was not found in the catalog; object "${node.name || node.id}" was skipped.`);
      continue;
    }
    const legacySize = legacyCardSize(node);
    const position = {
      x: (Number(node.x) + legacySize.w / 2) / LEGACY_SCALE,
      z: (Number(node.y) + legacySize.h / 2) / LEGACY_SCALE,
    };
    if (!Number.isFinite(position.x) || !Number.isFinite(position.z)) {
      warnings.push(`Object "${node.name || node.id}" has invalid coordinates and was skipped.`);
      continue;
    }
    const mode = Array.isArray(device.modes) ? device.modes.find((entry) => entry.id === node.modeId) : null;
    const modeByChannels = !mode && node.channels ? device.modes.find((entry) => entry.channels === Number(node.channels)) : null;
    const effectiveMode = mode || modeByChannels || getMode(device, device.defaultModeId);
    const scene = createSceneObject(device.id, position, {
      name: String(node.name || device.shortName).slice(0, 80),
      rotation: [0, 90, 180, 270].includes(node.rotation) ? node.rotation : 0,
      mount: node.mountLevel === 'ceiling' ? 'ceiling' : 'floor',
      elevation: node.mountLevel === 'ceiling' ? 4.5 : 0,
      outputs: Number.isFinite(Number(node.outputs)) ? Number(node.outputs) : null,
    });
    objectIds.set(node.id, scene.id);
    scene.fixture = scene.fixture
      ? {
          modeId: effectiveMode?.id || null,
          universe: 1,
          address: Number.isInteger(node.manual) ? node.manual : Number.isInteger(node.address) ? node.address : null,
          manualAddress: !!node.manual,
          customChannels: Number.isInteger(node.customChannels) ? node.customChannels : null,
          wattsOverride: node.wattsBasis === 'user' && Number.isFinite(Number(node.watts)) ? Number(node.watts) : null,
          powerOn: node.powerOff !== true,
        }
      : null;
    scene.dmxSourceUniverses = { ...(node.dmxSourceUniverses || {}) };
    // The old project stored source universes as an array keyed by output index.
    if (device.dmx && Array.isArray(node.universes)) {
      const outputs = portsOf(device).filter((port) => port.type === 'dmx' && port.direction !== 'in');
      outputs.forEach((port, index) => {
        if (Number.isInteger(node.universes[index])) scene.dmxSourceUniverses[port.id] = node.universes[index];
      });
    }
    scene.portDirections = { ...(node.portDirections || {}) };
    scene.portPhases = { ...(node.phases || {}) };
    scene.portPhasesThreePhase = !!node.threePhase;
    scene.powerLimits = { ...(node.limits || {}) };
    scene.outputLimits = { ...(node.outputLimits || {}) };
    scene.totalPowerLimit = Number.isFinite(Number(node.totalLimit)) ? Number(node.totalLimit) : null;
    scene.circuitId = String(node.circuit || '');
    scene.notes = String(node.notes || '');
    scene.groupId = node.groupId || groupId;
    if (scene.type === 'stage' && node.type) {
      scene.name = String(node.name || LEGACY_AREA_TYPES[node.type] || device.shortName);
    }
    objects.push(scene);
  }

  let hasRoom = false;
  if (Array.isArray(raw.areas)) {
    for (const area of raw.areas) {
      if (!area || !Number.isFinite(area.x) || !Number.isFinite(area.y) || !Number.isFinite(area.w) || !Number.isFinite(area.h)) continue;
      const position = {
        x: (area.x + area.w / 2) / LEGACY_SCALE,
        z: (area.y + area.h / 2) / LEGACY_SCALE,
      };
      const width = Math.max(0.5, area.w / LEGACY_SCALE);
      const depth = Math.max(0.5, area.h / LEGACY_SCALE);
      const name = String(area.name || LEGACY_AREA_TYPES[area.type] || 'Zone');
      if (area.type === 'room') {
        const room = createRoom(position, { w: width, d: depth }, 4.5, name);
        room.room = { wallHeight: 4.5, walls: true, floorColor: '#6f6b63', wallColor: '#74736d' };
        objects.push(room);
        hasRoom = true;
        continue;
      }
      if (area.type === 'stage') {
        const stage = createStage(position, { w: width, d: depth, h: 0.45 }, name);
        objects.push(stage);
        continue;
      }
      if (area.type === 'seating') {
        const seating = createSeating(position, { w: width, d: depth }, name);
        objects.push(seating);
        continue;
      }
      const scene = createSceneObject('stage-deck', position, {
        name,
        size: { w: width, d: depth, h: 0.2 },
        elevation: 0.2,
      });
      scene.type = 'stage';
      scene.deviceId = null;
      scene.stage = { color: '#242a30', label: name };
      scene.size = { w: width, d: depth, h: 0.2 };
      objects.push(scene);
    }
  }

  const connections: Connection[] = [];
  if (Array.isArray(raw.edges)) {
    for (const edge of raw.edges) {
      const from = objectIds.get(edge.from);
      const to = objectIds.get(edge.to);
      if (!from || !to || !edge.type) {
        warnings.push(`Cable ${edge.id || ''} skipped: object or type not found.`);
        continue;
      }
      connections.push({
        id: uid('cbl'),
        type: edge.type,
        from,
        fromPort: String(edge.port || ''),
        to,
        toPort: String(edge.toPort || `${edge.type}In`),
        waypoints: Array.isArray(edge.points)
          ? edge.points
              .filter((point: any) => Number.isFinite(point.x) && Number.isFinite(point.y))
              .map((point: any) => ({ x: point.x / LEGACY_SCALE, z: point.y / LEGACY_SCALE }))
          : [],
        note: String(edge.note || ''),
      });
    }
  }

  const guides = Array.isArray(raw.guides)
    ? raw.guides
        .filter((guide: any) => guide && ['x', 'y'].includes(guide.axis) && Number.isFinite(guide.value))
        .map((guide: any) => ({ id: uid('gd'), axis: guide.axis === 'x' ? 'x' : 'z', position: guide.value / LEGACY_SCALE }))
    : [];

  const project: Project = {
    schemaVersion: 5,
    id: uid('prj'),
    name: String(raw.name || fallbackName).slice(0, 120),
    createdAt: now,
    updatedAt: now,
    settings: { ...DEFAULT_SETTINGS },
    objects,
    connections,
    guides,
    effects: [],
    customShaders: [],
    postShaders: [],
    fields: [],
    looks: [],
    signals: [],
    effectGroups: [],
    physics: normalizePhysics(raw.physics),
    timeline: { duration: 10, loop: true, tracks: [], clips: [], groupEffects: [] },
    lighting: {
      ...DEFAULT_LIGHTING,
      groups: [],
      presets: [],
      haze: clampNumber(raw.previewSettings?.haze, 0, 2, DEFAULT_LIGHTING.haze),
      master: clampNumber(raw.previewSettings?.master, 0, 10, DEFAULT_LIGHTING.master),
      ambient: clampNumber(raw.previewSettings?.ambient, 0, 1, DEFAULT_LIGHTING.ambient),
    },
    view: { plan: { panX: 0, panY: 0, zoom: 0 }, camera3d: null },
    migration: {
      fromVersion: Number(raw.version) || 4,
      importedAt: now,
      warnings,
      importedObjects: objects.length,
      importedConnections: connections.length,
    },
  };

  // Older exports sometimes omitted the room area entirely. Only derive one
  // when the file did not carry a real room.
  if (!hasRoom && objects.length) {
    const xs = objects.map((object) => object.position.x);
    const zs = objects.map((object) => object.position.z);
    const minX = Math.min(...xs) - 3;
    const maxX = Math.max(...xs) + 3;
    const minZ = Math.min(...zs) - 2.5;
    const maxZ = Math.max(...zs) + 2.5;
    project.objects.unshift({
      ...createSceneObject('stage-deck', { x: (minX + maxX) / 2, z: (minZ + maxZ) / 2 }, {}),
      id: uid('room'),
      type: 'room',
      name: 'Venue (reconstructed)',
      deviceId: null,
      size: { w: Math.max(6, maxX - minX), d: Math.max(5, maxZ - minZ), h: 4.5 },
      room: { wallHeight: 4.5, walls: true, floorColor: '#6f6b63', wallColor: '#74736d' },
      stage: null,
      fixture: null,
      light: null,
      elevation: 0,
      mount: 'floor',
    });
    warnings.push('The venue boundaries were not saved in the old version: a venue was created around the equipment. Check the dimensions.');
  }
  return { project, warnings };
}

function sanitizeLight(input: any, fallback: LightState): LightState {
  if (!input || typeof input !== 'object') return fallback;
  return {
    on: input.on !== false,
    intensity: clampNumber(input.intensity, 0, 10, fallback.intensity),
    color: typeof input.color === 'string' && /^#[0-9a-f]{6}$/i.test(input.color) ? input.color : fallback.color,
    colorTemp: clampNumber(input.colorTemp, 2000, 12000, fallback.colorTemp),
    pan: clampNumber(input.pan, -360, 360, fallback.pan),
    tilt: clampNumber(input.tilt, -90, 90, fallback.tilt),
    zoom: clampNumber(input.zoom, 1, 120, fallback.zoom),
    strobe: clampNumber(input.strobe, 0, 30, fallback.strobe),
    focus: clampNumber(input.focus, 0, 1, fallback.focus),
    segments: Array.isArray(input.segments)
      ? input.segments.slice(0, 16).map((segment: any) => ({
          intensity: clampNumber(segment?.intensity, 0, 10, 1),
          color: typeof segment?.color === 'string' && /^#[0-9a-f]{6}$/i.test(segment.color) ? segment.color : undefined,
        }))
      : null,
  };
}

function clampNumber(input: any, min: number, max: number, fallback: number): number {
  const value = Number(input);
  if (!Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}

export interface ValidationResult {
  project: Project;
  warnings: string[];
}

export function validateProject(raw: any): ValidationResult {
  const warnings: string[] = [];
  if (!raw || typeof raw !== 'object') throw new Error('Project data is not an object');
  if (!Array.isArray(raw.objects)) throw new Error('The project contains no object array');
  if (raw.schemaVersion !== 5) {
    if (Array.isArray(raw.nodes)) return { ...migrateLegacy(raw), warnings: ['Legacy project format detected. Conversion complete.'] };
    warnings.push(`Unknown schema version: ${raw.schemaVersion}. The project was read as version 5.`);
  }
  const now = new Date().toISOString();
  const gridSize = [0.1, 0.25, 0.5, 1].includes(raw.settings?.gridSize) ? raw.settings.gridSize : DEFAULT_SETTINGS.gridSize;
  const objects: SceneObject[] = [];
  const ids = new Set<string>();
  for (const input of raw.objects) {
    if (!input || typeof input.id !== 'string' || ids.has(input.id)) {
      warnings.push('Skipped an object with an invalid or duplicate ID.');
      continue;
    }
    ids.add(input.id);
    const device = getDevice(input.deviceId);
    if (input.type === 'device' && !device) warnings.push(`Device "${input.deviceId}" was not found in the catalog; its body is preserved.`);
    const type = ['device', 'room', 'stage', 'truss', 'furniture', 'seating', 'crowd', 'areabar', 'model', 'light'].includes(input.type) ? input.type : 'device';
    const rotation = Number.isFinite(Number(input.rotation)) ? ((Number(input.rotation) % 360) + 360) % 360 : 0;
    const fixture = device && input.fixture
      ? {
          modeId: typeof input.fixture.modeId === 'string' ? input.fixture.modeId : device.defaultModeId,
          universe: Math.max(1, Math.round(clampNumber(input.fixture.universe, 1, 32768, 1))),
          address: Number.isInteger(input.fixture.address) ? input.fixture.address : null,
          manualAddress: !!input.fixture.manualAddress,
          customChannels: Number.isInteger(input.fixture.customChannels) ? Math.max(1, Math.min(512, input.fixture.customChannels)) : null,
          wattsOverride: Number.isFinite(Number(input.fixture.wattsOverride)) ? Math.max(0, Number(input.fixture.wattsOverride)) : null,
          powerOn: input.fixture.powerOn !== false,
        }
      : null;
    const fallbackLight = (device && ['light', 'effects'].includes(device.category)) || type === 'light'
      ? { on: true, intensity: 0.8, color: '#ffffff', colorTemp: 5600, pan: 0, tilt: 0, zoom: 20, strobe: 0, focus: 0.5 }
      : null;
    const object: SceneObject = {
      id: input.id,
      type,
      name: String(input.name || device?.shortName || 'Object').slice(0, 120),
      deviceId: device?.id || (typeof input.deviceId === 'string' ? input.deviceId : null),
      position: {
        x: clampNumber(input.position?.x, -10000, 10000, 0),
        z: clampNumber(input.position?.z, -10000, 10000, 0),
      },
      rotation,
      rotationX: clampNumber(input.rotationX, -3600, 3600, 0),
      rotationZ: clampNumber(input.rotationZ, -3600, 3600, 0),
      scale: input.scale && [input.scale.x, input.scale.y, input.scale.z].every((value: any) => Number.isFinite(Number(value)) && Number(value) > 0)
        ? { x: Math.max(0.001, Number(input.scale.x)), y: Math.max(0.001, Number(input.scale.y)), z: Math.max(0.001, Number(input.scale.z)) }
        : { x: 1, y: 1, z: 1 },
      modelVisible: input.modelVisible !== false,
      assetId: typeof input.assetId === 'string' ? input.assetId : null,
      assetName: typeof input.assetName === 'string' ? input.assetName : null,
      lightType: ['spot', 'point', 'area', 'directional'].includes(input.lightType) ? input.lightType : (type === 'light' ? 'spot' : undefined),
      range: clampNumber(input.range, 0.1, 500, type === 'light' ? 16 : 16),
      volumetric: clampNumber(input.volumetric, 0, 10, 0.25),
      beamInner: clampNumber(input.beamInner, 0.1, 89, 30),
      beamOuter: clampNumber(input.beamOuter, 1, 89, 60),
      castShadows: input.castShadows !== false,
      receiveShadows: input.receiveShadows !== false,
      material: normalizeMaterial(input.material),
      materialOverrides: normalizeMaterialOverrides(input.materialOverrides),
      materialSlots: Array.isArray(input.materialSlots) ? input.materialSlots.filter((slot: any) => typeof slot === 'string') : [],
      primitive: input.primitive && ['box', 'sphere', 'cylinder', 'plane', 'cone', 'torus'].includes(input.primitive.kind)
        ? { kind: input.primitive.kind, params: input.primitive.params && typeof input.primitive.params === 'object' ? input.primitive.params : {} }
        : null,
      modifiers: normalizeModifiers(input.modifiers),
      physics: normalizeObjectPhysics(input.physics),
      collision: normalizeCollision(input.collision),
      lookId: typeof input.lookId === 'string' ? input.lookId : undefined,
      shaders: Array.isArray(input.shaders) ? input.shaders : undefined,
      elevation: clampNumber(input.elevation, -10, 200, 0),
      size: input.size && [input.size.w, input.size.d, input.size.h].every((value: any) => Number.isFinite(Number(value)))
        ? { w: Math.max(0.05, Number(input.size.w)), d: Math.max(0.05, Number(input.size.d)), h: Math.max(0.01, Number(input.size.h)) }
        : null,
      mount: ['floor', 'stage', 'truss', 'ceiling', 'wall'].includes(input.mount) ? input.mount : 'floor',
      visible: input.visible !== false,
      locked: !!input.locked,
      groupId: typeof input.groupId === 'string' ? input.groupId : null,
      room: input.room && typeof input.room === 'object'
        ? { wallHeight: clampNumber(input.room.wallHeight, 0.5, 50, 4.5), walls: input.room.walls !== false, floorColor: typeof input.room.floorColor === 'string' ? input.room.floorColor : '#6f6b63', wallColor: typeof input.room.wallColor === 'string' ? input.room.wallColor : '#74736d' }
        : type === 'room' ? { wallHeight: 4.5, walls: true, floorColor: '#6f6b63', wallColor: '#74736d' } : null,
      stage: input.stage && typeof input.stage === 'object' ? { color: String(input.stage.color || '#242a30'), label: String(input.stage.label || '') } : type === 'stage' ? { color: '#242a30', label: '' } : null,
      seating: type === 'seating'
        ? {
            rows: Math.max(1, Math.min(80, Math.round(clampNumber(input.seating?.rows, 1, 80, 3)))),
            columns: Math.max(1, Math.min(80, Math.round(clampNumber(input.seating?.columns, 1, 80, 5)))),
            seatPitch: clampNumber(input.seating?.seatPitch, 0.35, 1.5, 0.62),
            rowPitch: clampNumber(input.seating?.rowPitch, 0.5, 2.5, 0.95),
          }
        : null,
      fixture,
      light: fallbackLight ? sanitizeLight(input.light, fallbackLight) : null,
      dmxSourceUniverses: input.dmxSourceUniverses && typeof input.dmxSourceUniverses === 'object' ? { ...input.dmxSourceUniverses } : {},
      portDirections: input.portDirections && typeof input.portDirections === 'object' ? { ...input.portDirections } : {},
      portPhases: input.portPhases && typeof input.portPhases === 'object' ? { ...input.portPhases } : {},
      portPhasesThreePhase: !!input.portPhasesThreePhase,
      powerLimits: input.powerLimits && typeof input.powerLimits === 'object' ? { ...input.powerLimits } : {},
      outputLimits: input.outputLimits && typeof input.outputLimits === 'object' ? { ...input.outputLimits } : {},
      circuitId: String(input.circuitId || ''),
      totalPowerLimit: Number.isFinite(Number(input.totalPowerLimit)) ? Number(input.totalPowerLimit) : null,
      outputs: Number.isFinite(Number(input.outputs)) ? Math.max(0, Math.floor(Number(input.outputs))) : null,
      notes: String(input.notes || ''),
    };
    objects.push(object);
  }

  const objectIds = new Set(objects.map((object) => object.id));
  const connections: Connection[] = [];
  const seenPorts = new Set<string>();
  for (const input of Array.isArray(raw.connections) ? raw.connections : []) {
    if (!input || !objectIds.has(input.from) || !objectIds.has(input.to) || input.from === input.to) {
      warnings.push('Skipped a cable with a missing object.');
      continue;
    }
    if (!['power', 'dmx', 'ethernet', 'usb', 'video', 'wireless'].includes(input.type)) {
      warnings.push('Skipped a cable of unknown type.');
      continue;
    }
    const key = `${input.to}:${input.toPort}`;
    if (seenPorts.has(key)) warnings.push('Two cables detected on one input; both were kept for review.');
    seenPorts.add(key);
    connections.push({
      id: typeof input.id === 'string' ? input.id : uid('cbl'),
      type: input.type,
      from: input.from,
      fromPort: String(input.fromPort || input.port || ''),
      to: input.to,
      toPort: String(input.toPort || ''),
      waypoints: Array.isArray(input.waypoints)
        ? input.waypoints.filter((point: any) => Number.isFinite(point.x) && Number.isFinite(point.z)).map((point: any) => ({ x: point.x, z: point.z }))
        : [],
      note: String(input.note || ''),
    });
  }

  const lighting = raw.lighting && typeof raw.lighting === 'object'
    ? {
        groups: Array.isArray(raw.lighting.groups)
          ? raw.lighting.groups.filter((group: any) => group && Array.isArray(group.memberIds)).map((group: any) => ({
              id: String(group.id || uid('grp')),
              name: String(group.name || 'Group'),
              memberIds: group.memberIds.filter((id: any) => objectIds.has(id)),
            }))
          : [],
        presets: Array.isArray(raw.lighting.presets)
          ? raw.lighting.presets.filter((preset: any) => preset && preset.values).map((preset: any) => ({
              id: String(preset.id || uid('pst')),
              name: String(preset.name || 'Preset'),
              values: preset.values,
              createdAt: String(preset.createdAt || now),
            }))
          : [],
        master: clampNumber(raw.lighting.master, 0, 1, DEFAULT_LIGHTING.master),
        ambient: clampNumber(raw.lighting.ambient, 0, 1, DEFAULT_LIGHTING.ambient),
        haze: clampNumber(raw.lighting.haze, 0, 2, DEFAULT_LIGHTING.haze),
        anisotropy: clampNumber(raw.lighting.anisotropy, -0.2, 0.95, DEFAULT_LIGHTING.anisotropy),
        exposure: clampNumber(raw.lighting.exposure, 0.2, 3, DEFAULT_LIGHTING.exposure),
        bloom: clampNumber(raw.lighting.bloom, 0, 10, DEFAULT_LIGHTING.bloom),
      bloomStrength: clampNumber(raw.lighting.bloomStrength, 0, 10, 1),
      showFloor: raw.lighting.showFloor !== false,
        quality: ['low', 'medium', 'high', 'ultra', 'photo'].includes(raw.lighting.quality) ? raw.lighting.quality : 'low',
        volumetric: raw.lighting.volumetric !== false,
        showWalls: raw.lighting.showWalls !== false,
        workLight: raw.lighting.workLight !== false,
        activePresetId: typeof raw.lighting.activePresetId === 'string' ? raw.lighting.activePresetId : null,
      }
    : { ...DEFAULT_LIGHTING, groups: [], presets: [] };

  for (const object of objects) snapObjectToGrid(object, gridSize);

  return {
    project: {
      schemaVersion: 5,
      id: typeof raw.id === 'string' ? raw.id : uid('prj'),
      name: String(raw.name || 'Project').slice(0, 120),
      createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : now,
      updatedAt: now,
      settings: {
        ...DEFAULT_SETTINGS,
        ...(raw.settings && typeof raw.settings === 'object' ? raw.settings : {}),
        gridSize,
      },
      objects,
      connections,
      guides: Array.isArray(raw.guides)
        ? raw.guides.filter((guide: any) => guide && ['x', 'z'].includes(guide.axis) && Number.isFinite(Number(guide.position))).map((guide: any) => ({ id: String(guide.id || uid('gd')), axis: guide.axis, position: Number(guide.position) }))
        : [],
      lighting,
      view: {
        plan: {
          panX: clampNumber(raw.view?.plan?.panX, -100000, 100000, 0),
          panY: clampNumber(raw.view?.plan?.panY, -100000, 100000, 0),
          zoom: clampNumber(raw.view?.plan?.zoom, 0, 500, 0),
        },
        camera3d: raw.view?.camera3d && typeof raw.view.camera3d === 'object' ? raw.view.camera3d : null,
        cameraPreset: ['perspective', 'front', 'top', 'side'].includes(raw.view?.cameraPreset) ? raw.view.cameraPreset : 'front',
      },
      effects: normalizeModifiers(raw.effects),
      customShaders: normalizeCustomShaders(raw.customShaders),
      fieldLinks: Array.isArray(raw.fieldLinks) ? raw.fieldLinks : [],
      mutation: raw.mutation && typeof raw.mutation === 'object' ? raw.mutation : undefined,
      reactionDiffusion: raw.reactionDiffusion ? normalizeReactionDiffusion(raw.reactionDiffusion) : undefined,
      postShaders: Array.isArray(raw.postShaders) ? raw.postShaders.map((entry: any, index: number) => ({ ...entry, id: entry.id || `pass_${index}_${entry.shaderId}` })) : [],
      fields: normalizeModifiers(raw.fields),
      looks: Array.isArray(raw.looks) ? raw.looks.filter((look: any) => look && typeof look.id === 'string' && look.material && typeof look.material === 'object').map((look: any) => ({ id: look.id, name: String(look.name || 'Look'), material: normalizeMaterial(look.material) || {}, modifiers: normalizeModifiers(look.modifiers), shaders: Array.isArray(look.shaders) ? look.shaders : undefined, createdAt: String(look.createdAt || '') })) : [],
      signals: normalizeSignals(raw.signals),
      effectGroups: normalizeEffectGroups(raw.effectGroups),
      physics: normalizePhysics(raw.physics),
      timeline: {
        duration: Math.max(0.5, Math.min(3600, Number(raw.timeline?.duration) || 10)),
        loop: raw.timeline?.loop !== false,
        tracks: Array.isArray(raw.timeline?.tracks) ? raw.timeline.tracks.filter((track: any) => track && typeof track.id === 'string' && typeof track.propertyPath === 'string').map((track: any) => ({
          id: track.id,
          objectId: typeof track.objectId === 'string' ? track.objectId : null,
          propertyPath: track.propertyPath,
          label: typeof track.label === 'string' ? track.label : undefined,
          keyframes: Array.isArray(track.keyframes) ? track.keyframes.filter((key: any) => key && Number.isFinite(Number(key.time))).map((key: any) => ({
            id: typeof key.id === 'string' ? key.id : `kf_${uid('kf')}`,
            time: Number(key.time),
            value: key.value,
            easing: ['linear','easeIn','easeOut','easeInOut','step'].includes(key.easing) ? key.easing : 'linear',
          })) : [],
        })) : [],
        clips: Array.isArray(raw.timeline?.clips) ? raw.timeline.clips.filter((clip: any) => clip && typeof clip.id === 'string' && typeof clip.type === 'string').map((clip: any) => ({
          id: clip.id,
          type: clip.type,
          objectId: typeof clip.objectId === 'string' ? clip.objectId : null,
          propertyPath: String(clip.propertyPath || ''),
          start: Math.max(0, Number(clip.start) || 0),
          end: Math.max(0, Number(clip.end) || 1),
          enabled: clip.enabled !== false,
          fadeIn: Math.max(0, Number(clip.fadeIn) || 0),
          fadeOut: Math.max(0, Number(clip.fadeOut) || 0),
          params: clip.params && typeof clip.params === 'object' ? clip.params : {},
        })) : [],
        groupEffects: normalizeGroupEffects(raw.timeline?.groupEffects),
      },
      migration: raw.migration && typeof raw.migration === 'object' ? raw.migration : null,
    },
    warnings,
  };
}

export function parseProjectFile(text: string, fallbackName = 'Imported project'): ValidationResult & { legacy: boolean } {
  let raw: any;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error('The file is not valid JSON');
  }
  if (raw && raw.project && typeof raw.project === 'object' && Array.isArray(raw.project.objects)) {
    return { ...validateProject(raw.project), legacy: false };
  }
  // A workspace file may contain several projects.
  if (raw && raw.schemaVersion === 1 && Array.isArray(raw.projects)) {
    if (!raw.projects.length) throw new Error('The file has no projects');
    const result = validateProject(raw.projects[0]);
    return { ...result, warnings: ['The file contains multiple projects. The first one was imported.', ...result.warnings], legacy: false };
  }
  if (raw && Array.isArray(raw.nodes) && !Array.isArray(raw.objects)) {
    const result = migrateLegacy(raw, fallbackName);
    return { ...result, warnings: ['Legacy Rig Grid project detected: coordinates were recalculated; check the Plan.', ...result.warnings], legacy: true };
  }
  return { ...validateProject(raw), legacy: false };
}

const WORKSPACE_KEY = 'regrid.workspace.v1';
const LEGACY_KEY = 'rig-grid-v4';

export function loadWorkspace(): { workspace: WorkspaceFile | null; legacyRaw: any | null } {
  let legacyRaw: any = null;
  try {
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) legacyRaw = JSON.parse(legacy);
  } catch {
    legacyRaw = null;
  }
  try {
    const stored = localStorage.getItem(WORKSPACE_KEY);
    if (!stored) return { workspace: null, legacyRaw };
    const raw = JSON.parse(stored);
    if (!raw || !Array.isArray(raw.projects)) return { workspace: null, legacyRaw };
    const projects: Project[] = [];
    const warnings: string[] = [];
    for (const entry of raw.projects) {
      try {
        const result = validateProject(entry);
        projects.push(result.project);
        warnings.push(...result.warnings);
      } catch {
        warnings.push(`Could not read the saved project "${entry?.name || 'untitled'}".`);
      }
    }
    return {
      workspace: {
        schemaVersion: 1,
        activeProjectId: typeof raw.activeProjectId === 'string' ? raw.activeProjectId : projects[0]?.id || null,
        projects,
      },
      legacyRaw,
    };
  } catch {
    return { workspace: null, legacyRaw };
  }
}

export function saveWorkspace(workspace: WorkspaceFile): boolean {
  try {
    localStorage.setItem(WORKSPACE_KEY, JSON.stringify(workspace));
    return true;
  } catch {
    return false;
  }
}

export function exportProjectJson(project: Project): string {
  return JSON.stringify(
    {
      application: 'RE:GRID',
      exportedAt: new Date().toISOString(),
      schemaVersion: 5,
      project,
    },
    null,
    2,
  );
}
