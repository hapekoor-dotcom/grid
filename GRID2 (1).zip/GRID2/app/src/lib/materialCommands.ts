import type { MaterialMapChannel, MaterialMapKind, MaterialTextureLayer } from '../types/project';
import { useWorkspaceStore } from '../store/workspaceStore';

/**
 * Structured material-map commands. The Inspector, future AI tools and any
 * automation should go through this layer so edits stay per object/material
 * slot and participate in the normal Undo/Redo + persistence path.
 */
function updateMap(objectId: string, slot: string, kind: MaterialMapKind, update: (layer: MaterialTextureLayer | undefined) => MaterialTextureLayer | null): void {
  const state = useWorkspaceStore.getState();
  const project = state.projects.find((entry) => entry.id === state.activeId);
  const object = project?.objects.find((entry) => entry.id === objectId);
  if (!object) return;
  const slotMaterial = object.materialOverrides?.[slot] || {};
  const maps = { ...(slotMaterial.maps || {}) };
  const next = update(maps[kind]);
  if (next) maps[kind] = next;
  else delete maps[kind];
  state.updateObject(objectId, {
    materialOverrides: {
      ...(object.materialOverrides || {}),
      [slot]: { ...slotMaterial, maps },
    },
  });
}

export const materialCommands = {
  setMap(objectId: string, slot: string, kind: MaterialMapKind, layer: MaterialTextureLayer): void {
    updateMap(objectId, slot, kind, () => ({ ...layer }));
  },

  removeMap(objectId: string, slot: string, kind: MaterialMapKind): void {
    updateMap(objectId, slot, kind, () => null);
  },

  resetToOriginal(objectId: string, slot: string, kind: MaterialMapKind): void {
    updateMap(objectId, slot, kind, (layer) => layer ? { ...layer, assetId: null, assetName: null } : null);
  },

  setTransform(objectId: string, slot: string, kind: MaterialMapKind, transform: Pick<MaterialTextureLayer, 'uv' | 'tiling' | 'offset' | 'rotation'>): void {
    updateMap(objectId, slot, kind, (layer) => ({ ...(layer || {}), ...transform }));
  },

  setChannel(objectId: string, slot: string, kind: MaterialMapKind, channel: MaterialMapChannel): void {
    updateMap(objectId, slot, kind, (layer) => ({ ...(layer || {}), channel }));
  },

  setIntensity(objectId: string, slot: string, kind: MaterialMapKind, intensity: number): void {
    updateMap(objectId, slot, kind, (layer) => ({ ...(layer || {}), intensity: Math.max(0, intensity) }));
  },

  tileMap(objectId: string, slot: string, kind: MaterialMapKind, x: number, y = x): void {
    updateMap(objectId, slot, kind, (layer) => ({ ...(layer || {}), tiling: { x, y } }));
  },

  setUv(objectId: string, slot: string, kind: MaterialMapKind, uv: number): void {
    updateMap(objectId, slot, kind, (layer) => ({ ...(layer || {}), uv: Math.max(0, Math.min(7, Math.round(uv))) }));
  },

  /** The displacement modifier keeps its existing image-URL parameter. */
  setDisplacementTexture(objectId: string, modifierId: string, texture: string): void {
    const state = useWorkspaceStore.getState();
    const project = state.projects.find((entry) => entry.id === state.activeId);
    const object = project?.objects.find((entry) => entry.id === objectId);
    if (!object) return;
    state.updateObject(objectId, {
      modifiers: (object.modifiers || []).map((modifier) => modifier.id === modifierId ? { ...modifier, params: { ...modifier.params, texture } } : modifier),
    });
  },
};

export type MaterialCommands = typeof materialCommands;
