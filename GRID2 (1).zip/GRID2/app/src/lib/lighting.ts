import type { LightPreset } from '../types/project';

export function lightPresetLabel(name: string): string {
  return name.trim() || 'Untitled';
}

export function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (value: number) => Math.max(0, Math.min(255, Math.round(value)));
  return `#${clamp(r).toString(16).padStart(2, '0')}${clamp(g).toString(16).padStart(2, '0')}${clamp(b).toString(16).padStart(2, '0')}`;
}

export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const value = clean.length === 3 ? clean.split('').map((char) => char + char).join('') : clean;
  const number = Number.parseInt(value || 'ffffff', 16);
  return { r: (number >> 16) & 255, g: (number >> 8) & 255, b: number & 255 };
}

export const COLOR_SWATCHES = [
  { name: 'Warm white', color: '#ffe1b0' },
  { name: 'White', color: '#ffffff' },
  { name: 'Cool white', color: '#cfe4ff' },
  { name: 'Amber', color: '#ff9a1f' },
  { name: 'Red', color: '#ff2f38' },
  { name: 'Magenta', color: '#ff35c8' },
  { name: 'Violet', color: '#7c4dff' },
  { name: 'Blue', color: '#245bff' },
  { name: 'Cyan', color: '#19c8ff' },
  { name: 'Green', color: '#35fc72' },
  { name: 'Lime', color: '#c8ff3d' },
  { name: 'UV', color: '#5b2cff' },
];

export function presetMemberCount(preset: LightPreset): number {
  return Object.keys(preset.values).length;
}
