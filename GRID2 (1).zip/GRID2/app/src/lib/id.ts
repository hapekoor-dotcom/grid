export function uid(prefix = 'o'): string {
  const random = Math.random().toString(36).slice(2, 9);
  return `${prefix}_${Date.now().toString(36).slice(-4)}${random}`;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function round(value: number, step = 0.001): number {
  return Math.round(value / step) * step;
}

export function formatMeters(value: number, digits = 2): string {
  return `${value.toFixed(digits)} m`;
}

export function formatWatts(value: number | null, digits = 0): string {
  if (value === null || !Number.isFinite(value)) return '—';
  return `${value.toLocaleString('en-US', { maximumFractionDigits: digits })} W`;
}

export function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat('en-US', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export function plural(value: number, one: string, few: string, many: string): string {
  // English uses a single plural form; `few` remains for call-site compatibility.
  void few;
  return Math.abs(value) === 1 ? one : many;
}
