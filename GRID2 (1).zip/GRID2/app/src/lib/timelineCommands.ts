import { useWorkspaceStore } from '../store/workspaceStore';
import { uid } from './id';
import type { GroupEffect, GroupEffectPhaseMode, TimelineClip, TimelineClipType, TimelineEasing, TimelineKeyframe, TimelineState, TimelineTrack } from '../types/timeline';

type Store = ReturnType<typeof useWorkspaceStore.getState>;

function edit(recipe: (timeline: TimelineState) => void): void {
  const store = useWorkspaceStore.getState() as Store;
  store.mutate((draft) => {
    if (!draft.timeline) draft.timeline = { duration: 10, loop: true, tracks: [], clips: [], groupEffects: [] };
    recipe(draft.timeline);
  });
}

export function setTimelineDuration(seconds: number): void {
  edit((timeline) => { timeline.duration = Math.max(0.5, Math.min(3600, seconds)); });
}

export function setTimelineLoop(loop: boolean): void {
  edit((timeline) => { timeline.loop = loop; });
}

export function createTrack(objectId: string | null, propertyPath: string): string {
  const id = uid('trk');
  edit((timeline) => {
    const existing = timeline.tracks.find((track) => track.objectId === objectId && track.propertyPath === propertyPath);
    if (existing) return;
    timeline.tracks.push({ id, objectId, propertyPath, keyframes: [] });
  });
  const project = useWorkspaceStore.getState().projects.find((entry) => entry.id === useWorkspaceStore.getState().activeId);
  return project?.timeline.tracks.find((track) => track.objectId === objectId && track.propertyPath === propertyPath)?.id || id;
}

export function addKeyframe(trackId: string, time: number, value: number | string | boolean, easing: TimelineEasing = 'linear'): string {
  const id = uid('kf');
  edit((timeline) => {
    const track = timeline.tracks.find((entry) => entry.id === trackId);
    if (!track) return;
    const existing = track.keyframes.find((key) => Math.abs(key.time - time) < 0.001);
    if (existing) {
      existing.value = value;
      existing.easing = easing;
    } else {
      track.keyframes.push({ id, time, value, easing });
      track.keyframes.sort((a, b) => a.time - b.time);
    }
  });
  return id;
}

export function upsertKeyframe(objectId: string | null, propertyPath: string, time: number, value: number | string | boolean, easing: TimelineEasing = 'linear'): void {
  edit((timeline) => {
    let track = timeline.tracks.find((entry) => entry.objectId === objectId && entry.propertyPath === propertyPath);
    if (!track) {
      track = { id: uid('trk'), objectId, propertyPath, keyframes: [] };
      timeline.tracks.push(track);
    }
    const existing = track.keyframes.find((key) => Math.abs(key.time - time) < 0.001);
    if (existing) { existing.value = value; existing.easing = easing; }
    else { track.keyframes.push({ id: uid('kf'), time, value, easing }); track.keyframes.sort((a, b) => a.time - b.time); }
  });
}

export function createTrackWithKeyframe(objectId: string | null, propertyPath: string, time: number, value: number | string | boolean, easing: TimelineEasing = 'linear'): string {
  let result = '';
  edit((timeline) => {
    let track = timeline.tracks.find((entry) => entry.objectId === objectId && entry.propertyPath === propertyPath);
    if (!track) { track = { id: uid('trk'), objectId, propertyPath, keyframes: [] }; timeline.tracks.push(track); }
    result = track.id;
    const existing = track.keyframes.find((key) => Math.abs(key.time - time) < 0.001);
    if (existing) { existing.value = value; existing.easing = easing; }
    else { track.keyframes.push({ id: uid('kf'), time, value, easing }); track.keyframes.sort((a, b) => a.time - b.time); }
  });
  return result;
}

export function removeKeyframe(trackId: string, keyframeId: string): void {
  edit((timeline) => {
    const track = timeline.tracks.find((entry) => entry.id === trackId);
    if (track) track.keyframes = track.keyframes.filter((key) => key.id !== keyframeId);
  });
}

export function updateKeyframe(trackId: string, keyframeId: string, patch: Partial<TimelineKeyframe>): void {
  edit((timeline) => {
    const track = timeline.tracks.find((entry) => entry.id === trackId);
    const keyframe = track?.keyframes.find((key) => key.id === keyframeId);
    if (keyframe) Object.assign(keyframe, patch);
  });
}

export function removeTrack(trackId: string): void {
  edit((timeline) => { timeline.tracks = timeline.tracks.filter((track) => track.id !== trackId); });
}

export function createClip(clip: Omit<TimelineClip, 'id'>): string {
  const id = uid('clip');
  edit((timeline) => {
    timeline.clips.push({ ...clip, id });
    timeline.clips.sort((a, b) => a.start - b.start);
  });
  return id;
}

export function updateClip(clipId: string, patch: Partial<TimelineClip>): void {
  edit((timeline) => {
    const clip = timeline.clips.find((entry) => entry.id === clipId);
    if (clip) Object.assign(clip, patch);
  });
}

export function removeClip(clipId: string): void {
  edit((timeline) => { timeline.clips = timeline.clips.filter((clip) => clip.id !== clipId); });
}

export type PhaseMode = GroupEffectPhaseMode;

export interface GroupWaveOptions {
  objectIds: string[];
  propertyPath: string;
  start: number;
  duration: number;
  frequency: number;
  min: number;
  max: number;
  phaseMode: PhaseMode;
  spreadDegrees: number;
  stagger?: number;
  waveform: 'sine' | 'triangle' | 'square';
  fadeIn?: number;
  fadeOut?: number;
  colorFrom?: string;
  colorTo?: string;
}

/** Creates ONE shared group effect targeting every selected object. */
export function createGroupWave(options: GroupWaveOptions): string {
  const store = useWorkspaceStore.getState();
  const project = store.projects.find((entry) => entry.id === store.activeId);
  if (!project) return '';
  const targetIds = [...new Set(options.objectIds.filter((id) => project.objects.some((object) => object.id === id)))];
  if (!targetIds.length) return '';
  const effectId = uid('eff');
  edit((timeline) => {
    const effect: GroupEffect = {
      id: effectId,
      type: 'groupWave',
      enabled: true,
      targetIds,
      propertyPath: options.propertyPath,
      start: options.start,
      end: options.start + options.duration,
      fadeIn: options.fadeIn ?? 0,
      fadeOut: options.fadeOut ?? 0,
      params: {
        frequency: options.frequency,
        phaseSpread: options.spreadDegrees,
        phaseMode: options.phaseMode,
        basePhase: 0,
        min: options.min,
        max: options.max,
        waveform: options.waveform,
        ...(options.colorFrom ? { colorFrom: options.colorFrom } : {}),
        ...(options.colorTo ? { colorTo: options.colorTo } : {}),
      },
    };
    timeline.groupEffects = [...(timeline.groupEffects || []), effect];
  });
  return effectId;
}

export function updateGroupEffect(effectId: string, patch: Partial<Omit<GroupEffect, 'id' | 'type'>>): void {
  edit((timeline) => {
    const effect = timeline.groupEffects?.find((entry) => entry.id === effectId);
    if (!effect) return;
    if (patch.params) Object.assign(effect.params, patch.params);
    const { params: _params, ...rest } = patch;
    Object.assign(effect, rest);
  });
}

/** AI-friendly flat update for a shared effect. */
export function updateEffect(effectId: string, patch: { enabled?: boolean; frequency?: number; phaseSpread?: number; phaseMode?: GroupEffectPhaseMode; min?: number; max?: number; waveform?: GroupEffect['params']['waveform']; start?: number; end?: number; targetIds?: string[] }): void {
  const { frequency, phaseSpread, phaseMode, min, max, waveform, ...rest } = patch;
  const params = {
    ...(frequency !== undefined ? { frequency } : {}),
    ...(phaseSpread !== undefined ? { phaseSpread } : {}),
    ...(phaseMode !== undefined ? { phaseMode } : {}),
    ...(min !== undefined ? { min } : {}),
    ...(max !== undefined ? { max } : {}),
    ...(waveform !== undefined ? { waveform } : {}),
  };
  updateGroupEffect(effectId, { ...rest, ...(Object.keys(params).length ? { params } : {}) } as Partial<Omit<GroupEffect, 'id' | 'type'>>);
}

export function removeGroupEffect(effectId: string): void {
  edit((timeline) => { timeline.groupEffects = (timeline.groupEffects || []).filter((effect) => effect.id !== effectId); });
}

export function setGroupEffectTargets(effectId: string, targetIds: string[]): void {
  edit((timeline) => {
    const effect = timeline.groupEffects?.find((entry) => entry.id === effectId);
    if (!effect) return;
    effect.targetIds = [...new Set(targetIds)];
  });
}

export function addGroupEffectTargets(effectId: string, targetIds: string[]): void {
  edit((timeline) => {
    const effect = timeline.groupEffects?.find((entry) => entry.id === effectId);
    if (!effect) return;
    effect.targetIds = [...new Set([...effect.targetIds, ...targetIds])];
  });
}

export function removeGroupEffectTargets(effectId: string, targetIds: string[]): void {
  const remove = new Set(targetIds);
  edit((timeline) => {
    const effect = timeline.groupEffects?.find((entry) => entry.id === effectId);
    if (!effect) return;
    effect.targetIds = effect.targetIds.filter((id) => !remove.has(id));
  });
}

/**
 * Detach targets from a shared effect into a copied, independent effect.
 * The remaining targets continue to share the original effect.
 */
export function detachGroupEffectTargets(effectId: string, targetIds: string[]): string | null {
  const remove = new Set(targetIds);
  const store = useWorkspaceStore.getState();
  const project = store.projects.find((entry) => entry.id === store.activeId);
  const source = project?.timeline?.groupEffects?.find((effect) => effect.id === effectId);
  if (!source) return null;
  const detachedIds = source.targetIds.filter((id) => remove.has(id));
  if (!detachedIds.length) return null;
  const detachedId = uid('eff');
  edit((timeline) => {
    const effect = timeline.groupEffects?.find((entry) => entry.id === effectId);
    if (!effect) return;
    effect.targetIds = effect.targetIds.filter((id) => !remove.has(id));
    timeline.groupEffects = [...(timeline.groupEffects || []), {
      ...effect,
      id: detachedId,
      targetIds: detachedIds,
      params: { ...effect.params },
    }];
  });
  return detachedId;
}

export function setGroupEffectTiming(effectId: string, start: number, end: number): void {
  updateGroupEffect(effectId, { start, end: Math.max(start + 0.01, end) });
}

export function createColorFade(objectIds: string[], propertyPath: string, start: number, end: number, from: string, to: string): void {
  edit((timeline) => {
    for (const objectId of objectIds) {
      let track = timeline.tracks.find((entry) => entry.objectId === objectId && entry.propertyPath === propertyPath);
      if (!track) { track = { id: uid('trk'), objectId, propertyPath, keyframes: [] }; timeline.tracks.push(track); }
      for (const [time, value] of [[start, from], [end, to]] as const) {
        const existing = track.keyframes.find((key) => Math.abs(key.time - time) < 0.001);
        if (existing) { existing.value = value; existing.easing = 'easeInOut'; }
        else track.keyframes.push({ id: uid('kf'), time, value, easing: 'easeInOut' });
      }
      track.keyframes.sort((a, b) => a.time - b.time);
    }
  });
}

export function setTimelineClipTiming(clipId: string, start: number, end: number): void {
  updateClip(clipId, { start, end: Math.max(start + 0.01, end) });
}

export const timelineCommands = {
  setDuration: setTimelineDuration,
  setLoop: setTimelineLoop,
  createTrack,
  createTrackWithKeyframe,
  addKeyframe,
  upsertKeyframe,
  removeKeyframe,
  updateKeyframe,
  createClip,
  updateClip,
  removeClip,
  createGroupWave,
  updateGroupEffect,
  updateEffect,
  removeGroupEffect,
  setGroupEffectTargets,
  addGroupEffectTargets,
  removeGroupEffectTargets,
  detachGroupEffectTargets,
  setGroupEffectTiming,
  createColorFade,
  setClipTiming: setTimelineClipTiming,
};
