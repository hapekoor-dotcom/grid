import type { SceneObject } from '../types/project';
import { getDevice } from './catalog';

/**
 * Capability vocabulary shared by inspectors, commands and future integrations.
 * Capabilities describe what an object can expose; object types only describe
 * how the base record was created.
 */
export type SceneCapability =
  | 'transform'
  | 'visibility'
  | 'material'
  | 'light'
  | 'spot'
  | 'point'
  | 'area'
  | 'directional'
  | 'advancedFixture'
  | 'panTilt'
  | 'zoom'
  | 'color';

export function capabilitiesOf(object: SceneObject): Set<SceneCapability> {
  const caps = new Set<SceneCapability>(['transform', 'visibility']);
  if (object.type === 'model') {
    caps.add('material');
    return caps;
  }
  if (object.light) {
    caps.add('light');
    caps.add('color');
    const kind = object.lightType || (object.type === 'light' ? 'spot' : undefined);
    if (kind) caps.add(kind);
    if (kind === 'spot' || kind === 'area') caps.add('zoom');
    if (object.type === 'device') {
      const device = getDevice(object.deviceId);
      caps.add('advancedFixture');
      if (device?.capabilities?.pan || device?.capabilities?.tilt) caps.add('panTilt');
      if (device?.capabilities?.zoom) caps.add('zoom');
    }
  }
  return caps;
}
