export interface EffectPreset {
  id: string;
  label: string;
  description: string;
  stack: { type: string; params?: Record<string, number | string | boolean> }[];
}

/** Presets are ordinary effect stacks, not special-cased renderer paths. */
export const EFFECT_PRESETS: EffectPreset[] = [
  { id: 'meltingChrome', label: 'Melting Chrome', description: 'Liquid chrome under a slow downward melt.', stack: [{ type: 'liquidChrome' }, { type: 'melt', params: { amount: 0.45, viscosity: 0.35 } }, { type: 'domainWarp', params: { strength: 0.22, scale: 2.4 } }] },
  { id: 'deadSignal', label: 'Dead Signal', description: 'Glitched surface with RGB split and scanlines.', stack: [{ type: 'glitchSurface' }, { type: 'hologram', params: { glitch: 0.55, opacity: 0.55 } }, { type: 'scanlinesPost' }] },
  { id: 'plasmaOrganism', label: 'Plasma Organism', description: 'Plasma body, ripple deformation, plasma color pulse.', stack: [{ type: 'plasma' }, { type: 'ripple', params: { strength: 0.12, frequency: 8 } }, { type: 'lightColorDrift' }] },
  { id: 'digitalGhost', label: 'Digital Ghost', description: 'Hologram with afterimage feedback.', stack: [{ type: 'hologram' }, { type: 'feedback', params: { persistence: 0.82, intensity: 0.5, ghost: true } }] },
  { id: 'magmaHeart', label: 'Magma Heart', description: 'Magma shell with pulse and volumetric glow.', stack: [{ type: 'magma' }, { type: 'spherize', params: { amount: 0.1 } }, { type: 'lightBeamPulse' }] },
  { id: 'liquidMirror', label: 'Liquid Mirror', description: 'Chrome flow with mirrored geometry.', stack: [{ type: 'liquidChrome' }, { type: 'mirrorGeometry', params: { amount: 0.7 } }, { type: 'waveField', params: { strength: 0.05 } }] },
  { id: 'fracturedLight', label: 'Fractured Light', description: 'Sliced geometry with iridescent edges.', stack: [{ type: 'slice', params: { bands: 12, gap: 0.5 } }, { type: 'iridescentFilm' }] },
  { id: 'blackHole', label: 'Black Hole', description: 'Attractor field, vortex and feedback zoom.', stack: [{ type: 'attractorField', params: { strength: 2, radius: 4 } }, { type: 'vortexField' }, { type: 'feedback', params: { persistence: 0.9, intensity: 0.55 } }] },
  { id: 'radioactiveGlass', label: 'Radioactive Glass', description: 'Iridescent glass with toxic plasma edges.', stack: [{ type: 'iridescentFilm' }, { type: 'plasma', params: { colorB: '#aaff00', emission: 0.8 } }, { type: 'fresnel' }] },
  { id: 'hyperspace', label: 'Hyperspace', description: 'Spiral warp with kaleidoscope post.', stack: [{ type: 'spiralWarp', params: { amount: 3 } }, { type: 'kaleidoscopePost' }, { type: 'rgbSplit' }] },
  { id: 'brokenHologram', label: 'Broken Hologram', description: 'Hologram with hard glitch and breakup.', stack: [{ type: 'hologram', params: { glitch: 0.8, breakup: 0.45, flicker: 0.7 } }, { type: 'glitchSurface' }] },
  { id: 'neonParasite', label: 'Neon Parasite', description: 'Voronoi cracks with animated gradient and edge glow.', stack: [{ type: 'voronoiSurface' }, { type: 'animatedGradient', params: { emission: 0.6 } }, { type: 'fresnel' }] },
  { id: 'feedbackTunnel', label: 'Feedback Tunnel', description: 'Recursive feedback, RGB split and scanlines.', stack: [{ type: 'feedback', params: { persistence: 0.94, intensity: 0.7 } }, { type: 'rgbSplit' }, { type: 'scanlinesPost' }] },
  { id: 'organicMachine', label: 'Organic Machine', description: 'Domain warp, iridescence and light noise.', stack: [{ type: 'domainWarp', params: { strength: 0.3, octaves: 6 } }, { type: 'iridescentFilm' }, { type: 'lightIntensityNoise' }] },
  { id: 'voidObject', label: 'Void Object', description: 'Black glass, x-ray fresnel and spatial slices.', stack: [{ type: 'liquidChrome', params: { metalness: 1, roughness: 0.02, emission: 0 } }, { type: 'fresnel' }, { type: 'slice', params: { bands: 24, gap: 0.05 } }] },
];
