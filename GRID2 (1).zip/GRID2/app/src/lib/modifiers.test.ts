import { describe, expect, it } from 'vitest';
import { MODIFIER_DEFINITIONS } from './modifiers';

describe('modifier catalog', () => {
  it('has unique stable type ids', () => {
    const ids = MODIFIER_DEFINITIONS.map((definition) => definition.type);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('gives every declared field a default and unique key', () => {
    for (const definition of MODIFIER_DEFINITIONS) {
      const keys = definition.fields.map((field) => field.key);
      expect(new Set(keys).size, `${definition.type} has duplicate fields`).toBe(keys.length);
      for (const field of definition.fields) {
        expect(Object.prototype.hasOwnProperty.call(definition.defaults, field.key), `${definition.type}.${field.key} is missing a default`).toBe(true);
      }
    }
  });
});
