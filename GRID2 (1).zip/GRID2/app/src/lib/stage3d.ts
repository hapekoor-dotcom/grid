import type { Project, SceneObject } from '../types/project';
import { getDevice } from './catalog';
import { objectDims } from './objects';

export interface RoomBounds {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  centerX: number;
  centerZ: number;
}

export function getRoomBounds(project: Project): RoomBounds {
  const room = project.objects.find((object) => object.type === 'room' && object.size);
  if (room && room.size) {
    const { h } = room.size;
    const w = room.rotation % 180 === 0 ? room.size.w : room.size.d;
    const d = room.rotation % 180 === 0 ? room.size.d : room.size.w;
    return {
      minX: room.position.x - w / 2,
      maxX: room.position.x + w / 2,
      minZ: room.position.z - d / 2,
      maxZ: room.position.z + d / 2,
      height: room.room?.wallHeight || h || project.settings.venueHeight,
      centerX: room.position.x,
      centerZ: room.position.z,
    };
  }
  const visible = project.objects.filter((object) => object.visible);
  if (!visible.length) return { minX: -7, maxX: 7, minZ: -4.5, maxZ: 4.5, height: 5, centerX: 0, centerZ: 0 };
  const dims = visible.map((object) => ({ object, dims: objectDims(object) }));
  const minX = Math.min(...dims.map(({ object, dims: size }) => object.position.x - size.w / 2)) - 2;
  const maxX = Math.max(...dims.map(({ object, dims: size }) => object.position.x + size.w / 2)) + 2;
  const minZ = Math.min(...dims.map(({ object, dims: size }) => object.position.z - size.d / 2)) - 2;
  const maxZ = Math.max(...dims.map(({ object, dims: size }) => object.position.z + size.d / 2)) + 2;
  return { minX, maxX, minZ, maxZ, height: project.settings.venueHeight || 3.5, centerX: (minX + maxX) / 2, centerZ: (minZ + maxZ) / 2 };
}

export function getStageCenter(project: Project): { x: number; z: number; y: number } {
  const stage = project.objects.find((object) => object.type === 'stage' && (object.size?.h || 0) > 0.1);
  if (stage) return { x: stage.position.x, z: stage.position.z, y: stage.size?.h || 0.45 };
  const bounds = getRoomBounds(project);
  return { x: bounds.centerX, z: bounds.centerZ, y: 0 };
}

export function fixtureMountY(object: SceneObject): number {
  const dims = objectDims(object);
  if (object.mount === 'truss' || object.mount === 'ceiling') return Math.max(dims.h / 2 + 0.08, object.elevation - dims.h / 2);
  return object.elevation + dims.h / 2;
}

export function fixtureAimPoint(object: SceneObject, project: Project): [number, number, number] {
  const device = getDevice(object.deviceId);
  const kind = device?.kind || 'other';
  const light = object.light;
  const bounds = getRoomBounds(project);
  const stage = getStageCenter(project);
  const isHung = object.mount === 'truss' || object.mount === 'ceiling';
  const audienceZ = Math.min(bounds.maxZ - 0.8, stage.z + 5.4);
  let base: [number, number, number];

  if (['bar', 'pixel', 'panel', 'strobe', 'blinder'].includes(kind)) {
    base = [stage.x, Math.max(0.4, stage.y + 1.1), audienceZ];
  } else if (['par', 'flood', 'effectlight'].includes(kind)) {
    base = [object.position.x * 0.45, Math.max(0.25, stage.y + 0.15), Math.min(bounds.maxZ - 0.8, stage.z + 3.4)];
  } else if (['head', 'beam', 'spot'].includes(kind)) {
    base = isHung ? [stage.x, Math.max(0.05, stage.y + 0.15), stage.z + 1.3] : [object.position.x, 0.2, object.position.z + 2.2];
  } else {
    base = [object.position.x, 0.4, object.position.z + 2];
  }

  const pan = ((light?.pan || 0) * Math.PI) / 180;
  const offsetX = base[0] - object.position.x;
  const offsetZ = base[2] - object.position.z;
  const distance = Math.hypot(offsetX, offsetZ) || 1;
  const angle = Math.atan2(offsetX, offsetZ) + pan;
  const reach = Math.max(2.2, distance);
  const x = object.position.x + Math.sin(angle) * reach + (light?.pan ? Math.sin(pan) * 1.2 : 0);
  const z = object.position.z + Math.cos(angle) * reach + (light?.pan ? Math.cos(pan) * 1.2 : 0);
  const tilt = light?.tilt || 0;
  const y = Math.min(bounds.height - 0.15, Math.max(0.05, base[1] - (isHung ? tilt * 0.06 : tilt * 0.035)));
  return [x, y, z];
}

export function fixtureBeamAngle(object: SceneObject): number {
  const device = getDevice(object.deviceId);
  const zoom = object.light?.zoom;
  if (Number.isFinite(zoom) && zoom) return Math.max(2, Math.min(85, zoom));
  return device?.beamAngle.min || 20;
}

export function fixtureLightColor(object: SceneObject): string {
  return object.light?.color || '#ffffff';
}

export function isShadowCandidate(object: SceneObject, index: number, quality: 'low' | 'medium' | 'high' | 'ultra' | 'photo'): boolean {
  const limit = quality === 'photo' || quality === 'ultra' || quality === 'high' ? 4 : quality === 'medium' ? 2 : 0;
  return index < limit;
}
