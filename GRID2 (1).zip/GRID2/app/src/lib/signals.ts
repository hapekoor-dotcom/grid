import type { EffectGroup, ParameterModulator, Project, SceneModifier, SceneObject, SignalSource } from '../types/project';
import { modifierDefinition, type ModifierDefinition } from './modifiers';
import { physicsSignalState } from './physics';
import { modifierOutputValue } from './modifierOutputs';
import { sampleReactionOutput } from './reactionField';
import { applyAdapter, type Adapter } from './graphRouting';

const TAU = Math.PI * 2;

function hash(value: number): number {
  const x = Math.sin(value * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

function noise(value: number): number {
  const integer = Math.floor(value);
  const fraction = value - integer;
  const smooth = fraction * fraction * (3 - 2 * fraction);
  return (hash(integer) * (1 - smooth) + hash(integer + 1) * smooth) * 2 - 1;
}

function fbm(value: number, octaves: number, lacunarity: number, persistence: number): number {
  let total = 0;
  let amplitude = 1;
  let normal = 0;
  let cursor = value;
  for (let index = 0; index < Math.max(1, Math.min(8, octaves)); index += 1) {
    total += noise(cursor) * amplitude;
    normal += amplitude;
    cursor = cursor * lacunarity + 13.7;
    amplitude *= persistence;
  }
  return normal > 0 ? total / normal : 0;
}

function parameter(source: SignalSource, key: string, fallback: number): number {
  return Number(source.params[key] ?? fallback);
}

export function defaultSignal(kind: SignalSource['kind'] = 'sine'): SignalSource {
  const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const names: Record<SignalSource['kind'], string> = {
    time: 'Time', sine: 'Sine', saw: 'Saw', triangle: 'Triangle', pulse: 'Pulse',
    noise: 'Noise', fbm: 'FBM', randomWalk: 'Random Walk', sampleHold: 'Sample & Hold',
    objectDistance: 'Object Distance', objectDirection: 'Object Direction', worldPosition: 'World Position',
    normalDirection: 'Normal Direction', fresnel: 'Fresnel', timeline: 'Timeline', velocity: 'Velocity', angularSpeed: 'Angular Speed',
    height: 'Height', impact: 'Impact', distanceToGround: 'Distance to Ground', sleeping: 'Sleeping', trigger: 'Trigger',
  };
  return {
    id: `sig_${id}`,
    name: names[kind],
    kind,
    enabled: true,
    params: { speed: 1, phase: 0, amplitude: 1, offset: 0, octaves: 4, lacunarity: 2, persistence: 0.5, seed: 1, axis: 'y', objectId: '', range: 5 },
  };
}

export function signalValue(source: SignalSource, project: Project | null, time: number, object?: SceneObject | null): number {
  const speed = parameter(source, 'speed', 1);
  const phase = parameter(source, 'phase', 0);
  const amplitude = parameter(source, 'amplitude', 1);
  const offset = parameter(source, 'offset', 0);
  const seed = parameter(source, 'seed', 1);
  const x = time * speed + phase + seed;
  let value = 0;
  switch (source.kind) {
    case 'time': value = time; break;
    case 'sine': value = Math.sin(x * TAU); break;
    case 'saw': value = ((x % 1) + 1) % 1 * 2 - 1; break;
    case 'triangle': value = Math.abs((((x % 1) + 1) % 1) * 4 - 2) - 1; break;
    case 'pulse': value = ((x % 1) + 1) % 1 < 0.5 ? 1 : -1; break;
    case 'noise': value = noise(x); break;
    case 'fbm': value = fbm(x, parameter(source, 'octaves', 4), parameter(source, 'lacunarity', 2), parameter(source, 'persistence', 0.5)); break;
    case 'randomWalk': value = noise(x) * 0.6 + noise(x * 2.17 + 5) * 0.3 + noise(x * 4.31 + 11) * 0.1; break;
    case 'sampleHold': value = hash(Math.floor(x * 4)) * 2 - 1; break;
    case 'objectDistance': {
      const target = project?.objects.find((entry) => entry.id === String(source.params.objectId));
      if (!object || !target) return 0;
      const distance = Math.hypot(object.position.x - target.position.x, object.elevation - target.elevation, object.position.z - target.position.z);
      value = Math.min(1, distance / Math.max(0.001, parameter(source, 'range', 5)));
      break;
    }
    case 'objectDirection': {
      const target = project?.objects.find((entry) => entry.id === String(source.params.objectId));
      if (!object || !target) return 0;
      const dx = target.position.x - object.position.x;
      const dy = target.elevation - object.elevation;
      const dz = target.position.z - object.position.z;
      const axis = String(source.params.axis || 'y');
      const component = axis === 'x' ? dx : axis === 'z' ? dz : dy;
      value = Math.max(-1, Math.min(1, component / Math.max(0.001, Math.hypot(dx, dy, dz))));
      break;
    }
    case 'worldPosition': {
      if (!object) return 0;
      const axis = String(source.params.axis || 'y');
      value = axis === 'x' ? object.position.x : axis === 'z' ? object.position.z : object.elevation;
      break;
    }
    case 'normalDirection': {
      if (!object) return 0;
      const axis = String(source.params.axis || 'y');
      value = axis === 'x' ? 0 : axis === 'z' ? 0 : 1;
      break;
    }
    case 'fresnel': value = 0; break;
    case 'timeline': value = ((time % Math.max(0.001, parameter(source, 'range', 10))) / Math.max(0.001, parameter(source, 'range', 10))) * 2 - 1; break;
    case 'velocity': value = object ? physicsSignalState(object.id).velocity : 0; break;
    case 'angularSpeed': value = object ? physicsSignalState(object.id).angularSpeed : 0; break;
    case 'height': value = object ? physicsSignalState(object.id).height : 0; break;
    case 'impact': value = object ? physicsSignalState(object.id).impact : 0; break;
    case 'distanceToGround': value = object ? physicsSignalState(object.id).distanceToGround : 0; break;
    case 'sleeping': value = object ? physicsSignalState(object.id).sleeping : 0; break;
    case 'trigger': value = object ? physicsSignalState(object.id).trigger : 0; break;
    default: break;
  }
  return offset + value * amplitude;
}

export function findSignal(project: Project | null, id: string | undefined): SignalSource | undefined {
  if (!project || !id) return undefined;
  return project.signals?.find((signal) => signal.id === id && signal.enabled);
}

export function modulatedParams(
  modifier: SceneModifier,
  project: Project | null,
  time: number,
  object?: SceneObject | null,
  definition: ModifierDefinition = modifierDefinition(modifier.type),
  cache?: Map<string, Record<string, number | string | boolean>>,
  stack?: Set<string>,
): Record<string, number | string | boolean> {
  if (!modifier.modulators || !Object.keys(modifier.modulators).length) return modifier.params;
  if (cache?.has(modifier.id)) return cache.get(modifier.id)!;
  const activeStack = stack || new Set<string>();
  if (activeStack.has(modifier.id)) return modifier.params;
  activeStack.add(modifier.id);
  const next = { ...modifier.params };
  for (const [key, modulator] of Object.entries(modifier.modulators)) {
    if (!modulator?.enabled) continue;
    const field = definition.fields.find((entry) => entry.key === key);
    if (!field || (field.kind !== 'number' && field.kind !== 'percent' && !field.overdrive)) continue;
    const sourceType = modulator.sourceType || 'signal';
    const source = sourceType === 'signal' ? findSignal(project, modulator.sourceId) : null;
    let sourceValue = 0;
    if (sourceType === 'signal') { if (!source) continue; sourceValue = signalValue(source, project, time, object); }
    else if (sourceType === 'reaction') sourceValue = sampleReactionOutput(modulator.output || 'scalar');
    else if (sourceType === 'modifier') {
      if (!project) continue;
      const sourceModifier = (object ? effectiveModifiers(object, project) : (project.effects || [])).find((entry) => entry.id === modulator.sourceId && entry.enabled);
      if (!sourceModifier) continue;
      const sourceDefinition = modifierDefinition(sourceModifier.type);
      const sourceParams = modulatedParams(sourceModifier, project, time, object, sourceDefinition, cache, activeStack);
      sourceValue = modifierOutputValue({ ...sourceModifier, params: sourceParams }, modulator.output || 'scalar', project, time, object);
    } else continue;
    if (modulator.adapter) sourceValue = Number(applyAdapter(sourceValue, modulator.adapter as Adapter));
    const base = Number(next[key] ?? field.min ?? 0);
    const driven = base + Number(modulator.offset ?? 0) + sourceValue * Number(modulator.amount ?? 0);
    const min = field.overdrive ? 0 : field.min;
    const max = field.overdrive ? 10 : field.max;
    next[key] = Math.max(min ?? -Infinity, Math.min(max ?? Infinity, driven));
  }
  activeStack.delete(modifier.id);
  cache?.set(modifier.id, next);
  return next;
}

export function effectiveModifiers(object: SceneObject, project: Project | null): SceneModifier[] {
  const groups = (project?.effectGroups || []).filter((group) => group.enabled && group.targetIds.includes(object.id));
  const look = project?.looks?.find((entry) => entry.id === object.lookId);
  return [...(look?.modifiers || []), ...(object.modifiers || []), ...groups.flatMap((group) => group.modifiers)];
}

export function defaultModulator(sourceId?: string, sourceType: ParameterModulator['sourceType'] = 'signal', output?: string): ParameterModulator {
  return { sourceId: sourceId || '', sourceType, output, amount: 0.25, offset: 0, enabled: true };
}

export function normalizeSignals(value: unknown): SignalSource[] {
  if (!Array.isArray(value)) return [];
  return value.filter((entry): entry is Partial<SignalSource> => !!entry && typeof entry === 'object').map((entry) => ({
    id: typeof entry.id === 'string' ? entry.id : defaultSignal().id,
    name: typeof entry.name === 'string' ? entry.name : 'Signal',
    kind: (entry.kind || 'sine') as SignalSource['kind'],
    enabled: entry.enabled !== false,
    params: entry.params && typeof entry.params === 'object' ? { ...entry.params } : {},
  }));
}

export function normalizeModifiers(value: unknown): SceneModifier[] {
  if (!Array.isArray(value)) return [];
  return value.filter((entry): entry is Partial<SceneModifier> => !!entry && typeof entry === 'object' && typeof entry.type === 'string').map((entry) => ({
    id: typeof entry.id === 'string' ? entry.id : `mod_${Date.now()}-${Math.random().toString(36).slice(2)}`,
    type: entry.type!,
    enabled: entry.enabled !== false,
    params: entry.params && typeof entry.params === 'object' ? { ...entry.params } : {},
    ...(entry.modulators && typeof entry.modulators === 'object' ? { modulators: entry.modulators } : {}),
  }));
}

export function normalizeEffectGroups(value: unknown): EffectGroup[] {
  if (!Array.isArray(value)) return [];
  return value.filter((entry): entry is Partial<EffectGroup> => !!entry && typeof entry === 'object').map((entry) => ({
    id: typeof entry.id === 'string' ? entry.id : `grp_${Date.now()}-${Math.random().toString(36).slice(2)}`,
    name: typeof entry.name === 'string' ? entry.name : 'Shared effect',
    enabled: entry.enabled !== false,
    targetIds: Array.isArray(entry.targetIds) ? entry.targetIds.filter((id): id is string => typeof id === 'string') : [],
    modifiers: normalizeModifiers(entry.modifiers),
  }));
}
