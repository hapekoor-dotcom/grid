import type { LightingSettings } from '../types/project';

export type RenderQuality = LightingSettings['quality'];

export interface QualityProfile {
  label: string;
  dpr: number | [number, number];
  shadows: number;
  raymarch: boolean;
  volumetricSamples: number;
  msaa: number;
  bloom: boolean;
  contactShadows: boolean;
  ssaoRadius: number;
}

const PROFILES: Record<RenderQuality, QualityProfile> = {
  low: {
    label: 'Low', dpr: 1, shadows: 0, raymarch: false, volumetricSamples: 0,
    msaa: 0, bloom: true, contactShadows: false, ssaoRadius: 0.8,
  },
  medium: {
    label: 'Medium', dpr: [1, 1.2], shadows: 2, raymarch: false, volumetricSamples: 0,
    msaa: 0, bloom: true, contactShadows: false, ssaoRadius: 0.8,
  },
  high: {
    label: 'High', dpr: 1, shadows: 4, raymarch: true, volumetricSamples: 20,
    msaa: 2, bloom: true, contactShadows: true, ssaoRadius: 0.8,
  },
  ultra: {
    label: 'Ultra', dpr: [1, 1.5], shadows: 4, raymarch: true, volumetricSamples: 48,
    msaa: 4, bloom: true, contactShadows: true, ssaoRadius: 0.9,
  },
  photo: {
    label: 'Photo', dpr: [1, 2], shadows: 4, raymarch: true, volumetricSamples: 96,
    msaa: 4, bloom: true, contactShadows: true, ssaoRadius: 0.9,
  },
};

export type AntiAliasingMode = 'off' | 'msaa' | 'taa';

export function antiAliasingFor(lighting: LightingSettings): AntiAliasingMode {
  if (lighting.antiAliasing) return lighting.antiAliasing;
  if (lighting.quality === 'high' || lighting.quality === 'ultra' || lighting.quality === 'photo') return 'taa';
  if (lighting.quality === 'medium') return 'msaa';
  return 'off';
}

export function getQualityProfile(quality: RenderQuality): QualityProfile {
  return PROFILES[quality] || PROFILES.high;
}

export const QUALITY_OPTIONS = (Object.keys(PROFILES) as RenderQuality[]).map((id) => ({ id, label: PROFILES[id].label }));
