import { strToU8, strFromU8, unzipSync, zipSync } from 'fflate';
import type { Project } from '../types/project';
import { getAsset, putAsset, type StoredAsset } from './assetStore';
import { collectMaterialTextureAssetIds } from './materialMaps';

export interface PortableAsset {
  id: string;
  name: string;
  mime: string;
  path: string;
}

export interface PortableManifest {
  format: 'remorph-portable';
  version: 1;
  project: Project;
  assets: PortableAsset[];
}

function safeName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 100) || 'asset';
}

export async function createPortableProject(project: Project): Promise<Blob> {
  const ids = [...new Set([
    ...project.objects.map((object) => object.assetId).filter((id): id is string => !!id),
    ...collectMaterialTextureAssetIds(project.objects),
  ])];
  const files: Record<string, Uint8Array> = {};
  const assets: PortableAsset[] = [];
  for (const id of ids) {
    const asset = await getAsset(id);
    if (!asset) throw new Error(`Missing imported asset: ${id}`);
    const path = `assets/${id}/${safeName(asset.name)}`;
    files[path] = new Uint8Array(asset.data);
    assets.push({ id, name: asset.name, mime: asset.mime, path });
  }
  const manifest: PortableManifest = { format: 'remorph-portable', version: 1, project, assets };
  files['manifest.json'] = strToU8(JSON.stringify(manifest, null, 2));
  const data = zipSync(files, { level: 6 });
  return new Blob([new Uint8Array(data).buffer as ArrayBuffer], { type: 'application/zip' });
}

export async function readPortableProject(file: File): Promise<{ manifest: PortableManifest; project: Project }> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let entries: Record<string, Uint8Array>;
  try {
    entries = unzipSync(bytes);
  } catch {
    throw new Error('The portable project archive is not a valid .remorph package.');
  }
  const rawManifest = entries['manifest.json'];
  if (!rawManifest) throw new Error('Missing manifest.json in portable project.');
  let manifest: PortableManifest;
  try {
    manifest = JSON.parse(strFromU8(rawManifest));
  } catch {
    throw new Error('Portable project manifest is not valid JSON.');
  }
  if (manifest.format !== 'remorph-portable' || manifest.version !== 1 || !manifest.project) {
    throw new Error('Unsupported portable project format.');
  }
  for (const asset of manifest.assets || []) {
    const data = entries[asset.path];
    if (!data) throw new Error(`Missing packaged asset: ${asset.path}`);
    const stored: StoredAsset = { id: asset.id, name: asset.name, mime: asset.mime, data: new Uint8Array(data).buffer as ArrayBuffer, createdAt: Date.now() };
    await putAsset(stored);
  }
  return { manifest, project: manifest.project };
}

export async function isPortableProjectFile(file: File): Promise<boolean> {
  if (/\.(remorph|zip)$/i.test(file.name) || /zip/i.test(file.type)) return true;
  const head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
  return head[0] === 0x50 && head[1] === 0x4b;
}
