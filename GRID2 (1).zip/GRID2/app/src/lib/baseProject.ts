import baseProject from '../data/base-project.json';
import type { Project } from '../types/project';
import { createDefaultTimeline } from '../types/timeline';
import { normalizePhysics } from './physics';
import { normalizeReactionDiffusion } from './reactionDiffusion';
import { normalizeCustomShaders } from './customShaders';

/**
 * The supplied venue scene is the working demo project.
 * It is stored as data so the demo button opens the real app frame.
 */
export function createBaseProject(): Project {
  const source = baseProject.project as unknown as Project;
  const project = structuredClone(source);
  // The saved editor pan/zoom is personal; start with a fitted plan instead.
  project.view = { plan: { panX: 0, panY: 0, zoom: 0 }, camera3d: null };
  project.effects = project.effects || [];
  project.fields = project.fields || [];
  project.customShaders = normalizeCustomShaders(project.customShaders);
  project.fieldLinks = project.fieldLinks || [];
  project.mutation = project.mutation || { accepted: [], branchId: `branch_${crypto.randomUUID()}` };
  project.reactionDiffusion = project.reactionDiffusion ? normalizeReactionDiffusion(project.reactionDiffusion) : undefined;
  project.postShaders = (project.postShaders || []).map((entry, index) => ({ ...entry, id: entry.id || `pass_${index}_${entry.shaderId}` }));
  project.looks = project.looks || [];
  project.signals = project.signals || [];
  project.effectGroups = project.effectGroups || [];
  project.physics = normalizePhysics(project.physics);
  project.timeline = project.timeline ? { ...project.timeline, groupEffects: project.timeline.groupEffects || [] } : createDefaultTimeline();
  return project;
}
