import { useMemo } from 'react';
import type { Project } from '../types/project';
import { computeDmxPatch, type DmxPatchResult } from './dmx';
import { computePower, type PowerResult } from './power';
import { computeDiagnostics, countDiagnostics, type DiagnosticCounts } from './diagnostics';
import type { Diagnostic } from './dmx';
import { useActiveProject } from '../store/workspaceStore';

export interface Analysis {
  dmx: DmxPatchResult;
  power: PowerResult;
  diagnostics: Diagnostic[];
  counts: DiagnosticCounts;
}

let cachedProject: Project | null = null;
let cachedAnalysis: Analysis | null = null;

export function getAnalysis(project: Project | null): Analysis {
  if (!project) {
    const empty: Analysis = {
      dmx: { rows: [], diagnostics: [], universes: [], patchedCount: 0, totalChannels: 0 },
      power: { rows: [], phases: [], ports: [], distros: [], diagnostics: [], totalWatts: 0, unknownCount: 0 },
      diagnostics: [],
      counts: { error: 0, warning: 0, info: 0 },
    };
    return empty;
  }
  if (cachedProject === project && cachedAnalysis) return cachedAnalysis;
  const dmx = computeDmxPatch(project);
  const power = computePower(project);
  const diagnostics = computeDiagnostics(project, dmx, power);
  const analysis: Analysis = { dmx, power, diagnostics, counts: countDiagnostics(diagnostics) };
  cachedProject = project;
  cachedAnalysis = analysis;
  return analysis;
}

export function useAnalysis(): Analysis {
  const project = useActiveProject();
  return useMemo(() => getAnalysis(project), [project]);
}
