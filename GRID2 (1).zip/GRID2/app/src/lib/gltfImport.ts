const MIME: Record<string, string> = {
  bin: 'application/octet-stream',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  ktx2: 'image/ktx2',
  basis: 'image/basis',
};

function normalizePath(path: string): string {
  const parts: string[] = [];
  for (const part of path.replace(/\\/g, '/').split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') parts.pop(); else parts.push(part);
  }
  return parts.join('/');
}

function dirname(path: string): string {
  const normalized = normalizePath(path);
  const index = normalized.lastIndexOf('/');
  return index < 0 ? '' : normalized.slice(0, index);
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(binary);
}

function filePaths(file: File): string[] {
  const relative = normalizePath((file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name);
  return [relative, normalizePath(file.name)];
}

export async function normalizeModelFiles(files: File[]): Promise<{ data: ArrayBuffer; name: string; mime: string }> {
  const glb = files.find((file) => /\.glb$/i.test(file.name));
  if (glb) {
    if (glb.size > 200 * 1024 * 1024) throw new Error('Model is larger than 200 MB.');
    return { data: await glb.arrayBuffer(), name: glb.name, mime: 'model/gltf-binary' };
  }
  const gltf = files.find((file) => /\.gltf$/i.test(file.name));
  if (!gltf) throw new Error('Select a .gltf or .glb file.');
  const text = await gltf.text();
  let document: any;
  try {
    document = JSON.parse(text);
  } catch {
    throw new Error('The .gltf document is not valid JSON.');
  }
  const byPath = new Map<string, File>();
  for (const file of files) for (const path of filePaths(file)) byPath.set(path.toLowerCase(), file);
  const entryPath = normalizePath((gltf as File & { webkitRelativePath?: string }).webkitRelativePath || gltf.name);
  const base = dirname(entryPath);
  const missing: string[] = [];
  const resolve = (uri: string): File | null => {
    if (!uri || uri.startsWith('data:') || /^https?:/i.test(uri)) return null;
    const clean = decodeURIComponent(uri.split(/[?#]/)[0]);
    const candidates = [normalizePath(base ? `${base}/${clean}` : clean), normalizePath(clean)];
    for (const candidate of candidates) {
      const found = byPath.get(candidate.toLowerCase());
      if (found) return found;
    }
    const basename = normalizePath(clean).split('/').pop()?.toLowerCase();
    const matches = files.filter((file) => normalizePath(file.name).toLowerCase() === basename);
    return matches.length === 1 ? matches[0] : null;
  };
  const inline = async (uri: string): Promise<string> => {
    const file = resolve(uri);
    if (!file) { missing.push(uri); return uri; }
    const extension = file.name.split('.').pop()?.toLowerCase() || 'bin';
    const bytes = new Uint8Array(await file.arrayBuffer());
    return `data:${MIME[extension] || 'application/octet-stream'};base64,${bytesToBase64(bytes)}`;
  };
  for (const buffer of document.buffers || []) {
    if (typeof buffer.uri === 'string') buffer.uri = await inline(buffer.uri);
  }
  for (const image of document.images || []) {
    if (typeof image.uri === 'string') image.uri = await inline(image.uri);
  }
  if (missing.length) throw new Error(`Missing file: ${missing[0]}${missing.length > 1 ? ` (+${missing.length - 1} more)` : ''}`);
  const normalized = new TextEncoder().encode(JSON.stringify(document));
  return { data: normalized.buffer as ArrayBuffer, name: gltf.name, mime: 'model/gltf+json' };
}
