import { describe, expect, it } from 'vitest';
import type { Project, SceneObject } from '../types/project';
import { effectiveModifiers } from './signals';
import { createModifier } from './modifiers';
import { applyTimelineToProject, baseValue, sampleTimeline } from './timeline';

const object = { id: 'o1', type: 'model', name: 'Sphere', deviceId: null, position: { x: 0, z: 0 }, rotation: 0, elevation: 0, lookId: 'look1' } as SceneObject;

function project(): Project {
  return {
    id: 'p', name: 'Looks', schemaVersion: 5, createdAt: '', updatedAt: '', settings: {} as Project['settings'], objects: [object],
    connections: [], guides: [], lighting: {} as Project['lighting'], view: {} as Project['view'], migration: null,
    timeline: { duration: 10, loop: true, tracks: [], clips: [], groupEffects: [] }, signals: [], effects: [], fields: [], looks: [{
      id: 'look1', name: 'Shared', createdAt: '',
      material: { roughness: 0.5, metalness: 0.8 },
      modifiers: [{ ...createModifier('liquidChrome'), id: 'effect1', params: { ...createModifier('liquidChrome').params, distortion: 0.4 } }],
    }],
  };
}

describe('shared look', () => {
  it('resolves one shared modifier stack through lookId', () => {
    expect(effectiveModifiers(object, project())[0].id).toBe('effect1');
  });

  it('exposes look material and effect Timeline paths', () => {
    const p = project();
    expect(baseValue(p, null, 'look.look1.material.roughness')).toBe(0.5);
    expect(baseValue(p, null, 'look.look1.effect.effect1.distortion')).toBe(0.4);
  });

  it('applies a look Timeline override to the one shared source', () => {
    const effective = applyTimelineToProject(project(), new Map([['scene:look.look1.material.roughness', 0.1], ['scene:look.look1.effect.effect1.distortion', 2]]));
    expect(effective.looks?.[0].material.roughness).toBe(0.1);
    expect(effective.looks?.[0].modifiers?.[0].params.distortion).toBe(2);
  });
});

it('samples and applies a post shader timeline value', () => {
  const postProject = { ...project() } as any;
  postProject.postShaders = [{ shaderId: 'post1', enabled: true, values: { uStrength: 1 } }];
  postProject.timeline = { duration: 10, loop: true, tracks: [{ id: 't1', objectId: null, propertyPath: 'scene.post.post1.uStrength', keyframes: [{ id: 'k1', time: 0, value: 1, easing: 'linear' }, { id: 'k2', time: 10, value: 5, easing: 'linear' }] }], clips: [], groups: [], groupEffects: [] } as any;
  const overrides = sampleTimeline(postProject, 5);
  expect(overrides.get('scene:scene.post.post1.uStrength')).toBe(3);
  const effective = applyTimelineToProject(postProject, overrides);
  expect(effective.postShaders?.[0].values.uStrength).toBe(3);
});
