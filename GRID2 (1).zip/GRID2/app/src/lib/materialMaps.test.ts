import { describe, expect, it } from 'vitest';
import { collectMaterialTextureAssetIds, normalizeMaterial, normalizeMaterialOverrides, normalizeTextureLayer } from './materialMaps';
import type { SceneObject } from '../types/project';

describe('material texture maps', () => {
  it('normalizes per-slot map layers without embedding binary data', () => {
    const material = normalizeMaterial({ maps: { normal: { assetId: 'asset_1', assetName: 'n.png', uv: 2, tiling: { x: 4, y: 4 }, offset: { x: 0.25, y: -0.25 }, rotation: 45, channel: 'g' } } });
    expect(material?.maps?.normal).toMatchObject({ assetId: 'asset_1', uv: 2, tiling: { x: 4, y: 4 }, rotation: 45, channel: 'g' });
    expect(material?.maps?.normal).not.toHaveProperty('data');
    expect(normalizeMaterialOverrides({ SlotA: material }).SlotA?.maps?.normal?.assetId).toBe('asset_1');
  });

  it('clamps UV channels and preserves reset-to-original references', () => {
    expect(normalizeTextureLayer({ uv: 12 })?.uv).toBe(7);
    expect(normalizeTextureLayer({ assetId: null, tiling: { x: 2, y: 2 } })).toEqual({ assetId: null, tiling: { x: 2, y: 2 } });
  });

  it('collects only texture assets referenced by instance overrides', () => {
    const objects = [
      { id: 'a', material: { maps: { normal: { assetId: 'asset_a' } } }, materialOverrides: { Slot: { maps: { ao: { assetId: 'asset_b' } } } } },
      { id: 'b', materialOverrides: { Slot: { maps: { ao: { assetId: 'asset_b' } } } } },
    ] as unknown as SceneObject[];
    expect(collectMaterialTextureAssetIds(objects).sort()).toEqual(['asset_a', 'asset_b']);
  });
});
