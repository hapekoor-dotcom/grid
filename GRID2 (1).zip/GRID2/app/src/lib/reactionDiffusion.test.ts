import { describe, expect, it } from 'vitest';
import type { Project, SignalSource } from '../types/project';
import { defaultReactionDiffusion, modulatedReactionDiffusion, normalizeReactionDiffusion, rdPreset } from './reactionDiffusion';

const signal: SignalSource = { id: 's1', name: 'Sine', kind: 'sine', enabled: true, params: { frequency: 1, amplitude: 1, phase: 0 } };
const project = { signals: [signal] } as unknown as Project;

describe('reaction diffusion config', () => {
  it('normalizes unsafe values and preserves presets', () => {
    const config = normalizeReactionDiffusion({ feed: Number.NaN, kill: 99, resolution: 9999, iterations: 999 });
    expect(config.feed).toBe(defaultReactionDiffusion().feed);
    expect(config.kill).toBe(0.1);
    expect(config.resolution).toBe(256);
    expect(config.iterations).toBe(64);
    expect(rdPreset('coral').preset).toBe('coral');
  });

  it('modulates RD parameters through the shared signal engine', () => {
    const config = { ...defaultReactionDiffusion(), feed: 0.03, modulators: { feed: { sourceId: 's1', amount: 0.01, offset: 0, enabled: true } } };
    expect(modulatedReactionDiffusion(config, project, 0.25).feed).not.toBe(0.03);
    expect(modulatedReactionDiffusion(config, project, 0).feed).toBeGreaterThanOrEqual(0);
  });
});
