import type { Project, SceneModifier, MutationRecord } from '../types/project';
import { modifierDefinition, modifierDefinition as definition } from './modifiers';
import { wouldCreateModifierCycle } from './graphRouting';
import { defaultModulator } from './signals';

export type MutationScope = 'object' | 'look' | 'scene';
export interface MutationOptions {
  project: Project;
  objectIds: string[];
  lookId?: string;
  scope: MutationScope;
  depth: number;
  seed?: number;
}

export interface MutationResult {
  project: Project;
  seed: number;
  id: string;
  diff: string[];
}

const MUTATION_KEYS: (keyof Project)[] = ['mutation'];

function random(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state += 0x6D2B79F5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function serializeProject(project: Project): string {
  const copy = structuredClone(project) as Project & Record<string, unknown>;
  for (const key of MUTATION_KEYS) delete copy[key];
  return JSON.stringify(copy);
}

function randomValue(rand: () => number, field: { min?: number; max?: number; step?: number; physicalMin?: number; physicalMax?: number; hardClamp?: boolean }, current: number): number {
  const min = field.physicalMin ?? field.min ?? -1;
  const max = field.physicalMax ?? field.max ?? 1;
  const span = Math.max(0.0001, max - min);
  const next = min + rand() * span;
  const step = field.step ?? span / 24;
  return Math.round(next / Math.max(0.0001, step)) * Math.max(0.0001, step);
}

function ownerModifiers(project: Project, scope: MutationScope, objectIds: string[], lookId?: string): { id: string; modifiers: SceneModifier[]; objectId?: string; lookId?: string }[] {
  if (scope === 'look') {
    const look = project.looks?.find((entry) => entry.id === lookId);
    return look ? [{ id: look.id, modifiers: look.modifiers || [], lookId: look.id }] : [];
  }
  if (scope === 'scene') {
    return project.objects.filter((object) => object.visible && object.type !== 'room').slice(0, 3).map((object) => ({ id: object.id, modifiers: object.modifiers || [], objectId: object.id }));
  }
  const object = project.objects.find((entry) => objectIds.includes(entry.id)) || project.objects.find((entry) => entry.type === 'model');
  return object ? [{ id: object.id, modifiers: object.modifiers || [], objectId: object.id }] : [];
}

function mutateValues(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, project: Project, diff: string[]): void {
  if (!owner.modifiers.length) return;
  const modifier = owner.modifiers[Math.floor(rand() * owner.modifiers.length)];
  const definition = modifierDefinition(modifier.type);
  const numeric = definition.fields.filter((field) => ['number', 'percent'].includes(field.kind || 'number') || field.overdrive);
  if (!numeric.length) return;
  const field = numeric[Math.floor(rand() * numeric.length)];
  const current = Number(modifier.params[field.key] ?? field.min ?? 0);
  let next = randomValue(rand, field, current);
  if (field.key === 'count') next = Math.max(1, Math.min(200, Math.round(next)));
  modifier.params = { ...modifier.params, [field.key]: next };
  diff.push(`value ${modifier.type}.${field.key}=${next}`);
  // Simulation parameters are configuration-only; never reset the RD state.
  if (project.reactionDiffusion && rand() < 0.18) {
    project.reactionDiffusion.feed = Math.max(0.005, Math.min(0.1, Number(project.reactionDiffusion.feed) + (rand() - 0.5) * 0.02));
    project.reactionDiffusion.kill = Math.max(0.02, Math.min(0.1, Number(project.reactionDiffusion.kill) + (rand() - 0.5) * 0.02));
    diff.push('simulation feed/kill perturbed');
  }
}

function mutateConnection(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, diff: string[]): void {
  const targets = owner.modifiers.filter((modifier) => modifier.enabled);
  if (targets.length < 2) return;
  const target = targets[Math.floor(rand() * targets.length)];
  const sources = owner.modifiers.filter((modifier) => modifier.id !== target.id && (modifierDefinition(modifier.type).outputs || []).length && modifier.enabled);
  if (!sources.length) return;
  const source = sources[Math.floor(rand() * sources.length)];
  if (wouldCreateModifierCycle(owner.modifiers as never, target.id, source.id)) return;
  const outputs = modifierDefinition(source.type).outputs || [];
  const output = outputs[Math.floor(rand() * outputs.length)].key;
  const fields = modifierDefinition(target.type).fields.filter((field) => ['number', 'percent'].includes(field.kind || 'number'));
  if (!fields.length) return;
  const field = fields[Math.floor(rand() * fields.length)];
  const adapters = ['remap', 'clamp', 'invert', 'multiply', 'power', 'smoothstep', 'quantize'];
  target.modulators = { ...(target.modulators || {}), [field.key]: { ...defaultModulator(source.id, 'modifier', output), amount: 0.2 + rand() * 0.8, adapter: rand() < 0.65 ? { kind: adapters[Math.floor(rand() * adapters.length)], params: {} } : undefined } };
  diff.push(`connection ${source.type}.${output} -> ${target.type}.${field.key}`);
}

function mutateAdapter(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, diff: string[]): void {
  const candidates = owner.modifiers.flatMap((modifier) => Object.entries(modifier.modulators || {}).map(([field, modulator]) => ({ modifier, field, modulator }))).filter((entry) => entry.modulator.sourceType === 'modifier' || entry.modulator.sourceType === 'reaction');
  if (!candidates.length) return;
  const entry = candidates[Math.floor(rand() * candidates.length)];
  const adapters = ['remap', 'clamp', 'invert', 'multiply', 'power', 'smoothstep', 'quantize'];
  entry.modulator.adapter = { kind: adapters[Math.floor(rand() * adapters.length)], params: {} };
  entry.modulator.amount = 0.15 + rand() * 1.1;
  diff.push(`adapter ${entry.modifier.type}.${entry.field}`);
}

function mutateStack(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, diff: string[]): void {
  const indices = owner.modifiers.map((modifier, index) => ({ modifier, index })).filter((entry) => {
    const definition = modifierDefinition(entry.modifier.type);
    return (definition.stage || definition.runtime) === 'geometry';
  });
  if (indices.length < 2) return;
  const a = indices[Math.floor(rand() * indices.length)];
  let b = indices[Math.floor(rand() * indices.length)];
  if (a.index === b.index) b = indices[(indices.indexOf(a) + 1) % indices.length];
  const first = owner.modifiers[a.index];
  owner.modifiers[a.index] = b.modifier;
  owner.modifiers[b.index] = first;
  diff.push(`stack swap ${first.type} <> ${b.modifier.type}`);
}

function mutateTime(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, diff: string[]): void {
  const candidates = owner.modifiers.filter((modifier) => modifier.params.speed !== undefined || modifier.params.phase !== undefined);
  if (!candidates.length) return;
  const modifier = candidates[Math.floor(rand() * candidates.length)];
  if (modifier.params.speed !== undefined) modifier.params = { ...modifier.params, speed: Number(modifier.params.speed) * (0.4 + rand() * 1.8) };
  if (modifier.params.phase !== undefined) modifier.params = { ...modifier.params, phase: rand() * Math.PI * 2 };
  diff.push(`time ${modifier.type}`);
}

function mutateMapping(rand: () => number, owner: { id: string; modifiers: SceneModifier[] }, diff: string[]): void {
  const candidates = owner.modifiers.filter((modifier) => modifier.params.mapping !== undefined);
  if (!candidates.length) return;
  const modifier = candidates[Math.floor(rand() * candidates.length)];
  const values = ['auto', 'uv0', 'triplanar', 'object', 'world', 'spherical'];
  modifier.params = { ...modifier.params, mapping: values[Math.floor(rand() * values.length)] };
  diff.push(`mapping ${modifier.type}`);
}

export function mutateProject(options: MutationOptions): MutationResult {
  const seed = options.seed ?? (Math.floor(Math.random() * 0xFFFFFFFF) >>> 0);
  const rand = random(seed);
  const project = structuredClone(options.project);
  const diff: string[] = [];
  const owners = ownerModifiers(project, options.scope, options.objectIds, options.lookId);
  const depth = Math.max(0, Math.min(1, options.depth));
  const count = depth < 0.25 ? 1 : depth < 0.5 ? 2 : depth < 0.75 ? 3 : 4;
  for (let index = 0; index < count; index += 1) {
    const owner = owners[Math.floor(rand() * Math.max(1, owners.length))];
    if (!owner) break;
    const roll = rand();
    if (depth < 0.3) mutateValues(rand, owner, project, diff);
    else if (roll < 0.45) mutateValues(rand, owner, project, diff);
    else if (roll < 0.68) mutateConnection(rand, owner, diff);
    else if (roll < 0.82) mutateAdapter(rand, owner, diff);
    else if (roll < 0.91) mutateStack(rand, owner, diff);
    else mutateTime(rand, owner, diff);
    if (rand() < 0.08) mutateMapping(rand, owner, diff);
  }
  if (!diff.length) {
    const owner = owners[0];
    if (owner?.modifiers.length) {
      const modifier = owner.modifiers[0];
      const field = modifierDefinition(modifier.type).fields.find((entry) => ['number', 'percent'].includes(entry.kind || 'number'));
      if (field) {
        const current = Number(modifier.params[field.key] ?? field.min ?? 0);
        modifier.params = { ...modifier.params, [field.key]: randomValue(rand, field, current) };
        diff.push(`value ${modifier.type}.${field.key}`);
      }
    }
  }
  const id = `mut_${seed.toString(16)}_${Date.now().toString(36)}`;
  if (!project.mutation) project.mutation = { accepted: [], branchId: `branch_${crypto.randomUUID()}` };
  return { project, seed, id, diff };
}

export function mutationRecord(project: Project, before: string, result: MutationResult, scope: MutationScope, depth: number, parentId: string | null): MutationRecord {
  return {
    id: result.id,
    parentId,
    branchId: project.mutation?.branchId || `branch_${crypto.randomUUID()}`,
    seed: result.seed,
    depth,
    scope,
    createdAt: new Date().toISOString(),
    before,
    after: serializeProject(project),
    diff: result.diff,
  };
}
