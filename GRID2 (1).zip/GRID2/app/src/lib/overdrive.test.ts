import { describe, expect, it } from 'vitest';
import { clampOverdrive, overdriveToSlider, sliderToOverdrive } from './overdrive';

describe('overdrive mapping', () => {
  it('preserves 0/100/1000 percent semantics', () => {
    expect(sliderToOverdrive(0)).toBe(0);
    expect(sliderToOverdrive(0.6)).toBe(1);
    expect(sliderToOverdrive(0.85)).toBeCloseTo(10, 6);
    expect(sliderToOverdrive(1)).toBeCloseTo(100, 6);
  });

  it('round-trips the tested percentages', () => {
    for (const percent of [0, 25, 100, 150, 500, 1000, 4200, 10000]) {
      const value = percent / 100;
      expect(sliderToOverdrive(overdriveToSlider(value))).toBeCloseTo(value, 6);
    }
  });

  it('keeps 0-100 percent in the first 60 percent of travel', () => {
    expect(overdriveToSlider(0.5)).toBeCloseTo(0.3, 6);
    expect(overdriveToSlider(1)).toBeCloseTo(0.6, 6);
  });

  it('clamps non-finite and out-of-range values', () => {
    expect(clampOverdrive(Number.NaN)).toBe(0);
    expect(clampOverdrive(Number.POSITIVE_INFINITY)).toBe(100);
    expect(clampOverdrive(-2)).toBe(0);
    expect(clampOverdrive(20)).toBe(20);
    expect(clampOverdrive(200)).toBe(100);
  });
});
