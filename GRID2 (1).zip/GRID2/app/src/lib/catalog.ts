import catalogJson from '../data/catalog.json';
import type { CableType, CatalogDevice, CatalogFile, DmxMode, PortDef } from '../types/catalog';

export const catalog = catalogJson as unknown as CatalogFile;

export const devicesById = new Map<string, CatalogDevice>(catalog.devices.map((device) => [device.id, device]));

export const devices = catalog.devices;

export const visibleDevices = catalog.devices.filter((device) => !device.hidden);

// Power first: the catalog opens with the power infrastructure, as on site.
const CATEGORY_ORDER = ['power', 'light', 'effects', 'rigging', 'stage', 'network', 'control', 'video'];
export const CATEGORY_LABELS: Record<string, string> = {
  light: 'Lighting',
  effects: 'Effects',
  rigging: 'Rigging',
  stage: 'Stage',
  power: 'Power',
  network: 'Network',
  control: 'Control',
  video: 'Video',
  sound: 'Sound',
};
// Keep the catalog's Russian category labels searchable alongside the English UI labels.
const CATEGORY_ALIASES: Record<string, string> = Object.fromEntries(catalog.categories.map((category) => [category.id, category.label]));
export const categories = [...catalog.categories].sort((a, b) => {
  const ai = CATEGORY_ORDER.indexOf(a.id);
  const bi = CATEGORY_ORDER.indexOf(b.id);
  return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
}).map((category) => ({ ...category, label: CATEGORY_LABELS[category.id] || category.label }));

export const CABLE_TYPES: CableType[] = ['power', 'dmx', 'ethernet', 'usb', 'video', 'wireless'];

export const CABLE_META: Record<CableType, { label: string; short: string; color: string; description: string }> = {
  power: { label: 'Power', short: 'PWR', color: '#E58A32', description: 'Power circuits, phases, and budgets' },
  dmx: { label: 'DMX', short: 'DMX', color: '#7FB26A', description: 'DMX lines, 512-channel Universe' },
  ethernet: { label: 'Ethernet', short: 'NET', color: '#7E94A3', description: 'Art-Net, sACN, and control' },
  usb: { label: 'USB', short: 'USB', color: '#B8B2A7', description: 'USB connections and service ports' },
  video: { label: 'Video / radio', short: 'VID', color: '#C06A3C', description: 'Video signal and wireless channels' },
  wireless: { label: 'Wireless', short: 'RF', color: '#C06A3C', description: 'Wireless DMX transmission' },
};

export function isCableType(value: string): value is CableType {
  return (CABLE_TYPES as string[]).includes(value);
}

export function getDevice(id: string | null | undefined): CatalogDevice | null {
  if (!id) return null;
  return devicesById.get(id) || null;
}

export function getMode(device: CatalogDevice | null, modeId: string | null): DmxMode | null {
  if (!device) return null;
  if (!modeId) return device.modes.find((mode) => mode.id === device.defaultModeId) || device.modes[0] || null;
  return device.modes.find((mode) => mode.id === modeId) || null;
}

export function deviceLabel(device: CatalogDevice): string {
  return device.shortName || device.name;
}

const GROUP_LABELS: Record<string, string> = {
  head: 'Moving heads', beam: 'Beam', spot: 'Spot', par: 'PAR & wash', bar: 'LED bars',
  pixel: 'Pixel bars', strobe: 'Strobes', blinder: 'Blinders', laser: 'Lasers',
  effectlight: 'Projectors & effects', flood: 'Flood', panel: 'Panels', decor: 'Decor',
  mirrorball: 'Mirror balls', motor: 'Motors', other: 'Other', haze: 'Hazers',
  fog: 'Fog machines', snow: 'Snow', bubble: 'Bubbles', co2: 'CO₂', confetti: 'Confetti',
  flame: 'Flame', fan: 'Fans', effect: 'Other', truss: 'Trusses', trussTower: 'Towers',
  stage: 'Risers', curtain: 'Backdrops', table: 'Tables', chair: 'Chairs', barricade: 'Barriers',
  outlet: 'Outlets & mains', distro: 'Distros', battery: 'Batteries', dimmer: 'Dimmers',
  generator: 'Generators', solar: 'Solar panels', power: 'Other', node: 'DMX nodes',
  splitter: 'Splitters', switch: 'Switches', receiver: 'Receivers', transmitter: 'Transmitters',
  interface: 'Interfaces', console: 'Consoles', laptop: 'Laptops', computer: 'Computers',
  controller: 'Controllers', player: 'Media players', mixer: 'Mixers', phone: 'Phones',
  tablet: 'Tablets', ledwall: 'LED walls', tv: 'Screens', projector: 'Projectors',
  processor: 'Processors', camera: 'Cameras', video: 'Other', canvas: 'Other',
  speaker: 'Speakers', soundbooth: 'Sound booths',
};

export function kindLabel(device: CatalogDevice): string {
  return GROUP_LABELS[device.kind] || CATEGORY_LABELS[device.category] || device.kind;
}

export const GROUP_ORDER: Record<string, string[]> = {
  light: ['head', 'beam', 'spot', 'par', 'bar', 'pixel', 'strobe', 'blinder', 'laser', 'effectlight', 'flood', 'panel', 'decor', 'mirrorball', 'motor', 'other'],
  effects: ['haze', 'fog', 'snow', 'bubble', 'co2', 'confetti', 'flame', 'fan', 'effect'],
  rigging: ['truss', 'trussTower'],
  stage: ['stage', 'curtain', 'table', 'chair', 'barricade'],
  power: ['outlet', 'distro', 'battery', 'dimmer', 'generator', 'solar', 'power'],
  network: ['node', 'splitter', 'switch', 'receiver', 'transmitter', 'interface'],
  control: ['console', 'laptop', 'computer', 'controller', 'interface', 'player', 'mixer', 'phone', 'tablet'],
  video: ['ledwall', 'tv', 'projector', 'processor', 'mixer', 'camera', 'video'],
  sound: ['speaker', 'soundbooth'],
};

export interface CatalogGroup {
  id: string;
  category: string;
  kind: string;
  label: string;
  count: number;
}

export function buildCatalogGroups(includeHidden = false): CatalogGroup[] {
  const pool = includeHidden ? catalog.devices : visibleDevices;
  const groups: CatalogGroup[] = [];
  for (const category of categories) {
    const kinds = GROUP_ORDER[category.id] || [];
    const found = new Set(pool.filter((device) => device.category === category.id).map((device) => device.kind));
    for (const kind of kinds) {
      const count = pool.filter((device) => device.category === category.id && device.kind === kind).length;
      if (count) groups.push({ id: `${category.id}.${kind}`, category: category.id, kind, label: GROUP_LABELS[kind] || kind, count });
    }
    for (const kind of found) {
      if (!kinds.includes(kind)) {
        const count = pool.filter((device) => device.category === category.id && device.kind === kind).length;
        groups.push({ id: `${category.id}.${kind}`, category: category.id, kind, label: GROUP_LABELS[kind] || kind, count });
      }
    }
  }
  return groups;
}

export function searchDevices(query: string, includeHidden = false): CatalogDevice[] {
  const pool = includeHidden ? catalog.devices : visibleDevices;
  const normalized = query.trim().toLowerCase();
  if (!normalized) return pool;
  const terms = normalized.split(/\s+/);
  return pool
    .map((device) => {
      const haystack = `${device.name} ${device.shortName} ${device.brand || ''} ${device.kind} ${CATEGORY_LABELS[device.category] || device.category} ${CATEGORY_ALIASES[device.category] || ''} ${device.colorSystem} ${device.catalogSubtitle}`.toLowerCase();
      if (!terms.every((term) => haystack.includes(term))) return null;
      const starts = device.shortName.toLowerCase().startsWith(normalized) ? 0 : 1;
      return { device, score: starts };
    })
    .filter((entry): entry is { device: CatalogDevice; score: number } => entry !== null)
    .sort((a, b) => a.score - b.score || a.device.shortName.localeCompare(b.device.shortName, 'ru'))
    .map((entry) => entry.device);
}

export function portsOf(device: CatalogDevice): PortDef[] {
  const byId = new Map<string, PortDef>();
  for (const port of [...device.signalPorts, ...device.powerPorts]) {
    if (!byId.has(port.id)) byId.set(port.id, port);
  }
  return [...byId.values()];
}

export function verificationLabel(device: CatalogDevice): { label: string; tone: 'ok' | 'warn' | 'muted' } {
  if (device.planning || device.verification.status === 'generic') return { label: 'Generic object', tone: 'muted' };
  switch (device.verification.status) {
    case 'verified':
      return { label: 'Verified', tone: 'ok' };
    case 'partial':
      return { label: 'Partial', tone: 'warn' };
    case 'unresolved':
      return { label: 'Unverified', tone: 'warn' };
    case 'not_applicable':
      return { label: 'No DMX', tone: 'muted' };
    default:
      return { label: 'Unverified', tone: 'muted' };
  }
}

export function wattsLabel(device: CatalogDevice): string {
  if (device.watts === null) return 'not specified';
  const suffix = device.wattsBasis === 'typical' ? ' typ.' : device.wattsBasis === 'maximum' ? ' max.' : device.wattsBasis === 'lamp-rating' ? ' lamp' : '';
  return `${device.watts} W${suffix}`;
}

export function dimsLabel(device: CatalogDevice): string {
  const { w, d, h, source } = device.dims;
  const text = `${Math.round(w * 1000)} × ${Math.round(d * 1000)} × ${Math.round(h * 1000)} mm`;
  return source === 'manufacturer' ? text : `${text} · nominal`;
}

export function hasDmx(device: CatalogDevice): boolean {
  return device.dmx && (device.modes.length > 0 || device.requiresProfile || device.generic);
}

export function sourceSupportsPhases(device: CatalogDevice): boolean {
  return device.sourceType && (device.kind === 'outlet' || device.kind === 'distro');
}

export function portColor(type: CableType): string {
  return CABLE_META[type].color;
}
