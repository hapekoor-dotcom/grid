import { assetObjectUrl, newAssetId, putAsset } from './assetStore';

const MAX_TEXTURE_BYTES = 40 * 1024 * 1024;

export async function storeMaterialTexture(file: File): Promise<{ assetId: string; assetName: string }> {
  if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|gif|avif|bmp|tga)$/i.test(file.name)) {
    throw new Error('Choose an image file for this texture map.');
  }
  if (file.size > MAX_TEXTURE_BYTES) throw new Error('Texture files must be smaller than 40 MB.');
  const assetId = newAssetId();
  const assetName = file.name || 'texture';
  await putAsset({ id: assetId, name: assetName, mime: file.type || 'image/png', data: await file.arrayBuffer(), createdAt: Date.now() });
  return { assetId, assetName };
}

export function materialTextureUrl(assetId: string): Promise<string | null> {
  return assetObjectUrl(assetId);
}
