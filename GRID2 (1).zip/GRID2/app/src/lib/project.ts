import { createDefaultTimeline } from '../types/timeline';
import type { LightingSettings, Project, ProjectSettings, SceneObject } from '../types/project';
import { uid } from './id';
import { createRoom } from './objects';

export const DEFAULT_SETTINGS: ProjectSettings = {
  gridSize: 0.25,
  snap: true,
  showGrid: true,
  showRulers: true,
  showBeams: false,
  showLabels: true,
  units: 'm',
  venueHeight: 4.5,
  wallTransparency: true,
};

export const DEFAULT_LIGHTING: LightingSettings = {
  groups: [],
  presets: [],
  master: 0.9,
  ambient: 0.16,
  haze: 0.45,
  anisotropy: 0.55,
  exposure: 1.05,
  bloom: 0.32,
  quality: 'low',
  volumetric: true,
  showWalls: true,
  showFloor: true,
  workLight: true,
  activePresetId: null,
};

export function createProject(name: string, width = 14, depth = 9, withRoom = true): Project {
  const now = new Date().toISOString();
  const room = createRoom({ x: 0, z: 0 }, { w: width, d: depth }, 4.8, 'Venue');
  return {
    schemaVersion: 5,
    id: uid('prj'),
    name: name.trim() || 'New project',
    createdAt: now,
    updatedAt: now,
    settings: { ...DEFAULT_SETTINGS },
    objects: withRoom ? [room] : [],
    connections: [],
    guides: [],
    lighting: { ...DEFAULT_LIGHTING, groups: [], presets: [] },
    effects: [],
    timeline: createDefaultTimeline(),
    view: { plan: { panX: 0, panY: 0, zoom: 0 }, camera3d: null, cameraPreset: 'front' },
    migration: null,
  };
}

export function touchProject(project: Project, objects: SceneObject[] = project.objects): Project {
  return { ...project, objects, updatedAt: new Date().toISOString() };
}

export function projectStats(project: Project): { devices: number; fixtures: number; rooms: number; connections: number; dmx: number; models: number; lights: number } {
  return {
    devices: project.objects.filter((object) => object.type === 'device').length,
    fixtures: project.objects.filter((object) => object.light !== null).length,
    rooms: project.objects.filter((object) => object.type === 'room').length,
    connections: project.connections.length,
    dmx: project.connections.filter((connection) => connection.type === 'dmx').length,
    models: project.objects.filter((object) => object.type === 'model').length,
    lights: project.objects.filter((object) => object.type === 'light').length,
  };
}
