import type { GroupEffect, GroupEffectPhaseMode } from '../types/timeline';
import type { Project } from '../types/project';

const PHASE_MODES: GroupEffectPhaseMode[] = ['left-right', 'right-left', 'front-back', 'center', 'sequential', 'random', 'custom'];
const WAVEFORMS = ['sine', 'triangle', 'square'] as const;

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function waveformValue(waveform: string, phase: number): number {
  const raw = Math.sin(phase * Math.PI * 2);
  if (waveform === 'triangle') return 2 * Math.abs(2 * (phase - Math.floor(phase + 0.5))) - 1;
  if (waveform === 'square') return raw >= 0 ? 1 : -1;
  return raw;
}

function randomFraction(id: string): number {
  let hash = 2166136261;
  for (let index = 0; index < id.length; index += 1) hash = Math.imul(hash ^ id.charCodeAt(index), 16777619);
  return ((hash >>> 0) % 10000) / 10000;
}

function hex(value: string): [number, number, number] | null {
  const match = /^#?([0-9a-f]{6})$/i.exec(value);
  if (!match) return null;
  const number = Number.parseInt(match[1], 16);
  return [(number >> 16) & 255, (number >> 8) & 255, number & 255];
}

function mixColor(from: string, to: string, amount: number): string {
  const a = hex(from);
  const b = hex(to);
  if (!a || !b) return from;
  return `#${a.map((channel, index) => Math.round(channel + (b[index] - channel) * clamp(amount, 0, 1)).toString(16).padStart(2, '0')).join('')}`;
}

export function normalizeGroupEffect(raw: unknown): GroupEffect | null {
  if (!raw || typeof raw !== 'object') return null;
  const source = raw as Record<string, unknown>;
  if (source.type !== 'groupWave') return null;
  const params = (source.params && typeof source.params === 'object' ? source.params : {}) as Record<string, unknown>;
  const start = Math.max(0, Number(source.start) || 0);
  const end = Math.max(start + 0.05, Number(source.end) || start + 1);
  const phaseMode = PHASE_MODES.includes(String(params.phaseMode) as GroupEffectPhaseMode) ? String(params.phaseMode) as GroupEffectPhaseMode : 'left-right';
  const waveform = WAVEFORMS.includes(String(params.waveform) as typeof WAVEFORMS[number]) ? String(params.waveform) as typeof WAVEFORMS[number] : 'sine';
  const colorFrom = typeof params.colorFrom === 'string' && /^#[0-9a-f]{6}$/i.test(params.colorFrom) ? params.colorFrom : undefined;
  const colorTo = typeof params.colorTo === 'string' && /^#[0-9a-f]{6}$/i.test(params.colorTo) ? params.colorTo : undefined;
  return {
    id: typeof source.id === 'string' && source.id ? source.id : `eff_${Math.random().toString(36).slice(2, 10)}`,
    type: 'groupWave',
    enabled: source.enabled !== false,
    targetIds: Array.isArray(source.targetIds) ? [...new Set(source.targetIds.filter((id): id is string => typeof id === 'string'))] : [],
    propertyPath: typeof source.propertyPath === 'string' && source.propertyPath ? source.propertyPath : 'light.intensity',
    start,
    end,
    fadeIn: Math.max(0, Number(source.fadeIn) || 0),
    fadeOut: Math.max(0, Number(source.fadeOut) || 0),
    params: {
      frequency: Math.max(0, Number(params.frequency ?? 1)),
      phaseSpread: Number(params.phaseSpread ?? 360),
      phaseMode,
      basePhase: Number(params.basePhase ?? 0),
      min: Number(params.min ?? 0),
      max: Number(params.max ?? 1),
      waveform,
      ...(colorFrom ? { colorFrom } : {}),
      ...(colorTo ? { colorTo } : {}),
    },
  };
}

export function normalizeGroupEffects(raw: unknown): GroupEffect[] {
  if (!Array.isArray(raw)) return [];
  return raw.map(normalizeGroupEffect).filter((effect): effect is GroupEffect => !!effect);
}

export function orderedEffectTargets(effect: GroupEffect, project: Project): string[] {
  const found = effect.targetIds.map((id) => project.objects.find((object) => object.id === id)).filter((object): object is NonNullable<typeof object> => !!object);
  if (effect.params.phaseMode === 'left-right') return found.sort((a, b) => a.position.x - b.position.x).map((object) => object.id);
  if (effect.params.phaseMode === 'right-left') return found.sort((a, b) => b.position.x - a.position.x).map((object) => object.id);
  if (effect.params.phaseMode === 'front-back') return found.sort((a, b) => a.position.z - b.position.z).map((object) => object.id);
  if (effect.params.phaseMode === 'center') {
    const centerX = found.reduce((sum, object) => sum + object.position.x, 0) / Math.max(1, found.length);
    const centerZ = found.reduce((sum, object) => sum + object.position.z, 0) / Math.max(1, found.length);
    return found.sort((a, b) => Math.hypot(a.position.x - centerX, a.position.z - centerZ) - Math.hypot(b.position.x - centerX, b.position.z - centerZ)).map((object) => object.id);
  }
  if (effect.params.phaseMode === 'random') return found.map((object) => object.id).sort((a, b) => randomFraction(`${effect.id}:${a}`) - randomFraction(`${effect.id}:${b}`));
  return found.map((object) => object.id);
}

export function effectPhase(effect: GroupEffect, targetId: string, project: Project): number {
  const targets = orderedEffectTargets(effect, project);
  const count = Math.max(1, targets.length);
  const index = Math.max(0, targets.indexOf(targetId));
  const fraction = effect.params.phaseMode === 'random' ? randomFraction(`${effect.id}:${targetId}`) : index / count;
  return (effect.params.basePhase ?? 0) + (effect.params.phaseSpread / 360) * fraction;
}

export function sampleGroupEffects(project: Project, time: number, overrides: Map<string, number | string | boolean>): void {
  for (const effect of project.timeline?.groupEffects || []) {
    if (!effect.enabled || time < effect.start || time > effect.end) continue;
    const targets = orderedEffectTargets(effect, project);
    const local = Math.max(0, time - effect.start);
    const duration = Math.max(0.0001, effect.end - effect.start);
    const fade = Math.min(effect.fadeIn > 0 ? Math.min(1, local / effect.fadeIn) : 1, effect.fadeOut > 0 ? Math.min(1, (effect.end - time) / effect.fadeOut) : 1);
    const progress = clamp(local / duration, 0, 1);
    for (const targetId of targets) {
      const phase = local * effect.params.frequency + effectPhase(effect, targetId, project);
      const wave = waveformValue(effect.params.waveform, phase);
      const value = effect.params.min + (effect.params.max - effect.params.min) * ((wave + 1) / 2);
      overrides.set(`${targetId}:${effect.propertyPath}`, effect.params.min + (value - effect.params.min) * fade);
      if (effect.params.colorFrom && effect.params.colorTo) {
        overrides.set(`${targetId}:light.color`, mixColor(effect.params.colorFrom, effect.params.colorTo, progress));
      }
    }
  }
}

export interface GroupEffectCommandOptions {
  effectId: string;
  project: Project;
}
