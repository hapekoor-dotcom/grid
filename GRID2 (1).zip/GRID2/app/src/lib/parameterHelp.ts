import type { ModifierDefinition, ModifierField } from './modifiers';
import { MODIFIER_DEFINITIONS } from './modifiers';
import type { SignalSourceKind } from '../types/project';

export interface ParameterDoc {
  short: string;
  long?: string;
  performance?: string;
  warning?: string;
  examples?: string[];
}

const explicit: Record<string, ParameterDoc> = {
  'domainWarp.strength': { short: 'How far vertices move along the warped noise field.', long: 'Negative values push opposite the computed field. Very high values can pull geometry far outside its original bounds.', performance: 'Medium' },
  'domainWarp.scale': { short: 'Spatial size of the noise pattern.', long: 'Lower values create large, broad deformation. Higher values create smaller, denser surface detail.' },
  'domainWarp.octaves': { short: 'Number of noise layers stacked into the warp.', long: 'Each extra octave adds finer detail and another noise evaluation.', performance: 'Medium → High' },
  'liquidChrome.noiseScale': { short: 'Size of the flowing noise pattern in the liquid metal.', long: 'Low values create broad liquid shapes; high values create fine turbulent ripples.' },
  'liquidChrome.fresnel': { short: 'How strongly grazing angles brighten the chrome edge.', long: 'Higher values produce a stronger rim reflection; extreme values can clip to white.' },
  'liquidChrome.distortion': { short: 'How much the liquid flow bends the surface response.', long: 'Higher values make the chrome more unstable and fluid. Negative values are allowed where the shader supports them.' },
  'hologram.breakup': { short: 'How much of the hologram randomly disappears.', long: 'Uses procedural noise to cut holes in the surface. Higher values create a more broken, unstable projection.' },
  'hologram.glitch': { short: 'Strength of random horizontal tearing.', long: 'Higher values create more frequent and stronger glitch bands.' },
  'feedback.persistence': { short: 'Feedback decay: how strongly previous frames remain visible.', long: '0 makes the previous frame vanish immediately; values near 1 create long recursive trails. This is the feedback decay control.', performance: 'High' },
  'feedback.intensity': { short: 'How much of the current frame is mixed into the feedback buffer.', long: 'Higher values brighten the trail and can quickly saturate the screen.' },
  'feedback.softness': { short: 'Blur applied to the previous frame.', long: 'Higher values smear the feedback trail; 0 keeps the echo sharp.' },
  'radialClone.count': { short: 'Number of duplicated instances.', long: 'Every instance is a draw entity. Very high counts cost memory and render time.', performance: 'High at large counts' },
  'radialClone.radius': { short: 'Distance of clones from the source object.', long: 'For ring and sphere patterns this is the distribution radius. Linear and grid patterns use spacing instead.' },
  'fieldAttractor.radius': { short: 'Distance over which the physics field applies.', long: 'Outside this radius the field has no effect. Larger values affect more of the scene.' },
  'fieldAttractor.falloff': { short: 'How quickly field strength drops with distance.', long: 'Higher values concentrate the force near the center; lower values spread it through the radius.' },
  'fieldAttractor.strength': { short: 'Force applied to dynamic rigid bodies.', long: 'Positive values attract; negative values repel when the field mode allows it.' },
  'cameraFovPulse.amount': { short: 'Peak change in vertical field of view.', long: 'Positive values widen the lens; negative values narrow it. Values beyond ±80° can look extreme.' },
  'iridescentFilm.thickness': { short: 'Thin-film thickness used to calculate interference colors.', long: 'Changing thickness shifts the rainbow across the surface. Values are in nanometres.' },
};

const byKey: Record<string, (definition: ModifierDefinition, field: ModifierField) => ParameterDoc> = {
  strength: (d, f) => ({ short: `How strongly ${d.label} is applied.`, long: `Higher values increase the magnitude of ${d.label.toLowerCase()}. Negative values reverse direction where the effect supports it.` }),
  amount: (d, f) => ({ short: `Magnitude of ${d.label}.`, long: `Higher values increase the effect; negative values reverse it where supported.` }),
  scale: (d, f) => ({ short: `Spatial size of the ${d.label.toLowerCase()} pattern.`, long: 'Lower values create broad, smooth features. Higher values create smaller, more detailed features.' }),
  frequency: (d, f) => ({ short: `How rapidly ${d.label.toLowerCase()} repeats.`, long: 'Higher values repeat more often per second or per metre. The unit is shown next to the field when applicable.' }),
  phase: (d, f) => ({ short: `Offsets the starting point of ${d.label.toLowerCase()}.`, long: 'Use phase to stagger identical animated effects. Values wrap through a full cycle.' }),
  gain: (d, f) => ({ short: `Multiplies the output of ${d.label.toLowerCase()}.`, long: '1 is neutral. Below 1 reduces the result; above 1 amplifies it and may clip.' }),
  falloff: (d, f) => ({ short: `How quickly ${d.label.toLowerCase()} fades with distance.`, long: 'Higher values concentrate the effect near its center; lower values spread it further.' }),
  threshold: (d, f) => ({ short: `Cutoff point for ${d.label.toLowerCase()}.`, long: 'Values below the threshold are suppressed; values above become visible or active.' }),
  decay: (d, f) => ({ short: `How quickly ${d.label.toLowerCase()} fades over time.`, long: 'Higher values keep the effect alive longer. Lower values make it disappear faster.' }),
  bias: (d, f) => ({ short: `Shifts the balance of ${d.label.toLowerCase()}.`, long: 'Positive values push the result one way; negative values push it the opposite way.' }),
  radius: (d, f) => ({ short: `Distance affected by ${d.label.toLowerCase()}.`, long: 'Larger radii include more geometry or more of the world in the effect.' }),
  speed: () => ({ short: 'How fast this parameter changes over time.', long: 'Higher values animate faster. Negative values run the animation backwards.' }),
  seed: () => ({ short: 'Random variation seed.', long: 'Changing the seed produces a different procedural pattern without changing its overall character.' }),
  octaves: () => ({ short: 'Number of procedural noise layers.', long: 'Each extra octave adds finer detail and increases computation.', performance: 'Medium → High' }),
  density: () => ({ short: 'How dense or frequent the pattern is.', long: 'Higher values pack more detail into the same space.' }),
  opacity: () => ({ short: 'Surface transparency.', long: '0 is fully transparent, 1 is fully opaque. This is a normalized value.' }),
  roughness: () => ({ short: 'Microsurface roughness used by PBR shading.', long: '0 gives sharp mirror-like reflections; 1 gives broad matte reflections. This is a normalized PBR value.' }),
  metalness: () => ({ short: 'How metallic the surface response is.', long: '0 behaves like a dielectric; 1 uses metallic reflection. This is a normalized PBR value.' }),
};

export function describeParameter(definition: ModifierDefinition, field: ModifierField): ParameterDoc {
  const exact = explicit[`${definition.type}.${field.key}`];
  if (exact) return exact;
  if (field.shortDescription) return { short: field.shortDescription, long: field.longDescription, performance: field.performanceNote, warning: field.warning, examples: field.examples };
  const generator = byKey[field.key];
  if (generator) return generator(definition, field);
  return {
    short: `${field.label} for ${definition.label}.`,
    long: definition.description || `Changes how ${definition.label} behaves. Increasing the value generally increases this parameter; decreasing it reduces the effect.`,
  };
}

export const SIGNAL_DOCS: Record<SignalSourceKind, ParameterDoc> = {
  time: { short: 'Monotonic time in seconds.' },
  sine: { short: 'Smooth periodic oscillation.', long: 'Speed controls frequency, amplitude controls peak value, phase shifts the waveform.' },
  saw: { short: 'Rising ramp that resets every cycle.' },
  triangle: { short: 'Linear rise and fall between -1 and 1.' },
  pulse: { short: 'Square-style on/off signal.' },
  noise: { short: 'Smooth one-dimensional procedural noise.', long: 'Speed changes how quickly the signal moves through the noise field.' },
  fbm: { short: 'Layered fractal noise made from multiple noise octaves.', long: 'Octaves add detail; lacunarity controls frequency growth; persistence controls amplitude decay.' },
  randomWalk: { short: 'Smooth drift with random direction changes.' },
  sampleHold: { short: 'Random value held for a fixed interval, then jumped to a new value.' },
  objectDistance: { short: 'Normalized distance from this object to a target object.', long: 'Range controls the distance at which the value reaches 1.' },
  objectDirection: { short: 'Signed direction from this object toward a target object on one axis.' },
  worldPosition: { short: 'Object world position on the selected axis.' },
  normalDirection: { short: 'Surface orientation indicator used as a signal.' },
  fresnel: { short: 'View-angle dependent signal.' },
  timeline: { short: 'Signal derived from timeline time.' },
  velocity: { short: 'Current rigid-body linear speed.' },
  angularSpeed: { short: 'Current rigid-body angular speed.' },
  height: { short: 'Current world height of the rigid body.' },
  impact: { short: 'Recent collision impact strength, decaying over time.' },
  distanceToGround: { short: 'Distance from the rigid body to the ground plane.' },
  sleeping: { short: '1 when the body is sleeping, 0 when active.' },
  trigger: { short: '1 while a trigger overlap is active.' },
};

export function searchParameterDocs(query: string): { title: string; description: string }[] {
  const needle = query.trim().toLowerCase();
  if (!needle) return [];
  const results: { title: string; description: string }[] = [];
  for (const definition of MODIFIER_DEFINITIONS) {
    if (`${definition.label} ${definition.description || ''} ${definition.type}`.toLowerCase().includes(needle)) results.push({ title: `Effect → ${definition.label}`, description: definition.description || `${definition.label} effect module.` });
    for (const field of definition.fields) {
      const doc = describeParameter(definition, field);
      if (`${definition.label} ${field.label} ${field.key} ${doc.short} ${doc.long || ''}`.toLowerCase().includes(needle)) {
        results.push({ title: `${definition.label} → ${field.label}`, description: doc.short });
      }
    }
  }
  for (const [kind, doc] of Object.entries(SIGNAL_DOCS)) {
    if (`${kind} ${doc.short} ${doc.long || ''}`.toLowerCase().includes(needle)) results.push({ title: `Signal → ${kind}`, description: doc.short });
  }
  return results.slice(0, 30);
}
