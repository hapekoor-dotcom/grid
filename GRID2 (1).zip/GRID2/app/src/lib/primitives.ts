import type { PrimitiveConfig, PrimitiveKind, SceneObject } from '../types/project';
import { createModel } from './objects';

export interface PrimitiveDefinition {
  kind: PrimitiveKind;
  label: string;
  defaults: Record<string, number>;
  fields: { key: string; label: string; min: number; step: number }[];
}

export const PRIMITIVES: PrimitiveDefinition[] = [
  { kind: 'box', label: 'Box', defaults: { width: 1, height: 1, depth: 1 }, fields: [
    { key: 'width', label: 'Width', min: 0.01, step: 0.05 },
    { key: 'height', label: 'Height', min: 0.01, step: 0.05 },
    { key: 'depth', label: 'Depth', min: 0.01, step: 0.05 },
  ] },
  { kind: 'sphere', label: 'Sphere', defaults: { radius: 0.5 }, fields: [{ key: 'radius', label: 'Radius', min: 0.01, step: 0.05 }] },
  { kind: 'cylinder', label: 'Cylinder', defaults: { radius: 0.5, height: 1 }, fields: [
    { key: 'radius', label: 'Radius', min: 0.01, step: 0.05 },
    { key: 'height', label: 'Height', min: 0.01, step: 0.05 },
  ] },
  { kind: 'plane', label: 'Plane', defaults: { width: 2, height: 2 }, fields: [
    { key: 'width', label: 'Width', min: 0.01, step: 0.05 },
    { key: 'height', label: 'Height', min: 0.01, step: 0.05 },
  ] },
  { kind: 'cone', label: 'Cone', defaults: { radius: 0.5, height: 1 }, fields: [
    { key: 'radius', label: 'Radius', min: 0.01, step: 0.05 },
    { key: 'height', label: 'Height', min: 0.01, step: 0.05 },
  ] },
  { kind: 'torus', label: 'Torus', defaults: { majorRadius: 0.7, minorRadius: 0.2 }, fields: [
    { key: 'majorRadius', label: 'Major radius', min: 0.02, step: 0.05 },
    { key: 'minorRadius', label: 'Minor radius', min: 0.01, step: 0.02 },
  ] },
];

export function primitiveDefinition(kind: PrimitiveKind): PrimitiveDefinition {
  return PRIMITIVES.find((entry) => entry.kind === kind) || PRIMITIVES[0];
}

export function primitiveConfig(kind: PrimitiveKind, params?: Record<string, number>): PrimitiveConfig {
  return { kind, params: { ...primitiveDefinition(kind).defaults, ...(params || {}) } };
}

export function primitiveFootprint(config: PrimitiveConfig): { w: number; d: number; h: number } {
  const p = config.params;
  switch (config.kind) {
    case 'box': return { w: p.width ?? 1, d: p.depth ?? 1, h: p.height ?? 1 };
    case 'sphere': return { w: (p.radius ?? 0.5) * 2, d: (p.radius ?? 0.5) * 2, h: (p.radius ?? 0.5) * 2 };
    case 'cylinder': return { w: (p.radius ?? 0.5) * 2, d: (p.radius ?? 0.5) * 2, h: p.height ?? 1 };
    case 'plane': return { w: p.width ?? 2, d: p.height ?? 2, h: 0.02 };
    case 'cone': return { w: (p.radius ?? 0.5) * 2, d: (p.radius ?? 0.5) * 2, h: p.height ?? 1 };
    case 'torus': return { w: ((p.majorRadius ?? 0.7) + (p.minorRadius ?? 0.2)) * 2, d: ((p.majorRadius ?? 0.7) + (p.minorRadius ?? 0.2)) * 2, h: (p.minorRadius ?? 0.2) * 2 };
    default: return { w: 1, d: 1, h: 1 };
  }
}

export function createPrimitive(kind: PrimitiveKind, position = { x: 0, z: 0 }): SceneObject {
  const config = primitiveConfig(kind);
  const size = primitiveFootprint(config);
  const object = createModel('', primitiveDefinition(kind).label, position, size);
  object.id = `primitive_${crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`}`;
  object.name = primitiveDefinition(kind).label;
  object.assetId = null;
  object.assetName = null;
  object.elevation = 0;
  object.primitive = config;
  object.materialSlots = ['Material 1'];
  return object;
}
