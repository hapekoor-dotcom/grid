type Listener = () => void;

const state = { time: 0, playing: false, duration: 10, loop: true };
const listeners = new Set<Listener>();

function emit(): void {
  for (const listener of listeners) listener();
}

export function getTimelineTime(): number { return state.time; }
export function isTimelinePlaying(): boolean { return state.playing; }
export function getTimelineDuration(): number { return state.duration; }
export function isTimelineLooping(): boolean { return state.loop; }

export function setTimelineRange(duration: number, loop: boolean): void {
  state.duration = Math.max(0.1, duration);
  state.loop = loop;
  if (state.time > state.duration) state.time = state.duration;
  emit();
}

export function seekTimeline(time: number): void {
  state.time = Math.max(0, Math.min(state.duration, Number.isFinite(time) ? time : 0));
  emit();
}

export function playTimeline(): void {
  if (state.time >= state.duration) state.time = 0;
  state.playing = true;
  emit();
}

export function pauseTimeline(): void {
  state.playing = false;
  emit();
}

export function stopTimeline(): void {
  state.playing = false;
  state.time = 0;
  emit();
}

export function advanceTimeline(dt: number): number {
  if (!state.playing) return state.time;
  state.time += Math.min(0.1, Math.max(0, dt));
  if (state.time >= state.duration) {
    if (state.loop) state.time = state.duration > 0 ? state.time % state.duration : 0;
    else { state.time = state.duration; state.playing = false; }
  }
  emit();
  return state.time;
}

export function subscribeTimelineClock(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
