/** Reusable typed routing primitives for the visual computation graph. */
export type PortType = 'float' | 'vec2' | 'vec3' | 'color' | 'texture' | 'scalarField' | 'vectorField';
export type AdapterKind = 'remap' | 'clamp' | 'invert' | 'multiply' | 'add' | 'subtract' | 'power' | 'smoothstep' | 'curve' | 'quantize' | 'luminance' | 'length' | 'floatToColor' | 'channelR' | 'channelG' | 'channelB' | 'channelA' | 'scalarToGradient' | 'scalarToNormal';
export interface Adapter { kind: AdapterKind; params?: Record<string, number>; channel?: 'r' | 'g' | 'b' | 'a'; }
export interface GraphPort { nodeId: string; port: string; type: PortType; }
export interface GraphConnection { id: string; from: GraphPort; to: GraphPort; adapter?: Adapter; }

export function wouldCreateCycle(connections: GraphConnection[], from: string, to: string): boolean {
  if (from === to) return true;
  const adjacency = new Map<string, string[]>();
  for (const connection of connections) {
    const list = adjacency.get(connection.from.nodeId) || [];
    list.push(connection.to.nodeId);
    adjacency.set(connection.from.nodeId, list);
  }
  const stack = [to];
  const seen = new Set<string>();
  while (stack.length) {
    const node = stack.pop()!;
    if (node === from) return true;
    if (seen.has(node)) continue;
    seen.add(node);
    for (const next of adjacency.get(node) || []) stack.push(next);
  }
  return false;
}

export function connect(connections: GraphConnection[], connection: GraphConnection): { ok: true; connections: GraphConnection[] } | { ok: false; error: string } {
  if (wouldCreateCycle(connections, connection.from.nodeId, connection.to.nodeId)) return { ok: false, error: 'Connection would create a dependency cycle.' };
  return { ok: true, connections: [...connections, connection] };
}

export function typesCompatible(from: PortType, to: PortType): boolean {
  if (from === to) return true;
  if (to === 'float' && ['scalarField', 'texture', 'color', 'vec3'].includes(from)) return true;
  if (to === 'color' && ['float', 'scalarField', 'texture', 'vec3'].includes(from)) return true;
  if (to === 'vec3' && ['float', 'color', 'texture', 'vectorField', 'scalarField'].includes(from)) return true;
  if (to === 'texture' && ['scalarField', 'texture'].includes(from)) return true;
  return false;
}

export function applyAdapter(value: number | number[], adapter: Adapter): number | number[] {
  if (Array.isArray(value)) {
    if (adapter.kind === 'length') return Math.hypot(...value);
    if (adapter.kind === 'luminance') return Number(value[0] || 0) * 0.2126 + Number(value[1] || 0) * 0.7152 + Number(value[2] || 0) * 0.0722;
    if (adapter.kind === 'channelR') return Number(value[0] || 0);
    if (adapter.kind === 'channelG') return Number(value[1] || 0);
    if (adapter.kind === 'channelB') return Number(value[2] || 0);
    if (adapter.kind === 'channelA') return Number(value[3] || 0);
    if (adapter.kind === 'floatToColor') return [Number(value[0] || 0), Number(value[1] || 0), Number(value[2] || 0)];
    return value;
  }
  const p = adapter.params || {};
  if (!Number.isFinite(value)) return 0;
  switch (adapter.kind) {
    case 'remap': { const inMin = Number(p.inMin ?? 0), inMax = Number(p.inMax ?? 1), outMin = Number(p.outMin ?? 0), outMax = Number(p.outMax ?? 1); return outMin + ((value - inMin) / Math.max(0.000001, inMax - inMin)) * (outMax - outMin); }
    case 'clamp': return Math.max(Number(p.min ?? 0), Math.min(Number(p.max ?? 1), value));
    case 'invert': return Number(p.max ?? 1) - value;
    case 'multiply': return value * Number(p.factor ?? 1);
    case 'add': return value + Number(p.amount ?? 0);
    case 'subtract': return value - Number(p.amount ?? 0);
    case 'power': return Math.sign(value) * Math.pow(Math.abs(value), Number(p.exponent ?? 1));
    case 'smoothstep': { const edge0 = Number(p.edge0 ?? 0), edge1 = Number(p.edge1 ?? 1); const t = Math.max(0, Math.min(1, (value - edge0) / Math.max(0.000001, edge1 - edge0))); return t * t * (3 - 2 * t); }
    case 'curve': return Math.pow(Math.max(0, Math.min(1, value)), Number(p.gamma ?? 1));
    case 'quantize': { const step = Math.max(0.000001, Number(p.step ?? 0.1)); return Math.round(value / step) * step; }
    case 'floatToColor': return [value, value, value];
    default: return value;
  }
}


/** Cycle check for the inline modifier modulation sockets. */
export function wouldCreateModifierCycle(modifiers: { id: string; modulators?: Record<string, { sourceType?: string; sourceId: string }> }[], targetId: string, sourceId: string): boolean {
  if (targetId === sourceId) return true;
  const adjacency = new Map<string, string[]>();
  for (const modifier of modifiers) {
    for (const modulator of Object.values(modifier.modulators || {})) {
      if (modulator.sourceType !== 'modifier') continue;
      const list = adjacency.get(modifier.id) || [];
      list.push(modulator.sourceId);
      adjacency.set(modifier.id, list);
    }
  }
  const stack = [sourceId];
  const seen = new Set<string>();
  while (stack.length) {
    const id = stack.pop()!;
    if (id === targetId) return true;
    if (seen.has(id)) continue;
    seen.add(id);
    for (const next of adjacency.get(id) || []) stack.push(next);
  }
  return false;
}

export interface GraphOrderResult {
  order: string[];
  cycles: string[];
}

/** Kahn topological order for modifier-to-modifier modulation edges. */
export function compileModifierOrder(modifiers: { id: string; modulators?: Record<string, { sourceType?: string; sourceId: string }> }[]): GraphOrderResult {
  const ids = new Set(modifiers.map((modifier) => modifier.id));
  const indegree = new Map<string, number>(modifiers.map((modifier) => [modifier.id, 0]));
  const adjacency = new Map<string, string[]>();
  for (const modifier of modifiers) {
    for (const modulator of Object.values(modifier.modulators || {})) {
      if (modulator.sourceType !== 'modifier' || !ids.has(modulator.sourceId)) continue;
      const list = adjacency.get(modulator.sourceId) || [];
      list.push(modifier.id);
      adjacency.set(modulator.sourceId, list);
      indegree.set(modifier.id, (indegree.get(modifier.id) || 0) + 1);
    }
  }
  const queue = modifiers.filter((modifier) => (indegree.get(modifier.id) || 0) === 0).map((modifier) => modifier.id);
  const order: string[] = [];
  while (queue.length) {
    const id = queue.shift()!;
    order.push(id);
    for (const next of adjacency.get(id) || []) {
      const remaining = (indegree.get(next) || 0) - 1;
      indegree.set(next, remaining);
      if (remaining === 0) queue.push(next);
    }
  }
  return { order, cycles: modifiers.map((modifier) => modifier.id).filter((id) => !order.includes(id)) };
}
