import type { Connection, LightPreset, Project, SceneObject } from '../types/project';
import { createProject } from './project';
import { createRoom, createSceneObject, createSeating, createStage, createTruss } from './objects';
import { uid } from './id';

function place(object: SceneObject, x: number, z: number, overrides: Partial<SceneObject> = {}): SceneObject {
  return { ...object, position: { x, z }, ...overrides };
}

export function createDemoProject(): Project {
  const base = createProject('Клуб «Платформа» · свет и сцена', 14, 9);
  const room = createRoom({ x: 0, z: 0 }, { w: 14, d: 9 }, 5.2, 'Основной зал');
  room.room = { wallHeight: 5.2, walls: true, floorColor: '#8b857a', wallColor: '#85837c' };
  room.notes = 'Условный зал 14 × 9 м. Стены и высота заданы для планировки.';

  const stage = createStage({ x: 0, z: -2.35 }, { w: 8, d: 3.6, h: 0.45 }, 'Сцена');
  const curtain = createSceneObject('curtain', { x: 0, z: -4.15 }, {
    type: 'stage',
    name: 'Задник',
    size: { w: 8, d: 0.08, h: 4.6 },
    elevation: 0,
    rotation: 0,
  });
  curtain.stage = { color: '#1b2025', label: 'Задник' };
  stage.notes = 'Подиум 8 × 3,6 м, высота 0,45 м.';
  curtain.notes = 'Условная ширма для визуализации; материал и огнезащита не подтверждены.';

  const truss = createTruss({ x: 0, z: -2.35 }, 8, 'Ферма 8 м');
  truss.elevation = 4.7;
  const towerLeft = createSceneObject('truss-tower', { x: -4.1, z: -2.35 }, { name: 'Башня левая', elevation: 0 });
  towerLeft.type = 'truss';
  towerLeft.size = { w: 0.3, d: 0.3, h: 4.7 };
  const towerRight = createSceneObject('truss-tower', { x: 4.1, z: -2.35 }, { name: 'Башня правая', elevation: 0 });
  towerRight.type = 'truss';
  towerRight.size = { w: 0.3, d: 0.3, h: 4.7 };

  const table = createSceneObject('table', { x: 0, z: 4.0 }, { name: 'Стол FOH', rotation: 0 });
  table.type = 'furniture';
  table.elevation = 0;
  const barricade = createSceneObject('barricade', { x: 0, z: -0.35 }, { name: 'Ограждение', size: { w: 7, d: 0.1, h: 1.1 } });
  barricade.type = 'furniture';
  barricade.elevation = 0;

  const focus: SceneObject[] = [];
  const focusPositions = [-2.8, -0.95, 0.95, 2.8];
  focusPositions.forEach((x, index) => {
    const object = createSceneObject('snl-444', { x, z: -2.35 }, {
      name: `Focus Flex 0${index + 1}`,
      elevation: 4.7,
      mount: 'truss',
      rotation: 0,
    });
    if (object.fixture) object.fixture.modeId = 'standard-rgbw-25';
    object.light = object.light ? { ...object.light, color: '#ff1d15', intensity: 0.95, zoom: 11, pan: 0, tilt: 4, focus: 0.55 } : null;
    object.notes = 'На ферме. Pan/tilt — виртуальное управление, без вывода на прибор.';
    focus.push(object);
  });

  const bars: SceneObject[] = [];
  const barLayout = [
    { x: -4.8, z: -2.2, rotation: 180 as const, color: '#ff35b8' },
    { x: -4.7, z: 1.7, rotation: 90 as const, color: '#2664ff' },
    { x: 4.8, z: -2.2, rotation: 180 as const, color: '#2664ff' },
    { x: 4.7, z: 1.7, rotation: 270 as const, color: '#ff35b8' },
  ];
  barLayout.forEach((entry, index) => {
    const object = createSceneObject('snl-499', { x: entry.x, z: entry.z }, {
      name: `UBL12H 0${index + 1}`,
      elevation: 0.08,
      mount: 'floor',
      rotation: entry.rotation,
    });
    if (object.fixture) object.fixture.modeId = '11ch';
    object.light = object.light ? { ...object.light, color: '#1f63ff', intensity: 0.9, zoom: 48, tilt: 52 } : null;
    object.notes = 'Напольный линейный бар у стены. Светит из ряда линз наружу и вверх.';
    bars.push(object);
  });

  const pars: SceneObject[] = [];
  [-2.4, 2.4].forEach((x, index) => {
    const object = createSceneObject('snl-450', { x, z: -1.15 }, {
      name: `18P-HEX 0${index + 1}`,
      elevation: 0.45,
      mount: 'stage',
      rotation: 0,
    });
    object.light = object.light ? { ...object.light, color: '#edf2ff', intensity: 0, tilt: -12, zoom: 36, on: false } : null;
    object.notes = 'Фронтальная заливка с авансцены (условная постановка).';
    pars.push(object);
  });

  const consoleObject = createSceneObject('console', { x: 0, z: 4.0 }, {
    name: 'Пульт FOH',
    elevation: 0.75,
    mount: 'floor',
    rotation: 180,
  });
  const node = createSceneObject('xnd8', { x: -1.7, z: 4.0 }, { name: 'Swisson XND-8', rotation: 0 });
  const distro = createSceneObject('distro', { x: 6.2, z: -3.35 }, { name: 'Распределитель сцены', rotation: 0, outputs: 4 });
  distro.outputLimits = { power1: 1800, power2: 900, power3: 700, power4: 700 };
  distro.totalPowerLimit = 3000;
  distro.notes = 'Бюджеты введены для демонстрации. Не являются проектом электроснабжения.';
  const outlet = createSceneObject('outlet', { x: 6.3, z: 3.9 }, { name: 'Сеть 230 В · A', rotation: 0, outputs: 4 });
  outlet.circuitId = 'A';
  outlet.portPhases = { power1: 'L1', power2: 'L1', power3: 'L1', power4: 'L1' };
  outlet.portPhasesThreePhase = false;
  outlet.powerLimits = { L1: 3680 };
  outlet.outputLimits = { power1: 2500, power2: 500, power3: 500 };
  outlet.notes = '16 A × 230 В = 3680 Вт — условный бюджет одной линии. Фактический автомат и сечение кабеля проверяются отдельно.';

  const seatingLeft = createSeating({ x: -2.1, z: 1.75 }, { w: 3.4, d: 3.8 }, 'Посадка слева');
  const seatingRight = createSeating({ x: 2.1, z: 1.75 }, { w: 3.4, d: 3.8 }, 'Посадка справа');
  const screen = createSceneObject('generic-ledwall', { x: 0, z: -4.02 }, {
    name: 'LED-экран',
    size: { w: 4.8, d: 0.15, h: 2.8 },
    elevation: 0.45,
    mount: 'stage',
    rotation: 0,
  });
  screen.type = 'device';
  screen.fixture = { modeId: null, universe: 1, address: null, manualAddress: false, customChannels: null, wattsOverride: 450, powerOn: true };
  screen.notes = 'Демонстрационный экран; размеры планировочные, контент не является частью проекта.';

  const objects: SceneObject[] = [
    room, stage, curtain, truss, towerLeft, towerRight, table, barricade, seatingLeft, seatingRight,
    screen, ...focus, ...bars, ...pars, consoleObject, node, distro, outlet,
  ];

  const connections: Connection[] = [];
  const connect = (type: Connection['type'], from: SceneObject, fromPort: string, to: SceneObject, toPort: string) => {
    connections.push({ id: uid('cbl'), type, from: from.id, fromPort, to: to.id, toPort, waypoints: [], note: '' });
  };

  // Ethernet control
  connect('ethernet', consoleObject, 'ethernet', node, 'ethernetIn');

  // DMX universes
  focus.forEach((object, index) => {
    if (index === 0) connect('dmx', node, 'out1', object, 'dmxIn');
    else connect('dmx', focus[index - 1], 'dmxOut', object, 'dmxIn');
  });
  bars.forEach((object, index) => {
    if (index === 0) connect('dmx', node, 'out2', object, 'dmxIn');
    else connect('dmx', bars[index - 1], 'dmxOut', object, 'dmxIn');
  });
  pars.forEach((object, index) => {
    if (index === 0) connect('dmx', node, 'out3', object, 'dmxIn');
    else connect('dmx', pars[index - 1], 'dmxOut', object, 'dmxIn');
  });

  // Power
  connect('power', outlet, 'power1', distro, 'powerIn');
  focus.forEach((object, index) => {
    if (index === 0) connect('power', distro, 'power1', object, 'powerIn');
    else connect('power', focus[index - 1], 'powerOut', object, 'powerIn');
  });
  bars.forEach((object, index) => {
    if (index === 0) connect('power', distro, 'power2', object, 'powerIn');
    else connect('power', bars[index - 1], 'powerOut', object, 'powerIn');
  });
  connect('power', distro, 'power3', node, 'powerIn');
  connect('power', distro, 'power4', screen, 'powerIn');
  connect('power', node, 'powerOut', consoleObject, 'powerIn');
  connect('power', outlet, 'power2', pars[0], 'powerIn');
  connect('power', outlet, 'power3', pars[1], 'powerIn');

  const groups = [
    { id: uid('grp'), name: 'Front · Focus Flex', memberIds: focus.map((object) => object.id) },
    { id: uid('grp'), name: 'Back · UBL12H', memberIds: bars.map((object) => object.id) },
    { id: uid('grp'), name: 'Front · 18P-HEX', memberIds: pars.map((object) => object.id) },
  ];

  const cinema: LightPreset = {
    id: uid('pst'),
    name: 'Кино · красный/синий',
    createdAt: new Date().toISOString(),
    values: Object.fromEntries([
      ...focus.map((object) => [object.id, { intensity: 0.95, color: '#ff1d15', zoom: 11, pan: 0, tilt: 4, on: true }]),
      ...bars.map((object) => [object.id, { intensity: 0.9, color: '#1f63ff', zoom: 48, tilt: 52, on: true }]),
      ...pars.map((object) => [object.id, { intensity: 0, color: '#2a67ff', tilt: -12, zoom: 40, on: false }]),
    ]),
  };
  const show: LightPreset = {
    id: uid('pst'),
    name: 'Магента + синий',
    createdAt: new Date().toISOString(),
    values: Object.fromEntries([
      ...focus.map((object) => [object.id, { intensity: 0.78, color: '#eef2ff', zoom: 24, pan: 0, tilt: 4, on: true }]),
      ...bars.map((object, index) => [object.id, { intensity: 0.9, color: index % 2 === 0 ? '#ff35b8' : '#2664ff', zoom: 48, tilt: 52, on: true }]),
      ...pars.map((object) => [object.id, { intensity: 0.32, color: '#edf2ff', tilt: -12, zoom: 36, on: true }]),
    ]),
  };
  const blue: LightPreset = {
    id: uid('pst'),
    name: 'Синяя заливка',
    createdAt: new Date().toISOString(),
    values: Object.fromEntries([
      ...focus.map((object) => [object.id, { intensity: 0.68, color: '#dce8ff', zoom: 28, pan: 0, tilt: 4, on: true }]),
      ...bars.map((object) => [object.id, { intensity: 0.92, color: '#1e63ff', zoom: 48, tilt: 52, on: true }]),
      ...pars.map((object) => [object.id, { intensity: 0.0, color: '#dce8ff', tilt: -12, on: false }]),
    ]),
  };
  const white: LightPreset = {
    id: uid('pst'),
    name: 'Белый фронт',
    createdAt: new Date().toISOString(),
    values: Object.fromEntries([
      ...focus.map((object) => [object.id, { intensity: 0.86, color: '#f4f7ff', zoom: 22, pan: 0, tilt: 4, on: true }]),
      ...bars.map((object) => [object.id, { intensity: 0.0, color: '#ff35b8', zoom: 48, tilt: 52, on: false }]),
      ...pars.map((object) => [object.id, { intensity: 0.0, color: '#edf2ff', tilt: -12, on: false }]),
    ]),
  };
  const black: LightPreset = {
    id: uid('pst'),
    name: 'Чёрный зал',
    createdAt: new Date().toISOString(),
    values: Object.fromEntries([
      ...focus.map((object) => [object.id, { intensity: 0.0, color: '#eef2ff', zoom: 24, tilt: 4, on: false }]),
      ...bars.map((object) => [object.id, { intensity: 0.0, color: '#ff35b8', zoom: 48, tilt: 52, on: false }]),
      ...pars.map((object) => [object.id, { intensity: 0.0, color: '#edf2ff', tilt: -12, on: false }]),
    ]),
  };

  const lighting = {
    ...base.lighting,
    groups,
    presets: [cinema, show, blue, white, black],
    activePresetId: cinema.id,
    master: 0.9,
    haze: 0.62,
    anisotropy: 0.58,
    ambient: 0.06,
    exposure: 2.15,
    bloom: 0.28,
    quality: 'low' as const,
    volumetric: true,
    showWalls: true,
    workLight: false,
  };

  return {
    ...base,
    name: 'Клуб «Платформа» · свет и сцена',
    objects,
    connections,
    guides: [
      { id: uid('gd'), axis: 'x', position: 0 },
      { id: uid('gd'), axis: 'z', position: -2.35 },
    ],
    lighting,
    migration: null,
  };
}

function indexPan(object: SceneObject, list: SceneObject[]): number {
  const index = list.indexOf(object);
  return [-8, -3, 3, 8][index] ?? 0;
}

