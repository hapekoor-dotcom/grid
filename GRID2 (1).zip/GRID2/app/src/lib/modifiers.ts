import type { SceneModifier } from '../types/project';

export type ModifierAxis = 'x' | 'y' | 'z';
export type ModifierTarget = 'model' | 'light' | 'device' | 'scene' | 'camera' | 'field';

export type ModifierFieldKind = 'number' | 'percent' | 'toggle' | 'select' | 'color' | 'texture' | 'vector' | 'text';
export type EffectStage = 'geometry' | 'surface' | 'light' | 'scene' | 'camera' | 'temporal' | 'post' | 'simulation' | 'field';
export type EffectCost = 'low' | 'medium' | 'high' | 'extreme';

export interface ModifierField {
  key: string;
  label: string;
  kind?: ModifierFieldKind;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  options?: { value: string; label: string }[];
  /** Normalized 0-10 values are shown and entered as 0-1000 percent. */
  overdrive?: boolean;
  physicalMin?: number;
  physicalMax?: number;
  recommendedMin?: number;
  recommendedMax?: number;
  sliderMin?: number;
  sliderMax?: number;
  hardClamp?: boolean;
  softClamp?: boolean;
  mapping?: 'linear' | 'log' | 'power';
  shortDescription?: string;
  longDescription?: string;
  performanceNote?: string;
  warning?: string;
  examples?: string[];
  /** Timeline/AI exposure metadata. */
  animatable?: boolean;
  aiDescription?: string;
}

export interface ModifierDefinition {
  type: string;
  label: string;
  category: 'Motion' | 'Deform' | 'Surface' | 'Structure' | 'Screen';
  targets: ModifierTarget[];
  runtime: 'motion' | 'shader' | 'clone' | 'scene' | 'light' | 'field';
  stage?: EffectStage;
  cost?: EffectCost;
  description?: string;
  capabilities?: string[];
  outputs?: { key: string; label: string; type?: 'float' | 'vec2' | 'vec3' | 'color' | 'texture' | 'scalarField' | 'vectorField' }[];
  defaults: Record<string, number | string | boolean>;
  fields: ModifierField[];
}

const AXIS: ModifierField = {
  key: 'axis', label: 'Axis', kind: 'select',
  options: [{ value: 'x', label: 'X' }, { value: 'y', label: 'Y' }, { value: 'z', label: 'Z' }],
};

export const MODIFIER_DEFINITIONS: ModifierDefinition[] = [
  {
    type: 'rotate',
    label: 'Rotate Motion',
    category: 'Motion',
    targets: ['model', 'light', 'device'],
    runtime: 'motion',
    defaults: { axis: 'y', speed: 30, direction: 1, local: false, autoPlay: true },
    fields: [
      AXIS,
      { key: 'speed', label: 'Speed', kind: 'number', min: -720, max: 720, step: 1, unit: '°/s' },
      { key: 'direction', label: 'Direction', kind: 'select', options: [{ value: '1', label: 'Positive' }, { value: '-1', label: 'Negative' }] },
      { key: 'local', label: 'Local space', kind: 'toggle' },
      { key: 'autoPlay', label: 'Auto play', kind: 'toggle' },
    ],
  },
  {
    type: 'float',
    label: 'Position Oscillation',
    category: 'Motion',
    targets: ['model', 'light', 'device'],
    runtime: 'motion',
    defaults: { axis: 'y', amplitude: 0.3, speed: 0.6, phase: 0 },
    fields: [
      AXIS,
      { key: 'amplitude', label: 'Amplitude', kind: 'number', min: 0, max: 20, step: 0.05, unit: 'm' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
    ],
  },
  {
    type: 'rotateOsc',
    label: 'Rotation Oscillation',
    category: 'Motion',
    targets: ['model', 'light', 'device'],
    runtime: 'motion',
    defaults: { axis: 'z', amplitude: 20, speed: 0.5, phase: 0 },
    fields: [
      AXIS,
      { key: 'amplitude', label: 'Amplitude', kind: 'number', min: 0, max: 180, step: 1, unit: '°' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
    ],
  },
  {
    type: 'scalePulse',
    label: 'Scale Pulse',
    category: 'Motion',
    targets: ['model', 'light', 'device'],
    runtime: 'motion',
    defaults: { amplitude: 0.2, speed: 0.5, phase: 0 },
    fields: [
      { key: 'amplitude', label: 'Amplitude', kind: 'number', min: 0, max: 5, step: 0.01 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
    ],
  },
  {
    type: 'twist',
    label: 'Twist',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { axis: 'y', amount: 90, falloff: 1, start: -1000000, end: 1000000, pivotX: 0, pivotY: 0, pivotZ: 0, animate: false, speed: 0.4, phase: 0 },
    fields: [
      AXIS,
      { key: 'amount', label: 'Amount', kind: 'number', min: -720, max: 720, step: 1, unit: '°' },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'start', label: 'Region start', kind: 'number', min: -1000000, max: 1000000, step: 0.1 },
      { key: 'end', label: 'Region end', kind: 'number', min: -1000000, max: 1000000, step: 0.1 },
      { key: 'pivotX', label: 'Pivot X', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'm' },
      { key: 'pivotY', label: 'Pivot Y', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'm' },
      { key: 'pivotZ', label: 'Pivot Z', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'm' },
      { key: 'animate', label: 'Animate amount', kind: 'toggle' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
    ],
  },
  {
    type: 'noiseDisplace',
    label: 'Noise Displace',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { strength: 0.25, scale: 2, speed: 0.5, maskX: true, maskY: true, maskZ: true, seed: 1 },
    outputs: [{ key: 'scalar', label: 'Noise scalar', type: 'float' }],
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 20, step: 0.01, unit: 'm' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'maskX', label: 'Displace X', kind: 'toggle' },
      { key: 'maskY', label: 'Displace Y', kind: 'toggle' },
      { key: 'maskZ', label: 'Displace Z', kind: 'toggle' },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'textureDisplace',
    label: 'Texture Displace',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'medium',
    defaults: { texture: '', strength: 0.2, mode: 'radial', channel: 'r', midpoint: 0, uvChannel: 'uv0', projection: 'uv', invert: false, offsetX: 0, offsetY: 0, tilingX: 1, tilingY: 1, fallback: 0.3, animate: false },
    fields: [
      { key: 'texture', label: 'Texture', kind: 'texture', aiDescription: 'Displacement or vector displacement image.' },
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 20, step: 0.01, unit: 'm', animatable: true },
      { key: 'mode', label: 'Displacement mode', kind: 'select', options: [{ value: 'radial', label: 'Radial / normal' }, { value: 'vector', label: 'RGB vector' }, { value: 'world', label: 'World XYZ' }, { value: 'normal', label: 'Surface normal' }] },
      { key: 'channel', label: 'Height channel', kind: 'select', options: [{ value: 'r', label: 'R' }, { value: 'g', label: 'G' }, { value: 'b', label: 'B' }, { value: 'a', label: 'A' }] },
      { key: 'midpoint', label: 'Midpoint', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'projection', label: 'Projection', kind: 'select', options: [{ value: 'uv', label: 'UV' }, { value: 'planar', label: 'Planar' }] },
      { key: 'uvChannel', label: 'UV channel', kind: 'select', options: [{ value: 'uv0', label: 'UV0' }, { value: 'uv1', label: 'UV1' }] },
      { key: 'invert', label: 'Invert', kind: 'toggle' },
      { key: 'offsetX', label: 'Offset X', kind: 'number', min: -10, max: 10, step: 0.01 },
      { key: 'offsetY', label: 'Offset Y', kind: 'number', min: -10, max: 10, step: 0.01 },
      { key: 'tilingX', label: 'Tiling X', kind: 'number', min: 0.01, max: 20, step: 0.05 },
      { key: 'tilingY', label: 'Tiling Y', kind: 'number', min: 0.01, max: 20, step: 0.05 },
      { key: 'fallback', label: 'Fallback', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'animate', label: 'Animate', kind: 'toggle' },
    ],
  },

  {
    type: 'domainWarp',
    label: 'Domain Warp',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'high',
    description: 'Multi-octave FBM displacement with a warped sampling domain.',
    capabilities: ['animated', 'timeline', 'gpu-vertex'],
    defaults: { strength: 0.45, scale: 1.6, speed: 0.25, octaves: 4, lacunarity: 2, persistence: 0.5, seed: 1, axis: 'normal' },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 20, step: 0.01, unit: 'm', animatable: true },
      { key: 'scale', label: 'Noise scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
      { key: 'octaves', label: 'Octaves', kind: 'number', min: 1, max: 8, step: 1 },
      { key: 'lacunarity', label: 'Lacunarity', kind: 'number', min: 1, max: 5, step: 0.05 },
      { key: 'persistence', label: 'Persistence', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
      { key: 'axis', label: 'Direction', kind: 'select', options: [{ value: 'normal', label: 'Radial' }, { value: 'x', label: 'X' }, { value: 'y', label: 'Y' }, { value: 'z', label: 'Z' }] },
    ],
  },
  {
    type: 'vortexField',
    label: 'Vortex / Swirl Field',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { strength: 1.1, radius: 3, axis: 'y', falloff: 1, centerX: 0, centerY: 0, centerZ: 0, animate: false, speed: 0.2 },
    outputs: [{ key: 'strength', label: 'Strength field', type: 'float' }, { key: 'directionX', label: 'Direction X', type: 'float' }, { key: 'directionY', label: 'Direction Y', type: 'float' }, { key: 'directionZ', label: 'Direction Z', type: 'float' }],
    fields: [
      AXIS,
      { key: 'strength', label: 'Strength', kind: 'number', min: -12, max: 12, step: 0.01 },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'animate', label: 'Animate swirl', kind: 'toggle' },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
    ],
  },
  {
    type: 'attractorField',
    label: 'Attractor / Repulsor',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { strength: 1, radius: 4, falloff: 1, pointX: 0, pointY: 0, pointZ: 0, mode: 'attract' },
    outputs: [{ key: 'distance', label: 'Distance', type: 'float' }, { key: 'normalizedDistance', label: 'Normalized distance', type: 'float' }, { key: 'force', label: 'Force', type: 'float' }, { key: 'directionX', label: 'Direction X', type: 'float' }, { key: 'directionY', label: 'Direction Y', type: 'float' }, { key: 'directionZ', label: 'Direction Z', type: 'float' }],
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -20, max: 20, step: 0.01 },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'pointX', label: 'Point X', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'pointY', label: 'Point Y', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'pointZ', label: 'Point Z', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'mode', label: 'Mode', kind: 'select', options: [{ value: 'attract', label: 'Attract' }, { value: 'repel', label: 'Repel' }] },
    ],
  },
  {
    type: 'bend',
    label: 'Bend / Curve',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { amount: 60, axis: 'y', start: -2, end: 2, falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, animate: false, speed: 0.2 },
    fields: [
      AXIS,
      { key: 'amount', label: 'Amount', kind: 'number', min: -1800, max: 1800, step: 1, unit: '°', animatable: true },
      { key: 'start', label: 'Region start', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'end', label: 'Region end', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.01, max: 20, step: 0.05 },
      { key: 'pivotX', label: 'Pivot X', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'pivotY', label: 'Pivot Y', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'pivotZ', label: 'Pivot Z', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'animate', label: 'Animate bend', kind: 'toggle' },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
    ],
  },
  {
    type: 'melt', label: 'Melt', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    description: 'Downward noise-thresholded progressive melt.',
    defaults: { amount: 0.4, viscosity: 0.5, noise: 1, threshold: 0.25, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 10, step: 0.01, animatable: true },
      { key: 'viscosity', label: 'Viscosity', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'noise', label: 'Noise scale', kind: 'number', min: 0, max: 20, step: 0.05 },
      { key: 'threshold', label: 'Threshold', kind: 'number', min: 0, max: 1, step: 0.01 },
      AXIS,
    ],
  },
  {
    type: 'spherize', label: 'Spherize', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { amount: 0.5, radius: 1.2, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: -2, max: 2, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.05, max: 50, step: 0.05 },
      AXIS,
    ],
  },
  {
    type: 'ripple', label: 'Ripple', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    defaults: { strength: 0.2, frequency: 4, speed: 0.6, centerX: 0, centerY: 0, centerZ: 0, radius: 8 },
    outputs: [{ key: 'amplitude', label: 'Amplitude field', type: 'float' }],
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 10, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 50, step: 0.1 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -20, max: 20, step: 0.05 },
    ],
  },
  {
    type: 'waveField', label: 'Wave Field', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { strength: 0.2, frequency: 3, speed: 0.3, direction: 'y', axis: 'y' },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 10, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 50, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
      { key: 'direction', label: 'Travel axis', kind: 'select', options: [{value:'x',label:'X'},{value:'y',label:'Y'},{value:'z',label:'Z'}] },
      AXIS,
    ],
  },
  {
    type: 'fold', label: 'Fold', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { amount: 0.5, axis: 'x', position: 0, sharpness: 1 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 10, step: 0.01, animatable: true },
      { key: 'position', label: 'Fold position', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'sharpness', label: 'Sharpness', kind: 'number', min: 0.01, max: 10, step: 0.01 },
      AXIS,
    ],
  },
  {
    type: 'explode', label: 'Explode', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    defaults: { amount: 0.3, seed: 1, threshold: 0.2, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 10, step: 0.01, animatable: true },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
      { key: 'threshold', label: 'Threshold', kind: 'number', min: 0, max: 1, step: 0.01 },
      AXIS,
    ],
  },
  {
    type: 'quantizeGeometry', label: 'Quantize Geometry', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { grid: 0.15, radial: 0, angular: 0 },
    fields: [
      { key: 'grid', label: 'Grid snap', kind: 'number', min: 0, max: 5, step: 0.01, unit: 'm' },
      { key: 'radial', label: 'Radial bands', kind: 'number', min: 0, max: 32, step: 1 },
      { key: 'angular', label: 'Angular steps', kind: 'number', min: 0, max: 64, step: 1 },
    ],
  },
  {
    type: 'inflate', label: 'Inflate / Deflate', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { amount: 0.2, falloff: 1, center: 0 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: -10, max: 10, step: 0.01, animatable: true },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.01, max: 20, step: 0.01 },
      { key: 'center', label: 'Center', kind: 'number', min: -20, max: 20, step: 0.05 },
    ],
  },
  {
    type: 'slice', label: 'Slice / Separate', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    defaults: { bands: 6, gap: 0.2, axis: 'y' },
    fields: [
      { key: 'bands', label: 'Bands', kind: 'number', min: 1, max: 64, step: 1 },
      { key: 'gap', label: 'Gap', kind: 'number', min: 0, max: 2, step: 0.01 },
      AXIS,
    ],
  },
  {
    type: 'mirrorGeometry', label: 'Mirror / Symmetry', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { axis: 'x', amount: 1, position: 0 },
    fields: [
      AXIS,
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'position', label: 'Mirror plane', kind: 'number', min: -20, max: 20, step: 0.05 },
    ],
  },
  {
    type: 'spiralWarp', label: 'Spiral / Helix Warp', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    defaults: { amount: 1.5, radius: 1.5, twist: 1, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Warp amount', kind: 'number', min: -20, max: 20, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05 },
      { key: 'twist', label: 'Twists', kind: 'number', min: -8, max: 8, step: 0.01 },
      AXIS,
    ],
  },
  {
    type: 'cylindrify', label: 'Cylindrify', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    defaults: { amount: 0.5, radius: 1, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: -2, max: 2, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.05, max: 50, step: 0.05 },
      AXIS,
    ],
  },
  {
    type: 'mercury', label: 'Mercury', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { metalness: 1, roughness: 0.03, distortion: 1.2, flowSpeed: 0.55, noiseScale: 3.4, fresnel: 2, tint: '#e8f4ff', accent: '#b8d8ff', emission: 0.18 },
    fields: [
      { key: 'metalness', label: 'Metalness', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'roughness', label: 'Roughness', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'distortion', label: 'Distortion', kind: 'number', min: 0, max: 4, step: 0.01, animatable: true },
      { key: 'flowSpeed', label: 'Flow speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'noiseScale', label: 'Noise scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'fresnel', label: 'Fresnel', kind: 'number', min: 0, max: 8, step: 0.01 },
      { key: 'tint', label: 'Tint', kind: 'color' },
      { key: 'accent', label: 'Accent', kind: 'color' },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 5, step: 0.01 },
    ],
  },
  {
    type: 'xray', label: 'X-Ray', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { color: '#67d9ff', intensity: 1.4, fresnelPower: 2.6, opacity: 0.4 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'fresnelPower', label: 'Fresnel power', kind: 'number', min: 0.1, max: 20, step: 0.01 },
      { key: 'opacity', label: 'Opacity', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
    ],
  },
  {
    type: 'ghost', label: 'Ghost / Fresnel Shell', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { color: '#dff6ff', intensity: 1.2, fresnelPower: 3.2, opacity: 0.22 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'fresnelPower', label: 'Fresnel power', kind: 'number', min: 0.1, max: 20, step: 0.01 },
      { key: 'opacity', label: 'Opacity', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
    ],
  },
  {
    type: 'glass', label: 'Glass / Refraction', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'high',
    defaults: { tint: '#bfefff', opacity: 0.38, roughness: 0.04, refraction: 1.45, thickness: 0.6 },
    fields: [
      { key: 'tint', label: 'Tint', kind: 'color' },
      { key: 'opacity', label: 'Opacity', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'roughness', label: 'Roughness', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'refraction', label: 'IOR', kind: 'number', min: 1, max: 3, step: 0.01 },
      { key: 'thickness', label: 'Thickness', kind: 'number', min: 0, max: 10, step: 0.01 },
    ],
  },
  {
    type: 'neonEdge', label: 'Neon Edge', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { color: '#48ffe8', intensity: 2.2, fresnelPower: 2.4, width: 0.65 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'fresnelPower', label: 'Edge power', kind: 'number', min: 0.1, max: 20, step: 0.01 },
      { key: 'width', label: 'Edge width', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'scanlinesSurface', label: 'Surface Scanlines', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { color: '#68f4ff', density: 80, speed: 1, intensity: 1.2 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'density', label: 'Density', kind: 'number', min: 0, max: 500, step: 1, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01 },
    ],
  },
  {
    type: 'chromaticSurface', label: 'Chromatic Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'high',
    defaults: { colorA: '#ff2a6d', colorB: '#05d9e8', strength: 1.2, scale: 2.2, speed: 0.3 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
    ],
  },
  {
    type: 'noiseSurface', label: 'Noise Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { colorA: '#11131a', colorB: '#d9f7ff', scale: 3, speed: 0.15, intensity: 0.8 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'digitalMatter', label: 'Digital Matter', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'high',
    defaults: { color: '#8affd8', blocks: 24, speed: 2, intensity: 1.4 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'blocks', label: 'Blocks', kind: 'number', min: 1, max: 200, step: 1 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 20, step: 0.1 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'checkerSurface', label: 'Checker Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { colorA: '#05070a', colorB: '#f2f2f2', scale: 4, intensity: 1 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01 },
    ],
  },
  {
    type: 'wavesSurface', label: 'Wave Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { color: '#55ffcc', scale: 3, speed: 0.5, intensity: 1.2 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'ringsSurface', label: 'Rings Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { color: '#ffd166', frequency: 8, speed: 0.3, intensity: 1.4 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 100, step: 0.1, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 20, step: 0.01 },
    ],
  },
  {
    type: 'wireframeSurface', label: 'Wireframe / Neon Mesh', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { color: '#59ffdf', intensity: 2.4 },
    fields: [
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'intensity', label: 'Emissive', kind: 'number', min: 0, max: 20, step: 0.01 },
    ],
  },
  {
    type: 'voronoiSurface', label: 'Voronoi Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'high',
    defaults: { scale: 4, border: 0.08, emission: 1.8, colorA: '#05070b', colorB: '#ff4bd8' },
    fields: [
      { key: 'scale', label: 'Cell scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'border', label: 'Border width', kind: 'number', min: 0.001, max: 0.5, step: 0.001 },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'colorA', label: 'Cell color', kind: 'color' },
      { key: 'colorB', label: 'Border color', kind: 'color' },
    ],
  },
  {
    type: 'animatedGradient', label: 'Animated Gradient', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'low',
    defaults: { colorA: '#0b1020', colorB: '#ff2fd0', colorC: '#4be1ff', scale: 1.2, speed: 0.2, angle: 0, emission: 1.4 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'colorC', label: 'Color C', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 20, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'angle', label: 'Angle', kind: 'number', min: -180, max: 180, step: 1, unit: '°' },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'glitchSurface', label: 'Glitch Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    defaults: { amount: 0.3, blocks: 18, shift: 0.4, emission: 1.6, color: '#7df9ff' },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'blocks', label: 'Blocks', kind: 'number', min: 1, max: 100, step: 1 },
      { key: 'shift', label: 'Shift', kind: 'number', min: 0, max: 4, step: 0.01 },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01 },
      { key: 'color', label: 'Glitch color', kind: 'color' },
    ],
  },
  {
    type: 'taper',
    label: 'Taper / Pinch / Bulge',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { amount: 0.5, axis: 'y', center: 0, falloff: 1, bulge: 0 },
    fields: [
      AXIS,
      { key: 'amount', label: 'Taper', kind: 'number', min: -4, max: 4, step: 0.01 },
      { key: 'bulge', label: 'Pinch / bulge', kind: 'number', min: -4, max: 4, step: 0.01 },
      { key: 'center', label: 'Center', kind: 'number', min: -20, max: 20, step: 0.05 },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.05, max: 20, step: 0.05 },
    ],
  },
  {
    type: 'shear',
    label: 'Shear / Quantize',
    category: 'Deform',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'geometry',
    cost: 'low',
    defaults: { shearX: 0.3, shearZ: 0, quantize: 0, axis: 'y' },
    fields: [
      { key: 'shearX', label: 'Shear X', kind: 'number', min: -10, max: 10, step: 0.01 },
      { key: 'shearZ', label: 'Shear Z', kind: 'number', min: -10, max: 10, step: 0.01 },
      { key: 'quantize', label: 'Quantize', kind: 'number', min: 0, max: 2, step: 0.01, unit: 'm' },
      AXIS,
    ],
  },
  {
    type: 'liquidChrome',
    label: 'Liquid Chrome',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'medium',
    description: 'Procedural liquid metal with animated normals-emulated highlights and fresnel.',
    capabilities: ['animated', 'timeline', 'shared-look'],
    defaults: { metalness: 1, roughness: 0.08, distortion: 0.8, normalDistortion: 0.5, flowSpeed: 0.35, noiseScale: 2.2, fresnel: 1.3, tint: '#cfe8ff', accent: '#7fdcff', emission: 0.35 },
    fields: [
      { key: 'metalness', label: 'Metalness', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'roughness', label: 'Roughness', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'distortion', label: 'Flow distortion', kind: 'number', min: 0, max: 4, step: 0.01, animatable: true },
      { key: 'normalDistortion', label: 'Normal distortion', kind: 'number', min: 0, max: 4, step: 0.01, animatable: true },
      { key: 'flowSpeed', label: 'Flow speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'noiseScale', label: 'Noise scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'fresnel', label: 'Fresnel', kind: 'number', min: 0, max: 8, step: 0.01 },
      { key: 'tint', label: 'Tint', kind: 'color' },
      { key: 'accent', label: 'Emissive accent', kind: 'color' },
      { key: 'emission', label: 'Accent strength', kind: 'number', min: 0, max: 5, step: 0.01 },
    ],
  },
  {
    type: 'magma',
    label: 'Magma / Lava',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'high',
    defaults: { crust: '#120b08', lava: '#ff5a12', hot: '#ffd36a', noiseScale: 2.6, crackWidth: 0.12, temperature: 1.2, emission: 2.4, flowSpeed: 0.2, distortion: 0.4 },
    fields: [
      { key: 'crust', label: 'Crust color', kind: 'color' },
      { key: 'lava', label: 'Lava color', kind: 'color' },
      { key: 'hot', label: 'Hot core', kind: 'color' },
      { key: 'noiseScale', label: 'Noise scale', kind: 'number', min: 0.05, max: 20, step: 0.05 },
      { key: 'crackWidth', label: 'Crack width', kind: 'number', min: 0.005, max: 0.8, step: 0.005 },
      { key: 'temperature', label: 'Temperature', kind: 'number', min: 0, max: 8, step: 0.01, animatable: true },
      { key: 'emission', label: 'Emission strength', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'flowSpeed', label: 'Flow speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'distortion', label: 'Flow distortion', kind: 'number', min: 0, max: 3, step: 0.01 },
    ],
  },
  {
    type: 'plasma',
    label: 'Plasma / Energy',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'high',
    defaults: { colorA: '#1a0033', colorB: '#00e5ff', colorC: '#ff21c8', scale: 2.8, speed: 0.4, turbulence: 1.2, emission: 2.2, edgeGlow: 1.4 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'colorC', label: 'Color C', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'turbulence', label: 'Turbulence', kind: 'number', min: 0, max: 8, step: 0.01, animatable: true },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
      { key: 'edgeGlow', label: 'Edge glow', kind: 'number', min: 0, max: 10, step: 0.01 },
    ],
  },
  {
    type: 'hologram',
    label: 'Advanced Hologram',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'high',
    defaults: { colorA: '#35d9ff', colorB: '#ff3df2', scanlineDensity: 70, scanlineSpeed: 1.2, flicker: 0.35, glitch: 0.15, breakup: 0.1, noiseDistortion: 0.2, chromatic: 1.2, opacity: 0.72, emission: 2.1 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'scanlineDensity', label: 'Scanline density', kind: 'number', min: 1, max: 300, step: 1, animatable: true },
      { key: 'scanlineSpeed', label: 'Scanline speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'flicker', label: 'Flicker', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'glitch', label: 'Glitch', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'breakup', label: 'Vertical breakup', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'noiseDistortion', label: 'Noise distortion', kind: 'number', min: 0, max: 2, step: 0.01 },
      { key: 'chromatic', label: 'Chromatic offset', kind: 'number', min: 0, max: 4, step: 0.01 },
      { key: 'opacity', label: 'Opacity', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'iridescentFilm',
    label: 'Iridescent Thin Film',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'medium',
    defaults: { thickness: 420, ior: 1.38, hueShift: 0.2, intensity: 1.4, fresnel: 2.4, scale: 1.2, time: 0.2, tint: '#ffffff' },
    fields: [
      { key: 'thickness', label: 'Thickness', kind: 'number', min: 40, max: 2000, step: 1, unit: 'nm', animatable: true },
      { key: 'ior', label: 'IOR', kind: 'number', min: 1, max: 2.5, step: 0.01 },
      { key: 'hueShift', label: 'Hue shift', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'intensity', label: 'Intensity', kind: 'number', min: 0, max: 8, step: 0.01, animatable: true },
      { key: 'fresnel', label: 'Fresnel', kind: 'number', min: 0, max: 8, step: 0.01 },
      { key: 'scale', label: 'Noise scale', kind: 'number', min: 0.05, max: 20, step: 0.05 },
      { key: 'time', label: 'Time modulation', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'tint', label: 'Tint', kind: 'color' },
    ],
  },
  {
    type: 'triplanar',
    label: 'Triplanar Noise Surface',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'medium',
    defaults: { colorA: '#0a0d12', colorB: '#6be7ff', scale: 2.2, speed: 0.15, blend: 0.5, emission: 1.1 },
    fields: [
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.05, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'blend', label: 'Blend', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'radialClone',
    label: 'Radial Clone',
    category: 'Structure',
    targets: ['model', 'light'],
    runtime: 'clone',
    defaults: { count: 8, radius: 2, angleOffset: 0, rotationFollow: true, scaleVariation: 0, orbit: false, orbitSpeed: 0.2, pattern: 'ring', height: 0, spacing: 1.5, phase: 0, randomness: 0, scaleProgression: 0, pulse: 0, pulseSpeed: 1 },
    fields: [
      { key: 'count', label: 'Clone count', kind: 'number', min: 1, max: 200, step: 1 },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'angleOffset', label: 'Angle offset', kind: 'number', min: -360, max: 360, step: 1, unit: '°' },
      { key: 'rotationFollow', label: 'Rotation follow', kind: 'toggle' },
      { key: 'scaleVariation', label: 'Scale variation', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'orbit', label: 'Orbit', kind: 'toggle' },
      { key: 'orbitSpeed', label: 'Orbit speed', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'pattern', label: 'Pattern', kind: 'select', options: [{ value: 'ring', label: 'Radial ring' }, { value: 'linear', label: 'Linear array' }, { value: 'grid', label: 'Grid array' }, { value: 'spiral', label: 'Spiral' }, { value: 'helix', label: 'Helix' }, { value: 'sphere', label: 'Sphere distribution' }] },
      { key: 'height', label: 'Height', kind: 'number', min: -50, max: 50, step: 0.05, unit: 'm' },
      { key: 'spacing', label: 'Spacing', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
      { key: 'randomness', label: 'Randomness', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'scaleProgression', label: 'Scale progression', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'pulse', label: 'Pulse amount', kind: 'number', min: 0, max: 2, step: 0.01 },
      { key: 'pulseSpeed', label: 'Pulse speed', kind: 'number', min: 0, max: 10, step: 0.05, unit: 'Hz' },
    ],
  },
  {
    type: 'fresnel',
    label: 'Fresnel / Iridescence',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'medium',
    defaults: { intensity: 1.2, bias: 0, power: 3, colorMode: 'rainbow', color: '#57d7ff', iridescence: 0.5, blend: 1 },
    fields: [
      { key: 'intensity', label: 'Intensity', kind: 'percent', min: 0, max: 10, step: 0.01 },
      { key: 'bias', label: 'Bias', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'power', label: 'Power', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'colorMode', label: 'Color mode', kind: 'select', options: [{ value: 'rainbow', label: 'Rainbow' }, { value: 'solid', label: 'Solid' }] },
      { key: 'color', label: 'Color', kind: 'color' },
      { key: 'iridescence', label: 'Iridescence', kind: 'percent', min: 0, max: 10, step: 0.01 },
      { key: 'blend', label: 'Blend', kind: 'percent', min: 0, max: 10, step: 0.01 },
    ],
  },
  {
    type: 'dissolve',
    label: 'Dissolve',
    category: 'Surface',
    targets: ['model', 'light'],
    runtime: 'shader',
    stage: 'surface',
    cost: 'medium',
    defaults: { amount: 0.25, edgeWidth: 0.03, edgeColor: '#39e6ff', edgeGlow: 1.5, noiseScale: 3, animate: false, speed: 0.3, seed: 1 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'percent', min: 0, max: 1, step: 0.005 },
      { key: 'edgeWidth', label: 'Edge width', kind: 'number', min: 0.001, max: 0.3, step: 0.001 },
      { key: 'edgeColor', label: 'Edge color', kind: 'color' },
      { key: 'edgeGlow', label: 'Edge glow', kind: 'percent', min: 0, max: 10, step: 0.01 },
      { key: 'noiseScale', label: 'Noise scale', kind: 'number', min: 0.1, max: 20, step: 0.05 },
      { key: 'animate', label: 'Animated dissolve', kind: 'toggle' },
      { key: 'speed', label: 'Speed', kind: 'number', min: -10, max: 10, step: 0.05, unit: 'Hz' },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'lightIntensityNoise', label: 'Intensity Noise', category: 'Surface', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { amount: 0.35, frequency: 6, speed: 1.4, seed: 1 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 2, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Noise frequency', kind: 'number', min: 0, max: 40, step: 0.1 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05, unit: 'Hz' },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'lightColorDrift', label: 'Color Drift', category: 'Surface', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { amount: 0.5, speed: 0.15, colorA: '#ff3d00', colorB: '#00e5ff', seed: 1 },
    fields: [
      { key: 'amount', label: 'Mix', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'lightBeamPulse', label: 'Beam Pulse', category: 'Surface', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { amount: 0.5, frequency: 1, speed: 1, coneAmount: 0.25 },
    fields: [
      { key: 'amount', label: 'Intensity pulse', kind: 'number', min: 0, max: 2, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 30, step: 0.05, unit: 'Hz' },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05 },
      { key: 'coneAmount', label: 'Cone pulse', kind: 'number', min: 0, max: 2, step: 0.01 },
    ],
  },
  {
    type: 'lightOrbit', label: 'Light Orbit', category: 'Motion', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { radius: 2, speed: 0.25, height: 0, phase: 0 },
    fields: [
      { key: 'radius', label: 'Radius', kind: 'number', min: 0, max: 50, step: 0.05, unit: 'm' },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'height', label: 'Height', kind: 'number', min: -20, max: 20, step: 0.05, unit: 'm' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
    ],
  },
  {
    type: 'lightRandomWalk', label: 'Random Walk', category: 'Motion', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { amount: 1, speed: 0.3, seed: 1 },
    fields: [
      { key: 'amount', label: 'Distance', kind: 'number', min: 0, max: 20, step: 0.01, unit: 'm' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 5, step: 0.01 },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'lightStrobePattern', label: 'Strobe Pattern', category: 'Surface', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'low',
    defaults: { pattern: 'burst', rate: 8, duty: 0.25, amount: 1 },
    fields: [
      { key: 'pattern', label: 'Pattern', kind: 'select', options: [{value:'burst',label:'Burst'},{value:'random',label:'Random'},{value:'morse',label:'Morse-like'},{value:'accelerate',label:'Accelerating'},{value:'decelerate',label:'Decelerating'}] },
      { key: 'rate', label: 'Rate', kind: 'number', min: 0, max: 60, step: 0.1, unit: 'Hz' },
      { key: 'duty', label: 'Duty', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'amount', label: 'Depth', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'lightVolumetricMod', label: 'Volumetric Modulation', category: 'Surface', targets: ['light','device'], runtime: 'light', stage: 'light', cost: 'medium',
    defaults: { amount: 0.4, frequency: 3, speed: 0.5, seed: 1 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Noise frequency', kind: 'number', min: 0, max: 30, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05 },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'fieldDirectionalGravity', label: 'Directional Gravity Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'low',
    defaults: { strength: 9.81, directionX: 0, directionY: -1, directionZ: 0, affectMass: false },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 100, step: 0.01, animatable: true },
      { key: 'directionX', label: 'Direction X', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'directionY', label: 'Direction Y', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'directionZ', label: 'Direction Z', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'affectMass', label: 'Scale by mass', kind: 'toggle' },
    ],
  },
  {
    type: 'fieldAttractor', label: 'Attractor / Repulsor Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'medium',
    defaults: { strength: 12, radius: 8, falloff: 1, centerX: 0, centerY: 2, centerZ: 0, mode: 'attract' },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -100, max: 100, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 100, step: 0.05 },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'mode', label: 'Mode', kind: 'select', options: [{value:'attract',label:'Attract'},{value:'repel',label:'Repel'}] },
    ],
  },
  {
    type: 'fieldVortex', label: 'Vortex Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'medium',
    defaults: { strength: 10, radius: 8, falloff: 1, centerX: 0, centerY: 2, centerZ: 0, axis: 'y' },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -100, max: 100, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 100, step: 0.05 },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -100, max: 100, step: 0.05 },
      AXIS,
    ],
  },
  {
    type: 'fieldWind', label: 'Wind Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'low',
    defaults: { strength: 6, directionX: 1, directionZ: 0, turbulence: 0.4, speed: 0.5 },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 100, step: 0.01, animatable: true },
      { key: 'directionX', label: 'Direction X', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'directionZ', label: 'Direction Z', kind: 'number', min: -1, max: 1, step: 0.01 },
      { key: 'turbulence', label: 'Turbulence', kind: 'number', min: 0, max: 5, step: 0.01 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.01 },
    ],
  },
  {
    type: 'fieldNoise', label: 'Noise Force Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'high',
    defaults: { strength: 8, scale: 2, speed: 0.4, seed: 1 },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 100, step: 0.01, animatable: true },
      { key: 'scale', label: 'Noise scale', kind: 'number', min: 0.01, max: 20, step: 0.01 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.01 },
      { key: 'seed', label: 'Seed', kind: 'number', min: 0, max: 9999, step: 1 },
    ],
  },
  {
    type: 'fieldDrag', label: 'Drag Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'low',
    defaults: { strength: 0.4 },
    fields: [{ key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 20, step: 0.01, animatable: true }],
  },
  {
    type: 'fieldOrbit', label: 'Orbit Field', category: 'Screen', targets: ['field'], runtime: 'field', stage: 'field', cost: 'medium',
    defaults: { strength: 8, radius: 6, falloff: 1, centerX: 0, centerY: 2, centerZ: 0 },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -100, max: 100, step: 0.01, animatable: true },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 100, step: 0.05 },
      { key: 'falloff', label: 'Falloff', kind: 'number', min: 0.1, max: 8, step: 0.05 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -100, max: 100, step: 0.05 },
    ],
  },
  {
    type: 'cameraFovPulse', label: 'FOV Pulse', category: 'Screen', targets: ['camera'], runtime: 'scene', stage: 'camera', cost: 'low',
    defaults: { amount: 12, speed: 0.25, phase: 0, waveform: 'sine' },
    fields: [
      { key: 'amount', label: 'FOV amount', kind: 'number', min: -80, max: 80, step: 0.1, unit: '°', animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01 },
      { key: 'waveform', label: 'Waveform', kind: 'select', options: [{value:'sine',label:'Sine'},{value:'pulse',label:'Pulse'},{value:'noise',label:'Noise'}] },
    ],
  },

  {
    type: 'environmentExposure', label: 'Exposure Pulse', category: 'Screen', targets: ['scene'], runtime: 'scene', stage: 'scene', cost: 'low',
    defaults: { amount: 0.25, speed: 0.2, wave: 'sine', phase: 0 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: 0, max: 4, step: 0.01, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'wave', label: 'Waveform', kind: 'select', options: [{value:'sine',label:'Sine'},{value:'pulse',label:'Pulse'},{value:'noise',label:'Noise'}] },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01 },
    ],
  },
  {
    type: 'ambientColorDrift', label: 'Ambient Color Drift', category: 'Screen', targets: ['scene'], runtime: 'scene', stage: 'scene', cost: 'low',
    defaults: { amount: 0.5, speed: 0.05, colorA: '#150022', colorB: '#003344', phase: 0 },
    fields: [
      { key: 'amount', label: 'Mix', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -2, max: 2, step: 0.01, unit: 'Hz' },
      { key: 'colorA', label: 'Color A', kind: 'color' },
      { key: 'colorB', label: 'Color B', kind: 'color' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01 },
    ],
  },
  {
    type: 'fogField', label: 'Fog Density Field', category: 'Screen', targets: ['scene'], runtime: 'scene', stage: 'scene', cost: 'medium',
    defaults: { amount: 0.5, speed: 0.15, noiseScale: 2, noiseAmount: 0.35 },
    fields: [
      { key: 'amount', label: 'Density', kind: 'number', min: 0, max: 4, step: 0.01, animatable: true },
      { key: 'speed', label: 'Flow speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'noiseScale', label: 'Noise scale', kind: 'number', min: 0.05, max: 20, step: 0.05 },
      { key: 'noiseAmount', label: 'Noise amount', kind: 'number', min: 0, max: 2, step: 0.01 },
    ],
  },
  {
    type: 'fogTurbulence', label: 'Fog Turbulence', category: 'Screen', targets: ['scene'], runtime: 'scene', stage: 'scene', cost: 'medium',
    defaults: { amount: 0.4, speed: 0.4, frequency: 2.5 },
    fields: [
      { key: 'amount', label: 'Turbulence', kind: 'number', min: 0, max: 3, step: 0.01, animatable: true },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01 },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 20, step: 0.05 },
    ],
  },
  {
    type: 'rgbSplit',
    label: 'RGB Split',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'low',
    defaults: { amount: 4, angle: 0, mix: 0.75 },
    fields: [
      { key: 'amount', label: 'Offset', kind: 'number', min: 0, max: 60, step: 0.5, unit: 'px', animatable: true },
      { key: 'angle', label: 'Angle', kind: 'number', min: -180, max: 180, step: 1, unit: '°' },
      { key: 'mix', label: 'Mix', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'kaleidoscopePost',
    label: 'Kaleidoscope',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'high',
    defaults: { segments: 6, rotation: 0, zoom: 1.15, centerX: 0.5, centerY: 0.5 },
    fields: [
      { key: 'segments', label: 'Segments', kind: 'number', min: 2, max: 24, step: 1, animatable: true },
      { key: 'rotation', label: 'Rotation', kind: 'number', min: -180, max: 180, step: 1, unit: '°', animatable: true },
      { key: 'zoom', label: 'Zoom', kind: 'number', min: 0.2, max: 4, step: 0.01 },
      { key: 'centerX', label: 'Center X', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'pixelatePost',
    label: 'Pixelate',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'low',
    defaults: { size: 8, mix: 1 },
    fields: [
      { key: 'size', label: 'Pixel size', kind: 'number', min: 1, max: 64, step: 1, animatable: true },
      { key: 'mix', label: 'Mix', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'uvDistortPost',
    label: 'UV / Depth Distortion',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'medium',
    defaults: { strength: 12, scale: 6, speed: 0.3, mix: 1 },
    fields: [
      { key: 'strength', label: 'Displacement', kind: 'number', min: 0, max: 100, step: 0.5, unit: 'px', animatable: true },
      { key: 'scale', label: 'Wave scale', kind: 'number', min: 0.5, max: 40, step: 0.1 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'mix', label: 'Mix', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'scanlinesPost',
    label: 'Scanlines / VHS',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'low',
    defaults: { density: 320, opacity: 0.18, speed: 0.2, glitch: 0.05 },
    fields: [
      { key: 'density', label: 'Density', kind: 'number', min: 20, max: 1200, step: 1, animatable: true },
      { key: 'opacity', label: 'Opacity', kind: 'number', min: 0, max: 1, physicalMin: 0, physicalMax: 1, hardClamp: true, step: 0.01 },
      { key: 'speed', label: 'Scroll speed', kind: 'number', min: -5, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'glitch', label: 'Glitch', kind: 'number', min: 0, max: 1, step: 0.01, animatable: true },
    ],
  },
  {
    type: 'feedback',
    label: 'Feedback / Afterimage',
    category: 'Screen',
    targets: ['scene'],
    runtime: 'scene',
    stage: 'post',
    cost: 'high',
    defaults: { intensity: 0.45, persistence: 0.72, softness: 1, tint: '#5ea8ff', ghost: false },
    fields: [
      { key: 'intensity', label: 'Intensity', kind: 'percent', min: 0, max: 10, step: 0.01 },
      { key: 'persistence', label: 'Persistence', kind: 'number', min: 0, max: 0.99, step: 0.01 },
      { key: 'softness', label: 'Blur softness', kind: 'number', min: 0, max: 12, step: 0.1 },
      { key: 'tint', label: 'Color tint', kind: 'color' },
      { key: 'ghost', label: 'Ghost trail', kind: 'toggle' },
    ],
  },
  {
    type: 'reactionDisplace', label: 'Reaction Diffusion Displace', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    description: 'Displace geometry from the shared GPU Reaction Diffusion field. Uses the same mapping as surface routing.',
    defaults: { amount: 0.35, mapping: 'auto', output: 'scalar' },
    fields: [
      { key: 'amount', label: 'Displacement', kind: 'number', min: -3, max: 3, step: 0.01, shortDescription: 'Vertex offset along the local surface normal, driven by the RD field.' },
      { key: 'mapping', label: 'Mapping', kind: 'select', options: [{value:'auto',label:'Auto'},{value:'uv',label:'UV0'},{value:'object',label:'Object space'},{value:'world',label:'World space'},{value:'spherical',label:'Spherical'}], shortDescription: 'Mapping space shared by every RD consumer on this object.' },
      { key: 'output', label: 'Field output', kind: 'select', options: [{value:'scalar',label:'Scalar'},{value:'mask',label:'Threshold mask'},{value:'gradient',label:'Gradient magnitude'},{value:'normal',label:'Normal X'},{value:'vector',label:'Vector field'}], shortDescription: 'Which view of the same simulation drives displacement.' },
    ],
  },
  {
    type: 'reactionSurface', label: 'Reaction Diffusion Surface', category: 'Surface', targets: ['model','light'], runtime: 'shader', stage: 'surface', cost: 'medium',
    description: 'Drive emission from the shared GPU Reaction Diffusion field. Same simulation and mapping as displacement.',
    defaults: { emission: 1.2, color: '#42e8ff', colorB: '#ff2bd6', opacity: 0, baseColor: 0, roughness: 0, metallic: 0, mapping: 'auto', output: 'scalar' },
    fields: [
      { key: 'emission', label: 'Emission', kind: 'number', min: 0, max: 10, step: 0.01, shortDescription: 'Brightness of the RD-driven emission. Can be pushed into overdrive.' },
      { key: 'color', label: 'Color A', kind: 'color', shortDescription: 'Low-field emission tint.' },
      { key: 'colorB', label: 'Color B', kind: 'color', shortDescription: 'High-field emission tint. Scalar/mask/gradient interpolates between A and B.' },
      { key: 'opacity', label: 'Opacity influence', kind: 'number', min: 0, max: 1, step: 0.01, shortDescription: 'Blend the RD field into alpha. Zero leaves material opacity untouched.' },
      { key: 'baseColor', label: 'Base color influence', kind: 'number', min: 0, max: 1, step: 0.01, shortDescription: 'Blend the RD A/B gradient into the material albedo.' },
      { key: 'roughness', label: 'Roughness influence', kind: 'number', min: 0, max: 1, step: 0.01, shortDescription: 'Use the RD field to break up roughness spatially.' },
      { key: 'metallic', label: 'Metallic influence', kind: 'number', min: 0, max: 1, step: 0.01, shortDescription: 'Use the RD field to break up metalness spatially.' },
      { key: 'output', label: 'Field output', kind: 'select', options: [{value:'scalar',label:'Scalar'},{value:'mask',label:'Threshold mask'},{value:'gradient',label:'Gradient magnitude'},{value:'normal',label:'Normal X'},{value:'vector',label:'Vector field'}], shortDescription: 'Same simulation viewed as scalar, mask, gradient or normal field.' },
      { key: 'mapping', label: 'Mapping', kind: 'select', options: [{value:'auto',label:'Auto'},{value:'uv',label:'UV0'},{value:'object',label:'Object space'},{value:'world',label:'World space'},{value:'spherical',label:'Spherical'}], shortDescription: 'Mapping space shared by every RD consumer on this object.' },
    ],
  },
  {
    type: 'pinch', label: 'Pinch / Bulge', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    description: 'Radial attraction or bulge around a point. Negative values pinch, positive values bulge.',
    defaults: { amount: 0.35, radius: 1.2, centerX: 0, centerY: 0, centerZ: 0 },
    fields: [
      { key: 'amount', label: 'Amount', kind: 'number', min: -2, max: 2, step: 0.01, shortDescription: 'Negative pinches toward the center, positive bulges away.' },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 20, step: 0.01, unit: 'm' },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -20, max: 20, step: 0.01 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -20, max: 20, step: 0.01 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -20, max: 20, step: 0.01 },
    ],
  },
  {
    type: 'orbitMotion', label: 'Orbit Motion', category: 'Motion', targets: ['model','light','device'], runtime: 'motion', stage: 'geometry', cost: 'low',
    description: 'Orbit a object around a target point on a GPU-friendly runtime path.',
    defaults: { radius: 2, speed: 0.25, phase: 0, height: 0, centerX: 0, centerY: 0, centerZ: 0 },
    fields: [
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 5, step: 0.01, unit: 'Hz' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01, unit: 'rad' },
      { key: 'height', label: 'Height', kind: 'number', min: -20, max: 20, step: 0.05, unit: 'm' },
      { key: 'centerX', label: 'Center X', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'centerY', label: 'Center Y', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'centerZ', label: 'Center Z', kind: 'number', min: -50, max: 50, step: 0.05 },
    ],
  },
  {
    type: 'lookAtMotion', label: 'Look At', category: 'Motion', targets: ['model','light','device'], runtime: 'motion', stage: 'geometry', cost: 'low',
    description: 'Aim the object at a runtime target point.',
    defaults: { targetX: 0, targetY: 1, targetZ: 0, axis: 'y', strength: 1 },
    fields: [
      { key: 'targetX', label: 'Target X', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'targetY', label: 'Target Y', kind: 'number', min: -100, max: 100, step: 0.05 },
      { key: 'targetZ', label: 'Target Z', kind: 'number', min: -100, max: 100, step: 0.05 },
      AXIS,
      { key: 'strength', label: 'Strength', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'springFollow', label: 'Spring Follow', category: 'Motion', targets: ['model','light','device'], runtime: 'motion', stage: 'geometry', cost: 'low',
    description: 'Damped spring toward a target point. State evolves at runtime, outside React.',
    defaults: { targetX: 0, targetY: 1, targetZ: 0, stiffness: 20, damping: 6, maxOffset: 10 },
    fields: [
      { key: 'targetX', label: 'Target X', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'targetY', label: 'Target Y', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'targetZ', label: 'Target Z', kind: 'number', min: -50, max: 50, step: 0.05 },
      { key: 'stiffness', label: 'Stiffness', kind: 'number', min: 0.1, max: 100, step: 0.1 },
      { key: 'damping', label: 'Damping', kind: 'number', min: 0, max: 30, step: 0.1 },
      { key: 'maxOffset', label: 'Max offset', kind: 'number', min: 0.1, max: 50, step: 0.1, unit: 'm' },
    ],
  },
  {
    type: 'fbmDisplace', label: 'FBM Displace', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'medium',
    description: 'Multi-octave fractal displacement along XYZ with independent mask.',
    defaults: { strength: 0.25, scale: 2, speed: 0.2, octaves: 4, seed: 1, maskX: true, maskY: true, maskZ: true },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -5, max: 5, step: 0.01, animatable: true },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.01, max: 20, step: 0.01 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 10, step: 0.01 },
      { key: 'octaves', label: 'Octaves', kind: 'number', min: 1, max: 12, step: 1 },
      { key: 'seed', label: 'Seed', kind: 'number', min: -100, max: 100, step: 0.1 },
      { key: 'maskX', label: 'Mask X', kind: 'toggle' }, { key: 'maskY', label: 'Mask Y', kind: 'toggle' }, { key: 'maskZ', label: 'Mask Z', kind: 'toggle' },
    ],
  },
  {
    type: 'multiWave', label: 'Multi-Wave', category: 'Deform', targets: ['model','light'], runtime: 'shader', stage: 'geometry', cost: 'low',
    description: 'Three simultaneous wave fields on independent axes.',
    defaults: { strength: 0.15, frequency: 3, speed: 0.4 },
    fields: [
      { key: 'strength', label: 'Strength', kind: 'number', min: -5, max: 5, step: 0.01, animatable: true },
      { key: 'frequency', label: 'Frequency', kind: 'number', min: 0, max: 50, step: 0.05 },
      { key: 'speed', label: 'Speed', kind: 'number', min: -5, max: 5, step: 0.05 },
    ],
  },
  {
    type: 'curlNoiseMotion', label: 'Curl Noise Motion', category: 'Motion', targets: ['model','light','device'], runtime: 'motion', stage: 'geometry', cost: 'low',
    description: 'Organic runtime drift driven by layered noise, without React state changes.',
    defaults: { amplitude: 0.4, scale: 1.5, speed: 0.35, seed: 1 },
    fields: [
      { key: 'amplitude', label: 'Amplitude', kind: 'number', min: 0, max: 10, step: 0.01, unit: 'm' },
      { key: 'scale', label: 'Scale', kind: 'number', min: 0.01, max: 20, step: 0.01 },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 5, step: 0.01 },
      { key: 'seed', label: 'Seed', kind: 'number', min: -100, max: 100, step: 0.1 },
    ],
  },
  {
    type: 'noiseRotation', label: 'Noise Rotation', category: 'Motion', targets: ['model','light','device'], runtime: 'motion', stage: 'geometry', cost: 'low',
    description: 'Layered noise rotation on one or more axes.',
    defaults: { amount: 25, speed: 0.5, seed: 2, axis: 'y' },
    fields: [
      { key: 'amount', label: 'Angle', kind: 'number', min: -360, max: 360, step: 0.5, unit: '°' },
      { key: 'speed', label: 'Speed', kind: 'number', min: 0, max: 5, step: 0.01 },
      { key: 'seed', label: 'Seed', kind: 'number', min: -100, max: 100, step: 0.1 },
      AXIS,
    ],
  },
  {
    type: 'gridClone', label: 'Grid Clone', category: 'Structure', targets: ['model','light'], runtime: 'clone', stage: 'geometry', cost: 'medium',
    description: 'Instanced grid array using the shared runtime clone distribution path.',
    defaults: { count: 16, radius: 2, spacing: 1.5, height: 0, phase: 0, orbit: false, orbitSpeed: 0.2, scaleVariation: 0, rotationFollow: true, scaleProgression: 0, pulse: 0, pulseSpeed: 1, randomness: 0 },
    fields: [
      { key: 'count', label: 'Clone count', kind: 'number', min: 1, max: 200, step: 1 },
      { key: 'spacing', label: 'Spacing', kind: 'number', min: 0.01, max: 20, step: 0.01, unit: 'm' },
      { key: 'height', label: 'Height', kind: 'number', min: -20, max: 20, step: 0.05, unit: 'm' },
      { key: 'phase', label: 'Phase', kind: 'number', min: 0, max: 6.283, step: 0.01 },
      { key: 'scaleVariation', label: 'Scale variation', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'spiralClone', label: 'Spiral Clone', category: 'Structure', targets: ['model','light'], runtime: 'clone', stage: 'geometry', cost: 'medium',
    description: 'Spiral distribution using the shared runtime clone path.',
    defaults: { count: 24, radius: 2, spacing: 1.5, height: 0, phase: 0, orbit: false, orbitSpeed: 0.2, scaleVariation: 0, rotationFollow: true, scaleProgression: 0.2, pulse: 0, pulseSpeed: 1, randomness: 0 },
    fields: [
      { key: 'count', label: 'Clone count', kind: 'number', min: 1, max: 200, step: 1 },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'spacing', label: 'Spacing', kind: 'number', min: 0.01, max: 20, step: 0.01, unit: 'm' },
      { key: 'height', label: 'Height', kind: 'number', min: -20, max: 20, step: 0.05, unit: 'm' },
      { key: 'scaleProgression', label: 'Scale progression', kind: 'number', min: -1, max: 1, step: 0.01 },
    ],
  },
  {
    type: 'sphereClone', label: 'Sphere Distribution', category: 'Structure', targets: ['model','light'], runtime: 'clone', stage: 'geometry', cost: 'medium',
    description: 'Golden-angle sphere distribution using the shared runtime clone path.',
    defaults: { count: 32, radius: 2, spacing: 1.5, height: 0, phase: 0, orbit: false, orbitSpeed: 0.2, scaleVariation: 0, rotationFollow: true, scaleProgression: 0, pulse: 0, pulseSpeed: 1, randomness: 0 },
    fields: [
      { key: 'count', label: 'Clone count', kind: 'number', min: 1, max: 200, step: 1 },
      { key: 'radius', label: 'Radius', kind: 'number', min: 0.01, max: 50, step: 0.05, unit: 'm' },
      { key: 'scaleVariation', label: 'Scale variation', kind: 'number', min: 0, max: 1, step: 0.01 },
      { key: 'randomness', label: 'Randomness', kind: 'number', min: 0, max: 1, step: 0.01 },
    ],
  },
];

export function modifierDefinition(type: string): ModifierDefinition {
  return MODIFIER_DEFINITIONS.find((entry) => entry.type === type) || MODIFIER_DEFINITIONS[0];
}

export function createModifier(type: string): SceneModifier {
  const definition = modifierDefinition(type);
  const uuid = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return { id: `mod_${uuid}`, type: definition.type, enabled: true, params: { ...definition.defaults } };
}

export function modifiersForTarget(target: ModifierTarget): ModifierDefinition[] {
  return MODIFIER_DEFINITIONS.filter((definition) => definition.targets.includes(target));
}

export const EFFECT_GROUPS = ['DEFORM', 'MATERIAL', 'LIGHT', 'SCENE', 'CAMERA', 'TEMPORAL', 'POST', 'FIELD', 'CLONE', 'MOTION', 'EXPERIMENTAL'] as const;

export function effectGroup(definition: ModifierDefinition): (typeof EFFECT_GROUPS)[number] {
  if (definition.stage === 'geometry') return 'DEFORM';
  if (definition.stage === 'surface') return 'MATERIAL';
  if (definition.stage === 'light') return 'LIGHT';
  if (definition.stage === 'scene') return 'SCENE';
  if (definition.stage === 'camera') return 'CAMERA';
  if (definition.stage === 'temporal') return 'TEMPORAL';
  if (definition.stage === 'post') return 'POST';
  if (definition.stage === 'field') return 'FIELD';
  if (definition.stage === 'simulation') return 'EXPERIMENTAL';
  if (definition.runtime === 'clone') return 'CLONE';
  if (definition.runtime === 'motion') return 'MOTION';
  return 'EXPERIMENTAL';
}

export type ExecutionDomain = 'VALUE' | 'GEOMETRY' | 'SURFACE' | 'LIGHT' | 'SCENE' | 'POST' | 'SIMULATION' | 'FIELD';

export function executionDomain(definition: ModifierDefinition): ExecutionDomain {
  if (definition.stage === 'geometry') return 'GEOMETRY';
  if (definition.stage === 'surface') return 'SURFACE';
  if (definition.stage === 'light') return 'LIGHT';
  if (definition.stage === 'scene' || definition.stage === 'camera') return 'SCENE';
  if (definition.stage === 'post') return 'POST';
  if (definition.stage === 'simulation') return 'SIMULATION';
  if (definition.stage === 'field') return 'FIELD';
  return 'VALUE';
}

export interface ExecutionPlan {
  domains: Record<ExecutionDomain, string[]>;
  order: string[];
}

/** Stable domain buckets for runtime scheduling and graph diagnostics. */
export function compileExecutionPlan(modifiers: { id: string; type: string }[]): ExecutionPlan {
  const domains: Record<ExecutionDomain, string[]> = { VALUE: [], GEOMETRY: [], SURFACE: [], LIGHT: [], SCENE: [], POST: [], SIMULATION: [], FIELD: [] };
  for (const modifier of modifiers) domains[executionDomain(modifierDefinition(modifier.type))].push(modifier.id);
  return { domains, order: Object.values(domains).flat() };
}

export function executionOrderedModifiers<T extends { id: string; type: string }>(modifiers: T[]): T[] {
  const byId = new Map(modifiers.map((modifier) => [modifier.id, modifier]));
  return compileExecutionPlan(modifiers).order.map((id) => byId.get(id)!).filter(Boolean);
}
