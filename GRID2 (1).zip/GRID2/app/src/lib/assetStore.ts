/**
 * Browser-local storage for imported 3D assets.
 *
 * Project JSON keeps only a stable asset reference; binary GLB/GLTF payloads
 * live in IndexedDB so ordinary project documents stay small and readable.
 */
export interface StoredAsset {
  id: string;
  name: string;
  mime: string;
  data: ArrayBuffer;
  createdAt: number;
}

const DB_NAME = 'regrid-assets';
const DB_VERSION = 1;
const STORE = 'models';
let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') {
        reject(new Error('This browser does not support local 3D asset storage.'));
        return;
      }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open local asset storage.'));
    });
  }
  return dbPromise;
}

export function newAssetId(): string {
  const uuid = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `asset_${uuid}`;
}

export async function putAsset(asset: StoredAsset): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(asset);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('Could not save the 3D asset.'));
  });
}

export async function getAsset(id: string): Promise<StoredAsset | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).get(id);
    request.onsuccess = () => resolve((request.result as StoredAsset | undefined) || null);
    request.onerror = () => reject(request.error || new Error('Could not read the 3D asset.'));
  });
}

export async function deleteAsset(id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('Could not remove the 3D asset.'));
  });
}

export async function assetObjectUrl(id: string): Promise<string | null> {
  const asset = await getAsset(id);
  if (!asset) return null;
  return URL.createObjectURL(new Blob([asset.data], { type: asset.mime || 'model/gltf-binary' }));
}
