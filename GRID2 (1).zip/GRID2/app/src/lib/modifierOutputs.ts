import type { Project, SceneModifier, SceneObject } from '../types/project';

const noise = (x: number, y: number, z: number) => {
  const value = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453;
  return value - Math.floor(value);
};

/** Real CPU-visible outputs used by graph/modulation connections. */
export function modifierOutputValue(modifier: SceneModifier, output: string, project: Project, time: number, object?: SceneObject | null): number {
  const params = modifier.params;
  const ox = object ? object.position.x : 0;
  const oy = object ? object.elevation : 0;
  const oz = object ? object.position.z : 0;
  if (modifier.type === 'attractorField' || modifier.type === 'vortexField') {
    const cx = Number(params.pointX ?? params.centerX ?? 0);
    const cy = Number(params.pointY ?? params.centerY ?? 0);
    const cz = Number(params.pointZ ?? params.centerZ ?? 0);
    const dx = cx - ox; const dy = cy - oy; const dz = cz - oz;
    const distance = Math.hypot(dx, dy, dz);
    const radius = Math.max(0.0001, Number(params.radius ?? 1));
    const influence = Math.pow(Math.max(0, 1 - distance / radius), Math.max(0.05, Number(params.falloff ?? 1)));
    if (output === 'distance') return distance;
    if (output === 'normalizedDistance') return Math.min(1, distance / radius);
    if (output === 'force' || output === 'strength') return Number(params.strength ?? 0) * influence;
    if (output === 'directionX') return distance ? dx / distance : 0;
    if (output === 'directionY') return distance ? dy / distance : 0;
    if (output === 'directionZ') return distance ? dz / distance : 0;
  }
  if (modifier.type === 'ripple') {
    const cx = Number(params.centerX ?? 0); const cz = Number(params.centerZ ?? 0);
    const distance = Math.hypot(ox - cx, oz - cz);
    const wave = Math.sin(distance * Number(params.frequency ?? 4) - time * Number(params.speed ?? 0) * Math.PI * 2);
    const falloff = 1 - Math.min(1, distance / Math.max(0.0001, Number(params.radius ?? 1)));
    return wave * falloff * Number(params.strength ?? 0);
  }
  if (modifier.type === 'noiseDisplace' && output === 'scalar') {
    const s = Number(params.scale ?? 1);
    return noise(ox * s + Number(params.seed ?? 0), oz * s, time * Number(params.speed ?? 0)) * 2 - 1;
  }
  return 0;
}
