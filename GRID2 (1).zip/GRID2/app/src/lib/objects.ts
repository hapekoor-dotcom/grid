import type { CableType, CatalogDevice, PortDef } from '../types/catalog';
import type { GenericLightType, LightState, Point, Project, SceneObject, SceneObjectType } from '../types/project';
import { getDevice, getMode, portsOf } from './catalog';
import { uid } from './id';

export interface ObjectDims {
  w: number;
  d: number;
  h: number;
}

export const GRID_CELL = 0.25;

function cellCeil(value: number): number {
  return Math.max(GRID_CELL, Math.ceil(value / GRID_CELL - 1e-9) * GRID_CELL);
}

export function objectDims(object: SceneObject): ObjectDims {
  const raw = object.size
    ? object.size
    : (() => {
        const device = getDevice(object.deviceId);
        if (!device) return { w: 0.5, d: 0.4, h: 0.4 };
        return { w: device.planSize.w, d: device.planSize.d, h: device.dims.h };
      })();
  return { w: cellCeil(raw.w), d: cellCeil(raw.d), h: raw.h };
}

export function footprint(object: SceneObject): { w: number; d: number } {
  const dims = objectDims(object);
  return object.rotation % 180 === 0 ? { w: dims.w, d: dims.d } : { w: dims.d, d: dims.w };
}

export function snapObjectToGrid(object: SceneObject, step = GRID_CELL): void {
  const rect = objectRect(object);
  object.position.x = Math.round((Math.round(rect.x / step) * step + rect.w / 2) * 1000) / 1000;
  object.position.z = Math.round((Math.round(rect.z / step) * step + rect.d / 2) * 1000) / 1000;
}

export function objectRect(object: SceneObject): { x: number; z: number; w: number; d: number } {
  const { w, d } = footprint(object);
  return { x: object.position.x - w / 2, z: object.position.z - d / 2, w, d };
}

export function rectsOverlap(a: { x: number; z: number; w: number; d: number }, b: { x: number; z: number; w: number; d: number }): boolean {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.z < b.z + b.d && a.z + a.d > b.z;
}

export function containsPoint(object: SceneObject, point: Point): boolean {
  const local = worldToLocal(object, point);
  const dims = objectDims(object);
  return Math.abs(local.x) <= dims.w / 2 && Math.abs(local.z) <= dims.d / 2;
}

export function worldToLocal(object: SceneObject, point: Point): Point {
  const dx = point.x - object.position.x;
  const dz = point.z - object.position.z;
  const angle = (-object.rotation * Math.PI) / 180;
  return {
    x: dx * Math.cos(angle) - dz * Math.sin(angle),
    z: dx * Math.sin(angle) + dz * Math.cos(angle),
  };
}

export function localToWorld(object: SceneObject, point: Point): Point {
  const angle = (object.rotation * Math.PI) / 180;
  return {
    x: object.position.x + point.x * Math.cos(angle) - point.z * Math.sin(angle),
    z: object.position.z + point.x * Math.sin(angle) + point.z * Math.cos(angle),
  };
}

export function isStructure(object: SceneObject): boolean {
  return object.type === 'room' || object.type === 'stage' || object.type === 'truss' || object.type === 'furniture' || object.type === 'seating' || object.type === 'crowd' || object.type === 'areabar';
}

export function isFixture(object: SceneObject): boolean {
  return object.light !== null;
}

export function isDmxCapable(device: CatalogDevice | null): boolean {
  if (!device) return false;
  return device.dmx && (device.modes.length > 0 || device.generic || device.requiresProfile);
}

export function isDmxSource(device: CatalogDevice | null): boolean {
  if (!device) return false;
  if (device.sourceType) return false;
  if (!['node', 'console', 'interface', 'controller', 'player'].includes(device.kind)) return false;
  return device.signalPorts.some((port) => port.type === 'dmx' && port.direction !== 'in');
}

export function isPowerSource(object: SceneObject): boolean {
  const device = getDevice(object.deviceId);
  return !!device?.sourceType;
}

export function isVirtualPort(portId: string): boolean {
  return /^power\d+$/.test(portId);
}

/** All physical ports of an object, including user-adjusted power outputs. */
export function getObjectPorts(object: SceneObject): PortDef[] {
  const device = getDevice(object.deviceId);
  if (!device) return [];
  let ports = portsOf(device);

  if (object.outputs && object.outputs > 0 && ['distro', 'outlet', 'battery', 'generator'].includes(device.kind)) {
    const count = Math.min(16, Math.max(1, object.outputs));
    const others = ports.filter((port) => !(port.type === 'power' && /^power\d+$/.test(port.id)));
    const generated: PortDef[] = Array.from({ length: count }, (_, index) => ({
      id: `power${index + 1}`,
      type: 'power',
      direction: 'out',
      connector: device.powerConnector || 'AC',
      label: device.kind === 'battery' ? 'DC' : String(index + 1),
      domain: device.kind === 'battery' ? 'dc' : 'ac',
      derived: true,
    }));
    ports = [...others.filter((port) => !(port.type === 'power' && port.id === 'powerIn')), ...generated];
    if (device.kind === 'distro' && !ports.some((port) => port.type === 'power' && port.direction === 'in')) {
      ports.unshift({ id: 'powerIn', type: 'power', direction: 'in', connector: device.powerConnector || 'AC', label: '', domain: 'ac', derived: true });
    }
  }

  return ports.map((port) => {
    const override = object.portDirections[port.id];
    return override ? { ...port, direction: override } : port;
  });
}

export function getPort(object: SceneObject, portId: string): PortDef | null {
  return getObjectPorts(object).find((port) => port.id === portId) || null;
}

export function portUniverse(object: SceneObject, port: PortDef): number | null {
  if (port.type !== 'dmx') return null;
  const configured = object.dmxSourceUniverses[port.id];
  if (configured) return configured;
  if (port.universeIndex !== undefined) return port.universeIndex + 1;
  const match = port.id.match(/(\d+)/);
  return match ? Number(match[1]) : 1;
}

export function circuitLabel(object: SceneObject, port: PortDef): string {
  if (port.type !== 'power') return port.label || port.id;
  if (isPowerSource(object)) {
    const phase = object.portPhases[port.id] || (object.portPhasesThreePhase ? 'L1' : 'L1');
    return `${phase} · ${port.label || port.id}`;
  }
  return port.direction === 'in' ? 'IN' : 'OUT';
}

export interface PlacedPort extends PortDef {
  x: number;
  z: number;
  nx: number;
  nz: number;
  universe: number | null;
}

/**
 * Deterministic port placement around the object's footprint.
 * Power ports sit on the bottom edge, DMX inputs left, outputs right,
 * network/video ports on top. Rotation is applied around the centre.
 */
export function placePorts(object: SceneObject): PlacedPort[] {
  const device = getDevice(object.deviceId);
  if (!device) return [];
  const ports = getObjectPorts(object);
  const dims = objectDims(object);
  const w = dims.w;
  const d = dims.d;
  const sides: Record<'top' | 'bottom' | 'left' | 'right', PortDef[]> = { top: [], bottom: [], left: [], right: [] };
  const multiSignal = ['node', 'splitter', 'switch', 'interface', 'console', 'controller'].includes(device.kind);
  const barOrPar = device.kind === 'bar' || device.kind === 'par';

  for (const port of ports) {
    if (port.type === 'power') {
      if (barOrPar) {
        // Bars and PARs are chained left-to-right: power in/out on the sides.
        if (port.direction === 'in') sides.left.push(port);
        else sides.right.push(port);
      } else if (multiSignal) {
        if (port.direction === 'in') sides.left.push(port);
        else sides.right.push(port);
      } else {
        sides.bottom.push(port);
      }
    } else if (port.type === 'dmx') {
      if (barOrPar) {
        // DMX in on the left, DMX out on the right, alongside power.
        if (port.direction === 'in') sides.left.push(port);
        else sides.right.push(port);
      } else if (multiSignal) {
        if (port.direction === 'in') sides.left.push(port);
        else sides.bottom.push(port);
      } else if (port.direction === 'out') sides.right.push(port);
      else sides.left.push(port);
    } else if (port.type === 'ethernet') {
      sides.top.push(port);
    } else if (port.type === 'usb') {
      sides.left.push(port);
    } else if (port.type === 'video') {
      sides.top.push(port);
    } else {
      sides.top.push(port);
    }
  }

  const placed: PlacedPort[] = [];
  const spread = (count: number, index: number, start = 0.2, end = 0.8) => {
    if (count <= 1) return 0.5;
    return start + ((end - start) * index) / (count - 1);
  };

  const make = (port: PortDef, side: keyof typeof sides, ratio: number) => {
    let localX = 0;
    let localZ = 0;
    let nx = 0;
    let nz = 0;
    const edge = 0;
    if (side === 'bottom') {
      localX = -w / 2 + w * ratio;
      localZ = d / 2 + edge;
      nz = 1;
    } else if (side === 'top') {
      localX = -w / 2 + w * ratio;
      localZ = -d / 2 - edge;
      nz = -1;
    } else if (side === 'left') {
      localX = -w / 2 - edge;
      localZ = -d / 2 + d * ratio;
      nx = -1;
    } else {
      localX = w / 2 + edge;
      localZ = -d / 2 + d * ratio;
      nx = 1;
    }
    const angle = (object.rotation * Math.PI) / 180;
    placed.push({
      ...port,
      x: object.position.x + localX * Math.cos(angle) - localZ * Math.sin(angle),
      z: object.position.z + localX * Math.sin(angle) + localZ * Math.cos(angle),
      nx: nx * Math.cos(angle) - nz * Math.sin(angle),
      nz: nx * Math.sin(angle) + nz * Math.cos(angle),
      universe: portUniverse(object, port),
    });
  };

  // Order power inputs before outputs for a readable chain.
  sides.bottom.sort((a, b) => (a.direction === 'in' ? 0 : 1) - (b.direction === 'in' ? 0 : 1));
  for (const [side, list] of Object.entries(sides) as [keyof typeof sides, PortDef[]][]) {
    list.forEach((port, index) => {
      const ratio = side === 'top' || side === 'bottom' ? spread(list.length, index) : spread(list.length, index, 0.22, 0.78);
      make(port, side, ratio);
    });
  }
  return placed;
}

export function getFixtureChannels(project: Project, object: SceneObject): number | null {
  const device = getDevice(object.deviceId);
  if (!device || !object.fixture) return null;
  const mode = getMode(device, object.fixture.modeId);
  return mode?.channels ?? null;
}

export function effectiveWatts(object: SceneObject): number | null {
  if (object.fixture?.wattsOverride !== null && object.fixture?.wattsOverride !== undefined) return object.fixture.wattsOverride;
  const device = getDevice(object.deviceId);
  return Number.isFinite(device?.watts) ? Number(device?.watts) : null;
}

export function defaultLight(device: CatalogDevice): LightState | null {
  if (!['light', 'effects'].includes(device.category)) return null;
  const caps = device.capabilities;
  if (!caps.dimmer && !caps.color && !caps.pan) return null;
  return {
    on: true,
    intensity: 0.82,
    color: '#ffffff',
    colorTemp: 5600,
    pan: 0,
    tilt: 0,
    zoom: Math.round(((device.beamAngle.min + device.beamAngle.max) / 2) * 10) / 10,
    strobe: 0,
    focus: 0.5,
  };
}

function objectTypeFor(device: CatalogDevice): SceneObjectType {
  if (device.category === 'rigging') return 'truss';
  if (device.category === 'stage') return device.kind === 'table' || device.kind === 'chair' || device.kind === 'barricade' ? 'furniture' : 'stage';
  return 'device';
}

export function createSceneObject(deviceId: string, position: Point, overrides: Partial<SceneObject> = {}): SceneObject {
  const device = getDevice(deviceId);
  if (!device) throw new Error(`unknown device: ${deviceId}`);
  const type = objectTypeFor(device);
  const structured = type !== 'device';
  const fixture = isDmxCapable(device) && ['light', 'effects'].includes(device.category)
    ? {
        modeId: device.defaultModeId,
        universe: 1,
        address: null,
        manualAddress: false,
        customChannels: null,
        wattsOverride: null,
        powerOn: true,
      }
    : null;
  const universes: Record<string, number> = {};
  let index = 0;
  for (const port of device.signalPorts) {
    if (port.type === 'dmx' && port.direction !== 'in') {
      universes[port.id] = port.universeIndex !== undefined ? port.universeIndex + 1 : index + 1;
      index += 1;
    }
  }
  const powerOuts = device.powerPorts.filter((port) => port.type === 'power' && port.direction !== 'in').length;
  const object: SceneObject = {
    id: uid('obj'),
    type,
    name: device.shortName,
    deviceId,
    position: { x: Math.round(position.x * 1000) / 1000, z: Math.round(position.z * 1000) / 1000 },
    rotation: 0,
    elevation: 0,
    size: structured ? { w: device.dims.w, d: device.dims.d, h: device.dims.h } : null,
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: type === 'stage' ? { color: device.kind === 'stage' ? '#22262b' : '#1d2227', label: '' } : null,
    fixture,
    light: defaultLight(device),
    dmxSourceUniverses: universes,
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: powerOuts || null,
    notes: '',
    ...overrides,
  };
  snapObjectToGrid(object);
  return object;
}


export function createSeating(position: Point, size: { w: number; d: number }, name = 'Seating'): SceneObject {
  const seatPitch = 0.62;
  const rowPitch = 0.95;
  const columns = Math.max(1, Math.floor(Math.max(1, size.w) / seatPitch));
  const rows = Math.max(1, Math.floor(Math.max(1, size.d) / rowPitch));
  return {
    id: uid('seating'),
    type: 'seating',
    name,
    deviceId: null,
    position: { x: Math.round(position.x * 1000) / 1000, z: Math.round(position.z * 1000) / 1000 },
    rotation: 0,
    elevation: 0,
    size: { w: size.w, d: size.d, h: 0.95 },
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    seating: { rows, columns, seatPitch, rowPitch },
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function createCrowd(position: Point, size: { w: number; d: number }, name = 'Crowd'): SceneObject {
  return {
    id: uid('crowd'),
    type: 'crowd',
    name,
    deviceId: null,
    position: { x: Math.round(position.x * 1000) / 1000, z: Math.round(position.z * 1000) / 1000 },
    rotation: 0,
    elevation: 0,
    size: { w: Math.max(1, size.w), d: Math.max(1, size.d), h: 1.6 },
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    seating: null,
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: 'Dense crowd. People are generated procedurally.',
  };
}

export function createAreaBar(position: Point, name = 'Area Bar'): SceneObject {
  return {
    id: uid('areabar'),
    type: 'areabar',
    name,
    deviceId: null,
    position: { x: Math.round(position.x * 1000) / 1000, z: Math.round(position.z * 1000) / 1000 },
    rotation: 0,
    elevation: 2.6,
    size: { w: 1.8, d: 0.1, h: 0.1 },
    mount: 'truss',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    seating: null,
    fixture: null,
    light: { on: true, intensity: 1, color: '#ffffff', colorTemp: 5600, pan: 0, tilt: 0, zoom: 40, strobe: 0, focus: 0.5, segments: null },
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: 'Reference LED bar: black housing, white tube, rectangular area light.',
  };
}

export function createRoom(position: Point, size: { w: number; d: number }, wallHeight = 4.5, name = 'Venue'): SceneObject {
  return {
    id: uid('room'),
    type: 'room',
    name,
    deviceId: null,
    position,
    rotation: 0,
    elevation: 0,
    size: { w: size.w, d: size.d, h: wallHeight },
    mount: 'floor',
    visible: true,
    locked: true,
    groupId: null,
    room: { wallHeight, walls: true, floorColor: '#6f6b63', wallColor: '#74736d' },
    stage: null,
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function createStage(position: Point, size: { w: number; d: number; h: number }, name = 'Stage'): SceneObject {
  return {
    id: uid('stage'),
    type: 'stage',
    name,
    deviceId: null,
    position,
    rotation: 0,
    elevation: size.h,
    size,
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: { color: '#242a30', label: name },
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function createTruss(position: Point, length: number, name = 'Truss'): SceneObject {
  return {
    id: uid('truss'),
    type: 'truss',
    name,
    deviceId: null,
    position,
    rotation: 0,
    elevation: 4.5,
    size: { w: length, d: 0.29, h: 0.29 },
    mount: 'ceiling',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function objectLabel(object: SceneObject): string {
  return object.name || getDevice(object.deviceId)?.shortName || object.type;
}

export function isDeviceObject(object: SceneObject): boolean {
  return object.type === 'device';
}

export function cableTypeForPorts(from: PortDef, to: PortDef): CableType | null {
  if (from.type !== to.type) return null;
  if (from.type === 'wireless' || to.type === 'wireless') return from.type === to.type ? 'wireless' : null;
  return from.type;
}

export function canConnect(from: { object: SceneObject; port: PortDef }, to: { object: SceneObject; port: PortDef }): boolean {
  if (from.object.id === to.object.id) return false;
  if (from.port.type !== to.port.type) return false;
  if (from.port.direction === 'out' && to.port.direction === 'in') return true;
  if (from.port.direction === 'bi' && to.port.direction !== 'out') return true;
  if (from.port.direction === 'in' && to.port.direction === 'out') return false;
  // Allow reversed selection when the user started from an input.
  if (to.port.direction === 'out' && from.port.direction === 'in') return false;
  return from.port.direction !== 'in' && to.port.direction !== 'out';
}


export function createModel(assetId: string, assetName: string, position: Point = { x: 0, z: 0 }, size: { w: number; d: number; h: number } = { w: 2, d: 2, h: 2 }): SceneObject {
  return {
    id: uid('model'),
    type: 'model',
    name: assetName.replace(/\.[^.]+$/, '').slice(0, 100) || 'Model',
    deviceId: null,
    position: { ...position },
    rotation: 0,
    rotationX: 0,
    rotationZ: 0,
    elevation: 0,
    scale: { x: 1, y: 1, z: 1 },
    size,
    modelVisible: true,
    assetId,
    assetName,
    material: null,
    modifiers: [],
    castShadows: true,
    receiveShadows: true,
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    seating: null,
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function createLightSource(kind: GenericLightType, position: Point = { x: 0, z: 0 }, name?: string): SceneObject {
  const labels: Record<GenericLightType, string> = { spot: 'Spot Light', point: 'Point Light', area: 'Area Light', directional: 'Directional Light' };
  return {
    id: uid('light'),
    type: 'light',
    name: name || labels[kind],
    deviceId: null,
    position: { ...position },
    rotation: 0,
    rotationX: 0,
    rotationZ: 0,
    elevation: kind === 'area' ? 2.8 : kind === 'directional' ? 2.2 : 3.2,
    scale: { x: 1, y: 1, z: 1 },
    size: kind === 'area' ? { w: 1.8, d: 0.12, h: 0.12 } : kind === 'directional' ? { w: 0.6, d: 0.6, h: 0.6 } : { w: 0.28, d: 0.28, h: 0.42 },
    modelVisible: true,
    lightType: kind,
    range: kind === 'point' ? 10 : kind === 'directional' ? 100 : 16,
    beamInner: kind === 'spot' ? 25 : 40,
    beamOuter: kind === 'spot' ? 45 : 70,
    castShadows: false,
    volumetric: 0.25,
    material: null,
    modifiers: [],
    mount: kind === 'area' ? 'truss' : kind === 'directional' ? 'ceiling' : 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    seating: null,
    fixture: null,
    light: {
      on: true,
      intensity: 1,
      color: '#ffffff',
      colorTemp: 5600,
      pan: 0,
      tilt: 0,
      zoom: 35,
      strobe: 0,
      focus: 0.5,
      segments: null,
    },
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: '',
  };
}

export function defaultRotationX(object: SceneObject): number { return Number.isFinite(object.rotationX) ? object.rotationX! : 0; }
export function defaultRotationZ(object: SceneObject): number { return Number.isFinite(object.rotationZ) ? object.rotationZ! : 0; }
export function defaultScale(object: SceneObject): { x: number; y: number; z: number } {
  const scale = object.scale;
  return scale && [scale.x, scale.y, scale.z].every((value) => Number.isFinite(value) && value > 0)
    ? scale
    : { x: 1, y: 1, z: 1 };
}
export function isModelVisible(object: SceneObject): boolean { return object.modelVisible !== false; }

export function createWall(center: Point, length: number, rotation: 0 | 90, name = 'Wall'): SceneObject {
  const safeLength = Math.max(0.4, length);
  return {
    id: uid('wall'),
    type: 'furniture',
    name,
    deviceId: null,
    position: { x: Math.round(center.x * 1000) / 1000, z: Math.round(center.z * 1000) / 1000 },
    rotation,
    elevation: 0,
    size: { w: safeLength, d: 0.14, h: 2.7 },
    mount: 'floor',
    visible: true,
    locked: false,
    groupId: null,
    room: null,
    stage: null,
    fixture: null,
    light: null,
    dmxSourceUniverses: {},
    portDirections: {},
    portPhases: {},
    portPhasesThreePhase: false,
    powerLimits: {},
    outputLimits: {},
    circuitId: '',
    totalPowerLimit: null,
    outputs: null,
    notes: 'Layout wall. Structure and mounting are not calculated.',
  };
}
