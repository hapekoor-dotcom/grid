import type { MaterialMapKind, ObjectMaterial } from '../types/project';
import { newAssetId, putAsset } from './assetStore';

interface GltfTextureRef { index?: number }
interface GltfMaterial {
  name?: string;
  pbrMetallicRoughness?: {
    baseColorFactor?: number[];
    metallicFactor?: number;
    roughnessFactor?: number;
    baseColorTexture?: GltfTextureRef;
    metallicRoughnessTexture?: GltfTextureRef;
  };
  normalTexture?: GltfTextureRef;
  occlusionTexture?: GltfTextureRef;
  emissiveTexture?: GltfTextureRef;
  emissiveFactor?: number[];
  alphaMode?: string;
  doubleSided?: boolean;
  extensions?: Record<string, unknown>;
}

function componentColor(value: number[] | undefined, fallback: string): string {
  if (!value || value.length < 3) return fallback;
  const channel = (input: number) => Math.max(0, Math.min(255, Math.round(input * 255))).toString(16).padStart(2, '0');
  return `#${channel(value[0])}${channel(value[1])}${channel(value[2])}`;
}

export function parseGlbJson(buffer: ArrayBuffer): { json: any; bin: Uint8Array | null } {
  const view = new DataView(buffer);
  if (view.getUint32(0, true) !== 0x46546c67) throw new Error('Not a GLB file');
  let offset = 12;
  let json: any = null;
  let bin: Uint8Array | null = null;
  while (offset < buffer.byteLength) {
    const length = view.getUint32(offset, true);
    const type = view.getUint32(offset + 4, true);
    const start = offset + 8;
    if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, start, length)));
    else if (type === 0x004e4942) bin = new Uint8Array(buffer, start, length);
    offset = start + length;
  }
  if (!json) throw new Error('GLB has no JSON chunk');
  return { json, bin };
}

function imageBytes(json: any, bin: Uint8Array | null, imageIndex: number): { data: Uint8Array; mime: string; name: string } | null {
  const image = json.images?.[imageIndex];
  if (!image) return null;
  if (image.bufferView === undefined || !bin) return null;
  const bufferView = json.bufferViews?.[image.bufferView];
  if (!bufferView) return null;
  const start = Number(bufferView.byteOffset || 0);
  return { data: bin.slice(start, start + Number(bufferView.byteLength || 0)), mime: image.mimeType || 'image/png', name: image.name || `texture-${imageIndex}` };
}

export interface GlbLookOption { index: number; name: string; material: ObjectMaterial }

export async function extractGlbLookOptions(file: File): Promise<GlbLookOption[]> {
  const { json, bin } = parseGlbJson(await file.arrayBuffer());
  const materials: GltfMaterial[] = Array.isArray(json.materials) && json.materials.length ? json.materials : [{}];
  const textureCache = new Map<number, string>();
  const options: GlbLookOption[] = [];
  for (let materialIndex = 0; materialIndex < materials.length; materialIndex += 1) {
    const source = materials[materialIndex];
  const pbr = source.pbrMetallicRoughness || {};
  const material: ObjectMaterial = {
    color: componentColor(pbr.baseColorFactor, '#ffffff'),
    metalness: Math.max(0, Math.min(1, Number(pbr.metallicFactor ?? 1))),
    roughness: Math.max(0, Math.min(1, Number(pbr.roughnessFactor ?? 1))),
    emissive: componentColor(source.emissiveFactor, '#000000'),
    emissiveIntensity: Number((source.extensions?.KHR_materials_emissive_strength as { emissiveStrength?: number } | undefined)?.emissiveStrength ?? 1),
    opacity: source.alphaMode === 'BLEND' ? 0.85 : 1,
    doubleSided: source.doubleSided === true,
    maps: {},
  };
  const textureMap = (ref: GltfTextureRef | undefined, kind: MaterialMapKind): number | null => {
    if (!ref || ref.index === undefined) return null;
    const texture = json.textures?.[ref.index];
    return texture?.source ?? null;
  };
  const assign = async (imageIndex: number | null, kind: MaterialMapKind) => {
    if (imageIndex === null) return;
    let assetId = textureCache.get(imageIndex);
    if (!assetId) {
      const image = imageBytes(json, bin, imageIndex);
      if (!image) return;
      assetId = newAssetId();
      await putAsset({ id: assetId, name: image.name, mime: image.mime, data: image.data.slice().buffer as ArrayBuffer, createdAt: Date.now() });
      textureCache.set(imageIndex, assetId);
    }
    material.maps![kind] = { assetId, assetName: imageBytes(json, bin, imageIndex)?.name || `texture-${imageIndex}` };
  };
  const base = textureMap(pbr.baseColorTexture, 'baseColor');
  const metalRough = textureMap(pbr.metallicRoughnessTexture, 'metalness');
  const normal = textureMap(source.normalTexture, 'normal');
  const ao = textureMap(source.occlusionTexture, 'ao');
  const emissive = textureMap(source.emissiveTexture, 'emissive');
  await assign(base, 'baseColor');
  await assign(metalRough, 'metalness');
  await assign(metalRough, 'roughness');
  await assign(normal, 'normal');
  await assign(ao, 'ao');
    await assign(emissive, 'emissive');
    options.push({ index: materialIndex, name: source.name || `${file.name.replace(/\.(glb|gltf)$/i, '')} · material ${materialIndex + 1}`, material });
  }
  return options;
}

export async function extractGlbLook(file: File): Promise<{ name: string; material: ObjectMaterial }> {
  const options = await extractGlbLookOptions(file);
  return options[0] || { name: file.name, material: {} };
}
