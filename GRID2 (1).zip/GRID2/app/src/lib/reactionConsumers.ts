import type { Project, SceneModifier } from '../types/project';
import { modifierDefinition } from './modifiers';
import { objectLabel } from './objects';

export interface ReactionConsumer {
  id: string;
  ownerKind: 'object' | 'look' | 'post';
  ownerName: string;
  module: string;
  parameter: string;
  connectionId: string;
  usageCount: number;
}

function fieldLabel(modifier: SceneModifier, key: string): string {
  return modifierDefinition(modifier.type).fields.find((field) => field.key === key)?.label || key;
}

/** Every enabled runtime consumer of the one shared RD simulation. */
export function reactionConsumers(project: Project | null | undefined): ReactionConsumer[] {
  if (!project) return [];
  const consumers: ReactionConsumer[] = [];
  const seen = new Set<string>();
  const add = (consumer: Omit<ReactionConsumer, 'usageCount'> & { usageCount?: number }) => {
    const item: ReactionConsumer = { ...consumer, usageCount: Math.max(1, consumer.usageCount || 1) };
    if (seen.has(item.id)) return;
    seen.add(item.id);
    consumers.push(item);
  };
  const modifierOwner = new Map<string, { name: string; kind: 'object' | 'look'; objectId?: string }>();
  for (const object of project.objects) for (const modifier of object.modifiers || []) modifierOwner.set(modifier.id, { name: objectLabel(object), kind: 'object', objectId: object.id });
  for (const look of project.looks || []) for (const modifier of look.modifiers || []) modifierOwner.set(modifier.id, { name: look.name, kind: 'look' });

  const fieldLinkByModifier = new Map((project.fieldLinks || []).map((link) => [link.modifierId, link]));
  const inspect = (modifiers: SceneModifier[], ownerName: string, ownerKind: 'object' | 'look', ownerKey: string, usageCount = 1) => {
    for (const modifier of modifiers) {
      if (!modifier.enabled) continue;
      if (modifier.type === 'reactionSurface' || modifier.type === 'reactionDisplace') {
        const link = fieldLinkByModifier.get(modifier.id);
        const active = modifier.type === 'reactionSurface'
          ? [
              Number(modifier.params.emission ?? 0) > 0.0001 ? 'emission' : '',
              Number(modifier.params.opacity ?? 0) > 0.0001 ? 'opacity' : '',
              Number(modifier.params.baseColor ?? 0) > 0.0001 ? 'base color' : '',
              Number(modifier.params.roughness ?? 0) > 0.0001 ? 'roughness' : '',
              Number(modifier.params.metallic ?? 0) > 0.0001 ? 'metallic' : '',
            ].filter(Boolean).join(', ') || 'field'
          : 'field displacement';
        add({ id: link ? `field:${link.id}` : `implicit:${modifier.id}`, ownerKind, ownerName, usageCount, module: modifierDefinition(modifier.type).label, parameter: link ? `field · ${link.output}` : active, connectionId: link ? link.id : `implicit:${modifier.id}` });
      }
      for (const [key, modulator] of Object.entries(modifier.modulators || {})) {
        if (modulator.sourceType !== 'reaction' || !modulator.enabled) continue;
        add({ id: `mod:${ownerKey}:${modifier.id}:${key}`, ownerKind, ownerName, usageCount, module: modifierDefinition(modifier.type).label, parameter: fieldLabel(modifier, key), connectionId: `mod:${modifier.id}:${key}` });
      }
    }
  };
  for (const object of project.objects) {
    inspect(object.modifiers || [], objectLabel(object), 'object', object.id);
    // Look-owned modifiers are shared, so they are inspected once below.
  }
  for (const look of project.looks || []) inspect(look.modifiers || [], look.name, 'look', look.id, project.objects.filter((object) => object.lookId === look.id).length);

  for (const link of project.fieldLinks || []) {
    const owner = modifierOwner.get(link.modifierId);
    const modifier = [...project.objects.flatMap((object) => object.modifiers || []), ...(project.looks || []).flatMap((look) => look.modifiers || [])].find((entry) => entry.id === link.modifierId);
    if (!modifier || !modifier.enabled || !owner) continue;
    const linkLook = owner.kind === 'look' ? (project.looks || []).find((look) => (look.modifiers || []).some((entry) => entry.id === link.modifierId)) : undefined;
    add({ id: `field:${link.id}`, ownerKind: owner.kind, ownerName: owner.name, usageCount: linkLook ? project.objects.filter((object) => object.lookId === linkLook.id).length : 1, module: modifierDefinition(modifier.type).label, parameter: `field · ${link.output}`, connectionId: link.id });
  }

  for (const pass of project.postShaders || []) {
    if (!pass.enabled) continue;
    const shader = project.customShaders?.find((entry) => entry.id === pass.shaderId);
    const source = shader?.lastWorking?.fragment || shader?.fragment || '';
    if (!/uReaction/.test(source)) continue;
    add({ id: `post:${pass.id || pass.shaderId}`, ownerKind: 'post', ownerName: shader?.name || 'Post', usageCount: 1, module: 'Post / Fullscreen', parameter: 'uReaction', connectionId: pass.id || pass.shaderId });
  }
  return consumers;
}
