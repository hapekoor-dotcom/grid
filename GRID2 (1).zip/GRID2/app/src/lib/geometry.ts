import type { Point } from '../types/project';

export function distance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.z - b.z);
}

export function snapValue(value: number, step: number): number {
  return Math.round(value / step) * step;
}

export function snapPoint(point: Point, step: number): Point {
  return { x: snapValue(point.x, step), z: snapValue(point.z, step) };
}

export function rectContains(rect: { x: number; z: number; w: number; d: number }, point: Point, pad = 0): boolean {
  return point.x >= rect.x - pad && point.x <= rect.x + rect.w + pad && point.z >= rect.z - pad && point.z <= rect.z + rect.d + pad;
}

export function segmentIntersectsRect(a: Point, b: Point, rect: { x: number; z: number; w: number; d: number }, pad = 0): boolean {
  const minX = rect.x - pad;
  const maxX = rect.x + rect.w + pad;
  const minZ = rect.z - pad;
  const maxZ = rect.z + rect.d + pad;
  // Orthogonal routing: only axis-aligned segments are checked precisely.
  if (Math.abs(a.z - b.z) < 1e-6) {
    if (a.z < minZ || a.z > maxZ) return false;
    return Math.max(a.x, b.x) >= minX && Math.min(a.x, b.x) <= maxX;
  }
  if (Math.abs(a.x - b.x) < 1e-6) {
    if (a.x < minX || a.x > maxX) return false;
    return Math.max(a.z, b.z) >= minZ && Math.min(a.z, b.z) <= maxZ;
  }
  return false;
}

export function simplifyOrthogonal(points: Point[]): Point[] {
  const cleaned: Point[] = [];
  for (const point of points) {
    const last = cleaned[cleaned.length - 1];
    if (last && Math.abs(last.x - point.x) < 1e-6 && Math.abs(last.z - point.z) < 1e-6) continue;
    cleaned.push(point);
  }
  if (cleaned.length < 3) return cleaned;
  const result: Point[] = [cleaned[0]];
  for (let i = 1; i < cleaned.length - 1; i++) {
    const prev = result[result.length - 1];
    const current = cleaned[i];
    const next = cleaned[i + 1];
    const collinearX = Math.abs(prev.x - current.x) < 1e-6 && Math.abs(current.x - next.x) < 1e-6;
    const collinearZ = Math.abs(prev.z - current.z) < 1e-6 && Math.abs(current.z - next.z) < 1e-6;
    if (!collinearX && !collinearZ) result.push(current);
  }
  result.push(cleaned[cleaned.length - 1]);
  return result;
}

export function roundedPath(points: Point[], radius = 0.09): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M${points[0].x},${points[0].z}`;
  let d = `M${points[0].x},${points[0].z}`;
  for (let i = 1; i < points.length - 1; i++) {
    const a = points[i - 1];
    const b = points[i];
    const c = points[i + 1];
    const l1 = distance(a, b);
    const l2 = distance(b, c);
    if (l1 < 1e-6 || l2 < 1e-6) continue;
    const q = Math.min(radius, l1 / 2, l2 / 2);
    const p1 = { x: b.x + ((a.x - b.x) * q) / l1, z: b.z + ((a.z - b.z) * q) / l1 };
    const p2 = { x: b.x + ((c.x - b.x) * q) / l2, z: b.z + ((c.z - b.z) * q) / l2 };
    d += ` L${p1.x.toFixed(3)},${p1.z.toFixed(3)} Q${b.x.toFixed(3)},${b.z.toFixed(3)} ${p2.x.toFixed(3)},${p2.z.toFixed(3)}`;
  }
  const last = points[points.length - 1];
  d += ` L${last.x},${last.z}`;
  return d;
}

export function polylineLength(points: Point[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i++) total += distance(points[i - 1], points[i]);
  return total;
}

export function pointAtFraction(points: Point[], fraction: number): Point {
  const total = polylineLength(points);
  if (!total) return points[0] || { x: 0, z: 0 };
  let target = total * fraction;
  for (let i = 1; i < points.length; i++) {
    const segment = distance(points[i - 1], points[i]);
    if (target <= segment) {
      const t = segment ? target / segment : 0;
      return { x: points[i - 1].x + (points[i].x - points[i - 1].x) * t, z: points[i - 1].z + (points[i].z - points[i - 1].z) * t };
    }
    target -= segment;
  }
  return points[points.length - 1];
}

export function clampPoint(point: Point, min: number, max: number): Point {
  return { x: Math.min(max, Math.max(min, point.x)), z: Math.min(max, Math.max(min, point.z)) };
}
