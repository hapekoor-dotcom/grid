import { describe, expect, it } from 'vitest';
import { effectPhase, normalizeGroupEffect, sampleGroupEffects } from './groupEffects';
import type { Project } from '../types/project';
import type { GroupEffect } from '../types/timeline';

function projectWithBars(): Project {
  const bars = [0, 1, 2, 3].map((index) => ({
    id: `bar-${index}`,
    type: 'device' as const,
    name: `Bar ${index}`,
    position: { x: index * 2, z: 0 },
    elevation: 0,
    light: { on: true, intensity: 0.2, color: '#ffffff', colorTemp: 5600, pan: 0, tilt: 0, zoom: 20, strobe: 0, focus: 0.5 },
  }));
  return { objects: bars, timeline: { groupEffects: [] } } as unknown as Project;
}

const effect: GroupEffect = {
  id: 'effect-1', type: 'groupWave', enabled: true, targetIds: ['bar-0', 'bar-1', 'bar-2', 'bar-3'],
  propertyPath: 'light.intensity', start: 2, end: 10, fadeIn: 0, fadeOut: 0,
  params: { frequency: 2, phaseSpread: 360, phaseMode: 'left-right', basePhase: 0, min: 0.2, max: 1, waveform: 'sine', colorFrom: '#0000ff', colorTo: '#ff00ff' },
};

describe('shared group effects', () => {
  it('normalizes one shared effect with its target list', () => {
    const normalized = normalizeGroupEffect(effect);
    expect(normalized?.targetIds).toHaveLength(4);
    expect(normalized?.params.frequency).toBe(2);
  });

  it('derives per-target phase from the shared effect', () => {
    const project = projectWithBars();
    expect(effectPhase(effect, 'bar-0', project)).toBeCloseTo(0);
    expect(effectPhase(effect, 'bar-1', project)).toBeCloseTo(0.25);
    expect(effectPhase(effect, 'bar-3', project)).toBeCloseTo(0.75);
  });

  it('writes one shared parameter source to every target', () => {
    const project = projectWithBars();
    project.timeline.groupEffects = [effect];
    const overrides = new Map<string, number | string | boolean>();
    sampleGroupEffects(project, 3, overrides);
    for (const id of effect.targetIds) {
      expect(typeof overrides.get(`${id}:light.intensity`)).toBe('number');
      expect(typeof overrides.get(`${id}:light.color`)).toBe('string');
    }
    const first = overrides.get('bar-0:light.intensity');
    expect(overrides.get('bar-1:light.intensity')).not.toBe(first);
  });

  it('changes every target when the shared frequency changes', () => {
    const project = projectWithBars();
    project.timeline.groupEffects = [effect];
    const a = new Map<string, number | string | boolean>();
    const b = new Map<string, number | string | boolean>();
    sampleGroupEffects(project, 3, a);
    effect.params.frequency = 1;
    sampleGroupEffects(project, 3, b);
    expect(a.get('bar-2:light.intensity')).not.toBe(b.get('bar-2:light.intensity'));
  });
});
