import type { CustomShader, CustomShaderParam, Project, ShaderInstance } from '../types/project';

export const MESH_VERTEX_TEMPLATE = `// Modify the local vertex position p.
// Available: p, worldPos, uEffectTime, uStrength
float wave = sin(p.y * 3.0 + uEffectTime * 2.0);
p += normal * wave * uStrength;
`;

export const MESH_FRAGMENT_TEMPLATE = `// Modify emission only. PBR lighting and base textures remain intact.
// Available: emission, worldPos, normal, viewDir, uEffectTime, uStrength, uColor
float pulse = 0.5 + 0.5 * sin(worldPos.y * 4.0 + uEffectTime * 2.0);
emission += uColor * pulse * uStrength;
`;

export const CUSTOM_SHADER_PARAMS: CustomShaderParam[] = [
  { id: 'uStrength', label: 'Strength', type: 'float', default: 0.2, shortDescription: 'How strongly the custom shader affects the surface or vertex position.', recommendedMin: 0, recommendedMax: 2, hardClamp: false, animatable: true },
  { id: 'uColor', label: 'Color', type: 'color', default: [0.2, 0.8, 1], shortDescription: 'Emission color mixed by the custom shader.' },
];

export function defaultMeshShader(): CustomShader {
  const now = new Date().toISOString();
  return {
    id: `shader_${crypto.randomUUID()}`,
    name: 'Custom Mesh Shader',
    context: 'mesh',
    mode: 'pbr-extension',
    vertex: MESH_VERTEX_TEMPLATE,
    fragment: MESH_FRAGMENT_TEMPLATE,
    params: structuredClone(CUSTOM_SHADER_PARAMS),
    lastWorking: { vertex: MESH_VERTEX_TEMPLATE, fragment: MESH_FRAGMENT_TEMPLATE },
    boundsExpansion: 1,
    cost: 'medium',
    createdAt: now,
    updatedAt: now,
  };
}

export function defaultValues(shader: CustomShader): ShaderInstance['values'] {
  return Object.fromEntries(shader.params.map((param) => [param.id, param.default]));
}

export function customShaderById(project: Project | null, id: string): CustomShader | undefined {
  return project?.customShaders?.find((shader) => shader.id === id);
}

export function customShadersForObject(project: Project | null, object: { lookId?: string; shaders?: ShaderInstance[] }): { shader: CustomShader; instance: ShaderInstance }[] {
  const look = project?.looks?.find((entry) => entry.id === object.lookId);
  const instances = [...(look?.shaders || []), ...(object.shaders || [])];
  return instances.flatMap((instance) => {
    const shader = customShaderById(project, instance.shaderId);
    return shader && shader.context === 'mesh' && instance.enabled ? [{ shader, instance }] : [];
  });
}

function uniformType(param: CustomShaderParam): string {
  if (param.type === 'color' || param.type === 'vec3') return 'vec3';
  if (param.type === 'vec2') return 'vec2';
  if (param.type === 'vec4') return 'vec4';
  if (param.type === 'int') return 'int';
  if (param.type === 'bool') return 'bool';
  return 'float';
}

export function buildCustomVertexChunk(base: string, shader: CustomShader): string {
  const declarations = shader.params.map((param) => `uniform ${uniformType(param)} ${param.id};`).join('\n');
  const body = `void effectCustomVertex(inout vec3 p, vec3 normal, vec2 uv) {\n${shader.vertex}\n}`;
  return base.replace('void effectCustomVertex(inout vec3 p, vec3 normal, vec2 uv) {\n}', `${declarations}\n${body}`).replace('void effectCustomVertex(inout vec3 p, vec3 normal, vec2 uv) {}', `${declarations}\n${body}`);
}

export function buildCustomEmissiveChunk(base: string, shader: CustomShader): string {
  const declarations = shader.params.map((param) => `uniform ${uniformType(param)} ${param.id};`).join('\n');
  const body = `void effectCustomSurface(inout vec3 emission, vec3 worldPos, vec3 normal, vec3 viewDir) {\n${shader.fragment}\n}`;
  return base.replace('void effectCustomSurface(inout vec3 emission, vec3 worldPos, vec3 normal, vec3 viewDir) {\n}', `${declarations}\n${body}`).replace('void effectCustomSurface(inout vec3 emission, vec3 worldPos, vec3 normal, vec3 viewDir) {}', `${declarations}\n${body}`);
}

export interface ShaderCompileError { stage: 'vertex' | 'fragment'; line: number; message: string; raw: string }
export interface ShaderCompileResult { ok: boolean; errors: ShaderCompileError[]; log: string }

function uniformDeclaration(param: CustomShaderParam): string {
  return `uniform ${uniformType(param)} ${param.id};`;
}

function validationSources(shader: CustomShader): { vertex: string; fragment: string } {
  const uniforms = ['uniform float uEffectTime;', ...shader.params.map(uniformDeclaration)].join('\n');
  return {
    vertex: `#version 300 es
precision highp float;
${uniforms}
void effectCustomVertex(inout vec3 p, vec3 normal, vec2 uv) {
${shader.vertex}
}
void main() { vec3 p = vec3(0.0); effectCustomVertex(p, vec3(0.0, 1.0, 0.0), vec2(0.0)); gl_Position = vec4(p, 1.0); }`,
    fragment: `#version 300 es
precision highp float;
${uniforms}
void effectCustomSurface(inout vec3 emission, vec3 worldPos, vec3 normal, vec3 viewDir) {
${shader.fragment}
}
out vec4 shaderLabColor;
void main() { vec3 emission = vec3(0.0); effectCustomSurface(emission, vec3(0.0), vec3(0.0, 1.0, 0.0), vec3(0.0, 0.0, 1.0)); shaderLabColor = vec4(emission, 1.0); }`,
  };
}

export function compileCustomShader(shader: CustomShader): ShaderCompileResult {
  if (typeof document === 'undefined') return { ok: false, errors: [{ stage: 'vertex', line: 0, message: 'Shader compiler is not available outside the browser.', raw: '' }], log: '' };
  const canvas = document.createElement('canvas');
  const raw = shader.mode === 'full-custom' || shader.context === 'post';
  // PlayCanvas renders through WebGL2. WebGL2 accepts the GLSL ES 1.00
  // attribute/varying sources that ShaderMaterial uses, so validate against
  // the same context type as the runtime.
  const gl = canvas.getContext('webgl2');
  if (!gl) return { ok: false, errors: [{ stage: 'fragment', line: 0, message: 'WebGL is not available for shader compilation.', raw: '' }], log: '' };
  const errors: ShaderCompileError[] = [];
  let log = '';
  const rawAttribute = !raw && shader.vertex.match(/\bvertex_texCoord[01]\b|\bvertex_normal\b|\bvertex_tangent\b|\bvertex_color\b/);
  if (rawAttribute) errors.push({ stage: 'vertex', line: 0, message: `${rawAttribute[0]} is not guaranteed on imported meshes. Use the provided uv/normal parameters or generated coordinates instead.`, raw: rawAttribute[0] });
  const compile = (stage: 'vertex' | 'fragment', source: string) => {
    const shaderObject = gl.createShader(stage === 'vertex' ? gl.VERTEX_SHADER : gl.FRAGMENT_SHADER);
    if (!shaderObject) return;
    gl.shaderSource(shaderObject, source);
    gl.compileShader(shaderObject);
    if (!gl.getShaderParameter(shaderObject, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shaderObject) || 'Unknown shader compile error';
      log += `${stage.toUpperCase()}:\n${message}\n`;
      for (const lineText of message.split('\n')) {
        const match = lineText.match(/ERROR:\s*\d+:(\d+):\s*(.*)/i);
        if (match) errors.push({ stage, line: Math.max(0, Number(match[1]) - (raw ? 0 : 5)), message: match[2].trim(), raw: lineText });
        else if (lineText.trim() && !lineText.startsWith('ERROR:')) errors.push({ stage, line: 0, message: lineText.trim(), raw: lineText });
      }
    }
    gl.deleteShader(shaderObject);
  };
  const sources = raw ? { vertex: shader.vertex, fragment: shader.fragment } : validationSources(shader);
  compile('vertex', sources.vertex);
  compile('fragment', sources.fragment);
  return { ok: errors.length === 0, errors, log };
}

export function normalizeCustomShaders(value: unknown): CustomShader[] {
  if (!Array.isArray(value)) return [];
  return value.filter((entry): entry is Partial<CustomShader> => !!entry && typeof entry === 'object').map((entry) => ({
    id: typeof entry.id === 'string' ? entry.id : `shader_${Date.now()}`,
    name: typeof entry.name === 'string' ? entry.name : 'Custom Shader',
    context: entry.context === 'post' ? 'post' : 'mesh',
    mode: entry.mode === 'full-custom' ? 'full-custom' : 'pbr-extension',
    vertex: typeof entry.vertex === 'string' ? entry.vertex : MESH_VERTEX_TEMPLATE,
    fragment: typeof entry.fragment === 'string' ? entry.fragment : MESH_FRAGMENT_TEMPLATE,
    wgsl: typeof entry.wgsl === 'string' ? entry.wgsl : undefined,
    params: Array.isArray(entry.params) ? entry.params : structuredClone(CUSTOM_SHADER_PARAMS),
    lastWorking: entry.lastWorking && typeof entry.lastWorking === 'object' ? entry.lastWorking : undefined,
    boundsExpansion: Number.isFinite(Number(entry.boundsExpansion)) ? Number(entry.boundsExpansion) : 0,
    cost: entry.cost === 'low' || entry.cost === 'high' || entry.cost === 'extreme' ? entry.cost : 'medium',
    createdAt: typeof entry.createdAt === 'string' ? entry.createdAt : new Date().toISOString(),
    updatedAt: typeof entry.updatedAt === 'string' ? entry.updatedAt : new Date().toISOString(),
  }));
}


export const FULL_MESH_VERTEX_TEMPLATE = `attribute vec3 aPosition;
uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;

varying vec3 vWorldPos;

void main(void) {
    vec3 p = aPosition;
    vec4 world = matrix_model * vec4(p, 1.0);
    vWorldPos = world.xyz;
    gl_Position = matrix_viewProjection * world;
}`;

export const FULL_MESH_FRAGMENT_TEMPLATE = `precision highp float;
uniform float uEffectTime;
uniform float uStrength;
uniform vec3 uColor;
varying vec3 vWorldPos;

void main(void) {
    float pulse = 0.5 + 0.5 * sin(vWorldPos.y * 4.0 + uEffectTime * 2.0);
    gl_FragColor = vec4(mix(vec3(0.02), uColor, pulse) * (0.5 + uStrength), 1.0);
}`;

export const POST_SHADER_VERTEX_TEMPLATE = `attribute vec2 aPosition;
varying vec2 vUv;
void main(void) {
    vUv = aPosition * 0.5 + 0.5;
    gl_Position = vec4(aPosition, 0.0, 1.0);
}`;

export const POST_SHADER_FRAGMENT_TEMPLATE = `precision highp float;
uniform sampler2D uScene;
uniform sampler2D uPrevious;
uniform vec2 uResolution;
uniform float uTime;
uniform float uFrame;
uniform vec2 uMouse;
uniform float uFeedback;
uniform float uStrength;
varying vec2 vUv;

void main(void) {
    vec3 color = texture2D(uScene, vUv).rgb;
    vec3 previous = texture2D(uPrevious, vUv).rgb;
    gl_FragColor = vec4(mix(color, previous * 0.985, clamp(uFeedback * uStrength, 0.0, 1.0)), 1.0);
}`;

export function defaultFullMeshShader(): CustomShader {
  const base = defaultMeshShader();
  return {
    ...base,
    name: 'Full Custom Mesh Shader',
    mode: 'full-custom',
    vertex: FULL_MESH_VERTEX_TEMPLATE,
    fragment: FULL_MESH_FRAGMENT_TEMPLATE,
    lastWorking: { vertex: FULL_MESH_VERTEX_TEMPLATE, fragment: FULL_MESH_FRAGMENT_TEMPLATE },
    params: [
      { id: 'uStrength', label: 'Strength', type: 'float', default: 0.5, shortDescription: 'Scales the emitted color and pulse.', recommendedMin: 0, recommendedMax: 3, hardClamp: false, animatable: true },
      { id: 'uColor', label: 'Color', type: 'color', default: [0.2, 0.8, 1], shortDescription: 'Base emissive color.' },
    ],
  };
}

export function defaultPostShader(): CustomShader {
  return {
    id: `shader_${crypto.randomUUID()}`,
    name: 'Post · Feedback',
    context: 'post',
    mode: 'full-custom',
    vertex: POST_SHADER_VERTEX_TEMPLATE,
    fragment: POST_SHADER_FRAGMENT_TEMPLATE,
    params: [
      { id: 'uFeedback', label: 'Feedback', type: 'float', default: 0.85, shortDescription: 'How much of the previous post frame is retained.', recommendedMin: 0, recommendedMax: 1, hardClamp: false, animatable: true },
      { id: 'uStrength', label: 'Amount', type: 'float', default: 1, shortDescription: 'Overall feedback strength.', recommendedMin: 0, recommendedMax: 2, hardClamp: false, animatable: true },
    ],
    lastWorking: { vertex: POST_SHADER_VERTEX_TEMPLATE, fragment: POST_SHADER_FRAGMENT_TEMPLATE },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}


export type PostPresetName = 'passthrough' | 'feedback' | 'rgbSplit' | 'kaleidoscope' | 'temporalSmear' | 'reactionFeedback';

interface PostPreset {
  name: string;
  fragment: string;
  params: CustomShaderParam[];
}

const POST_PRESETS: Record<PostPresetName, PostPreset> = {
  passthrough: {
    name: 'Passthrough',
    fragment: `precision highp float;
uniform sampler2D uScene;
varying vec2 vUv;
void main(void) { gl_FragColor = texture2D(uScene, vUv); }`,
    params: [],
  },
  feedback: {
    name: 'Feedback',
    fragment: POST_SHADER_FRAGMENT_TEMPLATE,
    params: [
      { id: 'uFeedback', label: 'Feedback', type: 'float', default: 0.85, shortDescription: 'How much of the previous post frame is retained.', recommendedMin: 0, recommendedMax: 1, hardClamp: false, animatable: true },
      { id: 'uStrength', label: 'Amount', type: 'float', default: 1, shortDescription: 'Overall feedback strength.', recommendedMin: 0, recommendedMax: 2, hardClamp: false, animatable: true },
    ],
  },
  rgbSplit: {
    name: 'RGB Split',
    fragment: `precision highp float;
uniform sampler2D uScene;
uniform float uStrength;
varying vec2 vUv;
void main(void) {
    vec2 offset = vec2(0.006 * uStrength, 0.0);
    float r = texture2D(uScene, vUv + offset).r;
    float g = texture2D(uScene, vUv).g;
    float b = texture2D(uScene, vUv - offset).b;
    gl_FragColor = vec4(r, g, b, 1.0);
}`,
    params: [{ id: 'uStrength', label: 'Split amount', type: 'float', default: 1, shortDescription: 'Horizontal RGB channel separation.', recommendedMin: 0, recommendedMax: 4, hardClamp: false, animatable: true }],
  },
  kaleidoscope: {
    name: 'Kaleidoscope',
    fragment: `precision highp float;
uniform sampler2D uScene;
uniform float uStrength;
uniform float uSegments;
varying vec2 vUv;
const float PI = 3.14159265;
void main(void) {
    vec2 uv = vUv - 0.5;
    float radius = length(uv);
    float angle = atan(uv.y, uv.x);
    float segments = max(3.0, floor(uSegments));
    float slice = PI * 2.0 / segments;
    angle = mod(angle, slice);
    angle = abs(angle - slice * 0.5);
    vec2 sampleUv = 0.5 + vec2(cos(angle), sin(angle)) * radius * mix(1.0, 1.4, clamp(uStrength, 0.0, 1.0));
    gl_FragColor = vec4(texture2D(uScene, sampleUv).rgb, 1.0);
}`,
    params: [
      { id: 'uStrength', label: 'Distortion', type: 'float', default: 0.5, shortDescription: 'Radial kaleidoscope distortion.', recommendedMin: 0, recommendedMax: 1, hardClamp: true, animatable: true },
      { id: 'uSegments', label: 'Segments', type: 'float', default: 6, shortDescription: 'Number of mirrored slices.', recommendedMin: 3, recommendedMax: 24, hardClamp: true, animatable: true },
    ],
  },
  reactionFeedback: {
    name: 'Reaction Feedback',
    fragment: `precision highp float;
uniform sampler2D uScene;
uniform sampler2D uPrevious;
uniform sampler2D uReaction;
uniform float uStrength;
uniform float uFeedback;
varying vec2 vUv;
void main(void) {
    float rd = texture2D(uReaction, vUv).r;
    vec2 uv = vUv + (rd - 0.5) * 0.018 * uStrength;
    vec3 current = texture2D(uScene, uv).rgb;
    vec3 previous = texture2D(uPrevious, uv).rgb;
    gl_FragColor = vec4(mix(current, previous * 0.985, clamp(uFeedback * (0.35 + rd * 0.65), 0.0, 1.0)), 1.0);
}`,
    params: [
      { id: 'uFeedback', label: 'Feedback', type: 'float', default: 0.72, shortDescription: 'RD-modulated previous-frame retention.', recommendedMin: 0, recommendedMax: 1, hardClamp: false, animatable: true },
      { id: 'uStrength', label: 'Distortion', type: 'float', default: 1, shortDescription: 'RD-driven UV displacement strength.', recommendedMin: 0, recommendedMax: 3, hardClamp: false, animatable: true },
    ],
  },
  temporalSmear: {
    name: 'Temporal Smear',
    fragment: `precision highp float;
uniform sampler2D uScene;
uniform sampler2D uPrevious;
uniform float uStrength;
varying vec2 vUv;
void main(void) {
    vec3 color = texture2D(uScene, vUv).rgb;
    vec3 previous = texture2D(uPrevious, vUv).rgb;
    gl_FragColor = vec4(mix(color, previous, clamp(0.85 * uStrength, 0.0, 0.98)), 1.0);
}`,
    params: [{ id: 'uStrength', label: 'Smear', type: 'float', default: 1, shortDescription: 'Length of the previous-frame trail.', recommendedMin: 0, recommendedMax: 1, hardClamp: true, animatable: true }],
  },
};

export function defaultPostPreset(preset: PostPresetName = 'feedback'): CustomShader {
  const definition = POST_PRESETS[preset];
  const base = defaultPostShader();
  return {
    ...base,
    name: `Post · ${definition.name}`,
    fragment: definition.fragment,
    params: definition.params,
    lastWorking: { vertex: POST_SHADER_VERTEX_TEMPLATE, fragment: definition.fragment },
  };
}

export function postPresetNames(): { id: PostPresetName; label: string }[] {
  return (Object.keys(POST_PRESETS) as PostPresetName[]).map((id) => ({ id, label: POST_PRESETS[id].name }));
}
