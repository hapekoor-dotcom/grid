import type { Project, SceneObject } from '../types/project';
import { getDevice } from './catalog';
import { objectDims } from './objects';
import { fixtureMountY, getRoomBounds } from './stage3d';

export type OpticalFamily = 'spot' | 'beam' | 'wash' | 'bar' | 'panel' | 'strobe';

export interface OpticalProfile {
  family: OpticalFamily;
  beamAngle: number;
  fieldAngle: number;
  penumbra: number;
  intensityScale: number;
  alpha: number;
  coreAlpha: number;
  areaWidth: number;
  areaHeight: number;
  area: boolean;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function opticalProfile(object: SceneObject): OpticalProfile {
  const device = getDevice(object.deviceId);
  const kind = device?.kind || 'other';
  const light = object.light;
  const zoom = Number(light?.zoom) || device?.beamAngle.max || 30;
  const focus = clamp(light?.focus ?? 0.5, 0, 1);
  const dims = objectDims(object);

  if (kind === 'bar' || kind === 'pixel') {
    const beamAngle = clamp(zoom * 0.72, 12, 42);
    return {
      family: 'bar',
      beamAngle,
      fieldAngle: clamp(beamAngle * 1.35, 20, 65),
      penumbra: 0.7,
      intensityScale: 0.86,
      alpha: 0.075,
      coreAlpha: 0.1,
      areaWidth: Math.max(0.3, dims.w * 0.94),
      areaHeight: 0.08,
      area: true,
    };
  }
  if (kind === 'panel' || kind === 'blinder') {
    return {
      family: 'panel',
      beamAngle: clamp(zoom, 35, 85),
      fieldAngle: 88,
      penumbra: 0.95,
      intensityScale: 0.75,
      alpha: 0.035,
      coreAlpha: 0.04,
      areaWidth: Math.max(0.2, dims.w * 0.9),
      areaHeight: Math.max(0.08, dims.h * 0.65),
      area: true,
    };
  }
  if (kind === 'strobe') {
    return {
      family: 'strobe',
      beamAngle: 80,
      fieldAngle: 90,
      penumbra: 1,
      intensityScale: 1.15,
      alpha: 0.025,
      coreAlpha: 0.03,
      areaWidth: Math.max(0.2, dims.w * 0.86),
      areaHeight: 0.07,
      area: true,
    };
  }
  if (kind === 'par' || kind === 'flood' || kind === 'effectlight') {
    const beamAngle = clamp(zoom * 1.7, 46, 86);
    return {
      family: 'wash',
      beamAngle,
      fieldAngle: clamp(beamAngle * 1.16, 60, 100),
      penumbra: 0.9,
      intensityScale: 0.78,
      alpha: 0.045,
      coreAlpha: 0.03,
      areaWidth: 0,
      areaHeight: 0,
      area: false,
    };
  }
  if (kind === 'beam') {
    return {
      family: 'beam',
      beamAngle: clamp(zoom, 3, 20),
      fieldAngle: clamp(zoom * 1.18, 5, 28),
      penumbra: 0.12,
      intensityScale: 1.35,
      alpha: 0.12,
      coreAlpha: 0.2,
      areaWidth: 0,
      areaHeight: 0,
      area: false,
    };
  }
  const beamAngle = clamp(zoom, 6, 62);
  return {
    family: 'spot',
    beamAngle,
    fieldAngle: clamp(beamAngle * 1.3, 8, 82),
    penumbra: 0.18 + focus * 0.68,
    intensityScale: 1,
    alpha: 0.08,
    coreAlpha: 0.12,
    areaWidth: 0,
    areaHeight: 0,
    area: false,
  };
}

export interface BarEmitter {
  lenses: [number, number, number][];
  targets: [number, number, number][];
  center: [number, number, number];
  target: [number, number, number];
  forward: [number, number, number];
  tilt: number;
  profile: OpticalProfile;
}

/**
 * Bar light starts at the front lens row, not at the housing centre.
 * All lenses share the body's optical axis; each keeps its own position and segment state.
 */
export function barEmitter(object: SceneObject, project: Project): BarEmitter {
  const dims = objectDims(object);
  const device = getDevice(object.deviceId);
  const profile = opticalProfile(object);
  const count = clamp(device?.lensCount || 12, 3, 12);
  const yaw = (-object.rotation * Math.PI) / 180;
  const cos = Math.cos(yaw);
  const sin = Math.sin(yaw);
  const mountY = fixtureMountY(object);
  const frontZ = dims.d / 2 + 0.01;
  const span = dims.w * 0.9;
  const lenses: [number, number, number][] = [];
  for (let index = 0; index < count; index++) {
    const localX = count === 1 ? 0 : -span / 2 + (span * index) / (count - 1);
    lenses.push([
      object.position.x + localX * cos + frontZ * sin,
      mountY,
      object.position.z - localX * sin + frontZ * cos,
    ]);
  }
  const forward: [number, number, number] = [sin, 0, cos];
  const bounds = getRoomBounds(project);
  const distances = [
    forward[0] > 0 ? (bounds.maxX - object.position.x) / forward[0] : Infinity,
    forward[0] < 0 ? (bounds.minX - object.position.x) / forward[0] : Infinity,
    forward[2] > 0 ? (bounds.maxZ - object.position.z) / forward[2] : Infinity,
    forward[2] < 0 ? (bounds.minZ - object.position.z) / forward[2] : Infinity,
  ].filter((value) => Number.isFinite(value) && value > 0.4);
  const distance = clamp(distances.length ? Math.min(...distances) : 6, 1.2, 10);
  const tilt = clamp(object.light?.tilt || 0, -20, 70);
  const rise = Math.tan((tilt * Math.PI) / 180) * distance;
  const targets: [number, number, number][] = lenses.map((lens) => [
    lens[0] + forward[0] * distance,
    clamp(lens[1] + rise, 0.25, bounds.height - 0.2),
    lens[2] + forward[2] * distance,
  ]);
  const center: [number, number, number] = [object.position.x, mountY, object.position.z];
  const target: [number, number, number] = targets.reduce((sum, point) => [sum[0] + point[0] / targets.length, sum[1] + point[1] / targets.length, sum[2] + point[2] / targets.length], [0, 0, 0] as [number, number, number]);
  return { lenses, targets, center, target, forward, tilt, profile };
}
