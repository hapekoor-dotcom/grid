import type { Project, SceneObject } from '../types/project';
import { fixtureAimPoint, fixtureMountY } from './stage3d';
import { barEmitter, opticalProfile, type OpticalFamily } from './lightOptics';

export interface VolumeSpot {
  position: [number, number, number];
  direction: [number, number, number];
  color: string;
  energy: number;
  cosOuter: number;
  cosInner: number;
  range: number;
}

export interface VolumeBar {
  start: [number, number, number];
  end: [number, number, number];
  direction: [number, number, number];
  color: string;
  energy: number;
  range: number;
}

export interface VolumeSet {
  spots: VolumeSpot[];
  bars: VolumeBar[];
}

const MAX_SPOTS = 8;
const MAX_BARS = 4;

function normalized(vector: [number, number, number]): [number, number, number] {
  const length = Math.hypot(...vector) || 1;
  return [vector[0] / length, vector[1] / length, vector[2] / length];
}

function coneCos(angle: number): number {
  return Math.cos((Math.max(1, Math.min(100, angle)) * Math.PI) / 360);
}

/** Builds only the emitters that can actually contribute scattered light. */
export function collectVolumetrics(project: Project): VolumeSet {
  const spots: VolumeSpot[] = [];
  const bars: VolumeBar[] = [];
  const master = project.lighting.master ?? 0.9;

  for (const object of project.objects) {
    if (!object.visible || !object.light?.on || !object.light.intensity) continue;
    const profile = opticalProfile(object);
    if (profile.family === 'bar') {
      if (bars.length >= MAX_BARS) continue;
      const emitter = barEmitter(object, project);
      const start = emitter.lenses[0];
      const end = emitter.lenses[emitter.lenses.length - 1];
      const tilt = (object.light.tilt * Math.PI) / 180;
      bars.push({
        start, end,
        direction: [emitter.forward[0] * Math.cos(tilt), Math.sin(tilt), emitter.forward[2] * Math.cos(tilt)],
        color: object.light.color,
        energy: object.light.intensity * master * 0.01,
        range: 5,
      });
      continue;
    }
    if (spots.length >= MAX_SPOTS) continue;
    const aim = fixtureAimPoint(object, project);
    const position: [number, number, number] = [
      object.position.x,
      Math.max(0.1, fixtureMountY(object) - (object.mount === 'truss' || object.mount === 'ceiling' ? 0.1 : 0)),
      object.position.z,
    ];
    const direction = normalized([aim[0] - position[0], aim[1] - position[1], aim[2] - position[2]]);
    const familyScale: Record<OpticalFamily, number> = {
      spot: 1,
      beam: 1.22,
      wash: 0.0,
      bar: 0,
      panel: 0,
      strobe: 0,
    };
    if (familyScale[profile.family] <= 0) continue;
    spots.push({
      position,
      direction,
      color: object.light.color,
      energy: object.light.intensity * master * familyScale[profile.family],
      cosOuter: coneCos(profile.fieldAngle),
      cosInner: coneCos(profile.beamAngle),
      range: 24,
    });
  }

  return { spots, bars };
}
