import type { Connection, Point, Project, SceneObject } from '../types/project';
import { objectRect, placePorts } from './objects';
import { distance, rectContains, segmentIntersectsRect, simplifyOrthogonal, snapValue } from './geometry';

const EPS = 1e-5;
const CABLE_STEP = 0.25;
const OBSTACLE_PAD = 0.035;

// Separate lanes keep parallel power/DMX/data runs readable instead of painting over each other.
const CABLE_OFFSET: Record<string, number> = {
  power: 0,
  dmx: 0.16,
  ethernet: 0.32,
  video: 0.48,
  usb: -0.16,
  wireless: -0.32,
};

interface Rect { x: number; z: number; w: number; d: number }
interface Bounds { minX: number; minZ: number; maxX: number; maxZ: number }

interface RouteResult {
  points: Point[];
  distance: number;
}

const samePoint = (a: Point, b: Point) => Math.abs(a.x - b.x) < EPS && Math.abs(a.z - b.z) < EPS;

/** A diagonal in a cable path is always a bug. Insert the missing orthogonal bend. */
function orthogonalize(points: Point[]): Point[] {
  const clean: Point[] = [];
  for (const point of points) {
    const last = clean[clean.length - 1];
    if (last && samePoint(last, point)) continue;
    if (last && Math.abs(last.x - point.x) > EPS && Math.abs(last.z - point.z) > EPS) {
      const before = clean[clean.length - 2];
      // Continue the previous direction first, then turn once.
      const bend = before && Math.abs(before.x - last.x) < EPS
        ? { x: last.x, z: point.z }
        : { x: point.x, z: last.z };
      if (!samePoint(bend, last)) clean.push(bend);
    }
    clean.push(point);
  }
  return simplifyOrthogonal(clean);
}

function pathIsOrthogonal(points: Point[]): boolean {
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    if (Math.abs(a.x - b.x) > EPS && Math.abs(a.z - b.z) > EPS) return false;
  }
  return true;
}

function segmentClear(a: Point, b: Point, obstacles: Rect[]): boolean {
  if (Math.abs(a.x - b.x) > EPS && Math.abs(a.z - b.z) > EPS) return false;
  return !obstacles.some((rect) => segmentIntersectsRect(a, b, rect, OBSTACLE_PAD));
}

function pathClear(points: Point[], obstacles: Rect[]): boolean {
  if (points.length < 2) return false;
  for (const point of points) {
    if (obstacles.some((rect) => rectContains(rect, point, 0.01))) return false;
  }
  for (let i = 1; i < points.length; i++) {
    if (!segmentClear(points[i - 1], points[i], obstacles)) return false;
  }
  return true;
}

function pathLength(points: Point[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i++) total += distance(points[i - 1], points[i]);
  return total;
}

function bends(points: Point[]): number {
  return Math.max(0, points.length - 2);
}

function withinRoom(points: Point[], room: Bounds | null): boolean {
  if (!room) return true;
  return points.every((point) => point.x >= room.minX - EPS && point.x <= room.maxX + EPS && point.z >= room.minZ - EPS && point.z <= room.maxZ + EPS);
}

function clampRoom(points: Point[], room: Bounds | null): Point[] {
  if (!room) return points;
  return points.map((point) => ({
    x: Math.min(room.maxX, Math.max(room.minX, point.x)),
    z: Math.min(room.maxZ, Math.max(room.minZ, point.z)),
  }));
}

/**
 * Best clean orthogonal leg. Try the two simple Ls, then vertical/horizontal lanes
 * on the project grid. Long clean runs beat a jagged grid search.
 */
function bestLane(start: Point, end: Point, obstacles: Rect[], room: Bounds | null, offset = 0): Point[] | null {
  const candidates: Point[][] = [];
  const add = (points: Point[]) => {
    const clean = orthogonalize(points);
    if (!pathIsOrthogonal(clean) || !withinRoom(clean, room) || !pathClear(clean, obstacles)) return;
    if (clean.length > 1) candidates.push(clean);
  };

  // The direct L is the cleanest route, but only the primary lane may use it.
  // Other cable types take their own parallel lane so no cable disappears under another.
  if (Math.abs(offset) < EPS) {
    add([start, { x: end.x, z: start.z }, end]);
    add([start, { x: start.x, z: end.z }, end]);
  }

  const xs = new Set<number>();
  const zs = new Set<number>();
  const midX = snapValue((start.x + end.x) / 2, CABLE_STEP);
  const midZ = snapValue((start.z + end.z) / 2, CABLE_STEP);
  xs.add(midX);
  zs.add(midZ);
  for (const delta of [-0.5, 0.5, -1, 1, -2, 2, -3, 3]) {
    xs.add(snapValue(midX + delta, CABLE_STEP));
    zs.add(snapValue(midZ + delta, CABLE_STEP));
  }
  if (room) {
    xs.add(room.minX + 0.25);
    xs.add(room.maxX - 0.25);
    zs.add(room.minZ + 0.25);
    zs.add(room.maxZ - 0.25);
  }
  for (const rawX of xs) {
    const x = rawX + offset;
    add([start, { x, z: start.z }, { x, z: end.z }, end]);
  }
  for (const rawZ of zs) {
    const z = rawZ + offset;
    add([start, { x: start.x, z }, { x: end.x, z }, end]);
  }

  // Waypoint legs are short; keep the same tidy rules.
  candidates.sort((a, b) => {
    const ca = pathLength(a) + bends(a) * 0.9;
    const cb = pathLength(b) + bends(b) * 0.9;
    return ca - cb;
  });
  return candidates[0] || null;
}

function aStarGrid(
  start: Point,
  end: Point,
  obstacles: Rect[],
  bounds: Bounds,
): Point[] | null {
  // Align the routing lattice to the world grid, not to an arbitrary object bound.
  const minX = Math.floor(bounds.minX / CABLE_STEP) * CABLE_STEP;
  const minZ = Math.floor(bounds.minZ / CABLE_STEP) * CABLE_STEP;
  const maxX = Math.ceil(bounds.maxX / CABLE_STEP) * CABLE_STEP;
  const maxZ = Math.ceil(bounds.maxZ / CABLE_STEP) * CABLE_STEP;
  const cols = Math.round((maxX - minX) / CABLE_STEP) + 1;
  const rows = Math.round((maxZ - minZ) / CABLE_STEP) + 1;
  if (cols * rows > 80000) return null;

  const toCell = (p: Point) => ({
    x: Math.min(cols - 1, Math.max(0, Math.round((p.x - minX) / CABLE_STEP))),
    z: Math.min(rows - 1, Math.max(0, Math.round((p.z - minZ) / CABLE_STEP))),
  });
  const startCell = toCell(start);
  const endCell = toCell(end);
  const index = (x: number, z: number) => z * cols + x;
  const blocked = new Uint8Array(cols * rows);
  for (let z = 0; z < rows; z++) {
    for (let x = 0; x < cols; x++) {
      const point = { x: minX + x * CABLE_STEP, z: minZ + z * CABLE_STEP };
      if (obstacles.some((rect) => rectContains(rect, point, 0.02))) blocked[index(x, z)] = 1;
    }
  }
  const startIndex = index(startCell.x, startCell.z);
  const endIndex = index(endCell.x, endCell.z);
  blocked[startIndex] = 0;
  blocked[endIndex] = 0;

  const open: number[] = [startIndex];
  const cameFrom = new Int32Array(cols * rows).fill(-1);
  const gScore = new Float32Array(cols * rows).fill(Infinity);
  const fScore = new Float32Array(cols * rows).fill(Infinity);
  const openSet = new Set<number>([startIndex]);
  gScore[startIndex] = 0;
  fScore[startIndex] = Math.abs(startCell.x - endCell.x) + Math.abs(startCell.z - endCell.z);
  let guard = 0;

  while (open.length && guard++ < 50000) {
    let bestIndex = 0;
    let best = Infinity;
    for (let i = 0; i < open.length; i++) {
      const value = fScore[open[i]];
      if (value < best) { best = value; bestIndex = i; }
    }
    const current = open.splice(bestIndex, 1)[0];
    openSet.delete(current);
    if (current === endIndex) {
      const path: Point[] = [];
      let node = current;
      while (node !== -1) {
        const x = node % cols;
        const z = Math.floor(node / cols);
        path.push({ x: minX + x * CABLE_STEP, z: minZ + z * CABLE_STEP });
        node = cameFrom[node];
      }
      return path.reverse();
    }
    const cx = current % cols;
    const cz = Math.floor(current / cols);
    const neighbours = [[cx + 1, cz], [cx - 1, cz], [cx, cz + 1], [cx, cz - 1]];
    for (const [nx, nz] of neighbours) {
      if (nx < 0 || nz < 0 || nx >= cols || nz >= rows) continue;
      const neighbour = index(nx, nz);
      if (blocked[neighbour]) continue;
      const tentative = gScore[current] + 1;
      if (tentative >= gScore[neighbour]) continue;
      cameFrom[neighbour] = current;
      gScore[neighbour] = tentative;
      fScore[neighbour] = tentative + Math.abs(nx - endCell.x) + Math.abs(nz - endCell.z);
      if (!openSet.has(neighbour)) {
        open.push(neighbour);
        openSet.add(neighbour);
      }
    }
  }
  return null;
}

/** Collapse a staircase from the A* fallback into long, readable orthogonal runs. */
function smoothPath(points: Point[], obstacles: Rect[]): Point[] {
  if (points.length <= 2) return orthogonalize(points);
  const out: Point[] = [points[0]];
  let i = 0;
  while (i < points.length - 1) {
    let next = i + 1;
    for (let j = points.length - 1; j > i + 1; j--) {
      const options = [
        [points[i], { x: points[j].x, z: points[i].z }, points[j]],
        [points[i], { x: points[i].x, z: points[j].z }, points[j]],
      ].map(orthogonalize);
      if (options.some((option) => pathClear(option, obstacles))) {
        const chosen = options
          .filter((option) => pathClear(option, obstacles))
          .sort((a, b) => pathLength(a) - pathLength(b))[0];
        out.push(...chosen.slice(1));
        next = j;
        break;
      }
    }
    if (next === i + 1) {
      if (!samePoint(out[out.length - 1], points[i + 1])) out.push(points[i + 1]);
    }
    i = next;
  }
  return orthogonalize(out);
}

/** Route each leg with a clean lane candidate; resort to grid search only when necessary. */
function routeLeg(start: Point, end: Point, obstacles: Rect[], room: Bounds | null, offset = 0): Point[] {
  if (samePoint(start, end)) return [start];
  const lane = bestLane(start, end, obstacles, room, offset);
  if (lane) return lane;
  const pad = 1.25;
  const bounds: Bounds = {
    minX: Math.min(start.x, end.x, ...obstacles.map((r) => r.x)) - pad,
    minZ: Math.min(start.z, end.z, ...obstacles.map((r) => r.z)) - pad,
    maxX: Math.max(start.x, end.x, ...obstacles.map((r) => r.x + r.w)) + pad,
    maxZ: Math.max(start.z, end.z, ...obstacles.map((r) => r.z + r.d)) + pad,
  };
  if (room) {
    bounds.minX = Math.max(bounds.minX, room.minX);
    bounds.maxX = Math.min(bounds.maxX, room.maxX);
    bounds.minZ = Math.max(bounds.minZ, room.minZ);
    bounds.maxZ = Math.min(bounds.maxZ, room.maxZ);
  }
  const grid = aStarGrid(start, end, obstacles, bounds);
  if (!grid) {
    // Last-resort L. It may touch an obstacle; callers will still never draw diagonals.
    return orthogonalize([start, { x: end.x, z: start.z }, end]);
  }
  const clean = smoothPath(grid, obstacles);
  // Connect the arbitrary port stub to the aligned first/last grid cell without a diagonal.
  return orthogonalize([start, ...clean, end]);
}

/**
 * Original Rig Grid routing: shortest orthogonal run on a fixed 0.25 m lattice
 * with a turn penalty, avoiding every other fixture rectangle. No parallel-type
 * lanes and no decorative detours.
 */
function originalLeg(start: Point, end: Point, obstacles: Rect[]): Point[] {
  const step = CABLE_STEP;
  const from = { x: snapValue(start.x, step), z: snapValue(start.z, step) };
  const to = { x: snapValue(end.x, step), z: snapValue(end.z, step) };
  const minX = Math.min(from.x, to.x, ...obstacles.map((r) => r.x)) - step * 5;
  const maxX = Math.max(from.x, to.x, ...obstacles.map((r) => r.x + r.w)) + step * 5;
  const minZ = Math.min(from.z, to.z, ...obstacles.map((r) => r.z)) - step * 5;
  const maxZ = Math.max(from.z, to.z, ...obstacles.map((r) => r.z + r.d)) + step * 5;
  const blocked = (point: Point) => obstacles.some((rect) =>
    point.x > rect.x - 0.01 && point.x < rect.x + rect.w + 0.01
    && point.z > rect.z - 0.01 && point.z < rect.z + rect.d + 0.01);
  const key = (point: Point) => `${Math.round(point.x * 1000)},${Math.round(point.z * 1000)}`;
  const startKey = key(from);
  const endKey = key(to);
  type Node = Point & { dir: number; g: number; f: number; prev: Node | null };
  const open: Node[] = [{ ...from, dir: -1, g: 0, f: 0, prev: null }];
  const best = new Map<string, number>();
  const dirs: Array<[number, Point]> = [
    [0, { x: step, z: 0 }],
    [1, { x: 0, z: step }],
    [2, { x: -step, z: 0 }],
    [3, { x: 0, z: -step }],
  ];
  let found: Node | null = null;
  let guard = 0;
  while (open.length && guard++ < 15000) {
    open.sort((a, b) => b.f - a.f);
    const current = open.pop()!;
    if (key(current) === endKey) { found = current; break; }
    for (const [dir, delta] of dirs) {
      const next = { x: current.x + delta.x, z: current.z + delta.z };
      if (next.x < minX || next.x > maxX || next.z < minZ || next.z > maxZ) continue;
      if (blocked(next) && key(next) !== endKey && key(next) !== startKey) continue;
      const cost = current.g + 1 + (current.dir !== -1 && current.dir !== dir ? 2 : 0);
      const stateKey = `${key(next)}:${dir}`;
      if ((best.get(stateKey) ?? Infinity) <= cost) continue;
      best.set(stateKey, cost);
      open.push({
        ...next,
        dir,
        g: cost,
        f: cost + (Math.abs(next.x - to.x) + Math.abs(next.z - to.z)) / step,
        prev: current,
      });
    }
  }
  const grid: Point[] = [];
  if (found) {
    let node: Node | null = found;
    while (node) { grid.unshift({ x: node.x, z: node.z }); node = node.prev; }
  } else {
    grid.push(from, { x: to.x, z: from.z }, to);
  }
  return orthogonalize([start, ...grid, end]);
}

export function routeConnection(project: Project, connection: Connection, fast = false, laneIndex = 0): RouteResult {
  const from = project.objects.find((object) => object.id === connection.from);
  const to = project.objects.find((object) => object.id === connection.to);
  if (!from || !to) return { points: [], distance: 0 };
  const fromPort = placePorts(from).find((port) => port.id === connection.fromPort);
  const toPort = placePorts(to).find((port) => port.id === connection.toPort);
  if (!fromPort || !toPort) return { points: [], distance: 0 };

  const start = { x: fromPort.x, z: fromPort.z };
  const end = { x: toPort.x, z: toPort.z };
  const waypoints = connection.waypoints || [];
  const roomObject = project.objects.find((object) => object.type === 'room' && object.size);
  const roomW = roomObject?.size ? (roomObject.rotation % 180 === 0 ? roomObject.size.w : roomObject.size.d) : 0;
  const roomD = roomObject?.size ? (roomObject.rotation % 180 === 0 ? roomObject.size.d : roomObject.size.w) : 0;
  const roomInner: Bounds | null = roomObject?.size
    ? {
        minX: roomObject.position.x - roomW / 2 + 0.12,
        maxX: roomObject.position.x + roomW / 2 - 0.12,
        minZ: roomObject.position.z - roomD / 2 + 0.12,
        maxZ: roomObject.position.z + roomD / 2 - 0.12,
      }
    : null;
  const roomOuter: Bounds | null = roomObject?.size
    ? {
        minX: roomObject.position.x - roomW / 2,
        maxX: roomObject.position.x + roomW / 2,
        minZ: roomObject.position.z - roomD / 2,
        maxZ: roomObject.position.z + roomD / 2,
      }
    : null;
  const endpointsInside = !!roomInner && [start, end, ...waypoints].every((point) =>
    point.x > roomInner.minX && point.x < roomInner.maxX && point.z > roomInner.minZ && point.z < roomInner.maxZ);
  const room = endpointsInside ? roomInner : null;
  const endpointsInsideOuter = !!roomOuter && [start, end, ...waypoints].every((point) =>
    point.x >= roomOuter.minX && point.x <= roomOuter.maxX && point.z >= roomOuter.minZ && point.z <= roomOuter.maxZ);

  const clampInterior = (point: Point): Point => room
    ? { x: Math.min(room.maxX, Math.max(room.minX, point.x)), z: Math.min(room.maxZ, Math.max(room.minZ, point.z)) }
    : point;
  // Do not force a stub out of the socket. On the original Grid the path
  // starts at the port itself; an outward stub made a visible U-turn when
  // the remote endpoint was behind the socket normal.
  const startApproach = start;
  const endApproach = end;
  if (fast) {
    const quick = orthogonalize([start, startApproach, { x: endApproach.x, z: startApproach.z }, endApproach, end]);
    const bounded = clampRoom(quick, endpointsInsideOuter ? roomOuter : null);
    return { points: bounded, distance: pathLength(bounded) };
  }

  const obstacles = project.objects
    .filter((object) =>
      object.visible
      && object.id !== from.id
      && object.id !== to.id
      && object.type !== 'room'
      && object.type !== 'stage'
      && object.deviceId !== 'barricade')
    .map(objectRect);

  const points: Point[] = [start, startApproach];
  let cursor = startApproach;
  const targets = [...waypoints.map(clampInterior), endApproach];
  for (const target of targets) {
    const leg = originalLeg(cursor, target, obstacles);
    for (const point of leg) {
      if (!points.length || !samePoint(points[points.length - 1], point)) points.push(point);
    }
    cursor = target;
  }
  if (!samePoint(points[points.length - 1], end)) points.push(end);

  const bounded = clampRoom(points, endpointsInsideOuter ? roomOuter : null);
  const final = orthogonalize(bounded);
  // Never return a diagonal, even if a future route helper regresses.
  if (!pathIsOrthogonal(final)) return { points: orthogonalize(final), distance: pathLength(final) };
  return { points: final, distance: pathLength(final) };
}

export type RoutedCables = Map<string, Point[]>;

export function routeAll(project: Project, fast = false): RoutedCables {
  const map = new Map<string, Point[]>();
  for (const [index, connection] of project.connections.entries()) {
    const result = routeConnection(project, connection, fast, index);
    map.set(connection.id, result.points);
  }
  return map;
}

export function portAnchor(object: SceneObject, portId: string): { x: number; z: number; nx: number; nz: number } | null {
  const port = placePorts(object).find((entry) => entry.id === portId);
  return port ? { x: port.x, z: port.z, nx: port.nx, nz: port.nz } : null;
}

export function cableIntersectsObjects(points: Point[], objects: SceneObject[], pad = 0.02): boolean {
  if (points.length < 2) return false;
  const rects = objects.map(objectRect);
  for (let i = 1; i < points.length; i++) {
    if (rects.some((rect) => segmentIntersectsRect(points[i - 1], points[i], rect, pad))) return true;
  }
  return false;
}
