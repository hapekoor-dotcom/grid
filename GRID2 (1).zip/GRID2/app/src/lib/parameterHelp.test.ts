import { describe, expect, it } from 'vitest';
import { modifierDefinition } from './modifiers';
import { describeParameter, searchParameterDocs, SIGNAL_DOCS } from './parameterHelp';

describe('parameter help', () => {
  it('describes noisy parameters with context', () => {
    const warp = modifierDefinition('domainWarp');
    const scale = warp.fields.find((field) => field.key === 'scale')!;
    const doc = describeParameter(warp, scale);
    expect(doc.short.toLowerCase()).toContain('spatial size');
    expect(doc.long).toContain('Lower values');
  });

  it('documents feedback persistence as decay', () => {
    const feedback = modifierDefinition('feedback');
    const persistence = feedback.fields.find((field) => field.key === 'persistence')!;
    expect(describeParameter(feedback, persistence).short).toContain('previous frames');
  });

  it('searches the same metadata used by the Inspector', () => {
    const results = searchParameterDocs('feedback decay');
    expect(results.some((result) => result.title.includes('Feedback'))).toBe(true);
    expect(SIGNAL_DOCS.fbm.short).toContain('fractal');
  });
});
