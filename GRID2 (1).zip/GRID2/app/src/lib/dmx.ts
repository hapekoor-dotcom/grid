import type { CatalogDevice, DmxMode } from '../types/catalog';
import type { Connection, Project, SceneObject } from '../types/project';
import { getDevice, getMode } from './catalog';
import { getObjectPorts, getPort, isDmxSource, portUniverse } from './objects';

export type Severity = 'error' | 'warning' | 'info';

export interface Diagnostic {
  id: string;
  severity: Severity;
  area: 'dmx' | 'power' | 'connection' | 'project' | 'device';
  code: string;
  message: string;
  objectIds: string[];
  connectionId?: string;
  hint?: string;
}

export interface DmxRoot {
  sourceId: string;
  sourceName: string;
  sourcePort: string;
  universe: number;
  chain: string[];
}

export interface DmxRow {
  objectId: string;
  name: string;
  device: CatalogDevice;
  mode: DmxMode | null;
  channels: number | null;
  universe: number | null;
  address: number | null;
  end: number | null;
  root: DmxRoot | null;
  manual: boolean;
  status: 'patched' | 'unpatched' | 'error';
}

export interface DmxPatchResult {
  rows: DmxRow[];
  diagnostics: Diagnostic[];
  universes: UniverseUsage[];
  patchedCount: number;
  totalChannels: number;
}

export interface UniverseUsage {
  universe: number;
  used: number;
  fixtures: number;
  capacity: number;
  sources: string[];
}

export function isDmxFixture(object: SceneObject): boolean {
  const device = getDevice(object.deviceId);
  return !!device && ['light', 'effects'].includes(device.category) && device.dmx && (device.modes.length > 0 || device.requiresProfile || device.generic);
}

function connectionsInto(project: Project, objectId: string, types: Connection['type'][]): Connection[] {
  return project.connections.filter((connection) => connection.to === objectId && types.includes(connection.type));
}

function connectionIntoPort(project: Project, objectId: string, portId: string): Connection | null {
  return project.connections.find((connection) => connection.to === objectId && connection.toPort === portId) || null;
}

function traceParent(project: Project, parent: SceneObject, portId: string, visited: Set<string>, chain: string[]): DmxRoot | null {
  if (visited.has(parent.id)) return null;
  const nextVisited = new Set(visited);
  nextVisited.add(parent.id);
  const nextChain = [...chain, parent.id];
  const device = getDevice(parent.deviceId);
  if (!device) return null;
  const port = getPort(parent, portId);

  if (isDmxSource(device) && port && port.direction !== 'in') {
    return {
      sourceId: parent.id,
      sourceName: parent.name,
      sourcePort: portId,
      universe: parent.dmxSourceUniverses[portId] ?? portUniverse(parent, port) ?? 1,
      chain: nextChain,
    };
  }

  if (device.kind === 'receiver' || (port?.type === 'wireless' && port.direction === 'in')) {
    const wirelessIn = connectionsInto(project, parent.id, ['wireless'])[0];
    if (wirelessIn) {
      const upstream = project.objects.find((object) => object.id === wirelessIn.from);
      if (upstream) return traceParent(project, upstream, wirelessIn.fromPort, nextVisited, nextChain);
    }
    return null;
  }

  if (device.kind === 'splitter') {
    const input = connectionsInto(project, parent.id, ['dmx'])[0];
    if (!input) return null;
    const upstream = project.objects.find((object) => object.id === input.from);
    if (!upstream) return null;
    return traceParent(project, upstream, input.fromPort, nextVisited, nextChain);
  }

  if (device.kind === 'transmitter' || device.kind === 'interface') {
    const input = connectionsInto(project, parent.id, ['dmx'])[0];
    if (input) {
      const upstream = project.objects.find((object) => object.id === input.from);
      if (upstream) return traceParent(project, upstream, input.fromPort, nextVisited, nextChain);
    }
  }

  // Fixtures and other DMX loads pass the signal through their DMX input.
  const input = connectionsInto(project, parent.id, ['dmx'])[0];
  if (input) {
    const upstream = project.objects.find((object) => object.id === input.from);
    if (upstream) return traceParent(project, upstream, input.fromPort, nextVisited, nextChain);
  }
  return null;
}

export function resolveDmxRoot(project: Project, object: SceneObject): DmxRoot | null {
  if (!isDmxFixture(object)) return null;
  const incoming = connectionsInto(project, object.id, ['dmx', 'wireless']);
  if (!incoming.length) return null;
  const connection = incoming.find((entry) => {
    const port = getObjectPorts(object).find((candidate) => candidate.id === entry.toPort);
    return port && port.direction !== 'out';
  }) || incoming[0];
  const parent = project.objects.find((entry) => entry.id === connection.from);
  if (!parent) return null;
  return traceParent(project, parent, connection.fromPort, new Set(), [object.id]);
}

export function computeDmxPatch(project: Project): DmxPatchResult {
  const fixtures = project.objects.filter(isDmxFixture);
  const diagnostics: Diagnostic[] = [];
  const rows: DmxRow[] = [];
  const usage = new Map<number, UniverseUsage>();
  const occupied = new Map<number, { objectId: string; start: number; end: number }[]>();

  // First pass: roots, modes, manual addresses. Manual ranges are reserved first.
  for (const object of fixtures) {
    const device = getDevice(object.deviceId)!;
    const catalogMode = getMode(device, object.fixture?.modeId ?? null);
    const customChannels = object.fixture?.customChannels && object.fixture.customChannels >= 1 && object.fixture.customChannels <= 512 ? object.fixture.customChannels : null;
    const mode = catalogMode || (customChannels ? { id: 'custom', label: `Custom · ${customChannels} CH`, channels: customChannels } : null);
    const root = resolveDmxRoot(project, object);
    const channels = mode?.channels ?? null;
    const manual = !!object.fixture?.manualAddress;
    const address = manual ? object.fixture?.address ?? null : null;
    const row: DmxRow = {
      objectId: object.id,
      name: object.name,
      device,
      mode,
      channels,
      universe: root?.universe ?? null,
      address,
      end: address !== null && channels ? address + channels - 1 : null,
      root,
      manual,
      status: 'unpatched',
    };
    rows.push(row);

    if (!device.modes.length && !customChannels) {
      diagnostics.push({
        id: `dmx-mode-${object.id}`,
        severity: 'warning',
        area: 'dmx',
        code: 'mode-unknown',
        message: `${object.name}: DMX mode unverified`,
        objectIds: [object.id],
        hint: 'Set the mode manually after checking the fixture documentation.',
      });
      row.status = 'error';
    } else if (!mode) {
      diagnostics.push({
        id: `dmx-mode-missing-${object.id}`,
        severity: 'error',
        area: 'dmx',
        code: 'mode-missing',
        message: `${object.name}: select a DMX mode`,
        objectIds: [object.id],
      });
      row.status = 'error';
    }
    if (!root) {
      diagnostics.push({
        id: `dmx-root-${object.id}`,
        severity: 'error',
        area: 'dmx',
        code: 'no-signal',
        message: `${object.name}: no DMX line`,
        objectIds: [object.id],
        hint: 'Connect the fixture to a node, console, or splitter output.',
      });
      row.status = 'error';
    }
    if (device.dmxPhysical === false) {
      diagnostics.push({
        id: `dmx-wireless-${object.id}`,
        severity: 'info',
        area: 'dmx',
        code: 'wireless',
        message: `${object.name}: wireless DMX`,
        objectIds: [object.id],
        hint: 'Radio compatibility must be checked separately; the project does not transmit commands.',
      });
    }

    if (manual && root && channels) {
      const universe = root.universe;
      const list = occupied.get(universe) || [];
      const start = address ?? 0;
      const end = start + channels - 1;
      if (!Number.isInteger(start) || start < 1 || end > 512) {
        diagnostics.push({
          id: `dmx-range-${object.id}`,
          severity: 'error',
          area: 'dmx',
          code: 'address-range',
          message: `${object.name}: address ${start || '—'}–${end} outside the 1–512 range`,
          objectIds: [object.id],
        });
        row.status = 'error';
      } else {
        const overlap = list.find((entry) => start <= entry.end && end >= entry.start);
        if (overlap) {
          const other = project.objects.find((entry) => entry.id === overlap.objectId);
          diagnostics.push({
            id: `dmx-overlap-${object.id}`,
            severity: 'error',
            area: 'dmx',
            code: 'address-overlap',
            message: `${object.name} overlaps addresses with ${other?.name || overlap.objectId}`,
            objectIds: [object.id, overlap.objectId],
            hint: `Range ${start}–${end} in U${universe} is already in use.`,
          });
          row.status = 'error';
        }
        list.push({ objectId: object.id, start, end });
        occupied.set(universe, list);
      }
    }
  }

  // Second pass: automatic packing in project order, per universe.
  for (const row of rows) {
    if (row.manual || !row.root || !row.channels) continue;
    const list = occupied.get(row.root.universe) || [];
    let start = 1;
    const fits = (candidate: number) => {
      const end = candidate + (row.channels || 0) - 1;
      return end <= 512 && !list.some((entry) => candidate <= entry.end && end >= entry.start);
    };
    while (start <= 512 && !fits(start)) start += 1;
    const end = start + row.channels - 1;
    if (end > 512) {
      diagnostics.push({
        id: `dmx-full-${row.objectId}`,
        severity: 'error',
        area: 'dmx',
        code: 'universe-full',
        message: `U${row.root.universe}: not enough Channels for ${row.name} (needs ${row.channels})`,
        objectIds: [row.objectId],
        hint: 'Free up addresses, move the fixture to another Universe, or add a node.',
      });
      row.status = 'error';
      continue;
    }
    row.address = start;
    row.end = end;
    row.status = row.status === 'error' ? 'error' : 'patched';
    list.push({ objectId: row.objectId, start, end });
    occupied.set(row.root.universe, list);
  }

  // Universes and capacity.
  for (const row of rows) {
    if (!row.root) continue;
    const entry = usage.get(row.root.universe) || {
      universe: row.root.universe,
      used: 0,
      fixtures: 0,
      capacity: 512,
      sources: [],
    };
    entry.fixtures += 1;
    if (!entry.sources.includes(row.root.sourceName)) entry.sources.push(row.root.sourceName);
    usage.set(row.root.universe, entry);
  }
  for (const [universe, list] of occupied) {
    const entry = usage.get(universe) || { universe, used: 0, fixtures: 0, capacity: 512, sources: [] };
    entry.used = list.reduce((sum, item) => sum + (item.end - item.start + 1), 0);
    usage.set(universe, entry);
  }

  // Port conflicts: two cables into the same input or out of the same output.
  const inputs = new Map<string, Connection>();
  const outputs = new Map<string, Connection>();
  for (const connection of project.connections) {
    const inputKey = `${connection.to}:${connection.toPort}`;
    if (inputs.has(inputKey)) {
      diagnostics.push({
        id: `port-input-${connection.id}`,
        severity: 'error',
        area: 'connection',
        code: 'port-occupied',
        message: 'Two cables connected to the same input',
        objectIds: [connection.to],
        connectionId: connection.id,
      });
    } else inputs.set(inputKey, connection);
    if (connection.type !== 'wireless') {
      const outputKey = `${connection.from}:${connection.fromPort}`;
      if (outputs.has(outputKey)) {
        diagnostics.push({
          id: `port-output-${connection.id}`,
          severity: 'error',
          area: 'connection',
          code: 'port-output-occupied',
          message: 'Two cables connected to the same output',
          objectIds: [connection.from],
          connectionId: connection.id,
        });
      } else outputs.set(outputKey, connection);
    }
  }

  return {
    rows,
    diagnostics,
    universes: [...usage.values()].sort((a, b) => a.universe - b.universe),
    patchedCount: rows.filter((row) => row.address !== null && row.root && row.status !== 'error').length,
    totalChannels: [...usage.values()].reduce((sum, entry) => sum + entry.used, 0),
  };
}

/** Assigns the current automatic addresses back onto the project. */
export function applyAutoPatch(project: Project): SceneObject[] {
  const patch = computeDmxPatch(project);
  const byId = new Map(patch.rows.map((row) => [row.objectId, row]));
  return project.objects.map((object) => {
    const row = byId.get(object.id);
    if (!row || row.status === 'error' || row.address === null || !object.fixture) return object;
    if (object.fixture.manualAddress) return object;
    return { ...object, fixture: { ...object.fixture, address: row.address, universe: row.universe ?? object.fixture.universe } };
  });
}

export function nextFreeAddress(project: Project, universe: number, channels: number, ignoreId?: string): number | null {
  const patch = computeDmxPatch(project);
  const used = patch.rows
    .filter((row) => row !== null && row.objectId !== ignoreId && row.universe === universe && row.address !== null && row.end !== null)
    .map((row) => [row.address as number, row.end as number] as const);
  for (let start = 1; start + channels - 1 <= 512; start++) {
    const end = start + channels - 1;
    if (!used.some(([a, b]) => start <= b && end >= a)) return start;
  }
  return null;
}

export function dmxRowFor(patch: DmxPatchResult, objectId: string): DmxRow | undefined {
  return patch.rows.find((row) => row.objectId === objectId);
}
