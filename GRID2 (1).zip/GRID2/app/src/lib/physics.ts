import type { ObjectCollision, ObjectPhysics, PhysicsSettings } from '../types/project';

export function defaultPhysics(): PhysicsSettings {
  return { enabled: false, gravity: { x: 0, y: -9.81, z: 0 }, timeScale: 1, paused: false, debug: false, quality: 'medium', resetToken: 0, stepToken: 0 };
}

export function defaultObjectPhysics(mode: ObjectPhysics['mode'] = 'dynamic'): ObjectPhysics {
  return {
    mode, mass: 1, friction: 0.4, restitution: 0.2, linearDamping: 0.1, angularDamping: 0.2, gravityScale: 1,
    velocity: { x: 0, y: 0, z: 0 }, angularVelocity: { x: 0, y: 0, z: 0 },
    lockPosition: { x: false, y: false, z: false }, lockRotation: { x: false, y: false, z: false },
  };
}

export function defaultCollision(): ObjectCollision {
  return { mode: 'on', shape: 'auto', layer: 'objects', mask: ['world', 'objects'] };
}

export function normalizePhysics(value: unknown): PhysicsSettings {
  const raw = value && typeof value === 'object' ? value as Partial<PhysicsSettings> : {};
  const base = defaultPhysics();
  return {
    ...base,
    enabled: raw.enabled === true,
    gravity: { x: Number(raw.gravity?.x ?? base.gravity.x), y: Number(raw.gravity?.y ?? base.gravity.y), z: Number(raw.gravity?.z ?? base.gravity.z) },
    timeScale: Math.max(0, Math.min(8, Number(raw.timeScale ?? 1))),
    paused: raw.paused === true,
    debug: raw.debug === true,
    quality: raw.quality === 'low' || raw.quality === 'high' || raw.quality === 'extreme' ? raw.quality : 'medium',
    resetToken: Number(raw.resetToken ?? 0),
    stepToken: Number(raw.stepToken ?? 0),
  };
}

export interface PhysicsBodySignal {
  velocity: number;
  angularSpeed: number;
  height: number;
  impact: number;
  distanceToGround: number;
  sleeping: number;
  trigger: number;
}

const bodySignals = new Map<string, PhysicsBodySignal>();

export function physicsSignalState(id: string): PhysicsBodySignal {
  return bodySignals.get(id) || { velocity: 0, angularSpeed: 0, height: 0, impact: 0, distanceToGround: 0, sleeping: 0, trigger: 0 };
}

export function setPhysicsSignalState(id: string, patch: Partial<PhysicsBodySignal>): void {
  bodySignals.set(id, { ...physicsSignalState(id), ...patch });
}

export function clearPhysicsSignalState(): void {
  bodySignals.clear();
}

export function impactDecay(dt: number): void {
  for (const [id, state] of bodySignals) bodySignals.set(id, { ...state, impact: Math.max(0, state.impact - dt * 2.5), trigger: Math.max(0, state.trigger - dt * 2) });
}

export function normalizeObjectPhysics(value: unknown): ObjectPhysics | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const raw = value as Partial<ObjectPhysics>;
  const base = defaultObjectPhysics(raw.mode === 'off' || raw.mode === 'static' || raw.mode === 'kinematic' ? raw.mode : 'dynamic');
  return {
    ...base,
    mode: raw.mode === 'off' || raw.mode === 'static' || raw.mode === 'kinematic' || raw.mode === 'dynamic' ? raw.mode : 'dynamic',
    mass: Math.max(0.0001, Number(raw.mass ?? 1)),
    friction: Math.max(0, Math.min(2, Number(raw.friction ?? 0.4))),
    restitution: Math.max(0, Math.min(2, Number(raw.restitution ?? 0.2))),
    linearDamping: Math.max(0, Math.min(2, Number(raw.linearDamping ?? 0.1))),
    angularDamping: Math.max(0, Math.min(2, Number(raw.angularDamping ?? 0.2))),
    gravityScale: Number(raw.gravityScale ?? 1),
    velocity: { x: Number(raw.velocity?.x ?? 0), y: Number(raw.velocity?.y ?? 0), z: Number(raw.velocity?.z ?? 0) },
    angularVelocity: { x: Number(raw.angularVelocity?.x ?? 0), y: Number(raw.angularVelocity?.y ?? 0), z: Number(raw.angularVelocity?.z ?? 0) },
    lockPosition: { x: raw.lockPosition?.x === true, y: raw.lockPosition?.y === true, z: raw.lockPosition?.z === true },
    lockRotation: { x: raw.lockRotation?.x === true, y: raw.lockRotation?.y === true, z: raw.lockRotation?.z === true },
  };
}

export function normalizeCollision(value: unknown): ObjectCollision | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const raw = value as Partial<ObjectCollision>;
  const base = defaultCollision();
  return {
    mode: raw.mode === 'off' || raw.mode === 'trigger' || raw.mode === 'on' ? raw.mode : 'on',
    shape: raw.shape && ['auto', 'box', 'sphere', 'capsule', 'cylinder', 'cone', 'convex', 'mesh'].includes(raw.shape) ? raw.shape : 'auto',
    layer: typeof raw.layer === 'string' ? raw.layer : 'objects',
    mask: Array.isArray(raw.mask) ? raw.mask.filter((entry): entry is string => typeof entry === 'string') : base.mask,
  };
}
