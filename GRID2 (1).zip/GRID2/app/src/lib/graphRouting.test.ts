import { describe, expect, it } from 'vitest';
import { applyAdapter, connect, typesCompatible, wouldCreateCycle } from './graphRouting';

const base = { id: 'ab', from: { nodeId: 'a', port: 'out', type: 'float' as const }, to: { nodeId: 'b', port: 'in', type: 'float' as const } };

describe('routing graph', () => {
  it('detects cycles', () => {
    expect(wouldCreateCycle([base], 'b', 'a')).toBe(true);
    expect(connect([base], { ...base, id: 'ba', from: base.to, to: base.from })).toEqual({ ok: false, error: 'Connection would create a dependency cycle.' });
  });
  it('applies reusable adapters', () => {
    expect(applyAdapter(0.5, { kind: 'remap', params: { inMin: 0, inMax: 1, outMin: -1, outMax: 1 } })).toBe(0);
    expect(applyAdapter(2, { kind: 'clamp', params: { min: 0, max: 1 } })).toBe(1);
    expect(applyAdapter([0.5, 0.25, 0], { kind: 'length' })).toBeCloseTo(Math.hypot(0.5, 0.25));
  });
  it('rejects silent incompatible type connections', () => {
    expect(typesCompatible('texture', 'float')).toBe(true);
    expect(typesCompatible('float', 'texture')).toBe(false);
  });
});

import { wouldCreateModifierCycle } from './graphRouting';

it('detects cycles in modifier modulation sockets', () => {
  const modifiers = [
    { id: 'a', modulators: { strength: { sourceType: 'modifier', sourceId: 'b' } } },
    { id: 'b', modulators: {} },
  ];
  expect(wouldCreateModifierCycle(modifiers as any, 'b', 'a')).toBe(true);
  expect(wouldCreateModifierCycle(modifiers as any, 'a', 'b')).toBe(false);
});

import { compileModifierOrder } from './graphRouting';

it('compiles deterministic modifier evaluation order', () => {
  const result = compileModifierOrder([
    { id: 'c', modulators: { amount: { sourceType: 'modifier', sourceId: 'b' } } },
    { id: 'a', modulators: {} },
    { id: 'b', modulators: { amount: { sourceType: 'modifier', sourceId: 'a' } } },
  ]);
  expect(result.order).toEqual(['a', 'b', 'c']);
  expect(result.cycles).toEqual([]);
  expect(compileModifierOrder([{ id: 'x', modulators: { amount: { sourceType: 'modifier', sourceId: 'x' } } }]).cycles).toEqual(['x']);
});

import { compileExecutionPlan, executionOrderedModifiers } from './modifiers';

it('builds stable execution-domain buckets', () => {
  const plan = compileExecutionPlan([
    { id: 'surface', type: 'liquidChrome' },
    { id: 'geometry', type: 'twist' },
    { id: 'light', type: 'lightIntensityNoise' },
  ]);
  expect(plan.domains.GEOMETRY).toEqual(['geometry']);
  expect(plan.domains.SURFACE).toEqual(['surface']);
  expect(plan.domains.LIGHT).toEqual(['light']);
  expect(plan.order).toEqual(['geometry', 'surface', 'light']);
  expect(executionOrderedModifiers([{ id: 'surface', type: 'liquidChrome' }, { id: 'geometry', type: 'twist' }, { id: 'light', type: 'lightIntensityNoise' }]).map((modifier) => modifier.id)).toEqual(['geometry', 'surface', 'light']);
});
