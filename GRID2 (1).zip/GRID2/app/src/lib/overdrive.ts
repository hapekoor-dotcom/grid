export const OVERDRIVE_MAX = 100;

export function clampOverdrive(value: number): number {
  if (Number.isNaN(value)) return 0;
  if (value === Number.POSITIVE_INFINITY) return OVERDRIVE_MAX;
  if (value === Number.NEGATIVE_INFINITY) return 0;
  return Math.max(0, Math.min(OVERDRIVE_MAX, value));
}

/**
 * Nonlinear travel: 60% of the track covers 0-100%, the next 25% covers
 * 100-1000%, and the final 15% covers 1000-10000%.
 */
export function sliderToOverdrive(slider: number): number {
  const t = Math.max(0, Math.min(1, slider));
  if (t <= 0.6) return (t / 0.6) * 1;
  if (t <= 0.85) return 1 + ((t - 0.6) / 0.25) * 9;
  return 10 + ((t - 0.85) / 0.15) * 90;
}

export function overdriveToSlider(value: number): number {
  const v = clampOverdrive(value);
  if (v <= 1) return (v / 1) * 0.6;
  if (v <= 10) return 0.6 + ((v - 1) / 9) * 0.25;
  return 0.85 + ((v - 10) / 90) * 0.15;
}

export function overdrivePercent(value: number): number {
  return Math.round(clampOverdrive(value) * 100);
}
