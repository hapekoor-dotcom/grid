import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource-variable/ibm-plex-sans/index.css';
import '@fontsource/ibm-plex-mono/cyrillic-400.css';
import '@fontsource/ibm-plex-mono/cyrillic-500.css';
import '@fontsource/ibm-plex-mono/latin-400.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import './styles/tokens.css';
import './styles/base.css';
import './styles/ui.css';
import './styles/layout.css';
import './styles/welcome.css';
import './styles/editor.css';
import './styles/panels.css';
import './styles/dialogs.css';
import './styles/viewport.css';
import { App } from './App';
import { ErrorBoundary } from './components/ErrorBoundary';
import { useWorkspaceStore } from './store/workspaceStore';
import { useUiStore } from './store/uiStore';
import { MODIFIER_DEFINITIONS } from './lib/modifiers';
import * as CustomShaders from './lib/customShaders';

(window as unknown as { __RE_STORE__: typeof useWorkspaceStore }).__RE_STORE__ = useWorkspaceStore;
(window as unknown as { __RE_MODIFIERS__: typeof MODIFIER_DEFINITIONS }).__RE_MODIFIERS__ = MODIFIER_DEFINITIONS;
(window as unknown as { __RE_CUSTOM__: typeof CustomShaders }).__RE_CUSTOM__ = CustomShaders;
(window as unknown as { __RE_UI__: typeof useUiStore }).__RE_UI__ = useUiStore;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
