import type { CableType } from './catalog';
import type { TimelineState } from './timeline';

export interface Point {
  x: number;
  z: number;
}

export type SceneObjectType = 'device' | 'room' | 'stage' | 'truss' | 'furniture' | 'seating' | 'crowd' | 'areabar' | 'model' | 'light';
export type GenericLightType = 'spot' | 'point' | 'area' | 'directional';
export type PrimitiveKind = 'box' | 'sphere' | 'cylinder' | 'plane' | 'cone' | 'torus';
export interface PrimitiveConfig { kind: PrimitiveKind; params: Record<string, number> }
export interface ObjectScale { x: number; y: number; z: number }
export type MaterialMapKind = 'baseColor' | 'metalness' | 'roughness' | 'normal' | 'emissive' | 'opacity' | 'ao';
export type MaterialMapChannel = 'r' | 'g' | 'b' | 'a' | 'rgb';

export interface MaterialTextureLayer {
  /** Asset-store id for an uploaded texture. Null/undefined uses the imported texture. */
  assetId?: string | null;
  assetName?: string | null;
  uv?: number;
  tiling?: { x: number; y: number };
  offset?: { x: number; y: number };
  /** Degrees. */
  rotation?: number;
  channel?: MaterialMapChannel;
  /** For roughness/gloss maps: true treats texels as roughness. */
  invert?: boolean;
  /** Emissive-map strength multiplier. */
  intensity?: number;
}

export interface ObjectMaterial {
  color?: string;
  roughness?: number;
  metalness?: number;
  emissive?: string;
  emissiveIntensity?: number;
  opacity?: number;
  doubleSided?: boolean;
  baseColorGain?: number;
  saturation?: number;
  contrast?: number;
  specularGain?: number;
  reflectionGain?: number;
  normalStrength?: number;
  roughnessRemap?: number;
  roughnessContrast?: number;
  metalnessResponseGain?: number;
  emissiveGain?: number;
  maps?: Partial<Record<MaterialMapKind, MaterialTextureLayer>>;
}

export type MountType = 'floor' | 'stage' | 'truss' | 'ceiling' | 'wall';

export interface FixtureState {
  modeId: string | null;
  universe: number;
  address: number | null;
  manualAddress: boolean;
  customChannels: number | null;
  wattsOverride: number | null;
  powerOn: boolean;
}

export interface LightSegment {
  intensity: number;
  color?: string;
}

export interface LightState {
  on: boolean;
  intensity: number;
  color: string;
  colorTemp: number;
  pan: number;
  tilt: number;
  zoom: number;
  strobe: number;
  focus: number;
  segments?: LightSegment[] | null;
}

export type SignalSourceKind = 'time' | 'sine' | 'saw' | 'triangle' | 'pulse' | 'noise' | 'fbm' | 'randomWalk' | 'sampleHold' | 'objectDistance' | 'objectDirection' | 'worldPosition' | 'normalDirection' | 'fresnel' | 'timeline' | 'velocity' | 'angularSpeed' | 'height' | 'impact' | 'distanceToGround' | 'sleeping' | 'trigger';

export interface SignalSource {
  id: string;
  name: string;
  kind: SignalSourceKind;
  enabled: boolean;
  params: Record<string, number | string | boolean>;
}

export interface ParameterAdapter {
  kind: string;
  params?: Record<string, number>;
}

export interface ParameterModulator {
  /** Signal is the historical default; modifier/reaction outputs are graph sources. */
  sourceType?: 'signal' | 'modifier' | 'reaction';
  output?: string;
  adapter?: ParameterAdapter;
  sourceId: string;
  amount: number;
  offset: number;
  enabled: boolean;
}

export interface SceneModifier {
  id: string;
  type: string;
  enabled: boolean;
  params: Record<string, number | string | boolean>;
  modulators?: Record<string, ParameterModulator>;
  /** Incremented to request an artistic history reset for this post pass. */
  historyResetToken?: number;
}

export interface EffectGroup {
  id: string;
  name: string;
  enabled: boolean;
  targetIds: string[];
  modifiers: SceneModifier[];
}

export interface SeatingConfig {
  rows: number;
  columns: number;
  seatPitch: number;
  rowPitch: number;
}


export interface PhysicsSettings {
  enabled: boolean;
  gravity: { x: number; y: number; z: number };
  timeScale: number;
  paused: boolean;
  debug: boolean;
  quality: 'low' | 'medium' | 'high' | 'extreme';
  resetToken: number;
  stepToken: number;
}

export interface ObjectPhysics {
  mode: 'off' | 'static' | 'dynamic' | 'kinematic';
  mass: number;
  friction: number;
  restitution: number;
  linearDamping: number;
  angularDamping: number;
  gravityScale: number;
  velocity: { x: number; y: number; z: number };
  angularVelocity: { x: number; y: number; z: number };
  lockPosition: { x: boolean; y: boolean; z: boolean };
  lockRotation: { x: boolean; y: boolean; z: boolean };
}

export interface ObjectCollision {
  mode: 'off' | 'on' | 'trigger';
  shape: 'auto' | 'box' | 'sphere' | 'capsule' | 'cylinder' | 'cone' | 'convex' | 'mesh';
  layer: string;
  mask: string[];
}


export type CustomShaderContext = 'mesh' | 'post';

export interface CustomShaderParam {
  id: string;
  label: string;
  type: 'float' | 'int' | 'bool' | 'vec2' | 'vec3' | 'vec4' | 'color';
  default: number | number[] | boolean;
  shortDescription?: string;
  recommendedMin?: number;
  recommendedMax?: number;
  hardClamp?: boolean;
  unit?: string;
  animatable?: boolean;
}

export interface CustomShader {
  id: string;
  name: string;
  context: CustomShaderContext;
  mode: 'pbr-extension' | 'full-custom';
  vertex: string;
  fragment: string;
  wgsl?: string;
  params: CustomShaderParam[];
  lastWorking?: { vertex: string; fragment: string };
  boundsExpansion?: number;
  cost?: 'low' | 'medium' | 'high' | 'extreme';
  createdAt: string;
  updatedAt: string;
}

export interface ShaderInstance {
  /** Stable identity for scene post-stack passes. */
  id?: string;
  shaderId: string;
  enabled: boolean;
  values: Record<string, number | number[] | boolean>;
  modulators?: Record<string, ParameterModulator>;
  /** Incremented to request an artistic history reset for this post pass. */
  historyResetToken?: number;
}

export interface ReactionDiffusionConfig {
  id: string;
  enabled: boolean;
  paused: boolean;
  preset: string;
  feed: number;
  kill: number;
  diffusionA: number;
  diffusionB: number;
  timeStep: number;
  speed: number;
  iterations: number;
  resolution: number;
  seed: number;
  contrast: number;
  threshold: number;
  invert: boolean;
  injection: number;
  injectionRadius: number;
  paintChemical?: 'A' | 'B';
  resetToken: number;
  modulators?: Record<string, ParameterModulator>;
  /** Incremented to request an artistic history reset for this post pass. */
  historyResetToken?: number;
}

export interface FieldLink {
  id: string;
  source: 'reaction';
  output: 'scalar' | 'mask' | 'gradient' | 'normal' | 'vector';
  modifierId: string;
  slot: 'field';
  adapter?: 'threshold' | 'remap' | 'invert' | 'smoothstep' | 'multiply' | 'add' | 'power' | 'quantize';
  params?: { a?: number; b?: number };
}

export interface MaterialLook {
  id: string;
  name: string;
  material: ObjectMaterial;
  modifiers?: SceneModifier[];
  shaders?: ShaderInstance[];
  createdAt: string;
}

export interface SceneObject {
  id: string;
  type: SceneObjectType;
  name: string;
  deviceId: string | null;
  position: Point;
  rotation: number;
  elevation: number;
  rotationX?: number;
  rotationZ?: number;
  scale?: ObjectScale;
  modelVisible?: boolean;
  assetId?: string | null;
  assetName?: string | null;
  lightType?: GenericLightType;
  range?: number;
  volumetric?: number;
  beamInner?: number;
  beamOuter?: number;
  castShadows?: boolean;
  receiveShadows?: boolean;
  material?: ObjectMaterial | null;
  lookId?: string;
  shaders?: ShaderInstance[];
  physics?: ObjectPhysics;
  collision?: ObjectCollision;
  materialOverrides?: Record<string, ObjectMaterial>;
  materialSlots?: string[];
  primitive?: PrimitiveConfig | null;
  modifiers?: SceneModifier[];
  size: { w: number; d: number; h: number } | null;
  mount: MountType;
  visible: boolean;
  locked: boolean;
  groupId: string | null;
  room: { wallHeight: number; walls: boolean; floorColor: string; wallColor: string } | null;
  stage: { color: string; label: string } | null;
  seating?: SeatingConfig | null;
  fixture: FixtureState | null;
  light: LightState | null;
  dmxSourceUniverses: Record<string, number>;
  portDirections: Record<string, 'in' | 'out'>;
  portPhases: Record<string, string>;
  portPhasesThreePhase: boolean;
  powerLimits: Record<string, number>;
  outputLimits: Record<string, number>;
  circuitId: string;
  totalPowerLimit: number | null;
  outputs: number | null;
  notes: string;
}

export interface Connection {
  id: string;
  type: CableType;
  from: string;
  fromPort: string;
  to: string;
  toPort: string;
  waypoints: Point[];
  note: string;
}

export interface Guide {
  id: string;
  axis: 'x' | 'z';
  position: number;
}

export interface LightPreset {
  id: string;
  name: string;
  values: Record<string, Partial<LightState>>;
  createdAt: string;
}

export interface FixtureGroup {
  id: string;
  name: string;
  memberIds: string[];
}

export interface LightingSettings {
  groups: FixtureGroup[];
  presets: LightPreset[];
  master: number;
  ambient: number;
  haze: number;
  anisotropy: number;
  exposure: number;
  bloom: number;
  bloomStrength?: number;
  quality: 'low' | 'medium' | 'high' | 'ultra' | 'photo';
  volumetric: boolean;
  dithering?: 'off' | 'static' | 'temporal';
  ditherStrength?: number;
  antiAliasing?: 'off' | 'msaa' | 'taa';
  taaJitter?: number;
  showWalls: boolean;
  showFloor?: boolean;
  workLight: boolean;
  activePresetId: string | null;
}

export interface ProjectSettings {
  gridSize: number;
  snap: boolean;
  showGrid: boolean;
  showRulers: boolean;
  showBeams: boolean;
  showLabels: boolean;
  units: 'm';
  venueHeight: number;
  wallTransparency: boolean;
}

export interface ProjectView {
  plan: { panX: number; panY: number; zoom: number };
  camera3d: { azimuth: number; polar: number; distance: number } | null;
  cameraPreset?: 'perspective' | 'front' | 'top' | 'side';
}

export interface MigrationInfo {
  fromVersion: number;
  importedAt: string;
  warnings: string[];
  importedObjects: number;
  importedConnections: number;
}

export interface MutationRecord {
  id: string;
  parentId: string | null;
  branchId: string;
  seed: number;
  depth: number;
  scope: 'object' | 'look' | 'scene';
  createdAt: string;
  /** Serialized project configuration before/after this mutation. */
  before: string;
  after: string;
  diff: string[];
}

export interface MutationState {
  accepted: MutationRecord[];
  branchId: string;
}

export interface Project {
  schemaVersion: 5;
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  settings: ProjectSettings;
  objects: SceneObject[];
  connections: Connection[];
  guides: Guide[];
  lighting: LightingSettings;
  effects?: SceneModifier[];
  signals?: SignalSource[];
  effectGroups?: EffectGroup[];
  physics?: PhysicsSettings;
  fields?: SceneModifier[];
  looks?: MaterialLook[];
  customShaders?: CustomShader[];
  postShaders?: ShaderInstance[];
  reactionDiffusion?: ReactionDiffusionConfig;
  fieldLinks?: FieldLink[];
  mutation?: MutationState;
  timeline: TimelineState;
  view: ProjectView;
  migration: MigrationInfo | null;
}

export interface WorkspaceFile {
  schemaVersion: 1;
  activeProjectId: string | null;
  projects: Project[];
}
