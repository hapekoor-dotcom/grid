export type CableType = 'power' | 'dmx' | 'ethernet' | 'usb' | 'video' | 'wireless';
export type PortDirection = 'in' | 'out' | 'bi';

export interface PortDef {
  id: string;
  type: CableType;
  direction: PortDirection;
  connector: string;
  label: string;
  universeIndex?: number;
  powerOnly?: boolean;
  derived?: boolean;
  configurable?: boolean;
  domain?: 'ac' | 'dc';
  maxWatts?: number;
}

export interface DmxMode {
  id: string;
  label: string;
  channels: number;
}

export interface DeviceDims {
  w: number;
  d: number;
  h: number;
  source: 'manufacturer' | 'planning';
}

export interface VerificationInfo {
  status: 'verified' | 'partial' | 'unresolved' | 'generic' | 'not_applicable';
  note: string;
  missingFields: string[];
  checkedAt: string | null;
  checkedFields: string[];
}

export interface DeviceCapabilities {
  dimmer: boolean;
  color: boolean;
  pan: boolean;
  tilt: boolean;
  zoom: boolean;
  strobe: boolean;
  focus: boolean;
}

export interface CatalogDevice {
  id: string;
  name: string;
  shortName: string;
  brand: string | null;
  category: string;
  kind: string;
  rawKind: string;
  generic: boolean;
  hidden: boolean;
  requiresProfile: boolean;
  sourceType: boolean;
  sourceUrls: string[];
  verification: VerificationInfo;
  notes: string[];
  modes: DmxMode[];
  defaultModeId: string | null;
  defaultChannels: number | null;
  dmx: boolean;
  dmxPhysical: boolean;
  wirelessProtocol: string | null;
  dmxConnector: string;
  powerConnector: string;
  watts: number | null;
  wattsBasis: string;
  consumes: boolean;
  powerLink: boolean;
  internalBattery: boolean;
  usbPowered: boolean;
  ethernet: boolean;
  usb: boolean;
  video: boolean;
  videoConnector: string;
  colorSystem: string;
  protocols: string[];
  capabilities: DeviceCapabilities;
  beamAngle: { min: number; max: number };
  panRange: number;
  tiltRange: number;
  lensCount: number;
  dims: DeviceDims;
  weightKg: number | null;
  planSize: { w: number; d: number };
  signalPorts: PortDef[];
  powerPorts: PortDef[];
  loadKg: number | null;
  catalogSubtitle: string;
  powerRole: string;
  planning: boolean;
  aliasOf?: string;
}

export interface CatalogFile {
  schemaVersion: number;
  generatedAt: string;
  note: string;
  categories: { id: string; label: string }[];
  groups: { id: string; category: string; kind: string; label: string; count: number }[];
  devices: CatalogDevice[];
}
