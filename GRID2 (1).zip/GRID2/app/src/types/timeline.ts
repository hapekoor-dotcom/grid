export type TimelineEasing = 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | 'step';

export interface TimelineKeyframe {
  id: string;
  time: number;
  value: number | string | boolean;
  easing: TimelineEasing;
}

export interface TimelineTrack {
  id: string;
  objectId: string | null;
  propertyPath: string;
  label?: string;
  keyframes: TimelineKeyframe[];
}

export type TimelineClipType = 'pulse' | 'wave' | 'rotate' | 'noise';

export type GroupEffectPhaseMode = 'left-right' | 'right-left' | 'front-back' | 'center' | 'sequential' | 'random' | 'custom';

export interface GroupEffect {
  id: string;
  type: 'groupWave';
  enabled: boolean;
  targetIds: string[];
  propertyPath: string;
  start: number;
  end: number;
  fadeIn: number;
  fadeOut: number;
  params: {
    frequency: number;
    phaseSpread: number;
    phaseMode: GroupEffectPhaseMode;
    basePhase?: number;
    min: number;
    max: number;
    waveform: 'sine' | 'triangle' | 'square';
    colorFrom?: string;
    colorTo?: string;
  };
}

export interface TimelineClip {
  id: string;
  type: TimelineClipType;
  objectId: string | null;
  propertyPath: string;
  start: number;
  end: number;
  enabled: boolean;
  fadeIn: number;
  fadeOut: number;
  params: Record<string, number | string | boolean>;
}

export interface TimelineState {
  duration: number;
  loop: boolean;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  groupEffects: GroupEffect[];
}

export function createDefaultTimeline(): TimelineState {
  return { duration: 10, loop: true, tracks: [], clips: [], groupEffects: [] };
}
