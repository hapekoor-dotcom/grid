import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { ObjectInspector } from '../inspector/ObjectInspector';
import { MultiInspector } from '../inspector/MultiInspector';
import { ProjectOverview } from '../inspector/ProjectOverview';
import { ConnectionInspector } from '../inspector/ConnectionInspector';
import { LightingPanel } from '../lighting/LightingPanel';
import { PanelResizer } from '../shell/PanelResizer';
import { ScrollCue } from '../ui/ScrollCue';
import { useRef } from 'react';

export function RightPanel() {
  const project = useActiveProject();
  const mode = useUiStore((state) => state.mode);
  const selectedIds = useUiStore((state) => state.selectedIds);
  const selectedConnectionId = useUiStore((state) => state.selectedConnectionId);
  const rightOpen = useUiStore((state) => state.rightOpen);
  const panelRef = useRef<HTMLElement>(null);

  if (!project || !rightOpen) return null;
  const selectedObjects = project.objects.filter((object) => selectedIds.includes(object.id));
  const connection = selectedConnectionId ? project.connections.find((entry) => entry.id === selectedConnectionId) : null;

  let content;
  if (mode === 'light' || (mode === '3d' && !connection && selectedObjects.length === 0)) {
    content = <LightingPanel project={project} />;
  } else if (connection) {
    content = <ConnectionInspector connection={connection} project={project} />;
  } else if (selectedObjects.length === 1) {
    content = <ObjectInspector object={selectedObjects[0]} />;
  } else if (selectedObjects.length > 1) {
    content = <MultiInspector objects={selectedObjects} project={project} />;
  } else {
    content = <ProjectOverview project={project} />;
  }

  return (
    <aside ref={panelRef} className="panel right-panel" aria-label="Inspector">
      <PanelResizer side="right" />
      {content}
      <ScrollCue containerRef={panelRef} />
    </aside>
  );
}
