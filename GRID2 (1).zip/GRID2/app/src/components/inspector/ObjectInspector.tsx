import type { ReactNode } from 'react';
import {
  AlertTriangle, Armchair, ArrowLeftRight, Box, Cable, Check, CircleDot, Copy, ExternalLink,
  Eye, EyeOff, Gauge, Info, Lock, MapPin, Network, RotateCw, Trash2, Unlock, Unplug, Zap,
} from 'lucide-react';
import type { CableType, CatalogDevice } from '../../types/catalog';
import type { Project, SceneObject } from '../../types/project';
import { CABLE_META, getDevice, getMode, verificationLabel, dimsLabel, wattsLabel } from '../../lib/catalog';
import { effectiveWatts, getObjectPorts, isDmxSource, objectDims, portUniverse } from '../../lib/objects';
import { formatWatts } from '../../lib/id';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { useAnalysis } from '../../lib/analysis';
import { Button, IconButton } from '../ui/Button';
import { CommitText } from '../ui/CommitText';
import { Field, NumberInput, Segmented, Select, Slider, Toggle } from '../ui/Field';
import { LightControls } from '../lighting/LightControls';
import { GenericInspector } from './GenericInspector';
import { FixtureInspector } from './FixtureInspector';

const MISSING_LABELS: Record<string, string> = {
  modes: 'DMX modes',
  connectors: 'connectors',
  watts: 'power',
  powerLink: 'power pass-through',
  model: 'exact model',
  dmxConnector: 'DMX connector',
  maxPower: 'maximum power',
  powerConnector: 'power connector',
  signalPorts: 'signal ports',
  dmxConnectorVariant: 'DMX connector variant',
  powerPortDefinitions: 'power ports',
};

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

function InfoRow({ label, value, mono, tone }: { label: string; value: ReactNode; mono?: boolean; tone?: 'ok' | 'warn' | 'danger' }) {
  return (
    <div className="info-row">
      <span>{label}</span>
      <span className={`info-value ${mono ? 'num' : ''} ${tone ? `info-value--${tone}` : ''}`}>{value}</span>
    </div>
  );
}

const STRUCTURE_LABELS: Record<string, string> = {
  room: 'Room',
  stage: 'Stage or zone',
  truss: 'Truss',
  furniture: 'Layout object',
  seating: 'Seating',
  crowd: 'Crowd',
  device: 'Fixture',
  areabar: 'Area Bar',
};

function Section({ title, children, action, collapsed = false }: { title: string; children: ReactNode; action?: ReactNode; collapsed?: boolean }) {
  if (collapsed) {
    return (
      <details className="inspector-section inspector-details">
        <summary className="section-label">
          <span>{title}</span>
          {action}
        </summary>
        {children}
      </details>
    );
  }
  return (
    <section className="inspector-section">
      <div className="section-label">
        <span>{title}</span>
        {action}
      </div>
      {children}
    </section>
  );
}

export function ObjectInspector({ object }: { object: SceneObject }) {
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const analysis = useAnalysis();
  const updateObject = useWorkspaceStore((state) => state.updateObject);
  const updateLight = useWorkspaceStore((state) => state.updateLight);
  const setManualAddress = useWorkspaceStore((state) => state.setManualAddress);
  const replaceMode = useWorkspaceStore((state) => state.replaceMode);
  const setPowerState = useWorkspaceStore((state) => state.setPowerState);
  const deleteSelection = useWorkspaceStore((state) => state.deleteSelection);
  const duplicateSelection = useWorkspaceStore((state) => state.duplicateSelection);
  const lockSelection = useWorkspaceStore((state) => state.lockSelection);
  const hideSelection = useWorkspaceStore((state) => state.hideSelection);
  const selectConnection = useUiStore((state) => state.selectConnection);
  const setTool = useUiStore((state) => state.setTool);
  const setMode = useUiStore((state) => state.setMode);
  const setCableStart = useUiStore((state) => state.setCableStart);
  const select = useUiStore((state) => state.select);
  const focusCamera = useUiStore((state) => state.focusCamera);
  const pushToast = useUiStore((state) => state.pushToast);

  if (!project) return null;
  if (object.type === 'model' || object.type === 'light') return <GenericInspector object={object} />;
  if (object.type === 'device') return <FixtureInspector object={object} project={project} />;
  const device = getDevice(object.deviceId);
  const dims = objectDims(object);
  const dmx = analysis.dmx.rows.find((row) => row.objectId === object.id);
  const powerRow = analysis.power.rows.find((row) => row.objectId === object.id);
  const ports = getObjectPorts(object);
  const connectedConnections = project.connections.filter((connection) => connection.from === object.id || connection.to === object.id);
  const verification = device ? verificationLabel(device) : { label: 'Model not found', tone: 'warn' as const };
  const isFixture = !!object.fixture && !!device && ['light', 'effects'].includes(device.category);
  const source = device?.sourceType;
  const isDistro = device?.kind === 'distro';
  const dmxOutputs = ports.filter((port) => port.type === 'dmx' && port.direction !== 'in');
  const powerOutputs = ports.filter((port) => port.type === 'power' && port.direction !== 'in');
  const phaseKeys = object.portPhasesThreePhase ? ['L1', 'L2', 'L3'] : ['L1'];

  const updatePosition = (axis: 'x' | 'z', value: number | null) => {
    updateObject(object.id, { position: { ...object.position, [axis]: value ?? 0 } });
  };
  const updateAreaLight = (patch: Partial<NonNullable<SceneObject['light']>>) => {
    if (!object.light) return;
    updateObject(object.id, { light: { ...object.light, ...patch } });
  };
  const updateSize = (axis: 'w' | 'd' | 'h', value: number | null) => {
    if (value === null) return;
    const next = { ...dims, [axis]: Math.max(0.05, value) };
    updateObject(object.id, {
      size: next,
      ...(object.type === 'room' ? { room: { ...(object.room || { walls: true, floorColor: '#6f6b63', wallColor: '#74736d', wallHeight: 4.5 }), wallHeight: next.h } } : {}),
      ...(object.type === 'stage' ? { elevation: next.h } : {}),
      ...(object.type === 'seating' && object.seating ? { seating: {
        ...object.seating,
        columns: Math.max(1, Math.floor(next.w / object.seating.seatPitch)),
        rows: Math.max(1, Math.floor(next.d / object.seating.rowPitch)),
      } } : {}),
    });
  };
  const updateLimit = (phase: string, value: number | null) => {
    const next = { ...object.powerLimits };
    if (value === null || value <= 0) delete next[phase];
    else next[phase] = value;
    updateObject(object.id, { powerLimits: next });
  };
  const updatePhase = (portId: string, phase: string) => {
    updateObject(object.id, { portPhases: { ...object.portPhases, [portId]: phase } });
  };
  const updateOutputLimit = (portId: string, value: number | null) => {
    const next = { ...object.outputLimits };
    if (value === null || value <= 0) delete next[portId];
    else next[portId] = value;
    updateObject(object.id, { outputLimits: next });
  };
  const startCable = (portId: string, portType: CableType) => {
    setMode('plan');
    setTool('cable');
    setCableStart({ objectId: object.id, portId });
    pushToast(`${CABLE_META[portType].label}: choose the second port`, 'default');
  };
  const flipPort = (portId: string) => {
    const port = ports.find((entry) => entry.id === portId);
    if (!port || !port.configurable) return;
    const nextDirection = port.direction === 'out' ? 'in' : 'out';
    updateObject(object.id, { portDirections: { ...object.portDirections, [portId]: nextDirection } });
  };

  return (
    <>
      <div className="panel-head inspector-head">
        <span className="inspector-type-icon">
          {object.type === 'room' ? <MapPin /> : object.type === 'truss' ? <Network /> : object.type === 'stage' ? <Box /> : <CircleDot />}
        </span>
        <div className="inspector-title-block">
          <CommitText
            value={object.name}
            className="inspector-title-input"
            ariaLabel="Object name"
            maxLength={80}
            onCommit={(value) => updateObject(object.id, { name: value.trim().slice(0, 80) || object.name })}
          />
          <span className="inspector-kind">{STRUCTURE_LABELS[object.type] || 'Object'}</span>
        </div>
        <details className="inspector-more">
          <summary aria-label="More actions" title="More actions">•••</summary>
          <div className="inspector-more-menu">
            <button type="button" onClick={() => hideSelection(!object.visible)}>{object.visible ? <EyeOff /> : <Eye />} {object.visible ? 'Hide' : 'Show'}</button>
            <button type="button" onClick={() => lockSelection(!object.locked)}>{object.locked ? <Unlock /> : <Lock />} {object.locked ? 'Unlock' : 'Lock'}</button>
            <button type="button" onClick={() => { setMode('3d'); focusCamera(object.id); }}><Box /> Focus in 3D</button>
            <button type="button" onClick={() => duplicateSelection()}><Copy /> Duplicate</button>
            <span className="inspector-more-sep" />
            <button type="button" className="danger" onClick={() => deleteSelection()}><Trash2 /> Delete</button>
          </div>
        </details>
      </div>

      <div className="panel-body inspector-body">
        {device && (
          <div className="device-identity inspector-device-line">
            <div>
              <strong>{device.name}</strong>
              <span className="dim">{device.brand || ''}{device.brand ? ' · ' : ''}{device.catalogSubtitle || device.kind}</span>
            </div>
            <span className={`badge badge--${verification.tone === 'ok' ? 'ok' : verification.tone === 'warn' ? 'warn' : 'muted'}`}>{verification.label}</span>
          </div>
        )}

        {true && (
          <Section title="Dimensions">
            <div className="form-grid">
              <Field label={object.type === 'truss' ? 'Length' : 'Width'}>
                <NumberInput value={dims.w} onChange={(value) => updateSize('w', value)} min={0.1} step={0.05} suffix="m" ariaLabel="Object width" />
              </Field>
              <Field label="Depth">
                <NumberInput value={dims.d} onChange={(value) => updateSize('d', value)} min={0.1} step={0.05} suffix="m" ariaLabel="Object depth" />
              </Field>
              {object.type === 'room' ? (
                <Field label="Wall height">
                  <NumberInput value={dims.h} onChange={(value) => updateSize('h', value)} min={1} step={0.1} suffix="m" ariaLabel="Wall height" />
                </Field>
              ) : object.type !== 'furniture' && object.type !== 'seating' && object.type !== 'crowd' ? (
                <Field label="Height">
                  <NumberInput value={dims.h} onChange={(value) => updateSize('h', value)} min={0.05} step={0.05} suffix="m" ariaLabel="Object height" />
                </Field>
              ) : null}
            </div>
          </Section>
        )}

        <Section title="Visibility">
          <div className="row-between">
            <span className="field-label">Visible in 3D</span>
            <Toggle checked={object.modelVisible !== false} ariaLabel="Visible in 3D" onChange={(checked) => updateObject(object.id, { modelVisible: checked })} />
          </div>
          {object.light && (
            <div className="row-between">
              <span className="field-label">Light enabled</span>
              <Toggle checked={object.light.on} ariaLabel="Light enabled" onChange={(checked) => updateObject(object.id, { light: { ...object.light!, on: checked } })} />
            </div>
          )}
        </Section>

        {object.type === 'room' && object.room && (
          <Section title="Appearance">
            <Toggle
              checked={object.room.walls}
              label="Show walls in 3D"
              onChange={(checked) => updateObject(object.id, { room: { ...object.room!, walls: checked } })}
            />
            <div className="form-grid">
              <Field label="Wall color">
                <input type="color" className="color-input" aria-label="Wall color" value={object.room.wallColor || '#74736d'} onChange={(event) => updateObject(object.id, { room: { ...object.room!, wallColor: event.target.value } })} />
              </Field>
              <Field label="Floor color">
                <input type="color" className="color-input" aria-label="Floor color" value={object.room.floorColor || '#6f6b63'} onChange={(event) => updateObject(object.id, { room: { ...object.room!, floorColor: event.target.value } })} />
              </Field>
            </div>
          </Section>
        )}

        {object.type === 'areabar' && object.light && (
          <Section title="Area light">
            <div className="row-between">
              <span className="field-label">Output</span>
              <Toggle checked={object.light.on} ariaLabel="Toggle area light" onChange={(checked) => updateAreaLight({ on: checked })} />
            </div>
            <Field label="Height above floor">
              <NumberInput value={object.elevation} min={0} max={20} step={0.05} suffix="m" ariaLabel="Area bar height" onChange={(value) => updateObject(object.id, { elevation: Math.max(0, value ?? 0) })} />
            </Field>
            <div className="form-grid">
              <Field label="Intensity, %">
                <NumberInput value={Math.round(object.light.intensity * 100)} min={0} max={1000} step={1} suffix="%" ariaLabel="Area light intensity" onChange={(value) => updateAreaLight({ intensity: Math.max(0, Math.min(10, (value ?? 100) / 100)) })} />
              </Field>
              <Field label="Beam angle">
                <NumberInput value={object.light.zoom} min={10} max={80} step={1} suffix="°" ariaLabel="Area light beam angle" onChange={(value) => updateAreaLight({ zoom: Math.max(10, Math.min(80, value ?? 40)) })} />
              </Field>
              <Field label="Color">
                <input type="color" className="color-input" aria-label="Area light color" value={object.light.color} onChange={(event) => updateAreaLight({ color: event.target.value })} />
              </Field>
            </div>
            <p className="field-hint">Rect area light · 16 m range · black housing with a white tube.</p>
          </Section>
        )}

        <Section title="Position" collapsed>
          <div className="form-grid form-grid--3">
            <Field label="X">
              <NumberInput value={object.position.x} onChange={(value) => updatePosition('x', value)} step={0.05} suffix="m" ariaLabel="Position X" />
            </Field>
            <Field label="Y">
              <NumberInput value={object.elevation} onChange={(value) => updateObject(object.id, { elevation: value ?? 0 })} step={0.05} suffix="m" ariaLabel="Position Y" />
            </Field>
            <Field label="Z">
              <NumberInput value={object.position.z} onChange={(value) => updatePosition('z', value)} step={0.05} suffix="m" ariaLabel="Position Z" />
            </Field>
          </div>
          <div className="form-grid">
            <Field label="Rot X">
              <NumberInput value={object.rotationX || 0} onChange={(value) => updateObject(object.id, { rotationX: value ?? 0 })} step={5} suffix="°" ariaLabel="Rotation X" />
            </Field>
            <Field label="Rot Y">
              <NumberInput value={object.rotation} onChange={(value) => updateObject(object.id, { rotation: value ?? 0 })} step={5} suffix="°" ariaLabel="Rotation Y" />
            </Field>
            <Field label="Rot Z">
              <NumberInput value={object.rotationZ || 0} onChange={(value) => updateObject(object.id, { rotationZ: value ?? 0 })} step={5} suffix="°" ariaLabel="Rotation Z" />
            </Field>
          </div>
        </Section>

        {device && (
          <Section title="Specifications" collapsed>
            <div className="info-list">
              <InfoRow label="Dimensions" value={dimsLabel(device)} mono />
              <InfoRow label="Power" value={wattsLabel(device)} />
              {device.colorSystem && <InfoRow label="Color system" value={device.colorSystem} />}
              {device.dmxConnector && <InfoRow label="DMX connector" value={device.dmxConnector} />}
              {device.weightKg !== null && <InfoRow label="Weight" value={`${device.weightKg} kg`} mono />}
            </div>
          </Section>
        )}

        {object.type === 'seating' && object.seating && (
          <Section title="Seating">
            <div className="form-grid">
              <Field label="Rows">
                <NumberInput value={object.seating.rows} min={1} max={80} step={1} ariaLabel="Rows" onChange={(value) => updateObject(object.id, { seating: { ...object.seating!, rows: Math.max(1, Math.round(value ?? 1)) } })} />
              </Field>
              <Field label="Seats per row">
                <NumberInput value={object.seating.columns} min={1} max={80} step={1} ariaLabel="Seats per row" onChange={(value) => updateObject(object.id, { seating: { ...object.seating!, columns: Math.max(1, Math.round(value ?? 1)) } })} />
              </Field>
              <Field label="Seat pitch">
                <NumberInput value={object.seating.seatPitch} min={0.35} max={1.5} step={0.01} suffix="m" ariaLabel="Seat pitch" onChange={(value) => updateObject(object.id, { seating: { ...object.seating!, seatPitch: Math.max(0.35, value ?? 0.62) } })} />
              </Field>
              <Field label="Row pitch">
                <NumberInput value={object.seating.rowPitch} min={0.5} max={2.5} step={0.01} suffix="m" ariaLabel="Row pitch" onChange={(value) => updateObject(object.id, { seating: { ...object.seating!, rowPitch: Math.max(0.5, value ?? 0.95) } })} />
              </Field>
            </div>
            <div className="field-hint"><Armchair size={12} /> {object.seating.rows * object.seating.columns} seats.</div>
          </Section>
        )}

        {isFixture && (
          <Section title="DMX" action={<span className={`badge ${dmx?.status === 'patched' ? 'badge--ok' : dmx?.status === 'error' ? 'badge--danger' : 'badge--warn'}`}>{dmx?.status === 'patched' ? 'Patched' : dmx?.status === 'error' ? 'Error' : 'Unassigned'}</span>}>
            <Field label="Mode">
              {device && device.modes.length ? (
                <Select
                  value={object.fixture?.modeId || ''}
                  ariaLabel="DMX mode"
                  onChange={(value) => replaceMode(object.id, value)}
                  options={device.modes.map((mode) => ({ value: mode.id, label: `${mode.label} · ${mode.channels} CH` }))}
                />
              ) : (
                <div className="stack">
                  <NumberInput
                    value={object.fixture?.customChannels ?? null}
                    min={1}
                    max={512}
                    step={1}
                    suffix="CH"
                    ariaLabel="Custom channels"
                    placeholder="No channel data"
                    onChange={(value) => updateObject(object.id, {
                      fixture: object.fixture ? { ...object.fixture, customChannels: value === null ? null : Math.round(value), modeId: null } : null,
                    })}
                  />
                  <span className="field-hint">Mode is not confirmed by documentation. Enter the channel size manually or leave it unknown.</span>
                </div>
              )}
            </Field>
            <div className="form-grid">
              <Field label="Universe">
                <div className="input-group"><input className="input input--mono" value={dmx?.universe ? `U${dmx.universe}` : '—'} readOnly aria-label="Universe" /></div>
              </Field>
              <Field label="Address">
                <NumberInput
                  value={dmx?.address ?? null}
                  min={1}
                  max={512}
                  step={1}
                  ariaLabel="DMX address"
                  placeholder="auto"
                  onChange={(value) => setManualAddress(object.id, value)}
                />
              </Field>
            </div>
            <div className="row-between dmx-address-row">
              <span className="field-hint">
                {dmx?.channels ? `${dmx.channels} channels${dmx.manual ? ' · manual address' : ' · auto patched'}` : 'Channel size not set'}
              </span>
              <button type="button" className="btn btn--sm btn--ghost" onClick={() => setManualAddress(object.id, null)}>Auto</button>
            </div>
            {dmx?.root && (
              <InfoRow label="Line" value={`${dmx.root.sourceName} · ${dmx.root.sourcePort}`} />
            )}
          </Section>
        )}

        {object.light && object.type !== 'areabar' && (
          <Section title="Light">
            <LightControls project={project} objects={[object]} compact />
          </Section>
        )}

        {device && (device.consumes || source || isDistro) && (
          <Section title="Power" collapsed action={<span className={`badge ${powerRow?.status === 'ok' ? 'badge--ok' : powerRow?.status === 'unknown' ? 'badge--warn' : powerRow?.status === 'unpowered' ? 'badge--danger' : 'badge--muted'}`}>{powerRow?.status === 'ok' ? 'Accounted' : powerRow?.status === 'unknown' ? 'Power ?' : powerRow?.status === 'unpowered' ? 'Unpowered' : 'Source'}</span>}>
            <div className="info-list">
              <InfoRow label="Consumption" value={formatWatts(effectiveWatts(object))} mono />
              {device.wattsBasis && <InfoRow label="Basis" value={device.wattsBasis === 'manufacturer' ? 'documentation' : device.wattsBasis === 'typical' ? 'typical' : device.wattsBasis === 'maximum' ? 'maximum' : device.wattsBasis === 'lamp-rating' ? 'lamp rating' : 'unconfirmed'} />}
              {powerRow?.chain && <InfoRow label="Circuit" value={`${powerRow.chain.sourceName} · ${powerRow.chain.phase}`} />}
            </div>
            {isFixture && (
              <div className="form-grid">
                <Field label="Power override, W" hint="Leave empty to use catalog data">
                  <NumberInput
                    value={object.fixture?.wattsOverride ?? null}
                    min={0}
                    step={1}
                    suffix="W"
                    ariaLabel="Power override"
                    placeholder={device.watts === null ? 'unknown' : String(device.watts)}
                    onChange={(value) => updateObject(object.id, {
                      fixture: object.fixture ? { ...object.fixture, wattsOverride: value === null ? null : Math.max(0, value) } : null,
                    })}
                  />
                </Field>
                <Field label="Fixture power">
                  <Toggle
                    checked={object.fixture?.powerOn !== false}
                    label={object.fixture?.powerOn !== false ? 'On' : 'Off'}
                    onChange={(checked) => setPowerState(object.id, checked)}
                  />
                </Field>
              </div>
            )}

            {(source || isDistro) && (
              <div className="power-settings">
                <div className="form-grid">
                  <Field label="Circuit ID" hint="Groups outlets on the same circuit">
                    <CommitText value={object.circuitId} onCommit={(value) => updateObject(object.id, { circuitId: value.trim().slice(0, 24) })} placeholder="A" />
                  </Field>
                  {isDistro ? (
                    <Field label="Total limit, W">
                      <NumberInput value={object.totalPowerLimit} min={0} step={100} suffix="W" allowEmpty onChange={(value) => updateObject(object.id, { totalPowerLimit: value })} />
                    </Field>
                  ) : (
                    <Field label="Phases">
                      <Toggle checked={object.portPhasesThreePhase} label={object.portPhasesThreePhase ? '3-phase' : 'Single-phase'} onChange={(checked) => updateObject(object.id, { portPhasesThreePhase: checked })} />
                    </Field>
                  )}
                </div>
                <div className="form-grid">
                  {phaseKeys.map((phase) => (
                    <Field key={phase} label={`Budget ${phase}, W`}>
                      <NumberInput value={object.powerLimits[phase] ?? null} min={0} step={100} suffix="W" placeholder="not set" onChange={(value) => updateLimit(phase, value)} />
                    </Field>
                  ))}
                </div>
                {powerOutputs.length > 0 && (
                  <div className="output-limits">
                    <span className="field-label">Output limits</span>
                    {powerOutputs.map((port) => (
                      <div className="output-limit-row" key={port.id}>
                        <span className="num">{port.label || port.id.replace(/^power/, '')}</span>
                        {object.portPhasesThreePhase ? (
                          <select
                            className="select output-phase"
                            value={object.portPhases[port.id] || 'L1'}
                            aria-label={`Phase ${port.label || port.id}`}
                            onChange={(event) => updatePhase(port.id, event.target.value)}
                          >
                            <option value="L1">L1</option>
                            <option value="L2">L2</option>
                            <option value="L3">L3</option>
                          </select>
                        ) : <span className="output-phase-label">L1</span>}
                        <NumberInput
                          value={object.outputLimits[port.id] ?? null}
                          min={0}
                          step={100}
                          suffix="W"
                          placeholder="—"
                          ariaLabel={`Limit ${port.label || port.id}`}
                          onChange={(value) => updateOutputLimit(port.id, value)}
                        />
                      </div>
                    ))}
                  </div>
                )}
                <p className="field-hint">Budgets are entered manually. Cable sizing, breakers and phase distribution are not verified; this is not an electrical inspection.</p>
              </div>
            )}
          </Section>
        )}

        {device && isDmxSource(device) && dmxOutputs.length > 0 && (
          <Section title="DMX universes" collapsed action={<span className="badge badge--mono">{dmxOutputs.length} outputs</span>}>
            <div className="universe-list">
              {dmxOutputs.map((port) => (
                <div className="universe-row" key={port.id}>
                  <span className="universe-label">{port.label || port.id}</span>
                  <span className="dim">{port.connector || 'DMX'}</span>
                  <NumberInput
                    value={object.dmxSourceUniverses[port.id] ?? portUniverse(object, port) ?? 1}
                    min={1}
                    max={32768}
                    step={1}
                    ariaLabel={`Universe ${port.label || port.id}`}
                    onChange={(value) => updateObject(object.id, {
                      dmxSourceUniverses: { ...object.dmxSourceUniverses, [port.id]: value === null ? 1 : Math.round(value) },
                    })}
                  />
                </div>
              ))}
            </div>
            <p className="field-hint">U1 is a project-level logical universe. No Art-Net/sACN is sent to hardware.</p>
          </Section>
        )}

        {device && <Section title="Ports" collapsed action={<span className="badge badge--mono">{ports.length}</span>}>
          <div className="port-list">
            {ports.length === 0 && <div className="field-hint">Ports are not documented. Check the model documentation.</div>}
            {ports.map((port) => {
              const connection = project.connections.find((entry) =>
                (entry.from === object.id && entry.fromPort === port.id) || (entry.to === object.id && entry.toPort === port.id));
              const other = connection ? project.objects.find((entry) => entry.id === (connection.from === object.id ? connection.to : connection.from)) : null;
              const isOutput = connection?.from === object.id;
              return (
                <div className="port-row" key={port.id}>
                  <span className="port-color" style={{ background: CABLE_META[port.type].color }} />
                  <span className="port-label">{port.label || port.id}</span>
                  <span className="port-direction">{port.direction === 'out' ? 'OUT' : port.direction === 'in' ? 'IN' : 'IN/OUT'}</span>
                  <span className="port-connector dim">{port.connector || CABLE_META[port.type].label}</span>
                  {connection && other ? (
                    <button type="button" className="port-connection" onClick={() => selectConnection(connection.id)} title="Select cable">
                      {isOutput ? '→' : '←'} {other.name}
                    </button>
                  ) : (
                    <span className="port-unused">free</span>
                  )}
                  <div className="port-actions">
                    {port.configurable && !connection && (
                      <IconButton label="Flip direction" size="sm" onClick={() => flipPort(port.id)}><ArrowLeftRight /></IconButton>
                    )}
                    <IconButton label="Connect" size="sm" onClick={() => startCable(port.id, port.type)}><Cable /></IconButton>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>}

        {device && <Section title="Connections" collapsed action={<span className="badge badge--mono">{connectedConnections.length}</span>}>
          {connectedConnections.length === 0 ? (
            <div className="empty" style={{ padding: '16px 0' }}>
              <Cable />
              <span>No connections. Use the cable tool on the plan.</span>
            </div>
          ) : (
            <div className="connection-list">
              {connectedConnections.map((connection) => {
                const outgoing = connection.from === object.id;
                const other = project.objects.find((entry) => entry.id === (outgoing ? connection.to : connection.from));
                return (
                  <div className="connection-row" key={connection.id}>
                    <span className="port-color" style={{ background: CABLE_META[connection.type].color }} />
                    <button type="button" className="connection-main" onClick={() => selectConnection(connection.id)}>
                      <span>{CABLE_META[connection.type].label}</span>
                      <span className="dim">{outgoing ? '→' : '←'} {other?.name || 'object'}</span>
                    </button>
                    <span className="connection-ports num">{outgoing ? `${connection.fromPort} → ${connection.toPort}` : `${connection.fromPort} → ${connection.toPort}`}</span>
                  </div>
                );
              })}
            </div>
          )}
        </Section>}

        {device && (
          <Section title="Data and sources" collapsed>
            <div className={`verification-note ${verification.tone === 'ok' ? 'is-verified' : ''}`}>
              <strong>{verification.label}</strong>
              {device.verification.note && <p>{device.verification.note}</p>}
              {device.verification.missingFields.length > 0 && (
                <p className="field-hint">Still to check: {device.verification.missingFields.map((field) => MISSING_LABELS[field] || field).join(', ')}.</p>
              )}
            </div>
            {device.sourceUrls.length > 0 && (
              <div className="source-links">
                {device.sourceUrls.slice(0, 4).map((url) => (
                  <a key={url} href={url} target="_blank" rel="noopener noreferrer" className="source-link">
                    <ExternalLink /> {hostOf(url)}
                  </a>
                ))}
              </div>
            )}
            <Field label="Notes">
              <CommitText
                multiline
                value={object.notes}
                ariaLabel="Object notes"
                placeholder="Installation, cables, site notes"
                onCommit={(value) => updateObject(object.id, { notes: value.slice(0, 2000) })}
              />
            </Field>
          </Section>
        )}


      </div>
    </>
  );
}
