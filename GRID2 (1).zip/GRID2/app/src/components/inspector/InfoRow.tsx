import type { ReactNode } from 'react';

export function InfoRow({ label, value, mono, tone }: { label: string; value: ReactNode; mono?: boolean; tone?: 'ok' | 'warn' | 'danger' }) {
  return (
    <div className="info-row">
      <span>{label}</span>
      <span className={`info-value ${mono ? 'num' : ''} ${tone ? `info-value--${tone}` : ''}`}>{value}</span>
    </div>
  );
}
