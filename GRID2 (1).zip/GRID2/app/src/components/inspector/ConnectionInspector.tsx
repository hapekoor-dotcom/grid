import { ArrowLeftRight, Cable, Trash2 } from 'lucide-react';
import type { Connection, Project } from '../../types/project';
import { CABLE_META } from '../../lib/catalog';
import { routeConnection } from '../../lib/routing';
import { pointAtFraction } from '../../lib/geometry';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Button, IconButton } from '../ui/Button';
import { CommitText } from '../ui/CommitText';
import { InfoRow } from './InfoRow';

export function ConnectionInspector({ connection, project }: { connection: Connection; project: Project }) {
  const deleteConnection = useWorkspaceStore((state) => state.deleteConnection);
  const updateConnection = useWorkspaceStore((state) => state.updateConnection);
  const select = useUiStore((state) => state.select);
  const clearSelection = useUiStore((state) => state.clearSelection);
  const selectConnection = useUiStore((state) => state.selectConnection);
  const from = project.objects.find((object) => object.id === connection.from);
  const to = project.objects.find((object) => object.id === connection.to);
  const route = routeConnection(project, connection);
  const meta = CABLE_META[connection.type];

  return (
    <>
      <div className="panel-head inspector-head">
        <span className="inspector-type-icon" style={{ color: meta.color }}><Cable /></span>
        <span className="panel-title">Cable · {meta.label}</span>
        <div className="panel-head-actions">
          <IconButton label="Delete cable" size="sm" onClick={() => { deleteConnection(connection.id); clearSelection(); }}><Trash2 /></IconButton>
        </div>
      </div>
      <div className="panel-body">
        <section className="inspector-section">
          <div className="cable-endpoints">
            <button type="button" className="cable-endpoint" onClick={() => select(connection.from)}>
              <span className="field-label">From</span>
              <strong>{from?.name || connection.from}</strong>
              <span className="num">{connection.fromPort}</span>
            </button>
            <ArrowLeftRight className="cable-arrow" />
            <button type="button" className="cable-endpoint" onClick={() => select(connection.to)}>
              <span className="field-label">To</span>
              <strong>{to?.name || connection.to}</strong>
              <span className="num">{connection.toPort}</span>
            </button>
          </div>
          <div className="info-list">
            <InfoRow label="Type" value={meta.label} />
            <InfoRow label="Route length" value={`${route.distance.toFixed(2)} m`} mono />
            <InfoRow label="Bends" value={String(connection.waypoints.length)} mono />
          </div>
          <div className="row wrap">
            <Button
              size="sm"
              onClick={() => {
                const point = pointAtFraction(route.points, 0.55);
                const anchor = route.points[Math.max(0, Math.floor(route.points.length / 2))] || point;
                const next = route.points[Math.min(route.points.length - 1, Math.floor(route.points.length / 2) + 1)] || point;
                const dx = next.x - anchor.x;
                const dz = next.z - anchor.z;
                const length = Math.hypot(dx, dz) || 1;
                const offset = 0.35;
                updateConnection(connection.id, {
                  waypoints: [...connection.waypoints, {
                    x: Math.round((point.x - (dz / length) * offset) * 1000) / 1000,
                    z: Math.round((point.z + (dx / length) * offset) * 1000) / 1000,
                  }],
                });
              }}
            >
              Add bend
            </Button>
            {connection.waypoints.length > 0 && (
              <Button size="sm" onClick={() => updateConnection(connection.id, { waypoints: [] })}>Reset bends</Button>
            )}
          </div>
        </section>
        <section className="inspector-section">
          <div className="section-label"><span>Notes</span></div>
          <CommitText
            multiline
            value={connection.note}
            ariaLabel="Cable notes"
            placeholder="Route, cable length, limits"
            onCommit={(value) => updateConnection(connection.id, { note: value.slice(0, 1000) })}
          />
        </section>
        <div className="inspector-actions">
          <Button size="sm" onClick={() => selectConnection(null)}>Back to project</Button>
          <Button size="sm" variant="danger" icon={<Trash2 />} onClick={() => deleteConnection(connection.id)}>Delete cable</Button>
        </div>
      </div>
    </>
  );
}
