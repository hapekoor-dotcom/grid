import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronDown, ChevronRight, Copy, GripVertical, Plus, RotateCcw, Search, Trash2 } from 'lucide-react';
import type { SceneModifier } from '../../types/project';
import { EFFECT_GROUPS, createModifier, effectGroup, executionDomain, modifierDefinition, modifiersForTarget, type ModifierField, type ModifierTarget } from '../../lib/modifiers';
import { KeyframeButton } from './KeyframeButton';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { defaultModulator } from '../../lib/signals';
import { wouldCreateModifierCycle } from '../../lib/graphRouting';
import { useUiStore } from '../../store/uiStore';
import { describeParameter } from '../../lib/parameterHelp';
import { OverdriveControl } from '../ui/OverdriveControl';
import { clampOverdrive } from '../../lib/overdrive';
import { NumberInput, Select, Toggle } from '../ui/Field';
import { ModifierGraphDialog } from './ModifierGraphDialog';

function clampField(field: ModifierField, value: number): number {
  if (!Number.isFinite(value)) return field.hardClamp ? (field.physicalMin ?? field.min ?? 0) : 0;
  if (!field.hardClamp) return value;
  const min = field.physicalMin ?? field.min ?? -Infinity;
  const max = field.physicalMax ?? field.max ?? Infinity;
  return Math.max(min, Math.min(max, value));
}

function outsideRecommended(field: ModifierField, value: number): boolean {
  const min = field.recommendedMin ?? field.min;
  const max = field.recommendedMax ?? field.max;
  return (min !== undefined && value < min) || (max !== undefined && value > max);
}

function FieldLabel({ field, definition }: { field: ModifierField; definition: ReturnType<typeof modifierDefinition> }) {
  const doc = describeParameter(definition, field);
  return (
    <span className="field-label field-label-with-help">{field.label}{field.unit ? ` · ${field.unit}` : ''}<span className="param-help" tabIndex={0} aria-label={`About ${field.label}`}>i<span className="param-help-popover" role="tooltip"><strong>{field.label}</strong><span>{doc.short}</span>{doc.long && <span>{doc.long}</span>}{field.recommendedMin !== undefined || field.recommendedMax !== undefined || field.min !== undefined || field.max !== undefined ? <span>Recommended: {field.recommendedMin ?? field.min} – {field.recommendedMax ?? field.max}{field.unit ? ` ${field.unit}` : ''}</span> : null}{doc.performance && <span>Performance: {doc.performance}</span>}{doc.warning && <span className="param-help-warning">{doc.warning}</span>}</span></span></span>
  );
}

function FieldControl({ field, param, onChange, definition }: { field: ModifierField; param: number | string | boolean; onChange: (value: number | string | boolean) => void; definition: ReturnType<typeof modifierDefinition> }) {
  const kind = field.kind || 'number';
  if (kind === 'toggle') {
    return <div className="modifier-field-row"><FieldLabel field={field} definition={definition} /><Toggle checked={param === true} ariaLabel={field.label} onChange={onChange} /></div>;
  }
  if (kind === 'select') {
    return <label className="field"><FieldLabel field={field} definition={definition} /><Select value={String(param ?? '')} ariaLabel={field.label} options={field.options || []} onChange={onChange} /></label>;
  }
  if (kind === 'color') {
    return <label className="field"><FieldLabel field={field} definition={definition} /><input className="color-input" type="color" aria-label={field.label} value={String(param || '#ffffff')} onChange={(event) => onChange(event.target.value)} /></label>;
  }
  if (kind === 'texture') {
    return (
      <div className="field modifier-texture-field">
        <FieldLabel field={field} definition={definition} />
        <div className="modifier-texture-row">
          {param ? <img src={String(param)} alt="Displacement texture preview" className="modifier-texture-preview" /> : <span className="field-hint">No texture · procedural fallback</span>}
          <label className="btn btn--sm btn--ghost">Load<input type="file" accept="image/*" hidden onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => onChange(String(reader.result || ''));
            reader.readAsDataURL(file);
          }} /></label>
          {param ? <button type="button" className="section-link" onClick={() => onChange('')}>Clear</button> : null}
        </div>
      </div>
    );
  }
  if (kind === 'vector') {
    return <span className="field-hint">{field.label} vector</span>;
  }
  if (kind === 'percent') {
    return (
      <div className="field">
        <FieldLabel field={field} definition={definition} />
        <OverdriveControl value={Number(param ?? 0)} ariaLabel={field.label} onChange={(value) => onChange(clampField(field, value))} />
      </div>
    );
  }
  const numeric = Number(param ?? 0);
  const over = outsideRecommended(field, numeric);
  return (
    <label className="field">
      <span className="field-label field-label-with-help">{field.label}{field.unit ? ` · ${field.unit}` : ''}{field.hardClamp && <span className="field-hard-limit" title="Runtime hard clamp">hard</span>}<span className="param-help" tabIndex={0} aria-label={`About ${field.label}`}>i<span className="param-help-popover" role="tooltip"><strong>{field.label}</strong><span>{describeParameter(definition, field).short}</span>{describeParameter(definition, field).long && <span>{describeParameter(definition, field).long}</span>}{field.hardClamp && <span>Hard-clamped by runtime.</span>}</span></span></span>
      <NumberInput value={numeric} min={field.hardClamp ? (field.physicalMin ?? field.min) : undefined} max={field.hardClamp ? (field.physicalMax ?? field.max) : undefined} step={field.step ?? 0.1} ariaLabel={field.label} onChange={(value) => onChange(clampField(field, value ?? 0))} />
      {over && <span className="field-hint modifier-over-range">{field.recommendedMin ?? field.min}–{field.recommendedMax ?? field.max}{field.unit ? ` ${field.unit}` : ''} recommended · over range</span>}
    </label>
  );
}

export function ModifiersEditor({ modifiers, target, onChange, keyframeObjectId }: { modifiers: SceneModifier[]; target: ModifierTarget; onChange: (next: SceneModifier[]) => void; keyframeObjectId?: string | null }) {
  const available = useMemo(() => modifiersForTarget(target), [target]);
  const activeProject = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId));
  const signals = activeProject?.signals;
  const pushToast = useUiStore((state) => state.pushToast);
  const [modOpen, setModOpen] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(modifiers[0]?.id || null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [recentTypes, setRecentTypes] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem('regrid.effects.recent') || '[]'); } catch { return []; } });
  const searchRef = useRef<HTMLInputElement>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [dragId, setDragId] = useState<string | null>(null);
  const [graphOpen, setGraphOpen] = useState(false);
  const selected = modifiers.find((modifier) => modifier.id === selectedId) || null;
  const definition = selected ? modifierDefinition(selected.type) : null;

  useEffect(() => {
    if (!modifiers.some((modifier) => modifier.id === selectedId)) setSelectedId(modifiers[0]?.id || null);
  }, [modifiers, selectedId]);

  const updateSelected = (patch: Partial<SceneModifier>) => {
    if (!selected) return;
    onChange(modifiers.map((modifier) => modifier.id === selected.id ? { ...modifier, ...patch } : modifier));
  };
  const updateParam = (key: string, value: number | string | boolean) => {
    if (!selected) return;
    updateSelected({ params: { ...selected.params, [key]: value } });
  };
  const setModulator = (key: string, encoded: string) => {
    if (!selected) return;
    const field = definition?.fields.find((entry) => entry.key === key);
    const range = Math.max(0.01, (field?.max ?? 1) - (field?.min ?? 0));
    let next = null;
    if (encoded.startsWith('modifier:')) {
      const [, id, output] = encoded.split(':');
      next = { ...defaultModulator(id, 'modifier', output), amount: range * 0.25 };
    } else if (encoded.startsWith('reaction:')) {
      next = { ...defaultModulator('reaction', 'reaction', encoded.slice(9)), amount: range * 0.25 };
    } else if (encoded) {
      next = { ...defaultModulator(encoded), amount: range * 0.25 };
    }
    if (next?.sourceType === 'modifier' && wouldCreateModifierCycle(modifiers as never, selected.id, next.sourceId)) {
      pushToast('Connection would create a dependency cycle.', 'error');
      return;
    }
    const modulators = { ...(selected.modulators || {}) };
    if (next) modulators[key] = next; else delete modulators[key];
    updateSelected({ modulators });
  };
  const sourceValue = (modulator: any) => modulator.sourceType === 'modifier' ? `modifier:${modulator.sourceId}:${modulator.output || 'scalar'}` : modulator.sourceType === 'reaction' ? `reaction:${modulator.output || 'scalar'}` : modulator.sourceId;
  const setAdapter = (key: string, kind: string) => {
    if (!selected?.modulators?.[key]) return;
    const params: Record<string, number> = kind === 'remap' ? { inMin: 0, inMax: 1, outMin: 0, outMax: 1 } : kind === 'clamp' ? { min: 0, max: 1 } : kind === 'multiply' ? { factor: 1 } : kind === 'power' ? { exponent: 1 } : kind === 'smoothstep' ? { edge0: 0, edge1: 1 } : kind === 'quantize' ? { step: 0.1 } : {};
    const adapter = kind ? { kind, params } : undefined;
    updateSelected({ modulators: { ...(selected.modulators || {}), [key]: { ...selected.modulators![key], adapter } } });
  };
  const setAdapterParam = (key: string, name: string, value: number) => {
    if (!selected?.modulators?.[key]) return;
    const modulator = selected.modulators[key];
    updateSelected({ modulators: { ...(selected.modulators || {}), [key]: { ...modulator, adapter: { ...modulator.adapter!, params: { ...(modulator.adapter?.params || {}), [name]: value } } } } });
  };
  const addEffect = (type: string) => {
    const modifier = createModifier(type);
    onChange([...modifiers, modifier]);
    setSelectedId(modifier.id);
    setExpanded((state) => ({ ...state, [modifier.id]: true }));
    const next = [type, ...recentTypes.filter((entry) => entry !== type)].slice(0, 6);
    setRecentTypes(next);
    try { localStorage.setItem('regrid.effects.recent', JSON.stringify(next)); } catch { /* optional */ }
    setPickerOpen(false);
    setQuery('');
  };
  const randomize = () => {
    if (!selected || !definition) return;
    const params = { ...selected.params };
    for (const field of definition.fields) {
      if (field.kind === 'number' || field.kind === 'percent') {
        const min = field.min ?? 0;
        const max = field.max ?? 1;
        params[field.key] = min + Math.random() * (max - min);
      } else if (field.kind === 'toggle') params[field.key] = Math.random() > 0.5;
      else if (field.kind === 'select' && field.options?.length) params[field.key] = field.options[Math.floor(Math.random() * field.options.length)].value;
    }
    updateSelected({ params });
  };
  const move = (from: number, to: number) => {
    if (to < 0 || to >= modifiers.length || from === to) return;
    const fromStage = executionDomain(modifierDefinition(modifiers[from].type));
    const toStage = executionDomain(modifierDefinition(modifiers[to].type));
    if (fromStage !== toStage) { pushToast(`Effects can only be reordered within the same stage (${fromStage} → ${toStage}).`, 'warning'); return; }
    const next = [...modifiers];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    onChange(next);
  };

  useEffect(() => {
    if (!pickerOpen) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setPickerOpen(false); };
    window.addEventListener('keydown', close);
    window.setTimeout(() => searchRef.current?.focus(), 20);
    return () => window.removeEventListener('keydown', close);
  }, [pickerOpen]);

  return (
    <div className="modifiers-editor">
      <div className="modifier-add-row">
        <button type="button" className="btn btn--sm btn--primary modifier-add-button" onClick={() => setPickerOpen((value) => !value)} aria-expanded={pickerOpen}><Plus /> Effect</button>
        <button type="button" className="btn btn--sm btn--ghost" onClick={() => { const enabled = modifiers.every((entry) => !entry.enabled); onChange(modifiers.map((entry) => ({ ...entry, enabled }))); }}>{modifiers.length && modifiers.every((entry) => !entry.enabled) ? 'Enable all' : 'Bypass all'}</button>
        <button type="button" className="btn btn--sm btn--ghost" onClick={() => { if (!selected) return; onChange(modifiers.map((entry) => ({ ...entry, enabled: entry.id === selected.id }))); }} disabled={!selected}>Solo</button>
        <button type="button" className="btn btn--sm btn--ghost" onClick={randomize} disabled={!selected}>Randomize</button>
        <button type="button" className="btn btn--sm btn--ghost" onClick={() => setGraphOpen(true)} disabled={!modifiers.length}>Graph</button>
        <button type="button" className="btn btn--sm btn--ghost" onClick={() => { if (!selected || !definition) return; updateSelected({ params: { ...definition.defaults } }); }} disabled={!selected}>Reset</button>
        {pickerOpen && <div className="effect-picker">
          <div className="effect-picker-search"><Search /><input ref={searchRef} className="input" value={query} placeholder="Search effects…" aria-label="Search effects" onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === 'Escape') setPickerOpen(false); if (event.key === 'Enter' && query.trim()) { const first = available.find((entry) => entry.label.toLowerCase().includes(query.toLowerCase()) || entry.type.toLowerCase().includes(query.toLowerCase())); if (first) addEffect(first.type); } }} /><button type="button" className="section-link" onClick={() => setPickerOpen(false)}>Close</button></div>
          {recentTypes.length > 0 && !query && <div className="effect-picker-recent"><span className="field-label">Recent</span>{recentTypes.map((type) => available.find((entry) => entry.type === type)).filter(Boolean).map((entry) => <button type="button" key={entry!.type} className="effect-picker-item" onClick={() => addEffect(entry!.type)}>{entry!.label}</button>)}</div>}
          <div className="effect-picker-list">
            {EFFECT_GROUPS.map((category) => {
              const entries = available.filter((entry) => effectGroup(entry) === category && (!query || entry.label.toLowerCase().includes(query.toLowerCase()) || entry.type.toLowerCase().includes(query.toLowerCase()) || (entry.description || '').toLowerCase().includes(query.toLowerCase())));
              if (!entries.length) return null;
              return <div className="effect-picker-group" key={category}><div className="effect-picker-category">{category}</div>{entries.map((entry) => <button type="button" key={entry.type} className="effect-picker-item" onClick={() => addEffect(entry.type)}><span>{entry.label}</span><small>{entry.stage || entry.runtime}{entry.cost ? ` · ${entry.cost}` : ''}</small></button>)}</div>;
            })}
          </div>
        </div>}
      </div>
      {modifiers.length === 0 && <div className="modifier-empty">No modifiers · Add Modifier</div>}

      {modifiers.length > 0 && (
        <div className="modifier-list">
          {modifiers.map((modifier, index) => {
            const definition = modifierDefinition(modifier.type);
            const isOpen = expanded[modifier.id] !== false;
            const stage = executionDomain(definition);
            const previousStage = index > 0 ? executionDomain(modifierDefinition(modifiers[index - 1].type)) : null;
            return (
              <Fragment key={modifier.id}>
              {stage !== previousStage && <div className="modifier-stage-divider">{stage.toUpperCase()}</div>}
              <div
                key={modifier.id}
                className={`modifier-row ${selectedId === modifier.id ? 'is-selected' : ''}`}
                draggable
                onDragStart={(event) => { setDragId(modifier.id); event.dataTransfer.effectAllowed = 'move'; }}
                onDragOver={(event) => { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; }}
                onDrop={(event) => { event.preventDefault(); if (!dragId) return; move(modifiers.findIndex((entry) => entry.id === dragId), index); setDragId(null); }}
                onDragEnd={() => setDragId(null)}
                onClick={() => setSelectedId(modifier.id)}
              >
                <GripVertical className="modifier-grip" aria-hidden="true" />
                <button type="button" className="modifier-expand" aria-label={`${isOpen ? 'Collapse' : 'Expand'} ${definition.label}`} onClick={(event) => { event.stopPropagation(); setExpanded((state) => ({ ...state, [modifier.id]: !isOpen })); }}>
                  {isOpen ? <ChevronDown /> : <ChevronRight />}
                </button>
                <button type="button" className="modifier-name" title={definition.description || definition.label} onClick={() => setSelectedId(modifier.id)}>{definition.label}{definition.cost && <span className={`modifier-cost modifier-cost--${definition.cost}`}>{definition.cost}</span>}</button>
                <Toggle checked={modifier.enabled} ariaLabel={`Enable ${definition.label}`} onChange={(checked) => onChange(modifiers.map((entry) => entry.id === modifier.id ? { ...entry, enabled: checked } : entry))} />
                <button type="button" className="icon-btn icon-btn--sm" aria-label="Move modifier up" disabled={index === 0} onClick={(event) => { event.stopPropagation(); move(index, index - 1); }}><ArrowUp /></button>
                <button type="button" className="icon-btn icon-btn--sm" aria-label="Move modifier down" disabled={index === modifiers.length - 1} onClick={(event) => { event.stopPropagation(); move(index, index + 1); }}><ArrowDown /></button>
                <button type="button" className="icon-btn icon-btn--sm" aria-label="Duplicate modifier" onClick={(event) => { event.stopPropagation(); const copy = { ...modifier, id: `mod_${crypto.randomUUID()}`, params: { ...modifier.params } }; onChange([...modifiers, copy]); setSelectedId(copy.id); }}><Copy /></button>
                <button type="button" className="icon-btn icon-btn--sm" aria-label="Delete modifier" onClick={(event) => { event.stopPropagation(); onChange(modifiers.filter((entry) => entry.id !== modifier.id)); }}><Trash2 /></button>
              </div>
              </Fragment>
            );
          })}
        </div>
      )}

      {selected && definition && (expanded[selected.id] ?? true) && (
        <div className="modifier-params">
          {definition.description && <p className="field-hint modifier-description">{definition.description}</p>}
          <div className="row-between">
            <span className="field-label">{definition.label}{definition.stage && <span className="modifier-stage">{definition.stage}</span>}</span>
            <button type="button" className="section-link" onClick={() => updateSelected({ params: { ...definition.defaults } })}><RotateCcw /> Reset</button>
          </div>
          {definition.fields.map((field) => (
            <div key={field.key} className="modifier-field-with-key">
              <FieldControl field={field} definition={definition} param={selected.params[field.key]} onChange={(value) => updateParam(field.key, value)} />
              {keyframeObjectId !== undefined && (typeof selected.params[field.key] === 'number' || field.kind === 'color') && (
                <KeyframeButton objectId={keyframeObjectId} propertyPath={`modifier.${selected.id}.${field.key}`} value={selected.params[field.key]} label={`${definition.label} ${field.label}`} />
              )}
              {(['number', 'percent'].includes(field.kind || 'number') || field.overdrive) && (
                <div className="mod-socket-wrap">
                  <button type="button" className={`mod-socket ${selected.modulators?.[field.key] ? 'is-active' : ''}`} aria-label={`Modulate ${field.label}`} title="Modulation socket" onClick={() => setModOpen((value) => value === `${selected.id}.${field.key}` ? null : `${selected.id}.${field.key}`)}>~</button>
                  {modOpen === `${selected.id}.${field.key}` && (
                    <div className="mod-socket-popover">
                      <span className="field-label">Modulator · {field.label}</span>
                      <select className="select" value={selected.modulators?.[field.key] ? sourceValue(selected.modulators[field.key]) : ''} aria-label="Modulation source" onChange={(event) => setModulator(field.key, event.target.value)}>
                        <option value="">No modulator</option>
                        {(signals || []).map((signal) => <option key={signal.id} value={signal.id}>{signal.name} · {signal.kind}</option>)}
                        {activeProject?.reactionDiffusion?.enabled && <optgroup label="Reaction Diffusion"><option value="reaction:sampledScalar">RD · Scalar sample (global)</option></optgroup>}
                        {modifiers.some((entry) => entry.id !== selected.id && (modifierDefinition(entry.type).outputs || []).length) && <optgroup label="Modifier outputs">{modifiers.filter((entry) => entry.id !== selected.id).flatMap((entry) => (modifierDefinition(entry.type).outputs || []).map((output) => <option key={`${entry.id}:${output.key}`} value={`modifier:${entry.id}:${output.key}`}>{modifierDefinition(entry.type).label} · {output.label}</option>))}</optgroup>}
                      </select>
                      {!signals?.length && <span className="field-hint">Add a signal in Settings → Signal engine.</span>}
                      {selected.modulators?.[field.key] && <>
                        <label className="field"><span className="field-label">Adapter</span><select className="select" value={selected.modulators[field.key].adapter?.kind || ''} aria-label="Modulation adapter" onChange={(event) => setAdapter(field.key, event.target.value)}><option value="">None</option>{['remap','clamp','invert','multiply','add','subtract','power','smoothstep','curve','quantize'].map((kind) => <option key={kind} value={kind}>{kind}</option>)}</select></label>
                        {selected.modulators[field.key].adapter && Object.entries(selected.modulators[field.key].adapter!.params || {}).map(([name, value]) => <label className="field" key={name}><span className="field-label">{name}</span><NumberInput value={value} step={0.01} ariaLabel={`${name} adapter value`} onChange={(next) => setAdapterParam(field.key, name, next ?? 0)} /></label>)}
                      </>}

                      {selected.modulators?.[field.key] && (
                        <>
                          <label className="field"><span className="field-label">Amount</span><NumberInput value={selected.modulators[field.key].amount} step={0.01} ariaLabel="Modulation amount" onChange={(value) => updateSelected({ modulators: { ...(selected.modulators || {}), [field.key]: { ...selected.modulators![field.key], amount: value ?? 0 } } })} /></label>
                          <label className="field"><span className="field-label">Offset</span><NumberInput value={selected.modulators[field.key].offset} step={0.01} ariaLabel="Modulation offset" onChange={(value) => updateSelected({ modulators: { ...(selected.modulators || {}), [field.key]: { ...selected.modulators![field.key], offset: value ?? 0 } } })} /></label>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {graphOpen && <ModifierGraphDialog modifiers={modifiers} onChange={onChange} onClose={() => setGraphOpen(false)} />}
    </div>
  );
}
