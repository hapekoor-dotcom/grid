import {
  AlignCenterHorizontal, AlignCenterVertical, AlignEndVertical, AlignHorizontalSpaceAround,
  AlignLeft, AlignRight, AlignStartVertical, AlignVerticalSpaceAround, ClipboardPaste, Copy,
  Layers, Lock, RotateCcw, RotateCw, Trash2, Unlock, Eye, EyeOff,
} from 'lucide-react';
import { useState } from 'react';
import type { Project, SceneObject } from '../../types/project';
import { objectDims } from '../../lib/objects';
import { getDevice } from '../../lib/catalog';
import { MODIFIER_DEFINITIONS } from '../../lib/modifiers';
import { EFFECT_PRESETS } from '../../lib/effectPresets';
import { effectCommands } from '../../lib/effectCommands';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Button, IconButton } from '../ui/Button';
import { Field, NumberInput, Toggle } from '../ui/Field';
import { ModifiersEditor } from './ModifiersEditor';
import { MaterialLookControl } from './MaterialLookControl';

type Axis = 'x' | 'y' | 'z';

function commonValue(objects: SceneObject[], get: (object: SceneObject) => number): number | null {
  const values = objects.map(get);
  const first = values[0];
  return values.every((value) => Math.abs(value - first) < 0.0001) ? first : null;
}

function mixedLabel(label: string, value: unknown) {
  return <>{label}{value === null ? <span className="dim"> · Mixed</span> : null}</>;
}

function BulkToggle({ value, onChange, label }: { value: boolean | null; onChange: (value: boolean) => void; label: string }) {
  const next = value !== true;
  return <button type="button" role="switch" aria-checked={value === null ? 'mixed' : value} aria-label={label} className={`bulk-toggle ${value === true ? 'is-on' : ''} ${value === null ? 'is-mixed' : ''}`} onClick={() => onChange(next)}>{value === null ? 'Mixed' : value ? 'On' : 'Off'}</button>;
}

export function MultiInspector({ objects, project }: { objects: SceneObject[]; project: Project }) {
  const selectedIds = useUiStore((state) => state.selectedIds);
  const selectMany = useUiStore((state) => state.selectMany);
  const updateEffectGroups = useWorkspaceStore((state) => state.updateEffectGroups);
  const [presetId, setPresetId] = useState(EFFECT_PRESETS[0]?.id || '');
  const sharedGroups = (project?.effectGroups || []).filter((group) => group.targetIds.some((id) => selectedIds.includes(id)));
  const sharedTarget = objects.some((object) => object.type === 'device') ? 'device' : objects.some((object) => object.type === 'light') ? 'light' : 'model';
  const addSharedGroup = () => {
    const id = `grp_${crypto.randomUUID()}`;
    updateEffectGroups([...(project?.effectGroups || []), { id, name: `Shared stack ${(project?.effectGroups?.length || 0) + 1}`, enabled: true, targetIds: [...selectedIds], modifiers: [] }]);
  };
  const updateSharedGroup = (id: string, modifiers: typeof sharedGroups[number]['modifiers']) => updateEffectGroups((project?.effectGroups || []).map((group) => group.id === id ? { ...group, modifiers } : group));
  const removeSharedGroup = (id: string) => updateEffectGroups((project?.effectGroups || []).filter((group) => group.id !== id));
  const makeSharedUnique = (id: string) => {
    const group = project?.effectGroups?.find((entry) => entry.id === id);
    if (!group) return;
    useWorkspaceStore.getState().mutate((draft) => {
      const copy = group.modifiers.map((modifier) => ({ ...modifier, id: `mod_${crypto.randomUUID()}`, params: { ...modifier.params } }));
      for (const object of draft.objects) if (group.targetIds.includes(object.id)) object.modifiers = [...(object.modifiers || []), ...copy.map((modifier) => ({ ...modifier, id: `mod_${crypto.randomUUID()}`, params: { ...modifier.params } }))];
      const entry = draft.effectGroups?.find((candidate) => candidate.id === id);
      if (entry) entry.targetIds = entry.targetIds.filter((targetId) => !selectedIds.includes(targetId));
      if (entry && entry.targetIds.length === 0) draft.effectGroups = (draft.effectGroups || []).filter((candidate) => candidate.id !== id);
    });
  };
  const alignSelection = useWorkspaceStore((state) => state.alignSelection);
  const distributeSelection = useWorkspaceStore((state) => state.distributeSelection);
  const alignSelectionAxis = useWorkspaceStore((state) => state.alignSelectionAxis);
  const distributeSelectionAxis = useWorkspaceStore((state) => state.distributeSelectionAxis);
  const updateSelectionAxis = useWorkspaceStore((state) => state.updateSelectionAxis);
  const updateSelectionScaleUniform = useWorkspaceStore((state) => state.updateSelectionScaleUniform);
  const copySelectionTransform = useWorkspaceStore((state) => state.copySelectionTransform);
  const pasteSelectionTransform = useWorkspaceStore((state) => state.pasteSelectionTransform);
  const resetSelectionRotation = useWorkspaceStore((state) => state.resetSelectionRotation);
  const resetSelectionScale = useWorkspaceStore((state) => state.resetSelectionScale);
  const updateSelectionVisibility = useWorkspaceStore((state) => state.updateSelectionVisibility);
  const updateSelectionLight = useWorkspaceStore((state) => state.updateSelectionLight);
  const updateSelectionLightCapability = useWorkspaceStore((state) => state.updateSelectionLightCapability);
  const updateSelectionMaterial = useWorkspaceStore((state) => state.updateSelectionMaterial);
  const addModifierToSelection = useWorkspaceStore((state) => state.addModifierToSelection);
  const beginTransaction = useWorkspaceStore((state) => state.beginTransaction);
  const endTransaction = useWorkspaceStore((state) => state.endTransaction);
  const transformClipboard = useWorkspaceStore((state) => state.transformClipboard);
  const groupSelection = useWorkspaceStore((state) => state.groupSelection);
  const ungroupSelection = useWorkspaceStore((state) => state.ungroupSelection);
  const duplicateSelection = useWorkspaceStore((state) => state.duplicateSelection);
  const deleteSelection = useWorkspaceStore((state) => state.deleteSelection);
  const rotateSelection = useWorkspaceStore((state) => state.rotateSelection);
  const lockSelection = useWorkspaceStore((state) => state.lockSelection);
  const hideSelection = useWorkspaceStore((state) => state.hideSelection);
  const [uniformScale, setUniformScale] = useState(false);
  const primary = project.objects.find((object) => object.id === selectedIds[0]) || objects[0];
  const allModels = objects.every((object) => object.type === 'model');
  const hasModels = objects.some((object) => object.type === 'model');
  const lightObjects = objects.filter((object) => object.light);
  const modelObjects = objects.filter((object) => object.type === 'model');
  const commonBool = (get: (object: SceneObject) => boolean | undefined): boolean | null => {
    const values = objects.map(get);
    return values.every((value) => value === values[0]) ? values[0] ?? false : null;
  };
  const commonLight = (get: (light: NonNullable<SceneObject['light']>) => number | string | boolean) => {
    const values = lightObjects.map((object) => get(object.light!));
    if (!values.length) return null;
    return values.every((value) => value === values[0]) ? values[0] : null;
  };
  const commonMaterial = (get: (material: NonNullable<SceneObject['material']>) => number | string | undefined) => {
    const values = modelObjects.map((object) => get(object.material || {}));
    if (!values.length) return null;
    return values.every((value) => value === values[0]) ? values[0] ?? null : null;
  };
  const compatibleLights = (kind: 'pan' | 'tilt' | 'zoom' | 'focus' | 'strobe') => lightObjects.filter((object) => {
    if (object.type !== 'device' || !object.deviceId) return false;
    const device = getDevice(object.deviceId);
    return !!device?.capabilities?.[kind];
  });
  const commonCapability = (kind: 'pan' | 'tilt' | 'zoom' | 'focus' | 'strobe') => {
    const values = compatibleLights(kind).map((object) => object.light?.[kind]);
    if (!values.length) return null;
    return values.every((value) => value === values[0]) ? values[0] ?? null : null;
  };
  const [modifierType, setModifierType] = useState(MODIFIER_DEFINITIONS.find((entry) => entry.targets.includes('model'))?.type || 'rotate');

  const position = (axis: Axis) => commonValue(objects, (object) => axis === 'x' ? object.position.x : axis === 'y' ? object.elevation : object.position.z);
  const rotation = (axis: Axis) => commonValue(objects, (object) => axis === 'x' ? object.rotationX || 0 : axis === 'y' ? object.rotation : object.rotationZ || 0);
  const scale = (axis: Axis) => commonValue(objects.filter((object) => object.type === 'model'), (object) => (object.scale || { x: 1, y: 1, z: 1 })[axis]);
  const commitPosition = (axis: Axis, value: number | null) => { if (value !== null) updateSelectionAxis('position', axis, value); };
  const commitRotation = (axis: Axis, value: number | null) => { if (value !== null) updateSelectionAxis('rotation', axis, value); };
  const commitScale = (axis: Axis, value: number | null) => {
    if (value === null) return;
    if (uniformScale) updateSelectionScaleUniform(value);
    else updateSelectionAxis('scale', axis, value);
  };

  return (
    <>
      <div className="panel-head inspector-head">
        <span className="inspector-type-icon"><Layers /></span>
        <span className="panel-title">{objects.length} objects selected</span>
        <div className="panel-head-actions">
          <IconButton label="Duplicate" size="sm" onClick={duplicateSelection}><Copy /></IconButton>
          <IconButton label="Delete" size="sm" onClick={deleteSelection}><Trash2 /></IconButton>
        </div>
      </div>
      <div className="panel-body">
        <section className="inspector-section">
          <div className="section-label"><span>Transform</span><span className="dim">Reference · {primary?.name || 'Primary'}</span></div>
          <div className="section-label"><span>Position</span><span className="dim">meters</span></div>
          <div className="form-grid form-grid--3">
            {(['x', 'y', 'z'] as Axis[]).map((axis) => (
              <Field key={axis} label={mixedLabel(axis.toUpperCase(), position(axis))}>
                <NumberInput value={position(axis)} step={0.05} suffix="m" placeholder="Mixed" ariaLabel={`Multi position ${axis.toUpperCase()}`} onChange={(value) => commitPosition(axis, value)} />
              </Field>
            ))}
          </div>
          <div className="section-label"><span>Rotation</span><span className="dim">degrees</span></div>
          <div className="form-grid form-grid--3">
            {(['x', 'y', 'z'] as Axis[]).map((axis) => (
              <Field key={axis} label={mixedLabel(`Rot ${axis.toUpperCase()}`, rotation(axis))}>
                <NumberInput value={rotation(axis)} step={5} suffix="°" placeholder="Mixed" ariaLabel={`Multi rotation ${axis.toUpperCase()}`} onChange={(value) => commitRotation(axis, value)} />
              </Field>
            ))}
          </div>
          {hasModels && (
            <>
              <div className="row-between"><span className="field-label">Uniform scale lock <span className="dim">{objects.filter((object) => object.type === 'model').length}/{objects.length}</span></span><Toggle checked={uniformScale} ariaLabel="Uniform scale lock" onChange={setUniformScale} /></div>
              <div className="form-grid form-grid--3">
                {(['x', 'y', 'z'] as Axis[]).map((axis) => (
                  <Field key={axis} label={mixedLabel(`Scale ${axis.toUpperCase()}`, scale(axis))}>
                    <NumberInput value={scale(axis)} min={0.001} step={0.1} placeholder="Mixed" ariaLabel={`Multi scale ${axis.toUpperCase()}`} onChange={(value) => commitScale(axis, value)} />
                  </Field>
                ))}
              </div>
            </>
          )}
          <div className="row wrap">
            <Button size="sm" icon={<Copy />} onClick={copySelectionTransform}>Copy transform</Button>
            <Button size="sm" icon={<ClipboardPaste />} disabled={!transformClipboard} onClick={pasteSelectionTransform}>Paste transform</Button>
            <Button size="sm" icon={<RotateCcw />} onClick={resetSelectionRotation}>Reset rotation</Button>
            {hasModels && <Button size="sm" icon={<RotateCcw />} onClick={resetSelectionScale}>Reset scale</Button>}
          </div>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Visibility</span><span className="dim">{objects.length} objects</span></div>
          <div className="row-between"><span className="field-label">Visible in 3D</span><BulkToggle value={commonBool((object) => object.modelVisible !== false)} onChange={updateSelectionVisibility} label="Visible in 3D" /></div>
          {lightObjects.length > 0 && <div className="row-between"><span className="field-label">Light enabled <span className="dim">{lightObjects.length}/{objects.length}</span></span><BulkToggle value={commonLight((light) => light.on) as boolean | null} onChange={(checked) => updateSelectionLight({ on: checked })} label="Light enabled" /></div>}
        </section>

        {lightObjects.length > 0 && (
          <section className="inspector-section">
            <div className="section-label"><span>Light</span><span className="dim">{lightObjects.length} compatible</span></div>
            <Field label={mixedLabel('Dimmer', commonLight((light) => light.intensity) as number | null)}>
              <NumberInput value={typeof commonLight((light) => light.intensity) === 'number' ? (commonLight((light) => light.intensity) as number) * 100 : null} min={0} max={1000} step={1} suffix="%" placeholder="Mixed" ariaLabel="Bulk light dimmer" onChange={(value) => { if (value !== null) updateSelectionLight({ intensity: value / 100 }); }} />
            </Field>
            <div className="row-between"><span className="field-label">Color</span>{commonLight((light) => light.color) === null ? <span className="dim">Mixed</span> : null}<input className="color-input" type="color" aria-label="Bulk light color" value={String(commonLight((light) => light.color) || '#ffffff')} onPointerDown={beginTransaction} onPointerUp={endTransaction} onBlur={endTransaction} onChange={(event) => updateSelectionLight({ color: event.target.value })} /></div>
            {compatibleLights('pan').length + compatibleLights('tilt').length + compatibleLights('zoom').length + compatibleLights('focus').length + compatibleLights('strobe').length > 0 && (
              <details className="multi-advanced">
                <summary>Advanced light controls</summary>
                {compatibleLights('pan').length > 0 && <Field label={mixedLabel(`Pan (${compatibleLights('pan').length}/${objects.length})`, commonCapability('pan') as number | null)}><NumberInput value={typeof commonCapability('pan') === 'number' ? commonCapability('pan') as number : null} step={1} suffix="°" placeholder="Mixed" ariaLabel="Bulk pan" onChange={(value) => { if (value !== null) updateSelectionLightCapability('pan', { pan: value }); }} /></Field>}
                {compatibleLights('tilt').length > 0 && <Field label={mixedLabel(`Tilt (${compatibleLights('tilt').length}/${objects.length})`, commonCapability('tilt') as number | null)}><NumberInput value={typeof commonCapability('tilt') === 'number' ? commonCapability('tilt') as number : null} step={1} suffix="°" placeholder="Mixed" ariaLabel="Bulk tilt" onChange={(value) => { if (value !== null) updateSelectionLightCapability('tilt', { tilt: value }); }} /></Field>}
                {compatibleLights('zoom').length > 0 && <Field label={mixedLabel(`Zoom (${compatibleLights('zoom').length}/${objects.length})`, commonCapability('zoom') as number | null)}><NumberInput value={typeof commonCapability('zoom') === 'number' ? commonCapability('zoom') as number : null} step={0.5} suffix="°" placeholder="Mixed" ariaLabel="Bulk zoom" onChange={(value) => { if (value !== null) updateSelectionLightCapability('zoom', { zoom: value }); }} /></Field>}
                {compatibleLights('focus').length > 0 && <Field label={mixedLabel(`Focus (${compatibleLights('focus').length}/${objects.length})`, commonCapability('focus') as number | null)}><NumberInput value={typeof commonCapability('focus') === 'number' ? commonCapability('focus') as number : null} step={1} suffix="%" placeholder="Mixed" ariaLabel="Bulk focus" onChange={(value) => { if (value !== null) updateSelectionLight({ focus: value / 100 }); }} /></Field>}
                {compatibleLights('strobe').length > 0 && <Field label={mixedLabel(`Strobe (${compatibleLights('strobe').length}/${objects.length})`, commonCapability('strobe') as number | null)}><NumberInput value={typeof commonCapability('strobe') === 'number' ? commonCapability('strobe') as number : null} step={1} suffix="Hz" placeholder="Mixed" ariaLabel="Bulk strobe" onChange={(value) => { if (value !== null) updateSelectionLightCapability('strobe', { strobe: value }); }} /></Field>}
              </details>
            )}
          </section>
        )}

        {modelObjects.length > 0 && (
          <section className="inspector-section">
            <div className="section-label"><span>Material</span><span className="dim">{modelObjects.length}/{objects.length}</span></div>
            <div className="form-grid form-grid--3">
              <Field label={mixedLabel('Base color', commonMaterial((material) => material.color) as string | null)}><input className="color-input" type="color" aria-label="Bulk material color" value={String(commonMaterial((material) => material.color) || '#ffffff')} onPointerDown={beginTransaction} onPointerUp={endTransaction} onBlur={endTransaction} onChange={(event) => updateSelectionMaterial({ color: event.target.value })} /></Field>
              <Field label={mixedLabel('Metalness', commonMaterial((material) => material.metalness) as number | null)}><NumberInput value={typeof commonMaterial((material) => material.metalness) === 'number' ? commonMaterial((material) => material.metalness) as number : null} min={0} max={1} step={0.05} placeholder="Mixed" ariaLabel="Bulk material metalness" onChange={(value) => { if (value !== null) updateSelectionMaterial({ metalness: value }); }} /></Field>
              <Field label={mixedLabel('Roughness', commonMaterial((material) => material.roughness) as number | null)}><NumberInput value={typeof commonMaterial((material) => material.roughness) === 'number' ? commonMaterial((material) => material.roughness) as number : null} min={0} max={1} step={0.05} placeholder="Mixed" ariaLabel="Bulk material roughness" onChange={(value) => { if (value !== null) updateSelectionMaterial({ roughness: value }); }} /></Field>
              <Field label={mixedLabel('Emissive', commonMaterial((material) => material.emissive) as string | null)}><input className="color-input" type="color" aria-label="Bulk material emissive" value={String(commonMaterial((material) => material.emissive) || '#000000')} onPointerDown={beginTransaction} onPointerUp={endTransaction} onBlur={endTransaction} onChange={(event) => updateSelectionMaterial({ emissive: event.target.value })} /></Field>
              <Field label={mixedLabel('Opacity', commonMaterial((material) => material.opacity) as number | null)}><NumberInput value={typeof commonMaterial((material) => material.opacity) === 'number' ? (commonMaterial((material) => material.opacity) as number) * 100 : null} min={0} max={100} step={1} suffix="%" placeholder="Mixed" ariaLabel="Bulk material opacity" onChange={(value) => { if (value !== null) updateSelectionMaterial({ opacity: value / 100 }); }} /></Field>
            </div>
          </section>
        )}

        <section className="inspector-section">
          <div className="section-label"><span>Modifiers</span><span className="dim">apply to selection</span></div>
          <div className="row">
            <select className="select" aria-label="Bulk modifier type" value={modifierType} onChange={(event) => setModifierType(event.target.value)}>
              {MODIFIER_DEFINITIONS.filter((definition) => definition.targets.some((target) => target !== 'scene')).map((definition) => <option key={definition.type} value={definition.type}>{definition.label}</option>)}
            </select>
            <Button size="sm" onClick={() => addModifierToSelection(modifierType)}>Add to selection</Button>
          </div>
          <p className="field-hint">Adds an independently editable modifier to every compatible selected object.</p>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Align · active reference</span><span className="dim">{primary?.name || 'Primary'}</span></div>
          <div className="align-grid align-grid--transform">
            <Button size="sm" onClick={() => alignSelectionAxis('x')}>Same X</Button>
            <Button size="sm" onClick={() => alignSelectionAxis('y')}>Same Y</Button>
            <Button size="sm" onClick={() => alignSelectionAxis('z')}>Same Z</Button>
            <Button size="sm" onClick={() => distributeSelectionAxis('x')}>Distribute X</Button>
            <Button size="sm" onClick={() => distributeSelectionAxis('y')}>Distribute Y</Button>
            <Button size="sm" onClick={() => distributeSelectionAxis('z')}>Distribute Z</Button>
          </div>
          <div className="section-label"><span>Bounding align</span></div>
          <div className="align-grid">
            <IconButton label="Align left" onClick={() => alignSelection('left')}><AlignLeft /></IconButton>
            <IconButton label="Align center X" onClick={() => alignSelection('center-x')}><AlignCenterHorizontal /></IconButton>
            <IconButton label="Align right" onClick={() => alignSelection('right')}><AlignRight /></IconButton>
            <IconButton label="Align top" onClick={() => alignSelection('top')}><AlignStartVertical /></IconButton>
            <IconButton label="Align center Z" onClick={() => alignSelection('center-z')}><AlignCenterVertical /></IconButton>
            <IconButton label="Align bottom" onClick={() => alignSelection('bottom')}><AlignEndVertical /></IconButton>
            <IconButton label="Distribute on X" onClick={() => distributeSelection('x')}><AlignHorizontalSpaceAround /></IconButton>
            <IconButton label="Distribute on Z" onClick={() => distributeSelection('z')}><AlignVerticalSpaceAround /></IconButton>
          </div>
          <div className="row" style={{ marginTop: 8 }}>
            <Button size="sm" icon={<RotateCw />} onClick={() => rotateSelection(90)}>Rotate</Button>
            <Button size="sm" icon={<Layers />} onClick={groupSelection}>Group</Button>
            <Button size="sm" icon={<Layers />} onClick={ungroupSelection}>Ungroup</Button>
          </div>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Material / Look</span></div>
          <MaterialLookControl project={project} ids={[...selectedIds]} />
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Actions</span></div>
          <div className="row wrap">
            <Button size="sm" icon={<Lock />} onClick={() => lockSelection(true)}>Lock</Button>
            <Button size="sm" icon={<Unlock />} onClick={() => lockSelection(false)}>Unlock</Button>
            <Button size="sm" icon={<Eye />} onClick={() => hideSelection(true)}>Show</Button>
            <Button size="sm" icon={<EyeOff />} onClick={() => hideSelection(false)}>Hide</Button>
          </div>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Shared effect stacks</span><span className="count">{sharedGroups.length}</span></div>
          <p className="field-hint">One parameter source for every target in the stack.</p>
          <div className="row wrap"><Button size="sm" onClick={addSharedGroup}>New shared stack</Button><select className="select" value={presetId} aria-label="Effect preset" onChange={(event) => setPresetId(event.target.value)}>{EFFECT_PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.label}</option>)}</select><Button size="sm" onClick={() => effectCommands.applyPreset([...selectedIds], presetId)}>Apply preset</Button></div>
          {sharedGroups.map((group) => (
            <div className="shared-effect-group" key={group.id}>
              <div className="row-between">
                <span className="field-label">{group.name} · {group.targetIds.length} targets</span>
                <span className="row"><button type="button" className="section-link" onClick={() => makeSharedUnique(group.id)}>Make unique</button><button type="button" className="section-link" onClick={() => removeSharedGroup(group.id)}>Remove</button></span>
              </div>
              <ModifiersEditor modifiers={group.modifiers} target={sharedTarget} onChange={(next) => updateSharedGroup(group.id, next)} />
            </div>
          ))}
        </section>

        <details className="inspector-section multi-objects-details">
          <summary className="section-label"><span>Selected objects</span><span className="count">{objects.length}</span></summary>
          <div className="multi-list">
            {objects.map((object) => {
              const dims = objectDims(object);
              return (
                <button type="button" className={`multi-row ${object.id === primary?.id ? 'is-primary' : ''}`} key={object.id} onClick={() => selectMany([object.id, ...selectedIds.filter((id) => id !== object.id)])}>
                  <span className={`status-dot ${object.light ? 'status-dot--accent' : ''}`} />
                  <span className="truncate">{object.name}</span>
                  <span className="num dim">{dims.w.toFixed(2)} × {dims.d.toFixed(2)}</span>
                </button>
              );
            })}
          </div>
        </details>
      </div>
    </>
  );
}
