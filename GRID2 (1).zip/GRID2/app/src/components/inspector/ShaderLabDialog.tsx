import { useMemo, useState } from 'react';
import type { CustomShader, ShaderInstance } from '../../types/project';
import { compileCustomShader, defaultFullMeshShader, defaultMeshShader, defaultPostPreset, defaultPostShader, defaultValues, MESH_FRAGMENT_TEMPLATE, MESH_VERTEX_TEMPLATE, postPresetNames, type PostPresetName } from '../../lib/customShaders';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';

function LineNumbers({ source }: { source: string }) {
  const count = Math.max(1, source.split('\n').length);
  return <pre className="shader-line-numbers" aria-hidden="true">{Array.from({ length: count }, (_, index) => index + 1).join('\n')}</pre>;
}

export function ShaderLabDialog({ objectId, lookId, initialContext = 'mesh', initialShaderId, replacePostShaderId, onClose }: { objectId?: string; lookId?: string; initialContext?: 'mesh' | 'post'; initialShaderId?: string; replacePostShaderId?: string; onClose: () => void }) {
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const updateCustomShaders = useWorkspaceStore((state) => state.updateCustomShaders);
  const assignShader = useWorkspaceStore((state) => state.assignShader);
  const assignPostShader = useWorkspaceStore((state) => state.assignPostShader);
  const replacePostShader = useWorkspaceStore((state) => state.replacePostShader);
  const pushToast = useUiStore((state) => state.pushToast);
  const meshCapabilities = useUiStore((state) => state.meshCapabilities);
  const shaders = project?.customShaders || [];
  const initial = (initialShaderId ? shaders.find((shader) => shader.id === initialShaderId) : undefined) || shaders.find((shader) => shader.context === initialContext) || (initialContext === 'mesh' ? shaders[0] : undefined);
  const [selectedId, setSelectedId] = useState(initial?.id || '');
  const source = shaders.find((shader) => shader.id === selectedId);
  const [draft, setDraft] = useState<CustomShader | null>(source ? structuredClone(source) : null);
  const [tab, setTab] = useState<'vertex' | 'fragment' | 'parameters'>(source?.context === 'post' ? 'fragment' : 'vertex');
  const [status, setStatus] = useState<'idle' | 'valid' | 'error'>('idle');
  const [errors, setErrors] = useState<{ stage: string; line: number; message: string; raw: string }[]>([]);
  const [autoCompile, setAutoCompile] = useState(false);

  const select = (id: string) => {
    const next = shaders.find((shader) => shader.id === id);
    setSelectedId(id);
    setDraft(next ? structuredClone(next) : null);
    setErrors([]);
    setStatus('idle');
    setTab(next?.context === 'post' ? 'fragment' : 'vertex');
  };
  const createShader = (factory: () => CustomShader = defaultMeshShader) => {
    const shader = factory();
    updateCustomShaders([...shaders, shader]);
    setSelectedId(shader.id);
    setDraft(structuredClone(shader));
    setTab(shader.context === 'post' ? 'fragment' : 'vertex');
  };
  const saveDraft = (next: CustomShader) => {
    setDraft(next);
    if (autoCompile) compile(next);
  };
  const compile = (target = draft) => {
    if (!target) return;
    const result = compileCustomShader(target);
    setErrors(result.errors);
    setStatus(result.ok ? 'valid' : 'error');
    if (result.ok) {
      const next = { ...target, lastWorking: { vertex: target.vertex, fragment: target.fragment }, updatedAt: new Date().toISOString() };
      setDraft(next);
      updateCustomShaders(shaders.map((shader) => shader.id === next.id ? next : shader));
      pushToast('Shader compiled', 'success');
    } else {
      pushToast('Shader compile failed — last working shader remains active', 'warning');
    }
  };
  const revert = () => {
    if (!draft?.lastWorking) return;
    const next = { ...draft, vertex: draft.lastWorking.vertex, fragment: draft.lastWorking.fragment };
    setDraft(next);
    setErrors([]);
    setStatus('valid');
    updateCustomShaders(shaders.map((shader) => shader.id === next.id ? next : shader));
  };
  const assign = (replace = false) => {
    if (!draft) return;
    updateCustomShaders(shaders.map((shader) => shader.id === draft.id ? { ...draft, updatedAt: new Date().toISOString() } : shader));
    const instance: ShaderInstance = { id: `pass_${crypto.randomUUID()}`, shaderId: draft.id, enabled: true, values: defaultValues(draft) };
    if (draft.context === 'post') {
      if (replace && replacePostShaderId) { replacePostShader(replacePostShaderId, instance); pushToast('Post pass replaced', 'success'); }
      else { assignPostShader(instance); pushToast('Added to Post Stack', 'success'); }
    } else { assignShader({ objectId, lookId }, instance); pushToast(`Shader assigned to ${lookId ? 'shared Look' : 'object'}`, 'success'); }
    onClose();
  };
  const available = useMemo(() => shaders, [shaders]);

  return (
    <Dialog title="Shader Lab" description={draft?.context === 'post' ? 'POST / FULLSCREEN — fullscreen fragment shader over the rendered viewport with previous-frame feedback.' : 'Mesh shader — PBR extension or full-custom material.'} onClose={onClose} wide footer={<><Button size="sm" variant="ghost" onClick={onClose}>Close</Button>{draft?.context === 'post' ? <>{replacePostShaderId && <Button size="sm" variant="ghost" onClick={() => assign(false)}>Add as New Pass</Button>}<Button size="sm" onClick={() => assign(!!replacePostShaderId)}>{replacePostShaderId ? 'Replace Selected Pass' : 'Add to Post Stack'}</Button></> : draft && <Button size="sm" onClick={() => assign(false)}>Assign to {lookId ? 'Look' : 'Object'}</Button>}</>}>
      <div className="shader-lab">
        <div className="shader-lab-list">
          <div className="shader-create-row">
            <Button size="sm" onClick={() => createShader(defaultMeshShader)}>+ PBR Mesh</Button>
            <Button size="sm" onClick={() => createShader(defaultFullMeshShader)}>+ Full Custom Mesh</Button>
            <Button size="sm" onClick={() => createShader(defaultPostShader)}>+ Post / Fullscreen</Button>
          </div>
          <div className="row-between"><span className="field-label">Project shaders</span><span className="field-hint">{shaders.length}</span></div>
          {available.map((shader) => <button type="button" key={shader.id} className={`shader-lab-item ${shader.id === selectedId ? 'is-selected' : ''}`} onClick={() => select(shader.id)}><span>{shader.name}</span><small>{shader.mode}</small></button>)}
          {!available.length && <p className="field-hint">No custom shaders. Create one from the Vertex Displacement template.</p>}
        </div>
        {draft ? (
          <div className="shader-lab-editor">
            {objectId && meshCapabilities[objectId] && <div className="shader-capabilities"><span>Mesh capabilities</span><b>UV0 {meshCapabilities[objectId].uv0 ? 'Yes' : 'No'}</b><b>UV1 {meshCapabilities[objectId].uv1 ? 'Yes' : 'No'}</b><b>Normals {meshCapabilities[objectId].normals ? 'Yes' : 'No'}</b><b>Tangents {meshCapabilities[objectId].tangents ? 'Yes' : 'No'}</b><b>Colors {meshCapabilities[objectId].colors ? 'Yes' : 'No'}</b>{!meshCapabilities[objectId].uv0 && <em>UV0 unavailable — custom snippets use generated uv coordinates</em>}</div>}
            <div className={`shader-context-badge${draft.context === 'post' ? ' is-post' : ''}`}>{draft.context === 'post' ? 'POST / FULLSCREEN' : draft.mode === 'full-custom' ? 'FULL CUSTOM MESH' : 'PBR MESH'}</div>
            {draft.context === 'post' && <div className="shader-preset-row"><span className="field-label">Starter presets</span>{postPresetNames().map((preset) => <button type="button" key={preset.id} className="shader-preset" onClick={() => { const next = { ...draft, name: `Post · ${preset.label}`, fragment: defaultPostPreset(preset.id).fragment, params: defaultPostPreset(preset.id).params, lastWorking: defaultPostPreset(preset.id).lastWorking }; setDraft(next); setTab('fragment'); setStatus('idle'); setErrors([]); }}>{preset.label}</button>)}</div>}
            <div className="shader-lab-head">
              <input className="input" value={draft.name} aria-label="Shader name" onChange={(event) => saveDraft({ ...draft, name: event.target.value })} />
              <span className="modifier-cost">{draft.context} · {draft.cost || 'medium'}</span>
              <select className="select" value={draft.mode} aria-label="Shader mode" onChange={(event) => saveDraft({ ...draft, mode: event.target.value as CustomShader['mode'] })}><option value="pbr-extension">PBR Extension</option><option value="full-custom">Full Custom</option></select>
            </div>
            {draft.mode === 'full-custom' && draft.context === 'mesh' && <p className="field-hint" style={{ padding: '0 6px' }}>Attributes: aPosition always; aNormal, aUv0, aUv1, aTangent, aColor only when the mesh provides them. The active Look base-color texture is bound as uTexture (uHasTexture 0/1).</p>}
            {draft.context === 'mesh' && <div className="row gap-8" style={{ alignItems: 'center', padding: '0 6px' }}><span className="field-label">Bounds expansion</span><input className="input" type="number" min={0} step={1} value={draft.boundsExpansion ?? 0} aria-label="Bounds expansion" onChange={(event) => saveDraft({ ...draft, boundsExpansion: Math.max(0, Number(event.target.value) || 0) })} /><span className="field-hint">Conservative scene bounds; full-custom meshes also disable their own frustum culling.</span></div>}
            <div className="shader-lab-tabs">
              <button type="button" className={tab === 'vertex' ? 'is-active' : ''} onClick={() => setTab('vertex')}>Vertex</button>
              <button type="button" className={tab === 'fragment' ? 'is-active' : ''} onClick={() => setTab('fragment')}>Fragment</button>
              <button type="button" className={tab === 'parameters' ? 'is-active' : ''} onClick={() => setTab('parameters')}>Parameters</button>
              <span className={`shader-status shader-status--${status}`}>{status === 'valid' ? 'Valid' : status === 'error' ? 'Error' : 'Not compiled'}</span>
            </div>
            {tab !== 'parameters' ? (
              <div className="shader-source">
                <LineNumbers source={tab === 'vertex' ? draft.vertex : draft.fragment} />
                <textarea aria-label={`${tab} shader source`} spellCheck={false} value={tab === 'vertex' ? draft.vertex : draft.fragment} onChange={(event) => saveDraft({ ...draft, [tab]: event.target.value })} onKeyDown={(event) => { if (event.key === 'Tab') { event.preventDefault(); const target = event.currentTarget; const start = target.selectionStart; const sourceValue = target.value; const next = `${sourceValue.slice(0, start)}  ${sourceValue.slice(target.selectionEnd)}`; saveDraft({ ...draft, [tab]: next }); requestAnimationFrame(() => { target.selectionStart = target.selectionEnd = start + 2; }); } }} />
              </div>
            ) : (
              <div className="shader-params">
                {draft.params.map((param) => <div className="shader-param" key={param.id}><strong>{param.label}</strong><code>{param.type} {param.id}</code><span>{param.shortDescription}</span></div>)}
                <p className="field-hint">Parameters are derived from the uniform declarations in the shader. Auto-exposure of uniforms is limited to the current template parameters.</p>
              </div>
            )}
            <div className="row wrap">
              <Button size="sm" onClick={() => compile()}>Compile</Button>
              <label className="shader-auto"><input type="checkbox" checked={autoCompile} onChange={(event) => setAutoCompile(event.target.checked)} /> Auto compile</label>
              <Button size="sm" variant="ghost" onClick={revert} disabled={!draft.lastWorking}>Revert to last working</Button>
              <Button size="sm" variant="ghost" onClick={() => { const copy = { ...structuredClone(draft), id: `shader_${crypto.randomUUID()}`, name: `${draft.name} Copy` }; updateCustomShaders([...shaders, copy]); select(copy.id); }}>Duplicate</Button>
            </div>
            {errors.length > 0 && <div className="shader-errors">{errors.map((error, index) => <div key={`${error.raw}-${index}`}><strong>{error.stage.toUpperCase()}{error.line ? ` · line ${error.line}` : ''}</strong><span>{error.message}</span><details><summary>Raw</summary><code>{error.raw}</code></details></div>)}</div>}
            {draft.lastWorking && <p className="field-hint">Last valid compile is stored and used if the current source fails.</p>}
          </div>
        ) : <div className="shader-lab-empty"><p>Pick a shader type from the buttons above. Post / Fullscreen creates a fullscreen fragment shader with uScene, uPrevious and feedback presets.</p></div>}
      </div>
    </Dialog>
  );
}
