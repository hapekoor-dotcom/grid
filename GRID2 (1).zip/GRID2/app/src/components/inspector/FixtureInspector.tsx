import type { SceneObject, Project } from '../../types/project';
import { getDevice } from '../../lib/catalog';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { LightControls } from '../lighting/LightControls';
import { CommitText } from '../ui/CommitText';
import { Field, NumberInput, Toggle } from '../ui/Field';
import { KeyframeButton } from './KeyframeButton';

export function FixtureInspector({ object, project }: { object: SceneObject; project: Project }) {
  const updateObject = useWorkspaceStore((state) => state.updateObject);
  const deleteSelection = useWorkspaceStore((state) => state.deleteSelection);
  const duplicateSelection = useWorkspaceStore((state) => state.duplicateSelection);
  const setMode = useUiStore((state) => state.setMode);
  const focusCamera = useUiStore((state) => state.focusCamera);
  const device = getDevice(object.deviceId);
  const light = object.light;

  return (
    <>
      <div className="panel-head inspector-head">
        <span className="inspector-type-icon">{device?.kind === 'bar' ? '▬' : '◉'}</span>
        <div className="inspector-title-block">
          <CommitText value={object.name} className="inspector-title-input" ariaLabel="Object name" maxLength={80} onCommit={(value) => updateObject(object.id, { name: value.trim().slice(0, 80) || object.name })} />
          <span className="inspector-kind">{device?.shortName || 'Fixture'} · Advanced Fixture</span>
        </div>
        <details className="inspector-more">
          <summary aria-label="More actions">•••</summary>
          <div className="inspector-more-menu">
            <button type="button" onClick={() => { setMode('3d'); focusCamera(object.id); }}>Focus in 3D</button>
            <button type="button" onClick={() => duplicateSelection()}>Duplicate</button>
            <span className="inspector-more-sep" />
            <button type="button" className="danger" onClick={() => deleteSelection()}>Delete</button>
          </div>
        </details>
      </div>
      <div className="panel-body inspector-body">
        <section className="inspector-section">
          <div className="section-label"><span>Transform</span></div>
          <div className="form-grid form-grid--3">
            <Field label={<span className="field-label-row"><span className="field-label">X</span><KeyframeButton objectId={object.id} propertyPath="position.x" value={object.position.x} label="X" /></span>}><NumberInput value={object.position.x} step={0.05} suffix="m" ariaLabel="Position X" onChange={(value) => updateObject(object.id, { position: { ...object.position, x: value ?? 0 } })} /></Field>
            <Field label={<span className="field-label-row"><span className="field-label">Y</span><KeyframeButton objectId={object.id} propertyPath="position.y" value={object.elevation} label="Y" /></span>}><NumberInput value={object.elevation} step={0.05} suffix="m" ariaLabel="Position Y" onChange={(value) => updateObject(object.id, { elevation: value ?? 0 })} /></Field>
            <Field label={<span className="field-label-row"><span className="field-label">Z</span><KeyframeButton objectId={object.id} propertyPath="position.z" value={object.position.z} label="Z" /></span>}><NumberInput value={object.position.z} step={0.05} suffix="m" ariaLabel="Position Z" onChange={(value) => updateObject(object.id, { position: { ...object.position, z: value ?? 0 } })} /></Field>
          </div>
          <div className="form-grid form-grid--3">
            <Field label={<span className="field-label-row"><span className="field-label">Rot X</span><KeyframeButton objectId={object.id} propertyPath="rotation.x" value={object.rotationX || 0} label="Rot X" /></span>}><NumberInput value={object.rotationX || 0} step={5} suffix="°" ariaLabel="Rotation X" onChange={(value) => updateObject(object.id, { rotationX: value ?? 0 })} /></Field>
            <Field label={<span className="field-label-row"><span className="field-label">Rot Y</span><KeyframeButton objectId={object.id} propertyPath="rotation.y" value={object.rotation} label="Rot Y" /></span>}><NumberInput value={object.rotation} step={5} suffix="°" ariaLabel="Rotation Y" onChange={(value) => updateObject(object.id, { rotation: value ?? 0 })} /></Field>
            <Field label={<span className="field-label-row"><span className="field-label">Rot Z</span><KeyframeButton objectId={object.id} propertyPath="rotation.z" value={object.rotationZ || 0} label="Rot Z" /></span>}><NumberInput value={object.rotationZ || 0} step={5} suffix="°" ariaLabel="Rotation Z" onChange={(value) => updateObject(object.id, { rotationZ: value ?? 0 })} /></Field>
          </div>
          <p className="field-hint">Physical transform is independent from Pan/Tilt optics.</p>
        </section>
        <section className="inspector-section">
          <div className="section-label"><span>Visibility</span></div>
          <div className="row-between"><span className="field-label">Visible in 3D</span><Toggle checked={object.modelVisible !== false} ariaLabel="Visible in 3D" onChange={(checked) => updateObject(object.id, { modelVisible: checked })} /></div>
          {light && <div className="row-between"><span className="field-label">Light enabled</span><Toggle checked={light.on} ariaLabel="Light enabled" onChange={(checked) => updateObject(object.id, { light: { ...light, on: checked } })} /></div>}
        </section>
        {light && <section className="inspector-section"><div className="section-label"><span>Light</span></div><LightControls project={project} objects={[object]} compact /></section>}
      </div>
    </>
  );
}
