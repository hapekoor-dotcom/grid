import { useEffect, useRef, useState } from 'react';
import { FileImage, Image, RotateCcw, Upload, X } from 'lucide-react';
import type { MaterialMapChannel, MaterialMapKind, MaterialTextureLayer, ObjectMaterial } from '../../types/project';
import { MATERIAL_MAP_DEFINITIONS, type MaterialMapDefinition, type MaterialSourceMapInfo } from '../../lib/materialMaps';
import { materialTextureUrl, storeMaterialTexture } from '../../lib/materialAssets';
import { useUiStore } from '../../store/uiStore';
import { Field, NumberInput, Select, Toggle } from '../ui/Field';

function useTexturePreview(assetId: string | null | undefined): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    let objectUrl: string | null = null;
    setUrl(null);
    if (!assetId) return () => { active = false; };
    void materialTextureUrl(assetId).then((next) => {
      if (!next) return;
      if (!active) { URL.revokeObjectURL(next); return; }
      objectUrl = next;
      setUrl(next);
    });
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [assetId]);
  return url;
}

function MapCard({ definition, layer, source, onChange }: { definition: MaterialMapDefinition; layer?: MaterialTextureLayer; source?: MaterialSourceMapInfo; onChange: (layer: MaterialTextureLayer | null) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const pushToast = useUiStore((state) => state.pushToast);
  const preview = useTexturePreview(layer?.assetId);
  const status = layer?.assetId ? layer.assetName || 'Custom texture' : layer ? 'Original + transform' : source?.present ? 'Imported texture' : 'No imported map';

  const upload = async (file: File) => {
    setBusy(true);
    try {
      const stored = await storeMaterialTexture(file);
      onChange({ ...(layer || {}), assetId: stored.assetId, assetName: stored.assetName, ...(definition.kind === 'roughness' && layer?.invert === undefined ? { invert: true } : {}) });
      pushToast(`${definition.label} replaced`, 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Texture upload failed.', 'error');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const edit = (patch: Partial<MaterialTextureLayer>) => onChange({ ...(layer || {}), ...patch });
  const tiling = layer?.tiling || { x: 1, y: 1 };
  const offset = layer?.offset || { x: 0, y: 0 };

  return (
    <details
      className={`material-map-card ${dragging ? 'is-dragging' : ''}`}
      onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(event) => {
        event.preventDefault();
        setDragging(false);
        const file = Array.from(event.dataTransfer.files).find((entry) => entry.type.startsWith('image/'));
        if (file) void upload(file);
      }}
    >
      <summary className="material-map-summary">
        <span className="material-map-thumb">
          {preview || source?.thumbnail ? <img src={preview || source?.thumbnail} alt="" /> : <Image aria-hidden="true" />}
        </span>
        <span className="material-map-name">{definition.label}</span>
        <span className={`material-map-status ${layer?.assetId ? 'is-custom' : ''}`}>{status}</span>
      </summary>
      <div className="material-map-body">
        <div className="material-map-actions">
          <input ref={inputRef} type="file" accept="image/*" hidden aria-label={`Upload ${definition.label}`} onChange={(event) => { const file = event.target.files?.[0]; if (file) void upload(file); }} />
          <button type="button" className="btn btn--sm btn--ghost" disabled={busy} onClick={() => inputRef.current?.click()}><Upload /> {busy ? 'Uploading…' : layer?.assetId ? 'Replace' : 'Upload'}</button>
          <button type="button" className="section-link" disabled={!layer?.assetId} onClick={() => edit({ assetId: null, assetName: null })}><RotateCcw /> Use original</button>
          <button type="button" className="section-link" disabled={!layer} onClick={() => onChange(null)}><X /> Remove</button>
        </div>
        <div className="material-map-grid">
          <Field label="UV channel">
            <Select value={String(layer?.uv ?? 0)} ariaLabel={`${definition.label} UV channel`} options={Array.from({ length: 8 }, (_, index) => ({ value: String(index), label: `UV ${index}` }))} onChange={(value) => edit({ uv: Number(value) })} />
          </Field>
          {definition.channels && (
            <Field label="Channel">
              <Select value={layer?.channel || definition.defaultChannel || 'r'} ariaLabel={`${definition.label} channel`} options={definition.channels.map((channel) => ({ value: channel, label: channel.toUpperCase() }))} onChange={(value) => edit({ channel: value as MaterialMapChannel })} />
            </Field>
          )}
          <Field label="Tiling X"><NumberInput value={tiling.x} step={0.25} ariaLabel={`${definition.label} tiling X`} onChange={(value) => edit({ tiling: { ...tiling, x: value ?? 1 } })} /></Field>
          <Field label="Tiling Y"><NumberInput value={tiling.y} step={0.25} ariaLabel={`${definition.label} tiling Y`} onChange={(value) => edit({ tiling: { ...tiling, y: value ?? 1 } })} /></Field>
          <Field label="Offset X"><NumberInput value={offset.x} step={0.05} ariaLabel={`${definition.label} offset X`} onChange={(value) => edit({ offset: { ...offset, x: value ?? 0 } })} /></Field>
          <Field label="Offset Y"><NumberInput value={offset.y} step={0.05} ariaLabel={`${definition.label} offset Y`} onChange={(value) => edit({ offset: { ...offset, y: value ?? 0 } })} /></Field>
          <Field label="Rotation"><NumberInput value={layer?.rotation ?? 0} step={1} suffix="°" ariaLabel={`${definition.label} rotation`} onChange={(value) => edit({ rotation: value ?? 0 })} /></Field>
          {definition.kind === 'roughness' && <Field label="Invert gloss"><Toggle checked={layer?.invert === true} ariaLabel="Invert gloss map" onChange={(checked) => edit({ invert: checked })} /></Field>}
          {definition.kind === 'emissive' && <Field label="Map strength"><NumberInput value={layer?.intensity ?? 1} min={0} step={0.1} ariaLabel="Emissive map strength" onChange={(value) => edit({ intensity: value ?? 1 })} /></Field>}
        </div>
        <p className="material-map-hint"><FileImage /> Drop an image here or use Upload. Original GLB textures remain untouched.</p>
      </div>
    </details>
  );
}

export function MaterialMapsEditor({ material, sourceMaps, onChange }: { material: ObjectMaterial; sourceMaps?: Partial<Record<MaterialMapKind, MaterialSourceMapInfo>>; onChange: (maps: Partial<Record<MaterialMapKind, MaterialTextureLayer>>) => void }) {
  const maps = material.maps || {};
  return (
    <div className="material-maps">
      <div className="material-maps-head"><span>Texture maps</span><span className="dim">per slot · non-destructive</span></div>
      {MATERIAL_MAP_DEFINITIONS.map((definition) => (
        <MapCard
          key={definition.kind}
          definition={definition}
          layer={maps[definition.kind]}
          source={sourceMaps?.[definition.kind]}
          onChange={(layer) => {
            const next = { ...maps };
            if (layer) next[definition.kind] = layer;
            else delete next[definition.kind];
            onChange(next);
          }}
        />
      ))}
    </div>
  );
}
