import { useState } from 'react';
import { Upload } from 'lucide-react';
import type { MaterialLook, Project } from '../../types/project';
import { extractGlbLookOptions, type GlbLookOption } from '../../lib/glbLook';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { ShaderLabDialog } from './ShaderLabDialog';
import { Button } from '../ui/Button';
import { Select } from '../ui/Field';
import { Dialog } from '../ui/Dialog';

export function MaterialLookControl({ project, ids, objectId }: { project: Project; ids: string[]; objectId?: string }) {
  const applyLook = useWorkspaceStore((state) => state.applyLook);
  const applySavedLook = useWorkspaceStore((state) => state.applySavedLook);
  const updateLook = useWorkspaceStore((state) => state.updateLook);
  const makeLookUnique = useWorkspaceStore((state) => state.makeLookUnique);
  const duplicateLook = useWorkspaceStore((state) => state.duplicateLook);
  const deleteLook = useWorkspaceStore((state) => state.deleteLook);
  const pushToast = useUiStore((state) => state.pushToast);
  const [selected, setSelected] = useState(project.looks?.[0]?.id || '');
  const [busy, setBusy] = useState(false);
  const [choices, setChoices] = useState<GlbLookOption[]>([]);
  const [choiceIndex, setChoiceIndex] = useState(0);
  const [shaderLabOpen, setShaderLabOpen] = useState(false);
  const looks = project.looks || [];
  const currentLook = project.objects.find((object) => object.id === (objectId || ids[0]))?.lookId;
  const activeLook = looks.find((look) => look.id === (currentLook || selected));
  const importLook = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const options = await extractGlbLookOptions(file);
      if (options.length > 1) { setChoices(options); setChoiceIndex(options[0]?.index || 0); return; }
      const extracted = options[0];
      if (!extracted) throw new Error('GLB contains no materials.');
      const look: MaterialLook = { id: `look_${crypto.randomUUID()}`, name: extracted.name, material: extracted.material, createdAt: new Date().toISOString() };
      applyLook(look, ids);
      setSelected(look.id);
      pushToast(`Look “${look.name}” applied to ${ids.length} object${ids.length === 1 ? '' : 's'}`, 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Could not import GLB look', 'warning');
    } finally {
      setBusy(false);
    }
  };
  const applyChoice = () => {
    const option = choices.find((entry) => entry.index === choiceIndex) || choices[0];
    if (!option) return;
    const look: MaterialLook = { id: `look_${crypto.randomUUID()}`, name: option.name, material: option.material, createdAt: new Date().toISOString() };
    applyLook(look, ids);
    setSelected(look.id);
    setChoices([]);
    pushToast(`Look “${look.name}” applied to ${ids.length} object${ids.length === 1 ? '' : 's'}`, 'success');
  };
  return (
    <div className="material-look-control">
      <div className="row-between"><span className="field-label">Look source</span><span className="field-hint">{ids.length} target{ids.length === 1 ? '' : 's'}</span></div>
      <div className="row wrap">
        <label className="btn btn--sm btn--ghost"><Upload /> {busy ? 'Reading…' : 'Import Look'}<input type="file" accept=".glb,.gltf,model/gltf-binary,model/gltf+json" hidden onChange={(event) => { void importLook(event.target.files?.[0]); event.target.value = ''; }} /></label>
        {looks.length > 0 && <Select value={selected} ariaLabel="Look library" options={looks.map((look) => ({ value: look.id, label: look.name }))} onChange={setSelected} />}
        {looks.length > 0 && <Button size="sm" onClick={() => applySavedLook(selected, ids)}>Apply</Button>}
        {objectId && currentLook && <Button size="sm" variant="ghost" onClick={() => makeLookUnique(objectId)}>Make unique</Button>}
        <Button size="sm" variant="ghost" onClick={() => setShaderLabOpen(true)}>Shader Lab</Button>
      </div>
      {activeLook && <div className="row wrap"><input className="input" value={activeLook.name} aria-label="Look name" onChange={(event) => updateLook(activeLook.id, { name: event.target.value })} /><button type="button" className="section-link" onClick={() => duplicateLook(activeLook.id)}>Duplicate</button><button type="button" className="section-link" onClick={() => deleteLook(activeLook.id)}>Delete</button></div>}
      <p className="field-hint">GLB becomes material/texture source, not a scene model. Base material remains the foundation for shader modules.</p>
      {shaderLabOpen && <ShaderLabDialog objectId={objectId} lookId={project.objects.find((object) => object.id === objectId)?.lookId} onClose={() => setShaderLabOpen(false)} />}
      {choices.length > 0 && <Dialog title="Choose GLB material" description={`${choices.length} materials found`} onClose={() => setChoices([])} footer={<><Button size="sm" variant="ghost" onClick={() => setChoices([])}>Cancel</Button><Button size="sm" onClick={applyChoice}>Import selected material</Button></>}><div className="look-material-choices">{choices.map((option) => <label key={option.index} className={`look-material-choice ${choiceIndex === option.index ? 'is-selected' : ''}`}><input type="radio" name="glb-material" checked={choiceIndex === option.index} onChange={() => setChoiceIndex(option.index)} /><span className="look-material-swatch" style={{ background: option.material.color || '#888' }} /><span><strong>{option.name}</strong><small>material {option.index + 1} · metalness {option.material.metalness?.toFixed(2)} · roughness {option.material.roughness?.toFixed(2)} · {Object.keys(option.material.maps || {}).length} textures</small></span></label>)}</div></Dialog>}
    </div>
  );
}
