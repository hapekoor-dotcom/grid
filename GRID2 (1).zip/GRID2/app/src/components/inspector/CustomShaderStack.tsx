import { useWorkspaceStore } from '../../store/workspaceStore';
import type { Project, ShaderInstance } from '../../types/project';
import { NumberInput } from '../ui/Field';
import { defaultModulator } from '../../lib/signals';

export function CustomShaderStack({ project, objectId, lookId }: { project: Project; objectId?: string; lookId?: string }) {
  const updateShaderValues = useWorkspaceStore((state) => state.updateShaderValues);
  const setShaderModulator = useWorkspaceStore((state) => state.setShaderModulator);
  const updateCustomShaders = useWorkspaceStore((state) => state.updateCustomShaders);
  const list = lookId ? project.looks?.find((entry) => entry.id === lookId)?.shaders || [] : project.objects.find((entry) => entry.id === objectId)?.shaders || [];
  if (!list.length) return null;
  const remove = (instance: ShaderInstance) => {
    if (lookId) {
      const look = project.looks?.find((entry) => entry.id === lookId);
      if (look) {
        // Removing an instance is a Look edit; the mutation path supports one Undo step.
        useWorkspaceStore.getState().mutate((draft) => {
          const target = draft.looks?.find((entry) => entry.id === lookId);
          if (target) target.shaders = (target.shaders || []).filter((entry) => entry.shaderId !== instance.shaderId);
        });
      }
    }
  };
  return (
    <div className="custom-shader-stack">
      <div className="section-label"><span>Custom shaders</span><span className="count">{list.length}</span></div>
      {list.map((instance) => {
        const shader = project.customShaders?.find((entry) => entry.id === instance.shaderId);
        if (!shader) return null;
        return (
          <div className="custom-shader-instance" key={instance.shaderId}>
            <div className="row-between"><strong>{shader.name}</strong><span className="modifier-stage">{shader.mode}</span></div>
            {shader.params.filter((param) => param.type === 'float' || param.type === 'int').map((param) => <div className="field" key={param.id}><span className="field-label">{param.label}{param.unit ? ` · ${param.unit}` : ''}</span><NumberInput value={Number(instance.values[param.id] ?? param.default ?? 0)} step={0.01} ariaLabel={`${shader.name} ${param.label}`} onChange={(value) => updateShaderValues({ objectId, lookId }, shader.id, { [param.id]: value ?? 0 })} /><span className="field-hint">{param.shortDescription}</span><select className="select shader-mod-source" value={instance.modulators?.[param.id]?.sourceId || ''} aria-label={`${param.label} modulation source`} onChange={(event) => setShaderModulator({ objectId, lookId }, shader.id, param.id, event.target.value ? { ...defaultModulator(event.target.value), amount: 1 } : null)}><option value="">No modulator</option>{(project.signals || []).map((signal) => <option key={signal.id} value={signal.id}>{signal.name} · {signal.kind}</option>)}</select>{instance.modulators?.[param.id] && <NumberInput value={instance.modulators[param.id].amount} step={0.01} ariaLabel={`${param.label} modulation amount`} onChange={(value) => setShaderModulator({ objectId, lookId }, shader.id, param.id, { ...instance.modulators![param.id], amount: value ?? 0 })} />}</div>)}
            {shader.params.filter((param) => param.type === 'color').map((param) => <label className="field" key={param.id}><span className="field-label">{param.label}</span><input className="color-input" type="color" aria-label={`${shader.name} ${param.label}`} value={Array.isArray(instance.values[param.id]) ? `#${(instance.values[param.id] as number[]).map((value) => Math.round(value * 255).toString(16).padStart(2, '0')).join('')}` : '#33ccff'} onChange={(event) => updateShaderValues({ objectId, lookId }, shader.id, { [param.id]: [parseInt(event.target.value.slice(1, 3), 16) / 255, parseInt(event.target.value.slice(3, 5), 16) / 255, parseInt(event.target.value.slice(5, 7), 16) / 255] })} /></label>)}
            <div className="row">{!lookId && <button type="button" className="section-link" onClick={() => remove(instance)}>Remove</button>}</div>
          </div>
        );
      })}
    </div>
  );
}
