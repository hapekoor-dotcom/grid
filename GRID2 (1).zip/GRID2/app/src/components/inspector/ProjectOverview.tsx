import { Box, FolderOpen, Grid3X3, Layers, Lightbulb, Plus, Settings2, Sun } from 'lucide-react';
import type { Project } from '../../types/project';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { objectDims } from '../../lib/objects';
import { formatMeters } from '../../lib/id';
import { Button, IconButton } from '../ui/Button';
import { CommitText } from '../ui/CommitText';
import { NumberInput } from '../ui/Field';

export function ProjectOverview({ project }: { project: Project }) {
  const renameProject = useWorkspaceStore((state) => state.renameProject);
  const updateObject = useWorkspaceStore((state) => state.updateObject);
  const updateSettings = useWorkspaceStore((state) => state.updateSettings);
  const addRoom = useWorkspaceStore((state) => state.addRoom);
  const setMode = useUiStore((state) => state.setMode);
  const setProjectsOpen = useUiStore((state) => state.setProjectsOpen);
  const setSettingsOpen = useUiStore((state) => state.setSettingsOpen);
  const requestFit = useUiStore((state) => state.requestFit);

  const room = project.objects.find((object) => object.type === 'room');
  const roomDims = room ? objectDims(room) : null;
  const models = project.objects.filter((object) => object.type === 'model' || object.type === 'stage');
  const lights = project.objects.filter((object) => object.type === 'light' || object.light);
  const fixtures = project.objects.filter((object) => object.type === 'device');

  return (
    <>
      <div className="panel-head">
        <span className="panel-title">Scene</span>
        <div className="panel-head-actions">
          <IconButton label="Project settings" size="sm" onClick={() => setSettingsOpen(true)}><Settings2 /></IconButton>
          <IconButton label="All projects" size="sm" onClick={() => setProjectsOpen(true)}><FolderOpen /></IconButton>
        </div>
      </div>
      <div className="panel-body">
        <section className="inspector-section project-id">
          <CommitText value={project.name} className="project-title-input" ariaLabel="Project name" onCommit={(value) => renameProject(value)} maxLength={120} />
          <p className="field-hint">{models.length} models · {lights.length} lights · {project.objects.length} objects</p>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Scene</span></div>
          <div className="info-list">
            <div className="info-row"><span className="inline"><Box size={13} /> Models</span><span className="info-value num">{models.length}</span></div>
            <div className="info-row"><span className="inline"><Lightbulb size={13} /> Lights</span><span className="info-value num">{lights.length}</span></div>
            <div className="info-row"><span className="inline"><Layers size={13} /> Fixtures</span><span className="info-value num">{fixtures.length}</span></div>
          </div>
          <div className="row wrap" style={{ marginTop: 6 }}>
            <button type="button" className="btn btn--sm btn--ghost" onClick={() => { updateSettings({ showGrid: !project.settings.showGrid }); }}>Grid {project.settings.showGrid ? 'on' : 'off'}</button>
            <button type="button" className="btn btn--sm btn--ghost" onClick={() => { updateSettings({ snap: !project.settings.snap }); }}>Snap {project.settings.snap ? 'on' : 'off'}</button>
            <button type="button" className="btn btn--sm btn--ghost" onClick={requestFit}>Fit plan</button>
          </div>
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Room shell</span><span className="count">optional</span></div>
          {room && roomDims ? (
            <>
              <div className="form-grid">
                <label className="field"><span className="field-label">Width</span><NumberInput value={roomDims.w} min={1} step={0.5} suffix="m" ariaLabel="Room width" onChange={(value) => updateObject(room.id, { size: { ...roomDims, w: Math.max(1, value ?? 1) } })} /></label>
                <label className="field"><span className="field-label">Depth</span><NumberInput value={roomDims.d} min={1} step={0.5} suffix="m" ariaLabel="Room depth" onChange={(value) => updateObject(room.id, { size: { ...roomDims, d: Math.max(1, value ?? 1) } })} /></label>
                <label className="field"><span className="field-label">Wall height</span><NumberInput value={roomDims.h} min={1} step={0.1} suffix="m" ariaLabel="Wall height" onChange={(value) => updateObject(room.id, { size: { ...roomDims, h: Math.max(1, value ?? 1) }, room: room.room ? { ...room.room, wallHeight: Math.max(1, value ?? 1) } : null })} /></label>
              </div>
              <p className="field-hint">{formatMeters(roomDims.w, 1)} × {formatMeters(roomDims.d, 1)} m. The scene works without it.</p>
            </>
          ) : (
            <>
              <p className="field-hint">No room is required. Models and lights work in a neutral scene.</p>
              <Button size="sm" variant="ghost" icon={<Plus />} onClick={() => addRoom({ x: -7, z: -4.5, w: 14, d: 9 })}>Add optional room shell</Button>
            </>
          )}
        </section>

        <section className="inspector-section">
          <div className="section-label"><span>Preview</span></div>
          <div className="row wrap">
            <Button size="sm" variant="ghost" icon={<Grid3X3 />} onClick={() => setMode('plan')}>Plan</Button>
            <Button size="sm" variant="ghost" icon={<Sun />} onClick={() => setMode('3d')}>3D scene</Button>
          </div>
        </section>
      </div>
    </>
  );
}
