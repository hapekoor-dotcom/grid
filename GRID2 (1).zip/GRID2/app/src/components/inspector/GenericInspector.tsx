import { useEffect, useState, type ReactNode } from 'react';
import { Box, ChevronDown, ChevronRight, Lightbulb } from 'lucide-react';
import type { GenericLightType, SceneObject } from '../../types/project';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Field, NumberInput, Select, Toggle } from '../ui/Field';
import { capabilitiesOf } from '../../lib/sceneCapabilities';
import { OverdriveControl } from '../ui/OverdriveControl';
import { primitiveDefinition, primitiveFootprint } from '../../lib/primitives';
import { ModifiersEditor } from './ModifiersEditor';
import { KeyframeButton } from './KeyframeButton';
import { MaterialMapsEditor } from './MaterialMapsEditor';
import { MaterialLookControl } from './MaterialLookControl';
import { CustomShaderStack } from './CustomShaderStack';
import { defaultCollision, defaultObjectPhysics } from '../../lib/physics';

function Section({ title, children }: { title: ReactNode; children: ReactNode }) {
  return (
    <section className="inspector-section">
      <div className="section-label"><span>{title}</span></div>
      {children}
    </section>
  );
}

function CollapsibleSection({ title, count, defaultOpen = false, children }: { title: string; count?: string | number; defaultOpen?: boolean; children: ReactNode }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="inspector-section inspector-section--collapsible">
      <button type="button" className="section-label section-toggle" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        <span>{open ? <ChevronDown /> : <ChevronRight />}{title}</span>
        {count !== undefined && <span className="count">{count}</span>}
      </button>
      {open && <div className="section-collapse-body">{children}</div>}
    </section>
  );
}

const LIGHT_TYPES: { value: GenericLightType; label: string }[] = [
  { value: 'spot', label: 'Spot Light' },
  { value: 'point', label: 'Point Light' },
  { value: 'area', label: 'Area / Rect Light' },
  { value: 'directional', label: 'Directional Light' },
];

export function GenericInspector({ object }: { object: SceneObject }) {
  const updateObject = useWorkspaceStore((state) => state.updateObject);
  const updateLook = useWorkspaceStore((state) => state.updateLook);
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const light = object.light;
  const capabilities = capabilitiesOf(object);
  const [selectedMaterial, setSelectedMaterial] = useState('__all__');
  const [uniformScaleLock, setUniformScaleLock] = useState(false);
  const materialSlots = object.materialSlots?.length ? object.materialSlots : ['Material 1'];
  const materialKey = materialSlots.includes(selectedMaterial) ? selectedMaterial : materialSlots[0];
  useEffect(() => { if (!materialSlots.includes(selectedMaterial)) setSelectedMaterial(materialSlots[0]); }, [materialSlots, selectedMaterial]);
  const look = project?.looks?.find((entry) => entry.id === object.lookId);
  const material = { ...(look?.material || {}), ...(object.material || {}), ...(object.materialOverrides?.[materialKey] || {}) };
  const sourceMaps = useUiStore((state) => object.assetId ? state.assetMaterialMaps[object.assetId]?.find((entry) => entry.slot === materialKey)?.maps : undefined);
  const hasMaterialOverride = !!look || !!object.material || Object.keys(object.materialOverrides || {}).length > 0;
  const updateMaterial = (patch: Partial<NonNullable<typeof object.material>>) => {
    if (look) { updateLook(look.id, { material: { ...look.material, ...patch } }); return; }
    setTransform({ materialOverrides: { ...(object.materialOverrides || {}), [materialKey]: { ...(object.materialOverrides?.[materialKey] || {}), ...patch } } });
  };
  const resetMaterial = () => {
    const next = { ...(object.materialOverrides || {}) };
    delete next[materialKey];
    setTransform({ materialOverrides: next });
  };
  const isLight = capabilities.has('light');
  const keyLabel = (label: string, path: string, value: number | string | boolean | undefined) => (
    <span className="field-label-row"><span className="field-label">{label}</span><KeyframeButton objectId={object.id} propertyPath={path} value={value} label={label} /></span>
  );
  const scale = object.scale || { x: 1, y: 1, z: 1 };
  const setTransform = (patch: Partial<SceneObject>) => updateObject(object.id, patch);
  const setLight = (patch: Partial<NonNullable<SceneObject['light']>>) => { if (light) updateObject(object.id, { light: { ...light, ...patch } }); };

  const transform = (
    <>
      <div className="form-grid form-grid--3">
        <Field label={keyLabel('X', 'position.x', object.position.x)}><NumberInput value={object.position.x} step={0.05} suffix="m" ariaLabel="Position X" onChange={(value) => setTransform({ position: { ...object.position, x: value ?? 0 } })} /></Field>
        <Field label={keyLabel('Y', 'position.y', object.elevation)}><NumberInput value={object.elevation} step={0.05} suffix="m" ariaLabel="Position Y" onChange={(value) => setTransform({ elevation: value ?? 0 })} /></Field>
        <Field label={keyLabel('Z', 'position.z', object.position.z)}><NumberInput value={object.position.z} step={0.05} suffix="m" ariaLabel="Position Z" onChange={(value) => setTransform({ position: { ...object.position, z: value ?? 0 } })} /></Field>
      </div>
      <div className="form-grid form-grid--3">
        <Field label={keyLabel('Rot X', 'rotation.x', object.rotationX || 0)}><NumberInput value={object.rotationX || 0} step={5} suffix="°" ariaLabel="Rotation X" onChange={(value) => setTransform({ rotationX: value ?? 0 })} /></Field>
        <Field label={keyLabel('Rot Y', 'rotation.y', object.rotation)}><NumberInput value={object.rotation} step={5} suffix="°" ariaLabel="Rotation Y" onChange={(value) => setTransform({ rotation: value ?? 0 })} /></Field>
        <Field label={keyLabel('Rot Z', 'rotation.z', object.rotationZ || 0)}><NumberInput value={object.rotationZ || 0} step={5} suffix="°" ariaLabel="Rotation Z" onChange={(value) => setTransform({ rotationZ: value ?? 0 })} /></Field>
      </div>
      {capabilities.has('material') && (
        <>
          <div className="row-between"><span className="field-label">Uniform scale lock</span><Toggle checked={uniformScaleLock} ariaLabel="Uniform scale lock" onChange={setUniformScaleLock} /></div>
          <Field label={keyLabel('Uniform scale', 'scale.x', scale.x)}><NumberInput value={scale.x} min={0.01} max={100} step={0.1} ariaLabel="Uniform scale" onChange={(value) => { const next = Math.max(0.01, value ?? 1); setTransform({ scale: { x: next, y: next, z: next } }); }} /></Field>
          <div className="form-grid form-grid--3">
            {(['x', 'y', 'z'] as const).map((axis) => <Field key={axis} label={keyLabel(`Scale ${axis.toUpperCase()}`, `scale.${axis}`, scale[axis])}><NumberInput value={scale[axis]} min={0.01} max={100} step={0.1} ariaLabel={`Scale ${axis.toUpperCase()}`} onChange={(value) => { const next = Math.max(0.01, value ?? 1); setTransform({ scale: uniformScaleLock ? { x: next, y: next, z: next } : { ...scale, [axis]: next } }); }} /></Field>)}
          </div>
        </>
      )}
      {isLight && object.lightType === 'directional' && <p className="field-hint">Directional position only places the helper. Rotation controls the light direction.</p>}
    </>
  );

  const modifiers = (
    <Section title={<span className="section-title-with-count">Modifiers / Effects <em className="count">{(look?.modifiers || object.modifiers || []).length}</em></span>}>
      <ModifiersEditor modifiers={look?.modifiers || object.modifiers || []} target={object.type === 'light' ? 'light' : object.type === 'device' ? 'device' : 'model'} keyframeObjectId={look ? undefined : object.id} onChange={(next) => look ? updateLook(look.id, { modifiers: next }) : setTransform({ modifiers: next })} />
    </Section>
  );

  const materialSection = (
    <CollapsibleSection key={`material-${object.id}`} title="Material" defaultOpen={hasMaterialOverride}>
      <select className="select" value={materialKey} aria-label="Material slot" onChange={(event) => setSelectedMaterial(event.target.value)}>
        {materialSlots.map((slot) => <option key={slot} value={slot}>{slot}</option>)}
      </select>
      <div className="row-between"><span className="field-hint">Editing {materialKey}</span><button type="button" className="section-link" onClick={resetMaterial}>Reset slot</button></div>
      {project && <MaterialLookControl project={project} ids={[object.id]} objectId={object.id} />}
      {project && look && <CustomShaderStack project={project} objectId={object.id} lookId={look.id} />}
      {project && !look && <CustomShaderStack project={project} objectId={object.id} />}
      <MaterialMapsEditor material={material} sourceMaps={sourceMaps} onChange={(maps) => updateMaterial({ maps })} />
      <div className="form-grid form-grid--3">
        <Field label={keyLabel('Base color', 'material.color', material.color || '#ffffff')}><input type="color" className="color-input" aria-label="Material color" value={material.color || '#ffffff'} onChange={(event) => updateMaterial({ color: event.target.value })} /></Field>
        <Field label={keyLabel('Metalness', 'material.metalness', material.metalness ?? 0)} hint="Normalized PBR · hard runtime range 0–1"><NumberInput value={material.metalness ?? 0} min={0} max={1} step={0.05} ariaLabel="Material metalness" onChange={(value) => updateMaterial({ metalness: Math.max(0, Math.min(1, value ?? 0)) })} /></Field>
        <Field label={keyLabel('Roughness', 'material.roughness', material.roughness ?? 0.5)} hint="Normalized PBR · hard runtime range 0–1"><NumberInput value={material.roughness ?? 0.5} min={0} max={1} step={0.05} ariaLabel="Material roughness" onChange={(value) => updateMaterial({ roughness: Math.max(0, Math.min(1, value ?? 0.5)) })} /></Field>
      </div>
      <div className="form-grid form-grid--3">
        <Field label="Emissive"><input type="color" className="color-input" aria-label="Material emissive" value={material.emissive || '#000000'} onChange={(event) => updateMaterial({ emissive: event.target.value })} /></Field>
        <Field label="Opacity" hint="Normalized · hard runtime range 0–100%"><NumberInput value={Math.round((material.opacity ?? 1) * 100)} min={0} max={100} step={1} suffix="%" ariaLabel="Material opacity" onChange={(value) => updateMaterial({ opacity: Math.max(0, Math.min(1, (value ?? 100) / 100)) })} /></Field>
        <Field label="Double sided"><Toggle checked={material.doubleSided === true} ariaLabel="Double sided" onChange={(checked) => updateMaterial({ doubleSided: checked })} /></Field>
      </div>
      <Field label={keyLabel('Emissive intensity', 'material.emissiveIntensity', material.emissiveIntensity ?? 1)}><OverdriveControl value={material.emissiveIntensity ?? 1} ariaLabel="Emissive intensity" onChange={(value) => updateMaterial({ emissiveIntensity: value })} /></Field>
      <details className="material-overdrive">
        <summary>Creative overdrive</summary>
        <p className="field-hint">Gains may exceed 100%. Normalized PBR metalness/roughness/opacity still clamp to their physical 0–1 domain.</p>
        <div className="form-grid form-grid--2">
          <Field label="Base color gain"><OverdriveControl value={material.baseColorGain ?? 1} ariaLabel="Base color gain" onChange={(value) => updateMaterial({ baseColorGain: value })} /></Field>
          <Field label="Emissive gain"><OverdriveControl value={material.emissiveGain ?? 1} ariaLabel="Emissive gain" onChange={(value) => updateMaterial({ emissiveGain: value })} /></Field>
          <Field label="Specular gain"><OverdriveControl value={material.specularGain ?? 1} ariaLabel="Specular gain" onChange={(value) => updateMaterial({ specularGain: value })} /></Field>
          <Field label="Reflection gain"><OverdriveControl value={material.reflectionGain ?? 1} ariaLabel="Reflection gain" onChange={(value) => updateMaterial({ reflectionGain: value })} /></Field>
          <Field label="Metalness response"><OverdriveControl value={material.metalnessResponseGain ?? 1} ariaLabel="Metalness response gain" onChange={(value) => updateMaterial({ metalnessResponseGain: value })} /></Field>
          <Field label="Normal strength"><OverdriveControl value={material.normalStrength ?? 1} ariaLabel="Normal strength" onChange={(value) => updateMaterial({ normalStrength: value })} /></Field>
          <Field label="Saturation"><OverdriveControl value={material.saturation ?? 1} ariaLabel="Material saturation" onChange={(value) => updateMaterial({ saturation: value })} /></Field>
          <Field label="Contrast"><OverdriveControl value={material.contrast ?? 1} ariaLabel="Material contrast" onChange={(value) => updateMaterial({ contrast: value })} /></Field>
          <Field label="Roughness remap"><NumberInput value={material.roughnessRemap ?? 0} min={-1} max={1} step={0.01} ariaLabel="Roughness remap" onChange={(value) => updateMaterial({ roughnessRemap: value ?? 0 })} /></Field>
          <Field label="Roughness contrast"><NumberInput value={material.roughnessContrast ?? 1} min={0} max={100} step={0.05} ariaLabel="Roughness contrast" onChange={(value) => updateMaterial({ roughnessContrast: value ?? 1 })} /></Field>
        </div>
      </details>

    </CollapsibleSection>
  );

  const physics = object.physics;
  const collision = object.collision;
  const physicsSection = !isLight ? (
    <CollapsibleSection key={`physics-${object.id}`} title="Physics / Collision" defaultOpen={false}>
      <div className="form-grid form-grid--3">
        <Field label="Physics"><Select value={physics?.mode || 'off'} ariaLabel="Physics mode" options={[{ value: 'off', label: 'Off' }, { value: 'static', label: 'Static' }, { value: 'dynamic', label: 'Dynamic' }, { value: 'kinematic', label: 'Kinematic' }]} onChange={(value) => updateObject(object.id, { physics: { ...(physics || defaultObjectPhysics(value as 'off' | 'static' | 'dynamic' | 'kinematic')), mode: value as 'off' | 'static' | 'dynamic' | 'kinematic' } })} /></Field>
        <Field label="Collision"><Select value={collision?.mode || 'off'} ariaLabel="Collision mode" options={[{ value: 'off', label: 'Off' }, { value: 'on', label: 'On' }, { value: 'trigger', label: 'Trigger' }]} onChange={(value) => updateObject(object.id, { collision: { ...(collision || defaultCollision()), mode: value as 'off' | 'on' | 'trigger' } })} /></Field>
        <Field label="Collider"><Select value={collision?.shape || 'auto'} ariaLabel="Collider shape" options={[{ value: 'auto', label: 'Auto' }, { value: 'box', label: 'Box' }, { value: 'sphere', label: 'Sphere' }, { value: 'capsule', label: 'Capsule' }, { value: 'cylinder', label: 'Cylinder' }, { value: 'cone', label: 'Cone' }, { value: 'convex', label: 'Convex hull' }, { value: 'mesh', label: 'Mesh (explicit)' }]} onChange={(value) => updateObject(object.id, { collision: { ...(collision || defaultCollision()), shape: value as NonNullable<SceneObject['collision']>['shape'] } })} /></Field>
      </div>
      {physics && physics.mode !== 'off' && (
        <>
          <div className="form-grid form-grid--3">
            <Field label="Mass" hint="Larger masses resist forces more strongly."><NumberInput value={physics.mass} min={0.0001} step={0.1} ariaLabel="Mass" onChange={(value) => updateObject(object.id, { physics: { ...physics, mass: Math.max(0.0001, value ?? 1) } })} /></Field>
            <Field label="Friction" hint="Surface resistance during contact. Higher values reduce sliding."><NumberInput value={physics.friction} min={0} max={2} step={0.01} ariaLabel="Friction" onChange={(value) => updateObject(object.id, { physics: { ...physics, friction: value ?? 0 } })} /></Field>
            <Field label="Bounciness" hint="Restitution. 0 absorbs the impact; 1 preserves most velocity."><NumberInput value={physics.restitution} min={0} max={2} step={0.01} ariaLabel="Bounciness" onChange={(value) => updateObject(object.id, { physics: { ...physics, restitution: value ?? 0 } })} /></Field>
            <Field label="Linear damping" hint="How quickly translational motion slows over time."><NumberInput value={physics.linearDamping} min={0} max={2} step={0.01} ariaLabel="Linear damping" onChange={(value) => updateObject(object.id, { physics: { ...physics, linearDamping: value ?? 0 } })} /></Field>
            <Field label="Angular damping" hint="How quickly spinning slows over time."><NumberInput value={physics.angularDamping} min={0} max={2} step={0.01} ariaLabel="Angular damping" onChange={(value) => updateObject(object.id, { physics: { ...physics, angularDamping: value ?? 0 } })} /></Field>
            <Field label="Gravity scale" hint="Multiplier for gravity on this body. 0 floats; negative values invert gravity."><NumberInput value={physics.gravityScale} step={0.1} ariaLabel="Gravity scale" onChange={(value) => updateObject(object.id, { physics: { ...physics, gravityScale: value ?? 1 } })} /></Field>
          </div>
          <div className="form-grid form-grid--3">
            {(['x','y','z'] as const).map((axis) => <Field key={axis} label={`Velocity ${axis.toUpperCase()}`}><NumberInput value={physics.velocity[axis]} step={0.1} ariaLabel={`Velocity ${axis.toUpperCase()}`} onChange={(value) => updateObject(object.id, { physics: { ...physics, velocity: { ...physics.velocity, [axis]: value ?? 0 } } })} /></Field>)}
          </div>
          <div className="row wrap">
            {(['x','y','z'] as const).map((axis) => <button key={`p${axis}`} type="button" className={`btn btn--sm ${physics.lockPosition[axis] ? 'btn--primary' : 'btn--ghost'}`} onClick={() => updateObject(object.id, { physics: { ...physics, lockPosition: { ...physics.lockPosition, [axis]: !physics.lockPosition[axis] } } })}>Lock P{axis.toUpperCase()}</button>)}
            {(['x','y','z'] as const).map((axis) => <button key={`r${axis}`} type="button" className={`btn btn--sm ${physics.lockRotation[axis] ? 'btn--primary' : 'btn--ghost'}`} onClick={() => updateObject(object.id, { physics: { ...physics, lockRotation: { ...physics.lockRotation, [axis]: !physics.lockRotation[axis] } } })}>Lock R{axis.toUpperCase()}</button>)}
          </div>
        </>
      )}
      {collision && collision.mode !== 'off' && (
        <div className="form-grid form-grid--3">
          <Field label="Layer"><Select value={collision.layer} ariaLabel="Collision layer" options={['world','objects','particles','triggers','camera','custom1','custom2','custom3','custom4'].map((value) => ({ value, label: value }))} onChange={(value) => updateObject(object.id, { collision: { ...collision, layer: value } })} /></Field>
          <Field label="Mask"><input className="input" value={collision.mask.join(',')} aria-label="Collision mask" onChange={(event) => updateObject(object.id, { collision: { ...collision, mask: event.target.value.split(',').map((entry) => entry.trim()).filter(Boolean) } })} /></Field>
          <div className="row"><button type="button" className="btn btn--sm btn--ghost" onClick={() => updateObject(object.id, { collision: { ...collision, shape: 'auto' } })}>Fit collider</button></div>
        </div>
      )}
    </CollapsibleSection>
  ) : null;

  const rendering = (
    <CollapsibleSection key={`rendering-${object.id}`} title="Rendering" defaultOpen={false}>
      <div className="row-between"><span className="field-label">Visible in 3D</span><Toggle checked={object.modelVisible !== false} ariaLabel="Visible in 3D" onChange={(checked) => setTransform({ modelVisible: checked })} /></div>
      <div className="form-grid">
        <Field label="Cast shadows"><Toggle checked={object.castShadows !== false} ariaLabel="Cast shadows" onChange={(checked) => setTransform({ castShadows: checked })} /></Field>
        <Field label="Receive shadows"><Toggle checked={object.receiveShadows !== false} ariaLabel="Receive shadows" onChange={(checked) => setTransform({ receiveShadows: checked })} /></Field>
      </div>
    </CollapsibleSection>
  );

  const lightMain = light ? (
    <Section title="Light">
      <div className="row-between"><span className="field-label">Visible in 3D</span><Toggle checked={object.modelVisible !== false} ariaLabel="Visible in 3D" onChange={(checked) => setTransform({ modelVisible: checked })} /></div>
      <div className="row-between"><span className="field-label">Light enabled</span><Toggle checked={light.on} ariaLabel="Light enabled" onChange={(checked) => setLight({ on: checked })} /></div>
      <Field label={keyLabel('Color', 'light.color', light.color)}><input type="color" className="color-input" aria-label="Light color" value={light.color} onChange={(event) => setLight({ color: event.target.value })} /></Field>
      <div className="form-grid">
        <Field label={keyLabel('Intensity', 'light.intensity', light.intensity)}><OverdriveControl value={light.intensity} ariaLabel="Light intensity" onChange={(value) => setLight({ intensity: value })} /></Field>
        {object.lightType !== 'directional' && <Field label="Range"><NumberInput value={object.range ?? 16} min={0.1} max={500} step={0.5} suffix="m" ariaLabel="Light range" onChange={(value) => setTransform({ range: Math.max(0.1, value ?? 16) })} /></Field>}
      </div>
    </Section>
  ) : null;

  const lightAdvanced = light ? (
    <CollapsibleSection key={`advanced-${object.id}`} title="Advanced" defaultOpen={false}>
      {capabilities.has('zoom') && object.lightType !== 'directional' && (
        <div className="form-grid">
          <Field label="Inner cone"><NumberInput value={object.beamInner ?? light.zoom} min={1} max={89} step={1} suffix="°" ariaLabel="Inner cone" onChange={(value) => setTransform({ beamInner: Math.max(1, Math.min(89, value ?? 25)) })} /></Field>
          <Field label="Outer cone"><NumberInput value={object.beamOuter ?? ((object.beamInner ?? light.zoom) + 10)} min={1} max={89} step={1} suffix="°" ariaLabel="Outer cone" onChange={(value) => setTransform({ beamOuter: Math.max(1, Math.min(89, value ?? 45)) })} /></Field>
        </div>
      )}
      <div className="row-between"><span className="field-label">Cast shadows</span><Toggle checked={object.castShadows === true} ariaLabel="Cast shadows" onChange={(checked) => setTransform({ castShadows: checked })} /></div>
      <Field label="Volumetric contribution"><OverdriveControl value={object.volumetric ?? 0.2} ariaLabel="Volumetric contribution" onChange={(value) => setTransform({ volumetric: value })} /></Field>
      <div className="form-grid form-grid--3">
        <Field label="Width"><NumberInput value={object.size?.w ?? 0.3} min={0.01} step={0.05} suffix="m" ariaLabel="Light width" onChange={(value) => setTransform({ size: { w: Math.max(0.01, value ?? 0.3), d: object.size?.d ?? 0.3, h: object.size?.h ?? 0.3 } })} /></Field>
        <Field label="Height"><NumberInput value={object.size?.h ?? 0.3} min={0.01} step={0.05} suffix="m" ariaLabel="Light height" onChange={(value) => setTransform({ size: { w: object.size?.w ?? 0.3, d: object.size?.d ?? 0.3, h: Math.max(0.01, value ?? 0.3) } })} /></Field>
        <Field label="Depth"><NumberInput value={object.size?.d ?? 0.3} min={0.01} step={0.05} suffix="m" ariaLabel="Light depth" onChange={(value) => setTransform({ size: { w: object.size?.w ?? 0.3, d: Math.max(0.01, value ?? 0.3), h: object.size?.h ?? 0.3 } })} /></Field>
      </div>
    </CollapsibleSection>
  ) : null;

  return (
    <>
      <div className="panel-head inspector-head">
        <span className="inspector-type-icon">{isLight ? <Lightbulb /> : <Box />}</span>
        <span className="panel-title">{object.name}</span>
        <span className="inspector-kind">{isLight ? 'Generic Light' : 'Model'}</span>
      </div>
      <div className="panel-body inspector-body">
      <div className="generic-inspector">
      <Section title={isLight ? 'Light' : 'Model'}>
        <Field label="Name"><input className="input" value={object.name} maxLength={120} aria-label="Object name" onChange={(event) => setTransform({ name: event.target.value })} /></Field>
        {isLight ? <Field label="Type"><Select value={object.lightType || 'spot'} ariaLabel="Light type" options={LIGHT_TYPES} onChange={(value) => setTransform({ lightType: value as GenericLightType })} /></Field> : object.primitive ? (
          <div className="form-grid form-grid--3">
            {primitiveDefinition(object.primitive.kind).fields.map((field) => <Field key={field.key} label={field.label}><NumberInput value={object.primitive?.params[field.key] ?? 1} min={field.min} step={field.step} suffix="m" ariaLabel={`Primitive ${field.label}`} onChange={(value) => { const next = Math.max(field.min, value ?? field.min); const primitive = { ...object.primitive!, params: { ...object.primitive!.params, [field.key]: next } }; setTransform({ primitive, size: primitiveFootprint(primitive) }); }} /></Field>)}
          </div>
        ) : <span className="asset-meta">Asset · {object.assetName || 'Imported model'}</span>}
      </Section>

      <Section title="Transform">{transform}</Section>
      {!isLight && modifiers}
      {!isLight && materialSection}
      {!isLight && rendering}
      {physicsSection}
      {isLight && lightMain}
      {isLight && lightAdvanced}
      {isLight && modifiers}
      </div>
      </div>
    </>
  );
}
