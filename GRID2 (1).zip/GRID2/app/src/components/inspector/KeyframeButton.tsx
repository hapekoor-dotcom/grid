import { useEffect, useState } from 'react';
import { Diamond } from 'lucide-react';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { getTimelineTime } from '../../lib/timelineClock';
import { upsertKeyframe } from '../../lib/timelineCommands';
import { sampleTimeline } from '../../lib/timeline';

export function KeyframeButton({ objectId, propertyPath, value, label }: { objectId: string | null; propertyPath: string; value: number | string | boolean | undefined; label?: string }) {
  const project = useActiveProject();
  const track = project?.timeline?.tracks.find((entry) => entry.objectId === objectId && entry.propertyPath === propertyPath);
  const [time, setTime] = useState(getTimelineTime());
  const [evaluated, setEvaluated] = useState<number | string | boolean | undefined>(undefined);
  useEffect(() => {
    if (!project || !track) { setEvaluated(undefined); return; }
    const update = () => {
      const now = getTimelineTime();
      setTime(now);
      setEvaluated(sampleTimeline(project, now).get(`${objectId || 'scene'}:${propertyPath}`));
    };
    update();
    const timer = window.setInterval(update, 120);
    return () => window.clearInterval(timer);
  }, [project, track, objectId, propertyPath]);
  const active = !!track?.keyframes.some((key) => Math.abs(key.time - time) < 0.02);
  return (
    <button
      type="button"
      className={`keyframe-button ${active ? 'is-active' : ''}`}
      aria-label={`Keyframe ${label || propertyPath}`}
      title={`${active ? 'Keyframe at' : 'Add keyframe at'} ${time.toFixed(2)}s`}
      disabled={value === undefined}
      onClick={(event) => {
        event.stopPropagation();
        if (value === undefined) return;
        upsertKeyframe(objectId, propertyPath, getTimelineTime(), value);
        useWorkspaceStore.getState().persistNow();
      }}
    >
      <Diamond />
      {evaluated !== undefined && <span className="keyframe-evaluated">{typeof evaluated === 'number' ? evaluated.toFixed(2) : String(evaluated)}</span>}
    </button>
  );
}
