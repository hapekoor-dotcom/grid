import { useState } from 'react';
import type { SceneModifier } from '../../types/project';
import { Dialog } from '../ui/Dialog';
import { Button } from '../ui/Button';
import { NumberInput, Select } from '../ui/Field';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { getTimelineTime } from '../../lib/timelineClock';
import { modifierOutputValue } from '../../lib/modifierOutputs';
import { defaultModulator, signalValue } from '../../lib/signals';
import { executionDomain, modifierDefinition } from '../../lib/modifiers';
import { applyAdapter, compileModifierOrder, wouldCreateModifierCycle } from '../../lib/graphRouting';

function sourceLabel(value: string, project: any, modifiers: SceneModifier[]): string {
  if (value.startsWith('reaction:')) return `RD · ${value.slice(9)}`;
  if (value.startsWith('modifier:')) {
    const [, id, output] = value.split(':');
    const modifier = modifiers.find((entry) => entry.id === id);
    return `${modifier ? modifierDefinition(modifier.type).label : id} · ${output}`;
  }
  const signal = (project?.signals || []).find((entry: any) => entry.id === value);
  return signal ? `${signal.name} · ${signal.kind}` : value;
}

export function ModifierGraphDialog({ modifiers, onChange, onClose }: { modifiers: SceneModifier[]; onChange: (next: SceneModifier[]) => void; onClose: () => void }) {
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const pushToast = useUiStore((state) => state.pushToast);
  const [source, setSource] = useState('reaction:scalar');
  const [target, setTarget] = useState(modifiers[0]?.id || '');
  const [targetField, setTargetField] = useState('');
  const [adapter, setAdapter] = useState('');
  const [fieldSource, setFieldSource] = useState<'scalar' | 'mask' | 'gradient' | 'normal' | 'vector'>('scalar');
  const [fieldTarget, setFieldTarget] = useState('');
  const [fieldAdapter, setFieldAdapter] = useState<'threshold' | 'remap' | 'invert' | 'smoothstep' | 'multiply' | 'add' | 'power' | 'quantize' | ''>('');
  const [fieldA, setFieldA] = useState(0);
  const [fieldB, setFieldB] = useState(1);
  const addFieldLink = useWorkspaceStore((state) => state.addFieldLink);
  const removeFieldLink = useWorkspaceStore((state) => state.removeFieldLink);
  const targetModifier = modifiers.find((entry) => entry.id === target);
  const fields = targetModifier ? modifierDefinition(targetModifier.type).fields.filter((field) => ['number', 'percent'].includes(field.kind || 'number') || field.overdrive) : [];
  const topology = compileModifierOrder(modifiers as never);
  const selectedId = useUiStore((state) => state.selectedIds[0]);
  const selectedObject = project?.objects.find((object) => object.id === selectedId) || project?.objects[0] || null;
  const time = getTimelineTime();
  const fieldTargets = modifiers.filter((modifier) => modifier.type === 'reactionSurface' || modifier.type === 'reactionDisplace');
  const connections = modifiers.flatMap((modifier) => Object.entries(modifier.modulators || {}).map(([field, modulator]) => ({ modifier, field, modulator })));
  const add = () => {
    if (!targetModifier || !targetField) return;
    let nextModulator;
    if (source.startsWith('modifier:')) {
      const [, id, output] = source.split(':');
      if (wouldCreateModifierCycle(modifiers as never, targetModifier.id, id)) { pushToast('Connection would create a dependency cycle.', 'error'); return; }
      nextModulator = { ...defaultModulator(id, 'modifier', output), amount: 1 };
    } else if (source.startsWith('reaction:')) {
      nextModulator = { ...defaultModulator('reaction', 'reaction', source.slice(9)), amount: 1 };
    } else {
      nextModulator = { ...defaultModulator(source), amount: 1 };
    }
    if (adapter) nextModulator.adapter = { kind: adapter, params: {} };
    onChange(modifiers.map((modifier) => modifier.id === targetModifier.id ? { ...modifier, modulators: { ...(modifier.modulators || {}), [targetField]: nextModulator } } : modifier));
  };
  const connectionValue = (modulator: any): string => {
    if (modulator.sourceType === 'reaction') return 'GPU field';
    try {
      const sourceValue = modulator.sourceType === 'modifier'
        ? (() => { const source = modifiers.find((entry) => entry.id === modulator.sourceId); return source ? modifierOutputValue(source, modulator.output || 'scalar', project as any, time, selectedObject) : 0; })()
        : (() => { const signal = (project?.signals || []).find((entry) => entry.id === modulator.sourceId); return signal ? signalValue(signal, project as any, time, selectedObject) : 0; })();
      const adapted = Number(modulator.adapter ? applyAdapter(sourceValue, modulator.adapter) : sourceValue);
      return `${adapted.toFixed(2)} → ${(Number(adapted) * Number(modulator.amount || 0) + Number(modulator.offset || 0)).toFixed(2)}`;
    } catch { return '—'; }
  };
  const remove = (modifierId: string, field: string) => onChange(modifiers.map((modifier) => {
    if (modifier.id !== modifierId) return modifier;
    const modulators = { ...(modifier.modulators || {}) };
    delete modulators[field];
    return { ...modifier, modulators };
  }));
  return (
    <Dialog title="Modifier Graph" description="Real runtime routing graph. Edges are the same ParameterModulator records used by Inspector, Signal Engine and shader uniforms." onClose={onClose} wide footer={<Button size="sm" onClick={onClose}>Done</Button>}>
      <div className="modifier-graph">
        <div className="modifier-graph-nodes">
          {project?.reactionDiffusion?.enabled && <div className="graph-node is-source"><strong>Reaction Diffusion</strong><span>scalar · mask · gradient · normal</span></div>}
          {(project?.signals || []).map((signal) => <div className="graph-node is-source" key={signal.id}><strong>{signal.name}</strong><span>{signal.kind}</span></div>)}
          {modifiers.map((modifier) => <div className="graph-node" key={modifier.id}><strong>{modifierDefinition(modifier.type).label}</strong><span>{executionDomain(modifierDefinition(modifier.type))}{(modifierDefinition(modifier.type).outputs || []).length ? ' · outputs' : ''}</span></div>)}
        </div>
        <div className="modifier-graph-edges">
          <div className="section-label"><span>Evaluation order</span><span>{topology.cycles.length ? 'CYCLE' : 'VALID'}</span></div>
          <div className="graph-order">{topology.order.map((id, index) => { const modifier = modifiers.find((entry) => entry.id === id); return <span key={id}>{index + 1}. {modifier ? modifierDefinition(modifier.type).label : id}</span>; })}{topology.cycles.map((id) => <span key={id} className="is-error">Cycle: {id}</span>)}</div>
          <div className="section-label"><span>Connections</span><span>{connections.length}</span></div>
          {!connections.length && <p className="field-hint">No connections. Add one below.</p>}
          {connections.map(({ modifier, field, modulator }) => <div className="graph-edge" key={`${modifier.id}:${field}`}><span>{sourceLabel(modulator.sourceType === 'modifier' ? `modifier:${modulator.sourceId}:${modulator.output || 'scalar'}` : modulator.sourceType === 'reaction' ? `reaction:${modulator.output || 'scalar'}` : modulator.sourceId, project, modifiers)}</span><b>→</b><span>{modifierDefinition(modifier.type).label} · {field}</span>{modulator.adapter && <em>{modulator.adapter.kind}</em>}<em title="source → final contribution">{connectionValue(modulator)}</em><button type="button" className="section-link" onClick={() => remove(modifier.id, field)}>remove</button></div>)}
          <div className="section-label" style={{ marginTop: 10 }}><span>GPU field connections</span><span>{(project?.fieldLinks || []).length}</span></div>
          <p className="field-hint">One Reaction Diffusion field drives spatial shader inputs. These links bind directly to the GPU simulation texture; no CPU readback.</p>
          {(project?.fieldLinks || []).map((link) => {
            const target = modifiers.find((modifier) => modifier.id === link.modifierId);
            return <div className="graph-edge" key={link.id}><span>RD · {link.output} field</span><b>→</b><span>{target ? modifierDefinition(target.type).label : link.modifierId} · field</span><button type="button" className="section-link" onClick={() => removeFieldLink(link.id)}>remove</button></div>;
          })}
          <div className="form-stack graph-add">
            <div className="form-grid form-grid--2">
              <label className="field"><span className="field-label">Field source</span><Select value={fieldSource} ariaLabel="Field source" options={[{value:'scalar',label:'RD scalar field'},{value:'mask',label:'RD mask field'},{value:'gradient',label:'RD gradient field'},{value:'normal',label:'RD normal field'},{value:'vector',label:'RD vector field'}]} onChange={(value) => setFieldSource(value as any)} /></label>
              <label className="field"><span className="field-label">Field target</span><Select value={fieldTarget} ariaLabel="Field target" options={fieldTargets.map((modifier) => ({ value: modifier.id, label: modifierDefinition(modifier.type).label }))} onChange={setFieldTarget} /></label>
              {fieldAdapter && fieldAdapter !== 'invert' && <><label className="field"><span className="field-label">Field A</span><NumberInput value={fieldA} step={0.01} ariaLabel="Field adapter A" onChange={(value) => setFieldA(value ?? 0)} /></label><label className="field"><span className="field-label">Field B</span><NumberInput value={fieldB} step={0.01} ariaLabel="Field adapter B" onChange={(value) => setFieldB(value ?? 1)} /></label></>}
              <label className="field"><span className="field-label">Field adapter</span><Select value={fieldAdapter} ariaLabel="Field adapter" options={[{value:'',label:'None'},{value:'threshold',label:'Threshold'},{value:'remap',label:'Remap'},{value:'invert',label:'Invert'},{value:'smoothstep',label:'Smoothstep'},{value:'multiply',label:'Multiply'},{value:'add',label:'Add'},{value:'power',label:'Power'},{value:'quantize',label:'Quantize'}]} onChange={(value) => setFieldAdapter(value as any)} /></label>
            </div>
            <Button size="sm" onClick={() => { if (!fieldTarget) return; addFieldLink({ id: `field_${crypto.randomUUID()}`, source: 'reaction', output: fieldSource, modifierId: fieldTarget, slot: 'field', adapter: fieldAdapter || undefined, params: fieldAdapter && fieldAdapter !== 'invert' ? { a: fieldA, b: fieldB } : undefined }); }} disabled={!fieldTarget || !project?.reactionDiffusion?.enabled}>Add field connection</Button>
          </div>
          <div className="form-stack graph-add">
            <div className="form-grid form-grid--2">
              <label className="field"><span className="field-label">Source</span><Select value={source} ariaLabel="Graph source" options={[
                ...(project?.reactionDiffusion?.enabled ? [{ value: 'reaction:sampledScalar', label: 'RD · Scalar sample (global)' }] : []),
                ...modifiers.flatMap((modifier) => (modifierDefinition(modifier.type).outputs || []).map((output) => ({ value: `modifier:${modifier.id}:${output.key}`, label: `${modifierDefinition(modifier.type).label} · ${output.label}` }))),
                ...(project?.signals || []).map((signal) => ({ value: signal.id, label: `${signal.name} · ${signal.kind}` })),
              ]} onChange={setSource} /></label>
              <label className="field"><span className="field-label">Target effect</span><Select value={target} ariaLabel="Graph target effect" options={modifiers.map((modifier) => ({ value: modifier.id, label: modifierDefinition(modifier.type).label }))} onChange={(value) => { setTarget(value); setTargetField(''); }} /></label>
              <label className="field"><span className="field-label">Input</span><Select value={targetField} ariaLabel="Graph target input" options={fields.map((field) => ({ value: field.key, label: field.label }))} onChange={setTargetField} /></label>
              <label className="field"><span className="field-label">Adapter</span><Select value={adapter} ariaLabel="Graph adapter" options={['', 'remap','clamp','invert','multiply','add','subtract','power','smoothstep','curve','quantize'].map((kind) => ({ value: kind, label: kind || 'None' }))} onChange={setAdapter} /></label>
            </div>
            <Button size="sm" onClick={add} disabled={!targetModifier || !targetField}>Add connection</Button>
          </div>
        </div>
      </div>
    </Dialog>
  );
}
