import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, ChevronRight, Circle, Diamond, Pause, Play, Plus, Repeat, Square, Trash2, Wand2, ZoomIn } from 'lucide-react';
import type { Project } from '../../types/project';
import type { GroupEffect, GroupEffectPhaseMode, TimelineClip, TimelineEasing, TimelineTrack } from '../../types/timeline';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { baseValue, groupObjects, propertyLabel } from '../../lib/timeline';
import { advanceTimeline, getTimelineTime, isTimelinePlaying, pauseTimeline, playTimeline, seekTimeline, setTimelineRange, stopTimeline } from '../../lib/timelineClock';
import { addGroupEffectTargets, createClip, createGroupWave, createTrackWithKeyframe, detachGroupEffectTargets, removeClip, removeGroupEffect, removeGroupEffectTargets, removeKeyframe, removeTrack, setGroupEffectTargets, setGroupEffectTiming, setTimelineDuration, setTimelineLoop, updateClip, updateGroupEffect, updateKeyframe, type PhaseMode } from '../../lib/timelineCommands';
import { NumberInput, Select, Toggle } from '../ui/Field';

const EASINGS: { value: TimelineEasing; label: string }[] = [
  { value: 'linear', label: 'Linear' }, { value: 'easeIn', label: 'Ease in' },
  { value: 'easeOut', label: 'Ease out' }, { value: 'easeInOut', label: 'Ease in-out' }, { value: 'step', label: 'Hold / step' },
];

function propertyOptions(project: Project, objectId: string | null): { value: string; label: string }[] {
  if (!objectId) {
    const options = [
      { value: 'scene.exposure', label: 'Scene · Exposure' }, { value: 'scene.haze', label: 'Scene · Haze' },
      { value: 'scene.bloomStrength', label: 'Scene · Bloom strength' }, { value: 'scene.master', label: 'Scene · Light master' },
    ];
    if (project.reactionDiffusion) for (const [key, label] of [['feed','Feed'],['kill','Kill'],['speed','Speed'],['contrast','Contrast'],['threshold','Threshold'],['timeStep','Time step']] as const) options.push({ value: `simulation.reaction.${key}`, label: `Reaction Diffusion · ${label}` });
    for (const effect of project.effects || []) for (const key of Object.keys(effect.params)) options.push({ value: `effect.${effect.id}.${key}`, label: `${effect.type} · ${key}` });
    for (const instance of project.postShaders || []) {
      const shader = project.customShaders?.find((entry) => entry.id === instance.shaderId);
      for (const param of shader?.params || []) if (param.animatable !== false && (param.type === 'float' || param.type === 'int')) options.push({ value: `scene.post.${instance.id || instance.shaderId}.${param.id}`, label: `Post ${shader?.name || 'Shader'} · ${param.label}` });
    }
    for (const field of project.fields || []) for (const key of Object.keys(field.params)) options.push({ value: `field.${field.id}.${key}`, label: `${field.type} · ${key}` });
    for (const look of project.looks || []) {
      for (const key of ['color', 'roughness', 'metalness', 'emissiveIntensity', 'opacity', 'normalStrength']) options.push({ value: `look.${look.id}.material.${key}`, label: `Look ${look.name} · ${key}` });
      for (const effect of look.modifiers || []) for (const key of Object.keys(effect.params)) options.push({ value: `look.${look.id}.effect.${effect.id}.${key}`, label: `Look ${look.name} · ${effect.type} · ${key}` });
      for (const instance of look.shaders || []) {
        const shader = project.customShaders?.find((entry) => entry.id === instance.shaderId);
        for (const param of shader?.params || []) if (param.type === 'float' || param.type === 'int') options.push({ value: `look.${look.id}.shader.${instance.shaderId}.${param.id}`, label: `Look ${look.name} · ${shader?.name || 'Shader'} · ${param.label}` });
      }
    }
    return options;
  }
  const object = project.objects.find((entry) => entry.id === objectId);
  if (!object) return [];
  const options = [
    ['position.x', 'Position X'], ['position.y', 'Position Y'], ['position.z', 'Position Z'],
    ['rotation.x', 'Rotation X'], ['rotation.y', 'Rotation Y'], ['rotation.z', 'Rotation Z'],
  ].map(([value, label]) => ({ value, label }));
  if (object.type === 'model') options.push(...['x', 'y', 'z'].map((axis) => ({ value: `scale.${axis}`, label: `Scale ${axis.toUpperCase()}` })));
  if (object.light) options.push(
    { value: 'light.intensity', label: 'Light intensity' }, { value: 'light.color', label: 'Light color' },
    { value: 'light.pan', label: 'Pan' }, { value: 'light.tilt', label: 'Tilt' }, { value: 'light.zoom', label: 'Zoom' },
    { value: 'light.focus', label: 'Focus' }, { value: 'light.strobe', label: 'Strobe' }, { value: 'light.on', label: 'Light enabled' },
  );
  if (object.material) options.push(
    { value: 'material.roughness', label: 'Material roughness' }, { value: 'material.metalness', label: 'Material metalness' },
    { value: 'material.color', label: 'Material color' }, { value: 'material.emissiveIntensity', label: 'Emissive intensity' },
  );
  for (const modifier of object.modifiers || []) for (const key of Object.keys(modifier.params)) options.push({ value: `modifier.${modifier.id}.${key}`, label: `${modifier.type} · ${key}` });
  return options;
}

function WaveDialog({ project, close, created }: { project: Project; close: () => void; created: (id: string) => void }) {
  const selectedIds = useUiStore((state) => state.selectedIds);
  const rightOpen = useUiStore((state) => state.rightOpen);
  const [path, setPath] = useState('light.intensity');
  const [start, setStart] = useState(2), [duration, setDuration] = useState(8), [frequency, setFrequency] = useState(2);
  const [min, setMin] = useState(0.2), [max, setMax] = useState(1), [spread, setSpread] = useState(360);
  const [mode, setMode] = useState<PhaseMode>('left-right'), [waveform, setWaveform] = useState<'sine' | 'triangle' | 'square'>('sine');
  const [applyColor, setApplyColor] = useState(false), [colorFrom, setColorFrom] = useState('#2f7bff'), [colorTo, setColorTo] = useState('#ff2fd0');
  const objects = project.objects.filter((object) => selectedIds.includes(object.id));
  const paths = Array.from(new Map(objects.flatMap((object) => propertyOptions(project, object.id)).map((entry) => [entry.value, entry])).values());
  return (
    <div className="timeline-dialog">
      <div className="timeline-dialog-head"><strong>Group wave</strong><button type="button" onClick={close}>×</button></div>
      <p className="field-hint">{objects.length} targets · one shared group effect</p>
      <label className="field"><span className="field-label">Property</span><Select value={path} ariaLabel="Wave property" options={paths.length ? paths : propertyOptions(project, null)} onChange={setPath} /></label>
      <div className="form-grid form-grid--3">
        <label className="field"><span className="field-label">Start</span><NumberInput value={start} min={0} step={0.1} suffix="s" ariaLabel="Wave start" onChange={(value) => setStart(value ?? 0)} /></label>
        <label className="field"><span className="field-label">Duration</span><NumberInput value={duration} min={0.1} step={0.1} suffix="s" ariaLabel="Wave duration" onChange={(value) => setDuration(value ?? 1)} /></label>
        <label className="field"><span className="field-label">Frequency</span><NumberInput value={frequency} min={0} step={0.1} suffix="Hz" ariaLabel="Wave frequency" onChange={(value) => setFrequency(value ?? 1)} /></label>
        <label className="field"><span className="field-label">Min</span><NumberInput value={min} step={0.01} ariaLabel="Wave min" onChange={(value) => setMin(value ?? 0)} /></label>
        <label className="field"><span className="field-label">Max</span><NumberInput value={max} step={0.01} ariaLabel="Wave max" onChange={(value) => setMax(value ?? 1)} /></label>
        <label className="field"><span className="field-label">Phase spread</span><NumberInput value={spread} step={1} suffix="°" ariaLabel="Wave phase spread" onChange={(value) => setSpread(value ?? 360)} /></label>
        <label className="field"><span className="field-label">Phase mode</span><Select value={mode} ariaLabel="Wave phase mode" options={[
          { value: 'left-right', label: 'Left → right' }, { value: 'right-left', label: 'Right → left' }, { value: 'front-back', label: 'Front → back' }, { value: 'center', label: 'Center outward' },
          { value: 'sequential', label: 'Sequential' }, { value: 'random', label: 'Random' }, { value: 'custom', label: 'Custom delay' },
        ]} onChange={(value) => setMode(value as PhaseMode)} /></label>
        <label className="field"><span className="field-label">Color fade</span><Toggle checked={applyColor} ariaLabel="Wave color fade" onChange={setApplyColor} /></label><label className="field"><span className="field-label">From</span><input className="color-input" type="color" aria-label="Wave color from" value={colorFrom} onChange={(event) => setColorFrom(event.target.value)} /></label><label className="field"><span className="field-label">To</span><input className="color-input" type="color" aria-label="Wave color to" value={colorTo} onChange={(event) => setColorTo(event.target.value)} /></label><label className="field"><span className="field-label">Waveform</span><Select value={waveform} ariaLabel="Wave waveform" options={[{ value: 'sine', label: 'Sine' }, { value: 'triangle', label: 'Triangle' }, { value: 'square', label: 'Square' }]} onChange={(value) => setWaveform(value as typeof waveform)} /></label>
      </div>
      <div className="timeline-dialog-actions"><button type="button" className="btn btn--sm btn--ghost" onClick={close}>Cancel</button><button type="button" className="btn btn--sm btn--primary" onClick={() => { const id = createGroupWave({ objectIds: selectedIds, propertyPath: path, start, duration, frequency, min, max, phaseMode: mode, spreadDegrees: spread, stagger: 1, waveform, fadeIn: 0.3, fadeOut: 0.3, colorFrom: applyColor ? colorFrom : undefined, colorTo: applyColor ? colorTo : undefined }); if (id) created(id); close(); }}>Create wave</button></div>
    </div>
  );
}

export function TimelinePanel() {
  const project = useActiveProject();
  const selectedIds = useUiStore((state) => state.selectedIds);
  const rightOpen = useUiStore((state) => state.rightOpen);
  const open = useUiStore((state) => state.timelineOpen);
  const setOpen = useUiStore((state) => state.setTimelineOpen);
  const [time, setTime] = useState(getTimelineTime());
  const [playing, setPlaying] = useState(isTimelinePlaying());
  const [zoom, setZoom] = useState(1);
  const [addPath, setAddPath] = useState('rotation.y');
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);
  const [selectedKeyId, setSelectedKeyId] = useState<string | null>(null);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [selectedEffectId, setSelectedEffectId] = useState<string | null>(null);
  const [waveOpen, setWaveOpen] = useState(false);
  const [clipType, setClipType] = useState<'pulse' | 'wave' | 'rotate' | 'noise'>('pulse');
  const dragKey = useRef<{ trackId: string; keyId: string } | null>(null);
  const dragClip = useRef<{ clipId: string; edge: 'move' | 'start' | 'end'; start: number; end: number } | null>(null);
  const dragEffect = useRef<{ effectId: string; edge: 'move' | 'start' | 'end'; start: number; end: number } | null>(null);
  const laneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!playing) return;
    let frame = 0; let last = 0;
    let previous = performance.now();
    const tick = (now: number) => {
      const delta = Math.max(0, (now - previous) / 1000);
      previous = now;
      if (isTimelinePlaying()) advanceTimeline(delta);
      if (!isTimelinePlaying()) { setPlaying(false); setTime(getTimelineTime()); return; }
      if (now - last >= 60) { last = now; setTime(getTimelineTime()); }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing]);
  useEffect(() => { if (project?.timeline) setTimelineRange(project.timeline.duration, project.timeline.loop); }, [project?.timeline?.duration, project?.timeline?.loop]);

  const timeline = project?.timeline;
  const objectId = selectedIds.length === 1 ? selectedIds[0] : null;
  const selectedObject = selectedIds[0] ? project?.objects.find((object) => object.id === selectedIds[0]) : null;
  const options = useMemo(() => project ? propertyOptions(project, objectId) : [], [project, objectId]);
  useEffect(() => { if (options.length && !options.some((entry) => entry.value === addPath)) setAddPath(options[0].value); }, [options, addPath]);

  if (!project || !timeline) return null;
  const groups = groupObjects(project, timeline.tracks, timeline.clips);
  const selectedTrack = selectedTrackId ? timeline.tracks.find((track) => track.id === selectedTrackId) : null;
  const selectedKey = selectedTrack?.keyframes.find((key) => key.id === selectedKeyId) || null;
  const selectedClip = selectedClipId ? timeline.clips.find((clip) => clip.id === selectedClipId) : null;
  const groupEffects = timeline.groupEffects || [];
  const selectedEffect = selectedEffectId ? groupEffects.find((effect) => effect.id === selectedEffectId) : null;
  const pct = (value: number) => `${Math.max(0, Math.min(100, (value / timeline.duration) * 100))}%`;
  const timeAt = (clientX: number): number => {
    const rect = laneRef.current?.getBoundingClientRect();
    return rect ? Math.max(0, Math.min(timeline.duration, ((clientX - rect.left) / rect.width) * timeline.duration)) : 0;
  };
  const seek = (next: number) => { seekTimeline(next); setTime(getTimelineTime()); };
  const addTrack = () => {
    const value = baseValue(project, objectId, addPath);
    const id = createTrackWithKeyframe(objectId, addPath, time, value ?? 0);
    setSelectedTrackId(id);
    useUiStore.getState().pushToast('Animation track added', 'success');
  };

  const keyDown = (event: React.PointerEvent, track: TimelineTrack, keyId: string) => {
    event.stopPropagation(); setSelectedTrackId(track.id); setSelectedKeyId(keyId); dragKey.current = { trackId: track.id, keyId };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId); useWorkspaceStore.getState().beginTransaction();
  };
  const keyMove = (event: React.PointerEvent) => {
    if (!dragKey.current) return;
    updateKeyframe(dragKey.current.trackId, dragKey.current.keyId, { time: Math.round(timeAt(event.clientX) * 100) / 100 });
  };
  const keyUp = () => { if (!dragKey.current) return; dragKey.current = null; useWorkspaceStore.getState().endTransaction(); };
  const clipDown = (event: React.PointerEvent, clip: TimelineClip, edge: 'move' | 'start' | 'end') => {
    event.stopPropagation(); setSelectedClipId(clip.id); setSelectedEffectId(null); dragClip.current = { clipId: clip.id, edge, start: clip.start, end: clip.end };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId); useWorkspaceStore.getState().beginTransaction();
  };
  const clipMove = (event: React.PointerEvent) => {
    if (!dragClip.current) return;
    const next = timeAt(event.clientX);
    const drag = dragClip.current;
    if (drag.edge === 'move') { const length = drag.end - drag.start; const start = Math.max(0, Math.min(timeline.duration - length, next - length / 2)); updateClip(drag.clipId, { start, end: start + length }); }
    else if (drag.edge === 'start') updateClip(drag.clipId, { start: Math.min(next, drag.end - 0.05) });
    else updateClip(drag.clipId, { end: Math.max(next, drag.start + 0.05) });
  };
  const clipUp = () => { if (!dragClip.current) return; dragClip.current = null; useWorkspaceStore.getState().endTransaction(); };
  const effectDown = (event: React.PointerEvent, effect: GroupEffect, edge: 'move' | 'start' | 'end') => {
    event.stopPropagation(); setSelectedEffectId(effect.id); setSelectedClipId(null); setSelectedTrackId(null);
    dragEffect.current = { effectId: effect.id, edge, start: effect.start, end: effect.end };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    useWorkspaceStore.getState().beginTransaction();
  };
  const effectMove = (event: React.PointerEvent) => {
    if (!dragEffect.current) return;
    const drag = dragEffect.current;
    const next = timeAt(event.clientX);
    if (drag.edge === 'move') {
      const length = drag.end - drag.start;
      const start = Math.max(0, Math.min(timeline.duration - length, next - length / 2));
      setGroupEffectTiming(drag.effectId, start, start + length);
    } else if (drag.edge === 'start') setGroupEffectTiming(drag.effectId, Math.min(next, drag.end - 0.05), drag.end);
    else setGroupEffectTiming(drag.effectId, drag.start, Math.max(next, drag.start + 0.05));
  };
  const effectUp = () => { if (!dragEffect.current) return; dragEffect.current = null; useWorkspaceStore.getState().endTransaction(); };

  return (
    <section className={`timeline-panel ${open ? '' : 'is-collapsed'} ${rightOpen ? 'is-right-shifted' : ''} ${selectedEffect ? 'has-effect-editor' : ''}`} aria-label="Timeline">
      <div className="timeline-head">
        <button type="button" className="timeline-collapse" onClick={() => setOpen(!open)} aria-label={open ? 'Collapse timeline' : 'Expand timeline'}>{open ? <ChevronDown /> : <ChevronRight />}</button>
        <span className="timeline-title">Timeline</span>
        <button type="button" className="timeline-icon" aria-label={playing ? 'Pause timeline' : 'Play timeline'} onClick={() => { if (playing) pauseTimeline(); else playTimeline(); setPlaying(isTimelinePlaying()); }}>{playing ? <Pause /> : <Play />}</button>
        <button type="button" className="timeline-icon" aria-label="Stop timeline" onClick={() => { stopTimeline(); setTime(0); setPlaying(false); }}><Square /></button>
        <span className="timeline-time num">{time.toFixed(2)} / {timeline.duration.toFixed(2)}s</span>
        <label className="timeline-loop"><Repeat /> Loop <Toggle checked={timeline.loop} ariaLabel="Timeline loop" onChange={setTimelineLoop} /></label>
        <span className="timeline-head-spacer" />
        {selectedObject && <span className="timeline-selection">{selectedObject.name}</span>}
      </div>
      {open && (
        <div className="timeline-actions">
          <select className="select timeline-property-select" value={addPath} aria-label="Track property" onChange={(event) => setAddPath(event.target.value)}>{options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select>
          <button type="button" className="btn btn--sm btn--ghost" onClick={addTrack}><Plus /> Track</button>
          <button type="button" className="btn btn--sm btn--ghost" onClick={() => setWaveOpen(true)} disabled={!selectedIds.length}><Wand2 /> Group wave</button>
          <select className="select timeline-clip-type" value={clipType} aria-label="Clip type" onChange={(event) => setClipType(event.target.value as typeof clipType)}><option value="pulse">Pulse</option><option value="wave">Wave</option><option value="rotate">Rotate</option><option value="noise">Noise</option></select>
          <button type="button" className="btn btn--sm btn--ghost" onClick={() => { if (!project) return; const baseValueNow = baseValue(project, objectId, addPath); createClip({ type: clipType, objectId, propertyPath: addPath, start: time, end: Math.min(timeline.duration, time + 4), enabled: true, fadeIn: 0.2, fadeOut: 0.2, params: clipType === 'rotate' ? { speed: 30, direction: 1 } : clipType === 'noise' ? { amount: 0.2, speed: 1, seed: 1 } : { min: typeof baseValueNow === 'number' ? baseValueNow : 0, max: typeof baseValueNow === 'number' ? Math.max(1, baseValueNow) : 1, frequency: 1, phase: 0, waveform: 'sine' } }); }} disabled={!objectId}><Plus /> Clip</button>
          <span className="timeline-actions-spacer" />
          <button type="button" className="timeline-icon" aria-label="Zoom timeline" onClick={() => setZoom((value) => value >= 4 ? 1 : value * 2)}><ZoomIn /></button><span className="timeline-zoom">×{zoom}</span>
          <div className="timeline-duration"><NumberInput value={timeline.duration} min={0.5} max={3600} step={0.5} suffix="s" ariaLabel="Timeline duration" onChange={(value) => { if (value !== null) setTimelineDuration(value); }} /></div>
        </div>
      )}
      {open && (
        <div className="timeline-body">
          <div className="timeline-ruler-row"><div className="timeline-ruler-label">Object / property</div>
            <div className="timeline-ruler" ref={laneRef} style={{ width: `${zoom * 100}%` }}>
              <input className="timeline-scrubber" type="range" min={0} max={timeline.duration} step={0.01} value={time} aria-label="Timeline playhead" onChange={(event) => seek(Number(event.target.value))} />
              {[0, 0.25, 0.5, 0.75, 1].map((fraction) => <span key={fraction} className="timeline-tick" style={{ left: `${fraction * 100}%` }}>{(timeline.duration * fraction).toFixed(1)}s</span>)}
              <div className="timeline-playhead" style={{ left: pct(time) }} />
            </div>
          </div>
          <div className="timeline-scroll">
            {groups.length === 0 && groupEffects.length === 0 && <p className="timeline-empty">No animation yet. Add a track or keyframe a parameter.</p>}
            {groupEffects.length > 0 && <div className="timeline-group timeline-group-effects">
              <div className="timeline-group-name">Group Effects</div>
              {groupEffects.map((effect) => <div className="timeline-track" key={effect.id}>
                <div className="timeline-track-label"><Wand2 /><span>Group Wave · {effect.targetIds.length} targets</span><button type="button" className="timeline-track-delete" aria-label="Delete group effect" onClick={() => { removeGroupEffect(effect.id); if (selectedEffectId === effect.id) setSelectedEffectId(null); }}><Trash2 /></button></div>
                <div className="timeline-lane" style={{ width: `${zoom * 100}%` }} onClick={(event) => seek(timeAt(event.clientX))}>
                  <div className={`timeline-clip timeline-clip--effect ${selectedEffectId === effect.id ? 'is-selected' : ''}`} style={{ left: pct(effect.start), width: `${Math.max(0.3, ((effect.end - effect.start) / timeline.duration) * 100)}%` }} onPointerDown={(event) => effectDown(event, effect, 'move')} onPointerMove={effectMove} onPointerUp={effectUp} onPointerCancel={effectUp} onLostPointerCapture={effectUp}>
                    <span className="timeline-clip-handle timeline-clip-handle--start" onPointerDown={(event) => effectDown(event, effect, 'start')} />
                    <span>Group Wave · {effect.targetIds.length} targets</span>
                    <span className="timeline-clip-handle timeline-clip-handle--end" onPointerDown={(event) => effectDown(event, effect, 'end')} />
                  </div>
                  <div className="timeline-playhead" style={{ left: pct(time) }} />
                </div>
              </div>)}
            </div>}
            {groups.map((group) => <div key={group.id || 'scene'} className="timeline-group"><div className="timeline-group-name">{group.name}</div>
              {group.tracks.map((track) => <div className={`timeline-track ${selectedTrackId === track.id ? 'is-selected' : ''}`} key={track.id} onClick={() => { setSelectedTrackId(track.id); setSelectedEffectId(null); }}>
                <div className="timeline-track-label"><Diamond /><span>{propertyLabel(track.propertyPath)}</span><button type="button" className="timeline-track-delete" aria-label="Delete track" onClick={(event) => { event.stopPropagation(); removeTrack(track.id); }}><Trash2 /></button></div>
                <div className="timeline-lane" style={{ width: `${zoom * 100}%` }} onPointerMove={keyMove} onPointerUp={keyUp} onPointerCancel={keyUp} onClick={(event) => seek(timeAt(event.clientX))}>
                  {track.keyframes.map((key) => <button key={key.id} type="button" className={`timeline-key ${selectedKeyId === key.id ? 'is-selected' : ''}`} style={{ left: pct(key.time) }} aria-label={`Keyframe ${key.time.toFixed(2)} seconds`} title={`${key.time.toFixed(2)}s · ${String(key.value)} · ${key.easing}`} onPointerDown={(event) => keyDown(event, track, key.id)} onPointerMove={keyMove} onPointerUp={keyUp} onPointerCancel={keyUp} onLostPointerCapture={keyUp} />)}
                  <div className="timeline-playhead" style={{ left: pct(time) }} />
                </div>
              </div>)}
              {group.clips.map((clip) => <div className="timeline-track" key={clip.id}>
                <div className="timeline-track-label"><Circle /><span>{clip.type} · {propertyLabel(clip.propertyPath)}</span><button type="button" className="timeline-track-delete" aria-label="Delete clip" onClick={() => removeClip(clip.id)}><Trash2 /></button></div>
                <div className="timeline-lane" style={{ width: `${zoom * 100}%` }} onClick={(event) => seek(timeAt(event.clientX))}>
                  <div className={`timeline-clip ${selectedClipId === clip.id ? 'is-selected' : ''}`} style={{ left: pct(clip.start), width: `${Math.max(0.3, ((clip.end - clip.start) / timeline.duration) * 100)}%` }} onPointerDown={(event) => clipDown(event, clip, 'move')} onPointerMove={clipMove} onPointerUp={clipUp} onPointerCancel={clipUp} onLostPointerCapture={clipUp}>
                    <span className="timeline-clip-handle timeline-clip-handle--start" onPointerDown={(event) => clipDown(event, clip, 'start')} />
                    <span>{clip.type} · {String(clip.params.frequency ?? '')}{clip.type === 'pulse' ? ' Hz' : ''}</span>
                    <span className="timeline-clip-handle timeline-clip-handle--end" onPointerDown={(event) => clipDown(event, clip, 'end')} />
                  </div>
                  <div className="timeline-playhead" style={{ left: pct(time) }} />
                </div>
              </div>)}
            </div>)}
          </div>
          {selectedKey && selectedTrack && <div className="timeline-key-editor"><span className="field-label">Keyframe</span><span className="num">{selectedKey.time.toFixed(2)}s</span>{typeof selectedKey.value === 'string' && /^#/.test(selectedKey.value) ? <input className="color-input" type="color" aria-label="Keyframe color" value={selectedKey.value} onChange={(event) => updateKeyframe(selectedTrack.id, selectedKey.id, { value: event.target.value })} /> : <NumberInput value={typeof selectedKey.value === 'number' ? selectedKey.value : 0} step={0.01} ariaLabel="Keyframe value" onChange={(value) => updateKeyframe(selectedTrack.id, selectedKey.id, { value: value ?? 0 })} />}<Select value={selectedKey.easing} ariaLabel="Keyframe easing" options={EASINGS} onChange={(value) => updateKeyframe(selectedTrack.id, selectedKey.id, { easing: value as TimelineEasing })} /><button type="button" className="section-link" onClick={() => { removeKeyframe(selectedTrack.id, selectedKey.id); setSelectedKeyId(null); }}>Delete keyframe</button></div>}
          {selectedClip && <div className="timeline-key-editor timeline-clip-editor"><span className="field-label">Clip</span><Toggle checked={selectedClip.enabled} ariaLabel="Clip enabled" onChange={(checked) => updateClip(selectedClip.id, { enabled: checked })} /><NumberInput value={selectedClip.start} min={0} step={0.1} suffix="s" ariaLabel="Clip start" onChange={(value) => updateClip(selectedClip.id, { start: value ?? 0 })} /><NumberInput value={selectedClip.end} min={0.1} step={0.1} suffix="s" ariaLabel="Clip end" onChange={(value) => updateClip(selectedClip.id, { end: value ?? 1 })} /><NumberInput value={Number(selectedClip.params.frequency ?? 1)} min={0} step={0.1} suffix="Hz" ariaLabel="Clip frequency" onChange={(value) => updateClip(selectedClip.id, { params: { ...selectedClip.params, frequency: value ?? 0 } })} /><NumberInput value={Number(selectedClip.params.min ?? 0)} step={0.01} ariaLabel="Clip min" onChange={(value) => updateClip(selectedClip.id, { params: { ...selectedClip.params, min: value ?? 0 } })} /><NumberInput value={selectedClip.fadeIn} min={0} step={0.1} suffix="s" ariaLabel="Clip fade in" onChange={(value) => updateClip(selectedClip.id, { fadeIn: value ?? 0 })} /><NumberInput value={selectedClip.fadeOut} min={0} step={0.1} suffix="s" ariaLabel="Clip fade out" onChange={(value) => updateClip(selectedClip.id, { fadeOut: value ?? 0 })} /><NumberInput value={Number(selectedClip.params.max ?? 1)} step={0.01} ariaLabel="Clip max" onChange={(value) => updateClip(selectedClip.id, { params: { ...selectedClip.params, max: value ?? 1 } })} />{selectedClip.type === 'rotate' && <NumberInput value={Number(selectedClip.params.speed ?? 30)} step={1} suffix="°/s" ariaLabel="Clip speed" onChange={(value) => updateClip(selectedClip.id, { params: { ...selectedClip.params, speed: value ?? 0 } })} />}{selectedClip.type === 'noise' && <NumberInput value={Number(selectedClip.params.amount ?? 0.2)} step={0.01} ariaLabel="Clip amount" onChange={(value) => updateClip(selectedClip.id, { params: { ...selectedClip.params, amount: value ?? 0 } })} />}</div>}
          {selectedEffect && (() => {
            const targets = project.objects.filter((object) => selectedEffect.targetIds.includes(object.id));
            const selectedTargetIds = selectedIds.filter((id) => selectedEffect.targetIds.includes(id));
            const intensity = selectedEffect.propertyPath === 'light.intensity';
            const minValue = intensity ? selectedEffect.params.min * 100 : selectedEffect.params.min;
            const maxValue = intensity ? selectedEffect.params.max * 100 : selectedEffect.params.max;
            const updateParams = (patch: Partial<GroupEffect['params']>) => updateGroupEffect(selectedEffect.id, { params: { ...selectedEffect.params, ...patch } });
            return <div className="timeline-key-editor timeline-effect-editor">
              <div className="timeline-effect-editor-head"><strong>Group Wave</strong><span className="dim">Targets · {targets.length}</span><span className="dim">{propertyLabel(selectedEffect.propertyPath)}</span><Toggle checked={selectedEffect.enabled} ariaLabel="Group effect enabled" onChange={(checked) => updateGroupEffect(selectedEffect.id, { enabled: checked })} /></div>
              <div className="timeline-effect-fields">
                <label className="field"><span className="field-label">Frequency</span><NumberInput value={selectedEffect.params.frequency} min={0} step={0.1} suffix="Hz" ariaLabel="Group effect frequency" onChange={(value) => updateParams({ frequency: value ?? 0 })} /></label>
                <label className="field"><span className="field-label">Phase spread</span><NumberInput value={selectedEffect.params.phaseSpread} step={1} suffix="°" ariaLabel="Group effect phase spread" onChange={(value) => updateParams({ phaseSpread: value ?? 0 })} /></label>
                <label className="field"><span className="field-label">Direction</span><Select value={selectedEffect.params.phaseMode} ariaLabel="Group effect direction" options={[{ value: 'left-right', label: 'Left → right' }, { value: 'right-left', label: 'Right → left' }, { value: 'front-back', label: 'Front → back' }, { value: 'center', label: 'Center → out' }, { value: 'sequential', label: 'Sequential' }, { value: 'random', label: 'Random' }, { value: 'custom', label: 'Custom' }]} onChange={(value) => updateParams({ phaseMode: value as GroupEffectPhaseMode })} /></label>
                <label className="field"><span className="field-label">Min</span><NumberInput value={minValue} step={0.1} suffix={intensity ? '%' : undefined} ariaLabel="Group effect min" onChange={(value) => updateParams({ min: intensity ? (value ?? 0) / 100 : value ?? 0 })} /></label>
                <label className="field"><span className="field-label">Max</span><NumberInput value={maxValue} step={0.1} suffix={intensity ? '%' : undefined} ariaLabel="Group effect max" onChange={(value) => updateParams({ max: intensity ? (value ?? 0) / 100 : value ?? 0 })} /></label>
                <label className="field"><span className="field-label">Start</span><NumberInput value={selectedEffect.start} min={0} step={0.1} suffix="s" ariaLabel="Group effect start" onChange={(value) => updateGroupEffect(selectedEffect.id, { start: Math.max(0, value ?? 0) })} /></label>
                <label className="field"><span className="field-label">End</span><NumberInput value={selectedEffect.end} min={0.1} step={0.1} suffix="s" ariaLabel="Group effect end" onChange={(value) => updateGroupEffect(selectedEffect.id, { end: Math.max(selectedEffect.start + 0.05, value ?? 1) })} /></label>
                <label className="field"><span className="field-label">Fade in</span><NumberInput value={selectedEffect.fadeIn} min={0} step={0.1} suffix="s" ariaLabel="Group effect fade in" onChange={(value) => updateGroupEffect(selectedEffect.id, { fadeIn: Math.max(0, value ?? 0) })} /></label>
                <label className="field"><span className="field-label">Fade out</span><NumberInput value={selectedEffect.fadeOut} min={0} step={0.1} suffix="s" ariaLabel="Group effect fade out" onChange={(value) => updateGroupEffect(selectedEffect.id, { fadeOut: Math.max(0, value ?? 0) })} /></label>
                <label className="field"><span className="field-label">Waveform</span><Select value={selectedEffect.params.waveform} ariaLabel="Group effect waveform" options={[{ value: 'sine', label: 'Sine' }, { value: 'triangle', label: 'Triangle' }, { value: 'square', label: 'Square' }]} onChange={(value) => updateParams({ waveform: value as GroupEffect['params']['waveform'] })} /></label>
                <label className="field"><span className="field-label">Color fade</span><Toggle checked={!!selectedEffect.params.colorFrom && !!selectedEffect.params.colorTo} ariaLabel="Group effect color fade" onChange={(checked) => updateParams(checked ? { colorFrom: selectedEffect.params.colorFrom || '#2f7bff', colorTo: selectedEffect.params.colorTo || '#ff2fd0' } : { colorFrom: undefined, colorTo: undefined })} /></label>
                {selectedEffect.params.colorFrom && selectedEffect.params.colorTo && <><label className="field"><span className="field-label">From</span><input className="color-input" type="color" aria-label="Group effect color from" value={selectedEffect.params.colorFrom} onChange={(event) => updateParams({ colorFrom: event.target.value })} /></label><label className="field"><span className="field-label">To</span><input className="color-input" type="color" aria-label="Group effect color to" value={selectedEffect.params.colorTo} onChange={(event) => updateParams({ colorTo: event.target.value })} /></label></>}
              </div>
              <div className="timeline-effect-targets">
                <span className="field-label">Targets · {targets.length}</span>
                <button type="button" className="btn btn--sm btn--ghost" disabled={!selectedIds.length} onClick={() => addGroupEffectTargets(selectedEffect.id, selectedIds)}>Add selection</button>
                <button type="button" className="btn btn--sm btn--ghost" disabled={!selectedTargetIds.length} onClick={() => removeGroupEffectTargets(selectedEffect.id, selectedTargetIds)}>Remove selected</button>
                <button type="button" className="btn btn--sm btn--ghost" disabled={!selectedIds.length} onClick={() => setGroupEffectTargets(selectedEffect.id, selectedIds)}>Replace targets</button>
                <button type="button" className="btn btn--sm btn--ghost" disabled={!selectedTargetIds.length} onClick={() => { const id = detachGroupEffectTargets(selectedEffect.id, selectedTargetIds); if (id) setSelectedEffectId(id); }}>Detach selected</button>
                <details className="timeline-effect-target-list"><summary>Show targets</summary>{targets.map((object) => <div className="timeline-effect-target-row" key={object.id}><span>{object.name}</span><button type="button" className="section-link" aria-label={`Move ${object.name} earlier`} onClick={() => { const ids = [...selectedEffect.targetIds]; const index = ids.indexOf(object.id); if (index > 0) { [ids[index - 1], ids[index]] = [ids[index], ids[index - 1]]; setGroupEffectTargets(selectedEffect.id, ids); } }}>↑</button><button type="button" className="section-link" aria-label={`Move ${object.name} later`} onClick={() => { const ids = [...selectedEffect.targetIds]; const index = ids.indexOf(object.id); if (index >= 0 && index < ids.length - 1) { [ids[index + 1], ids[index]] = [ids[index], ids[index + 1]]; setGroupEffectTargets(selectedEffect.id, ids); } }}>↓</button><button type="button" className="section-link" onClick={() => removeGroupEffectTargets(selectedEffect.id, [object.id])}>Remove</button><button type="button" className="section-link" onClick={() => { const id = detachGroupEffectTargets(selectedEffect.id, [object.id]); if (id) setSelectedEffectId(id); }}>Detach</button></div>)}</details>
              </div>
            </div>;
          })()}
        </div>
      )}
      {waveOpen && <WaveDialog project={project} close={() => setWaveOpen(false)} created={(id) => setSelectedEffectId(id)} />}
    </section>
  );
}
