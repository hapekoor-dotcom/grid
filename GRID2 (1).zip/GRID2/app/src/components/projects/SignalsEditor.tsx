import { Plus, Trash2 } from 'lucide-react';
import type { Project, SignalSource, SignalSourceKind } from '../../types/project';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { defaultSignal } from '../../lib/signals';
import { SIGNAL_DOCS } from '../../lib/parameterHelp';
import { NumberInput, Select, Toggle } from '../ui/Field';

const KINDS: { value: SignalSourceKind; label: string }[] = [
  { value: 'sine', label: 'Sine' },
  { value: 'triangle', label: 'Triangle' },
  { value: 'saw', label: 'Saw' },
  { value: 'pulse', label: 'Pulse' },
  { value: 'noise', label: 'Noise' },
  { value: 'fbm', label: 'FBM' },
  { value: 'randomWalk', label: 'Random Walk' },
  { value: 'sampleHold', label: 'Sample & Hold' },
  { value: 'objectDistance', label: 'Object Distance' },
  { value: 'objectDirection', label: 'Object Direction' },
  { value: 'worldPosition', label: 'World Position' },
  { value: 'normalDirection', label: 'Normal Direction' },
  { value: 'fresnel', label: 'Fresnel / View Angle' },
  { value: 'timeline', label: 'Timeline' },
  { value: 'time', label: 'Time' },
  { value: 'velocity', label: 'Physics Velocity' },
  { value: 'angularSpeed', label: 'Physics Angular Speed' },
  { value: 'height', label: 'Physics Height' },
  { value: 'impact', label: 'Physics Impact' },
  { value: 'distanceToGround', label: 'Distance to Ground' },
  { value: 'sleeping', label: 'Sleeping' },
  { value: 'trigger', label: 'Trigger Overlap' },
];

export function SignalsEditor({ project }: { project: Project }) {
  const updateSignals = useWorkspaceStore((state) => state.updateSignals);
  const signals = project.signals || [];
  const update = (id: string, patch: Partial<SignalSource>) => updateSignals(signals.map((signal) => signal.id === id ? { ...signal, ...patch, params: patch.params || signal.params } : signal));
  const setParam = (signal: SignalSource, key: string, value: number | string | boolean) => update(signal.id, { params: { ...signal.params, [key]: value } });
  return (
    <div className="signals-editor">
      <div className="row-between">
        <span className="field-hint">Reusable signal sources for modulation sockets.</span>
        <button type="button" className="btn btn--sm btn--ghost" onClick={() => updateSignals([...signals, defaultSignal('sine')])}><Plus /> Signal</button>
      </div>
      {signals.length === 0 && <div className="modifier-empty">No signals yet. Add one, then bind it from any numeric effect parameter.</div>}
      {signals.map((signal) => (
        <details className="signal-row" key={signal.id} open>
          <summary>
            <span className={`status-dot ${signal.enabled ? 'status-dot--accent' : ''}`} />
            <input className="input signal-name" value={signal.name} aria-label="Signal name" onChange={(event) => update(signal.id, { name: event.target.value })} />
            <span className="modifier-stage">{signal.kind}</span>
            <Toggle checked={signal.enabled} ariaLabel={`Enable ${signal.name}`} onChange={(checked) => update(signal.id, { enabled: checked })} />
            <button type="button" className="icon-btn icon-btn--sm" aria-label="Delete signal" onClick={() => updateSignals(signals.filter((entry) => entry.id !== signal.id))}><Trash2 /></button>
          </summary>
          <div className="signal-params">
            <p className="field-hint signal-description"><strong>{signal.name}</strong> · {SIGNAL_DOCS[signal.kind]?.short}{SIGNAL_DOCS[signal.kind]?.long ? ` ${SIGNAL_DOCS[signal.kind].long}` : ''}</p>
            <label className="field"><span className="field-label">Kind</span><Select value={signal.kind} ariaLabel="Signal kind" options={KINDS} onChange={(value) => update(signal.id, { kind: value as SignalSourceKind })} /></label>
            {signal.kind !== 'objectDistance' && signal.kind !== 'objectDirection' && signal.kind !== 'worldPosition' && signal.kind !== 'normalDirection' && signal.kind !== 'fresnel' && (
              <>
                <label className="field"><span className="field-label">Speed</span><NumberInput value={Number(signal.params.speed ?? 1)} step={0.05} ariaLabel="Signal speed" onChange={(value) => setParam(signal, 'speed', value ?? 0)} /></label>
                <label className="field"><span className="field-label">Phase</span><NumberInput value={Number(signal.params.phase ?? 0)} step={0.05} ariaLabel="Signal phase" onChange={(value) => setParam(signal, 'phase', value ?? 0)} /></label>
              </>
            )}
            <label className="field"><span className="field-label">Amplitude</span><NumberInput value={Number(signal.params.amplitude ?? 1)} step={0.05} ariaLabel="Signal amplitude" onChange={(value) => setParam(signal, 'amplitude', value ?? 0)} /></label>
            <label className="field"><span className="field-label">Offset</span><NumberInput value={Number(signal.params.offset ?? 0)} step={0.05} ariaLabel="Signal offset" onChange={(value) => setParam(signal, 'offset', value ?? 0)} /></label>
            {['noise', 'fbm', 'randomWalk', 'sampleHold'].includes(signal.kind) && <label className="field"><span className="field-label">Seed</span><NumberInput value={Number(signal.params.seed ?? 1)} step={1} ariaLabel="Signal seed" onChange={(value) => setParam(signal, 'seed', value ?? 0)} /></label>}
            {['fbm'].includes(signal.kind) && <label className="field"><span className="field-label">Octaves</span><NumberInput value={Number(signal.params.octaves ?? 4)} min={1} max={8} step={1} ariaLabel="Signal octaves" onChange={(value) => setParam(signal, 'octaves', value ?? 4)} /></label>}
            {['objectDistance', 'objectDirection'].includes(signal.kind) && <label className="field"><span className="field-label">Object</span><Select value={String(signal.params.objectId || '')} ariaLabel="Signal object" options={[{ value: '', label: 'Select object' }, ...project.objects.map((object) => ({ value: object.id, label: object.name }))]} onChange={(value) => setParam(signal, 'objectId', value)} /></label>}
            {signal.kind === 'objectDistance' && <label className="field"><span className="field-label">Range</span><NumberInput value={Number(signal.params.range ?? 5)} min={0.01} step={0.1} ariaLabel="Signal range" onChange={(value) => setParam(signal, 'range', value ?? 5)} /></label>}
            {['objectDirection', 'worldPosition', 'normalDirection'].includes(signal.kind) && <label className="field"><span className="field-label">Axis</span><Select value={String(signal.params.axis || 'y')} ariaLabel="Signal axis" options={[{ value: 'x', label: 'X' }, { value: 'y', label: 'Y' }, { value: 'z', label: 'Z' }]} onChange={(value) => setParam(signal, 'axis', value)} /></label>}
          </div>
        </details>
      ))}
    </div>
  );
}
