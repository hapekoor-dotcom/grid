import { useRef } from 'react';
import { Copy, Download, FolderOpen, Plus, Trash2, Upload } from 'lucide-react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { projectStats } from '../../lib/project';
import { formatDate } from '../../lib/id';
import { isPortableProjectFile, readPortableProject } from '../../lib/portableProject';
import { Button, IconButton } from '../ui/Button';
import { Dialog } from '../ui/Dialog';

export function ProjectLibraryDialog() {
  const open = useUiStore((state) => state.projectsOpen);
  const setOpen = useUiStore((state) => state.setProjectsOpen);
  const setNewProjectOpen = useUiStore((state) => state.setNewProjectOpen);
  const setExportOpen = useUiStore((state) => state.setExportOpen);
  const setImportReport = useUiStore((state) => state.setImportReport);
  const askConfirm = useUiStore((state) => state.askConfirm);
  const pushToast = useUiStore((state) => state.pushToast);
  const projects = useWorkspaceStore((state) => state.projects);
  const activeId = useWorkspaceStore((state) => state.activeId);
  const openProject = useWorkspaceStore((state) => state.openProject);
  const duplicateProject = useWorkspaceStore((state) => state.duplicateProject);
  const deleteProject = useWorkspaceStore((state) => state.deleteProject);
  const importProjectFile = useWorkspaceStore((state) => state.importProjectFile);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!open) return null;

  const onImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const portable = await isPortableProjectFile(file);
      const text = portable ? JSON.stringify((await readPortableProject(file)).project) : await file.text();
      const result = importProjectFile(text, file.name.replace(/\.(json|remorph|zip)$/i, ''), portable);
      setImportReport({
        title: 'Project import',
        warnings: result.warnings,
        projectName: result.project.name,
        objects: result.project.objects.length,
        connections: result.project.connections.length,
        legacy: !portable && /"nodes"\s*:/.test(text) && !/"schemaVersion"\s*:\s*5/.test(text),
      });
      setOpen(false);
      pushToast('Project imported', 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Could not read project', 'error');
    }
  };

  return (
    <Dialog
      title="Projects"
      description="Local workspace in this browser"
      onClose={() => setOpen(false)}
      wide
      footer={
        <>
          <Button size="sm" variant="ghost" icon={<Upload />} onClick={() => fileRef.current?.click()}>Import project</Button>
          <Button size="sm" variant="ghost" icon={<Download />} onClick={() => { setOpen(false); setExportOpen(true); }}>Export</Button>
          <span className="spacer" />
          <Button size="sm" variant="primary" icon={<Plus />} onClick={() => { setOpen(false); setNewProjectOpen(true); }}>New project</Button>
        </>
      }
    >
      <input ref={fileRef} type="file" accept=".json,.remorph,.zip,application/json,application/zip" hidden onChange={(event) => { void onImport(event.target.files?.[0]); event.target.value = ''; }} />
      {projects.length === 0 ? (
        <div className="empty" style={{ padding: '40px 20px' }}>
          <FolderOpen />
          <strong>No projects yet</strong>
          <span>Create a new project or import a JSON file.</span>
        </div>
      ) : (
        <div className="project-dialog-list">
          {projects.map((project) => {
            const stats = projectStats(project);
            return (
              <div className={`project-dialog-row ${project.id === activeId ? 'is-active' : ''}`} key={project.id}>
                <button type="button" className="project-dialog-main" onClick={() => { openProject(project.id); setOpen(false); }}>
                  <span className="welcome-project-icon"><FolderOpen /></span>
                  <span className="project-dialog-copy">
                    <span className="project-dialog-name">{project.name}{project.id === activeId && <span className="badge badge--accent" style={{ marginLeft: 8 }}>open</span>}</span>
                    <span className="project-dialog-meta">
                      <span>{formatDate(project.updatedAt)}</span>
                      <span className="num">{stats.devices} objects</span>
                      <span className="num">{stats.models + stats.lights} scene objects</span>
                    </span>
                  </span>
                </button>
                <div className="project-dialog-actions">
                  <IconButton label="Duplicate" size="sm" onClick={() => duplicateProject(project.id)}><Copy /></IconButton>
                  <IconButton
                    label="Delete project"
                    size="sm"
                    onClick={() => askConfirm({
                      title: 'Delete project?',
                      message: `"${project.name}" will be deleted. This action cannot be undone.`,
                      confirmLabel: 'Delete',
                      danger: true,
                      onConfirm: () => deleteProject(project.id),
                    })}
                  >
                    <Trash2 />
                  </IconButton>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Dialog>
  );
}
