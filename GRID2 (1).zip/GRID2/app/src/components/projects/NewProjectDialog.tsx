import { useState } from 'react';
import { Plus } from 'lucide-react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';
import { Field, TextInput } from '../ui/Field';


export function NewProjectDialog() {
  const open = useUiStore((state) => state.newProjectOpen);
  const setOpen = useUiStore((state) => state.setNewProjectOpen);
  const setProjectsOpen = useUiStore((state) => state.setProjectsOpen);
  const pushToast = useUiStore((state) => state.pushToast);
  const createNewProject = useWorkspaceStore((state) => state.createNewProject);
  const [name, setName] = useState('');

  if (!open) return null;

  const create = () => {
    createNewProject(name.trim() || 'New project', 14, 9);
    setOpen(false);
    setProjectsOpen(false);
    pushToast('Project created', 'success');
    setName('');
  };

  return (
    <Dialog
      title="New project"
      description="Starts empty. Import a model, add lights and build the scene in 3D."
      onClose={() => setOpen(false)}
      footer={
        <>
          <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button size="sm" variant="primary" icon={<Plus />} onClick={create}>Create project</Button>
        </>
      }
    >
      <div className="form-stack">
        <Field label="Name">
          <TextInput value={name} onChange={setName} placeholder={'e.g. Club "Platform"'} ariaLabel="Project name" autoFocus maxLength={120} />
        </Field>
        <div className="notice">No room object is required. The 3D view uses a neutral scene.</div>
        <div className="notice">All coordinates are in meters. Plan and 3D share one scene model.</div>
      </div>
    </Dialog>
  );
}
