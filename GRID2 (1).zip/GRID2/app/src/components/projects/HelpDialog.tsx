import { Box, Info, Layers, Lightbulb, Search, Upload } from 'lucide-react';
import { useState } from 'react';
import { searchParameterDocs } from '../../lib/parameterHelp';
import { useUiStore } from '../../store/uiStore';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';

const SHORTCUTS: { group: string; items: { keys: string; label: string }[] }[] = [
  {
    group: 'Modes',
    items: [
      { keys: '1', label: 'Plan' },
      { keys: '2', label: '3D scene' },
      { keys: '3', label: 'Lighting in 3D' },
    ],
  },
  {
    group: 'Plan',
    items: [
      { keys: 'V', label: 'Select and move' },
      { keys: 'LMB + RMB', label: 'Pan' },
      { keys: 'Wheel', label: 'Zoom to cursor' },
      { keys: 'F', label: 'Fit plan' },
      { keys: 'R', label: 'Rotate selection' },
      { keys: 'L / H', label: 'Lock / hide' },
    ],
  },
  {
    group: '3D',
    items: [
      { keys: 'W A S D', label: 'Fly camera forward / left / back / right' },
      { keys: 'Space / C', label: 'Fly up / down' },
      { keys: 'Space / C', label: 'Fly up / down' },
      { keys: 'Shift / Alt', label: 'Fast / precision movement' },
      { keys: 'F / Shift+F', label: 'Frame selection / frame scene' },
      { keys: 'RMB / MMB drag', label: 'Orbit around the pivot' },
      { keys: 'Shift + MMB', label: 'Pan camera and pivot' },
      { keys: 'Wheel', label: 'Zoom camera' },
      { keys: 'Q / 1 / 2 / 3', label: 'Select / Move / Rotate / Scale' },
      { keys: 'LMB drag (unlocked)', label: 'Orbit' },
    ],
  },
  {
    group: 'Editing',
    items: [
      { keys: 'Ctrl Z', label: 'Undo' },
      { keys: 'Ctrl Shift Z', label: 'Redo' },
      { keys: 'Ctrl C / V', label: 'Copy / paste' },
      { keys: 'Ctrl D', label: 'Duplicate' },
      { keys: 'Ctrl G', label: 'Group' },
      { keys: 'Ctrl Shift G', label: 'Ungroup' },
      { keys: 'Delete', label: 'Delete selection' },
      { keys: 'Arrows', label: 'Nudge 5 cm' },
      { keys: 'Shift + arrows', label: 'Nudge 50 cm' },
    ],
  },
  {
    group: 'Project',
    items: [
      { keys: 'Ctrl S', label: 'Save locally' },
      { keys: 'Ctrl E', label: 'Export' },
      { keys: 'Ctrl K', label: 'Add equipment' },
      { keys: '?', label: 'Help' },
    ],
  },
];

export function HelpDialog() {
  const open = useUiStore((state) => state.helpOpen);
  const setOpen = useUiStore((state) => state.setHelpOpen);
  const [query, setQuery] = useState('');
  const results = searchParameterDocs(query);
  if (!open) return null;
  return (
    <Dialog
      title="RE:GRID · Documentation"
      description="Import models, arrange a scene and shape the lighting in real time"
      onClose={() => setOpen(false)}
      wide
      footer={<Button size="sm" onClick={() => setOpen(false)}>Close</Button>}
    >
      <div className="help-search"><Search /><input className="input" value={query} placeholder="Search parameters, effects and signals…" aria-label="Search documentation" onChange={(event) => setQuery(event.target.value)} /></div>
      {query.trim() && <section className="help-search-results"><div className="section-label"><span>Search results</span><span className="count">{results.length}</span></div>{results.length === 0 ? <p className="field-hint">No matching parameter or effect.</p> : results.map((result) => <div className="help-result" key={`${result.title}-${result.description}`}><strong>{result.title}</strong><span>{result.description}</span></div>)}</section>}
      <div className="help-grid">
        <section className="help-intro">
          <div className="section-label"><span>Quick start</span></div>
          <ol className="help-steps">
            <li><span className="help-step-num num">01</span><div><strong>Create a project</strong><span>Start empty or open the demo scene.</span></div></li>
            <li><span className="help-step-num num">02</span><div><strong>Import a 3D model</strong><span>Use Import 3D Model for a GLB or GLTF file.</span></div></li>
            <li><span className="help-step-num num">03</span><div><strong>Arrange the scene</strong><span>Move, rotate and scale objects in Plan or directly in 3D.</span></div></li>
            <li><span className="help-step-num num">04</span><div><strong>Add lights</strong><span>Choose Spot, Point or Area Light from the Add menu.</span></div></li>
            <li><span className="help-step-num num">05</span><div><strong>Orbit and refine</strong><span>Orbit, pan and zoom the camera, use a gizmo, then tune color, intensity and beam.</span></div></li>
          </ol>
          <div className="help-limitations">
            <div><Info /><span>Virtual light is not sent to fixtures and is not a photometric calculation.</span></div>
            <div><Upload /><span>Models are stored in this browser. Project JSON keeps a lightweight asset reference.</span></div>
            <div><Lightbulb /><span>Model visibility and light output are independent controls.</span></div>
            <div><Layers /><span>Scene export is JSON. Imported model binaries stay in browser storage.</span></div>
            <div><Box /><span>No room is required. The scene works with models and lights alone.</span></div>
          </div>
        </section>
        <section>
          <div className="section-label"><span>Keyboard shortcuts</span></div>
          <div className="shortcut-groups">
            {SHORTCUTS.map((group) => (
              <div className="shortcut-group" key={group.group}>
                <h3>{group.group}</h3>
                {group.items.map((item) => (
                  <div className="shortcut-row" key={item.keys}>
                    <span>{item.label}</span>
                    <span className="kbd">{item.keys}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </section>
      </div>
    </Dialog>
  );
}
