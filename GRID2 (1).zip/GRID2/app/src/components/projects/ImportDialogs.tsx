import { AlertTriangle } from 'lucide-react';
import { useUiStore } from '../../store/uiStore';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';

export function ConfirmDialog() {
  const confirm = useUiStore((state) => state.confirm);
  const askConfirm = useUiStore((state) => state.askConfirm);
  if (!confirm) return null;
  return (
    <Dialog
      title={confirm.title}
      onClose={() => askConfirm(null)}
      footer={
        <>
          <Button size="sm" variant="ghost" onClick={() => askConfirm(null)}>Cancel</Button>
          <Button
            size="sm"
            variant={confirm.danger ? 'danger' : 'primary'}
            onClick={() => { confirm.onConfirm(); askConfirm(null); }}
          >
            {confirm.confirmLabel || 'Confirm'}
          </Button>
        </>
      }
    >
      <div className="confirm-body">
        {confirm.danger && <AlertTriangle />}
        <p>{confirm.message}</p>
      </div>
    </Dialog>
  );
}

export function ImportReportDialog() {
  const report = useUiStore((state) => state.importReport);
  const setReport = useUiStore((state) => state.setImportReport);
  const setMode = useUiStore((state) => state.setMode);
  if (!report) return null;
  return (
    <Dialog
      title={report.title}
      description={report.projectName}
      onClose={() => setReport(null)}
      footer={
        <>
          <Button size="sm" variant="ghost" onClick={() => setReport(null)}>Continue</Button>
          <Button size="sm" variant="primary" onClick={() => { setMode('plan'); setReport(null); }}>Open scene</Button>
        </>
      }
    >
      <div className="import-report">
        <div className="metric-grid">
          <div className="metric"><span>Objects</span><strong className="num">{report.objects}</strong></div>
          <div className="metric"><span>Format</span><strong className="num">{report.legacy ? 'Rig Grid' : 'RE:GRID v5'}</strong></div>
        </div>
        {report.warnings.length > 0 ? (
          <div className="import-warnings">
            <div className="section-label"><span>Import warnings</span><span className="count">{report.warnings.length}</span></div>
            {report.warnings.map((warning, index) => (
              <div className="import-warning" key={index}><AlertTriangle /><span>{warning}</span></div>
            ))}
          </div>
        ) : (
          <div className="notice"><span>No warnings. All data was read without loss.</span></div>
        )}
        <div className="notice">After importing, review the scene in Plan or 3D. Import does not modify the source file.</div>
      </div>
    </Dialog>
  );
}
