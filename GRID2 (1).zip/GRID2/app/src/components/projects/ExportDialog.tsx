import { useState } from 'react';
import { CheckCircle2, Download, FileJson, Image, Info, Layers } from 'lucide-react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { download3dPng, downloadBlob, downloadText, exportPlanSvg, exportSceneJson } from '../../lib/exports';
import { createPortableProject } from '../../lib/portableProject';
import { exportProjectJson } from '../../lib/migration';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';

export function ExportDialog() {
  const open = useUiStore((state) => state.exportOpen);
  const setOpen = useUiStore((state) => state.setExportOpen);
  const pushToast = useUiStore((state) => state.pushToast);
  const mode = useUiStore((state) => state.mode);
  const setMode = useUiStore((state) => state.setMode);
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const [lastAction, setLastAction] = useState<string | null>(null);
  const [portableBusy, setPortableBusy] = useState(false);

  if (!open || !project) return null;
  const has3d = !!document.querySelector('.viewport3d canvas');
  const hasPlan = !!document.querySelector('[data-plan-svg]');
  const name = project.name.replace(/[^\p{L}\p{N}]+/gu, '-');

  const report = (label: string) => {
    setLastAction(label);
    pushToast(`${label}: file created`, 'success');
  };

  return (
    <Dialog
      title="Export project"
      description="Files are generated locally in the browser. Nothing is sent to a server."
      onClose={() => setOpen(false)}
      wide
      footer={<><span className="field-hint" style={{ marginRight: 'auto' }}>Files are created locally and are not sent to a server.</span><Button size="sm" onClick={() => setOpen(false)}>Close</Button></>}
    >
      <div className="export-sections">
        <section>
          <div className="section-label"><span>Project</span></div>
          <div className="export-grid">
            <button type="button" className="export-card" onClick={() => { downloadText(exportProjectJson(project), `${name}.json`, 'application/json'); report('Project JSON'); }}>
              <FileJson /><strong>Project JSON</strong><span>Scene objects, transforms, visibility and lighting. Schema v5.</span>
            </button>
            <button type="button" className="export-card" disabled={portableBusy} onClick={() => { setPortableBusy(true); void createPortableProject(project).then((blob) => { downloadBlob(blob, `${name}.remorph`); report('Portable project'); }).catch((error) => pushToast(error instanceof Error ? error.message : 'Portable export failed', 'error')).finally(() => setPortableBusy(false)); }}>
              <Layers /><strong>Portable project · .remorph</strong><span>Scene, imported models and texture maps.</span>
            </button>
            <button type="button" className="export-card" onClick={() => { exportSceneJson(project); report('Scene JSON'); }}>
              <Layers /><strong>Scene JSON</strong><span>Geometry and connections in meters for external tools.</span>
            </button>
          </div>
        </section>

        <section>
          <div className="section-label"><span>Visuals</span></div>
          <div className="export-grid">
            <button
              type="button"
              className="export-card"
              onClick={() => {
                if (!hasPlan) {
                  setMode('plan');
                  pushToast('Open the plan and export the SVG again', 'warning');
                  return;
                }
                if (exportPlanSvg(project)) report('Plan SVG');
              }}
            >
              <Image /><strong>2D plan SVG</strong><span>Vector plan without UI chrome.</span>
              {!hasPlan && <em>Available in Plan mode</em>}
            </button>
            <button
              type="button"
              className="export-card"
              onClick={() => {
                if (!has3d) {
                  setMode('3d');
                  pushToast('Open the 3D scene and take the snapshot again', 'warning');
                  return;
                }
                if (download3dPng(project)) report('3D PNG');
              }}
            >
              <Image /><strong>3D snapshot PNG</strong><span>Current 3D scene frame with lighting.</span>
              {!has3d && <em>Available in 3D and Lighting modes</em>}
            </button>
          </div>
        </section>

        <div className="notice">
          <Info />
          <span>
            {lastAction ? `Last export: ${lastAction}. ` : ''}
            Exports contain no access tokens. Unknown specifications stay empty rather than being replaced with estimates.
          </span>
        </div>
      </div>
    </Dialog>
  );
}
