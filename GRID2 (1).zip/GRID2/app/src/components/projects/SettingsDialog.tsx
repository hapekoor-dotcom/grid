import { useState } from 'react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';
import { Field, NumberInput, Select, Slider, Toggle } from '../ui/Field';
import { OverdriveControl } from '../ui/OverdriveControl';
import { ModifiersEditor } from '../inspector/ModifiersEditor';
import { SignalsEditor } from './SignalsEditor';
import { KeyframeButton } from '../inspector/KeyframeButton';
import { antiAliasingFor } from '../../lib/renderQuality';
import { defaultReactionDiffusion, rdPreset, RD_PRESETS } from '../../lib/reactionDiffusion';
import { reactionConsumers } from '../../lib/reactionConsumers';
import { defaultModulator } from '../../lib/signals';

function RDUsagePanel({ status, consumers }: { status: 'Running' | 'Paused' | 'Off'; consumers: ReturnType<typeof reactionConsumers> }) {
  const [showGraph, setShowGraph] = useState(false);
  return (
    <div className="rd-usage">
      <div className="rd-usage-head"><span>Status</span><b className={`rd-status rd-status--${status.toLowerCase()}`}>{status}</b><span>Consumers</span><b>{consumers.reduce((total, consumer) => total + consumer.usageCount, 0)}</b><Button size="sm" variant="ghost" onClick={() => setShowGraph((value) => !value)}>{showGraph ? 'Hide Graph' : 'Show in Graph'}</Button></div>
      {!consumers.length && <p className="field-hint rd-empty">RD is evolving, but currently does not affect the rendered scene.</p>}
      {!!consumers.length && <ul className="rd-consumers">{consumers.map((consumer) => <li key={consumer.id} className={showGraph ? 'is-highlighted' : ''}><span>{consumer.ownerName}{consumer.usageCount > 1 ? ` ×${consumer.usageCount}` : ''}</span><b>→</b><span>{consumer.module}</span><em>{consumer.parameter}</em><code>{consumer.connectionId}</code></li>)}</ul>}
      {showGraph && <div className="rd-graph">
        <div className="rd-graph-source">Reaction Diffusion</div>
        {consumers.map((consumer) => <div className="rd-graph-edge" key={`graph-${consumer.id}`}><span>RD</span><b>→</b><span>{consumer.ownerName} · {consumer.module} · {consumer.parameter}</span></div>)}
      </div>}
    </div>
  );
}

export function SettingsDialog() {
  const open = useUiStore((state) => state.settingsOpen);
  const setOpen = useUiStore((state) => state.setSettingsOpen);
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const updateSettings = useWorkspaceStore((state) => state.updateSettings);
  const updateLighting = useWorkspaceStore((state) => state.updateLighting);
  const updateSceneEffects = useWorkspaceStore((state) => state.updateSceneEffects);
  const updatePhysics = useWorkspaceStore((state) => state.updatePhysics);
  const updateFields = useWorkspaceStore((state) => state.updateFields);
  const updateReactionDiffusion = useWorkspaceStore((state) => state.updateReactionDiffusion);
  const resetReactionDiffusion = useWorkspaceStore((state) => state.resetReactionDiffusion);
  const setReactionDiffusionModulator = useWorkspaceStore((state) => state.setReactionDiffusionModulator);
  const renameProject = useWorkspaceStore((state) => state.renameProject);

  if (!open || !project) return null;

  return (
    <Dialog
      title="Project settings"
      description="Grid, display and 3D quality. Settings are saved with the project."
      onClose={() => setOpen(false)}
      footer={<Button size="sm" onClick={() => setOpen(false)}>Done</Button>}
    >
      <div className="settings-grid">
        <section>
          <div className="section-label"><span>Plan</span></div>
          <div className="form-stack">
            <Field label="Project name">
              <input
                className="input"
                aria-label="Project name"
                defaultValue={project.name}
                onBlur={(event) => renameProject(event.target.value)}
                onKeyDown={(event) => { if (event.key === 'Enter') (event.target as HTMLInputElement).blur(); }}
              />
            </Field>
            <Field label="Grid spacing">
              <Select
                value={String(project.settings.gridSize)}
                ariaLabel="Grid spacing"
                onChange={(value) => updateSettings({ gridSize: Number(value) })}
                options={[
                  { value: '0.1', label: '10 cm' },
                  { value: '0.25', label: '25 cm' },
                  { value: '0.5', label: '50 cm' },
                  { value: '1', label: '1 m' },
                ]}
              />
            </Field>
            <Toggle checked={project.settings.showGrid} label="Show grid" onChange={(checked) => updateSettings({ showGrid: checked })} />
            <Toggle checked={project.settings.snap} label="Snap to grid and objects" onChange={(checked) => updateSettings({ snap: checked })} />
            <Toggle checked={project.settings.showRulers} label="Rulers" onChange={(checked) => updateSettings({ showRulers: checked })} />
            <Toggle checked={project.settings.showLabels} label="Object labels" onChange={(checked) => updateSettings({ showLabels: checked })} />
            <Toggle checked={project.settings.showBeams} label="Beams on plan" onChange={(checked) => updateSettings({ showBeams: checked })} />
          </div>
        </section>
        <section>
          <div className="section-label"><span>3D scene</span></div>
          <div className="form-stack">
            <Toggle checked={project.lighting.volumetric} label="Volumetric beams" onChange={(checked) => updateLighting({ volumetric: checked })} />
            <div className="slider-label-row"><span className="field-label">Exposure</span><span className="num">{project.lighting.exposure.toFixed(2)}</span></div>
            <Slider value={project.lighting.exposure} min={0.4} max={2} step={0.01} ariaLabel="Exposure" onChange={(value) => updateLighting({ exposure: value })} />
            <span className="field-label-row"><span className="field-label">Bloom strength</span><KeyframeButton objectId={null} propertyPath="scene.bloomStrength" value={project.lighting.bloomStrength ?? 1} label="Bloom strength" /></span>
            <OverdriveControl value={project.lighting.bloomStrength ?? 1} ariaLabel="Bloom strength" onChange={(value) => updateLighting({ bloomStrength: value })} />
            <span className="field-label-row"><span className="field-label">Light master</span><KeyframeButton objectId={null} propertyPath="scene.master" value={project.lighting.master} label="Light master" /></span>
            <OverdriveControl value={project.lighting.master} ariaLabel="Light master" onChange={(value) => updateLighting({ master: value })} />
            <div className="slider-label-row"><span className="field-label">Ambient light</span><span className="num">{Math.round(project.lighting.ambient * 100)}%</span></div>
            <Slider value={project.lighting.ambient} min={0} max={1} step={0.01} ariaLabel="Ambient light" onChange={(value) => updateLighting({ ambient: value })} />
            <div className="section-label"><span>Final output</span></div>
            <Field label="Anti-aliasing" hint="TAA uses temporal history; MSAA is a cheaper spatial option. Not the same as temporal dithering."><Select value={antiAliasingFor(project.lighting)} ariaLabel="Anti-aliasing" options={[{ value: 'off', label: 'Off' }, { value: 'msaa', label: 'MSAA' }, { value: 'taa', label: 'TAA' }]} onChange={(value) => updateLighting({ antiAliasing: value as 'off' | 'msaa' | 'taa' })} /></Field>
            <div className="slider-label-row"><span className="field-label">TAA jitter</span><span className="num">{Math.round((project.lighting.taaJitter ?? 1) * 100)}%</span></div>
            <Slider value={project.lighting.taaJitter ?? 1} min={0} max={1} step={0.01} ariaLabel="TAA jitter" onChange={(value) => updateLighting({ taaJitter: value })} />
            <Field label="Dithering"><Select value={project.lighting.dithering ?? 'temporal'} ariaLabel="Dithering" options={[{ value: 'off', label: 'Off' }, { value: 'static', label: 'Static' }, { value: 'temporal', label: 'Temporal' }]} onChange={(value) => updateLighting({ dithering: value as 'off' | 'static' | 'temporal' })} /></Field>
            <Field label="Dither strength" hint="100% = approximately one 8-bit output step."><NumberInput value={Math.round((project.lighting.ditherStrength ?? 1) * 100)} min={0} max={300} step={1} suffix="%" ariaLabel="Dither strength" onChange={(value) => updateLighting({ ditherStrength: Math.max(0, (value ?? 100) / 100) })} /></Field>
            <div className="section-label"><span>Physics</span></div>
            <div className="form-stack">
              <Toggle checked={project.physics?.enabled === true} label="Physics enabled (optional)" onChange={(checked) => updatePhysics({ enabled: checked, paused: false })} />
              <div className="form-grid form-grid--3">
                <Field label="Gravity X"><NumberInput value={project.physics?.gravity.x ?? 0} step={0.1} ariaLabel="Gravity X" onChange={(value) => updatePhysics({ gravity: { ...(project.physics?.gravity || { x: 0, y: -9.81, z: 0 }), x: value ?? 0 } })} /></Field>
                <Field label="Gravity Y"><NumberInput value={project.physics?.gravity.y ?? -9.81} step={0.1} ariaLabel="Gravity Y" onChange={(value) => updatePhysics({ gravity: { ...(project.physics?.gravity || { x: 0, y: -9.81, z: 0 }), y: value ?? 0 } })} /></Field>
                <Field label="Gravity Z"><NumberInput value={project.physics?.gravity.z ?? 0} step={0.1} ariaLabel="Gravity Z" onChange={(value) => updatePhysics({ gravity: { ...(project.physics?.gravity || { x: 0, y: -9.81, z: 0 }), z: value ?? 0 } })} /></Field>
              </div>
              <Field label="Simulation speed"><NumberInput value={project.physics?.timeScale ?? 1} min={0} max={8} step={0.05} ariaLabel="Simulation speed" onChange={(value) => updatePhysics({ timeScale: value ?? 1 })} /></Field>
              <Field label="Quality"><Select value={project.physics?.quality ?? 'medium'} ariaLabel="Physics quality" options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }, { value: 'extreme', label: 'Extreme' }]} onChange={(value) => updatePhysics({ quality: value as 'low' | 'medium' | 'high' | 'extreme' })} /></Field>
              <div className="row wrap">
                <Button size="sm" onClick={() => updatePhysics({ paused: !(project.physics?.paused === true) })}>{project.physics?.paused ? 'Resume' : 'Pause'}</Button>
                <Button size="sm" onClick={() => updatePhysics({ paused: true, stepToken: (project.physics?.stepToken ?? 0) + 1 })}>Step one frame</Button>
                <Button size="sm" onClick={() => updatePhysics({ resetToken: (project.physics?.resetToken ?? 0) + 1 })}>Reset simulation</Button>
                <Toggle checked={project.physics?.debug === true} label="Debug colliders" onChange={(checked) => updatePhysics({ debug: checked })} />
              </div>
            </div>
            <div className="section-label"><span>Signal engine</span></div>
            <SignalsEditor project={project} />
            <div className="section-label"><span>Reaction diffusion</span></div>
            <p className="field-hint">Gray-Scott GPU simulation. One evolving field drives every enabled RD consumer. Feed/Kill edits do not reset state.</p>
            <RDUsagePanel status={project.reactionDiffusion?.enabled ? (project.reactionDiffusion.paused ? 'Paused' : 'Running') : 'Off'} consumers={reactionConsumers(project)} />
            <Toggle checked={project.reactionDiffusion?.enabled === true} label="Enable GPU simulation" onChange={(checked) => updateReactionDiffusion(project.reactionDiffusion ? { enabled: checked } : { ...defaultReactionDiffusion(), enabled: checked })} />
            {project.reactionDiffusion?.enabled && <>
              <Field label="Preset"><Select value={project.reactionDiffusion.preset} ariaLabel="RD preset" options={Object.entries(RD_PRESETS).map(([value, preset]) => ({ value, label: preset.label }))} onChange={(value) => updateReactionDiffusion(rdPreset(value))} /></Field>
              <div className="form-stack">
                <span className="field-label">Parameter modulation</span>
                {([['feed','Feed'],['kill','Kill'],['diffusionA','Diffusion A'],['diffusionB','Diffusion B'],['timeStep','Time step'],['speed','Speed'],['contrast','Contrast'],['threshold','Threshold']] as const).map(([key,label]) => <div className="row" key={key}><span className="field-hint" style={{width:70}}>{label}</span><select className="select shader-mod-source" aria-label={`RD ${label} modulation source`} value={project.reactionDiffusion?.modulators?.[key]?.sourceId || ''} onChange={(event) => setReactionDiffusionModulator(key, event.target.value ? { ...defaultModulator(event.target.value), amount: 1 } : null)}><option value="">~ No modulator</option>{(project.signals || []).map((signal) => <option key={signal.id} value={signal.id}>~ {signal.name} · {signal.kind}</option>)}</select>{project.reactionDiffusion?.modulators?.[key] && <NumberInput value={project.reactionDiffusion.modulators[key].amount} step={0.01} ariaLabel={`RD ${label} modulation amount`} onChange={(value) => setReactionDiffusionModulator(key, { ...project.reactionDiffusion!.modulators![key], amount: value ?? 0 })} />}</div>)}
              </div>
              <div className="slider-label-row"><span className="field-label">Feed</span><span className="num">{project.reactionDiffusion.feed.toFixed(4)}</span></div>
              <Slider value={project.reactionDiffusion.feed} min={0.005} max={0.09} step={0.0001} ariaLabel="RD feed" onChange={(value) => updateReactionDiffusion({ feed: value })} />
              <p className="field-hint">Controls how quickly chemical A is replenished. Small changes radically change spots, cells, stripes or waves.</p>
              <div className="slider-label-row"><span className="field-label">Kill</span><span className="num">{project.reactionDiffusion.kill.toFixed(4)}</span></div>
              <Slider value={project.reactionDiffusion.kill} min={0.03} max={0.08} step={0.0001} ariaLabel="RD kill" onChange={(value) => updateReactionDiffusion({ kill: value })} />
              <p className="field-hint">Controls how quickly chemical B disappears. Feed and Kill together define the characteristic pattern.</p>
              <div className="form-grid form-grid--3">
                <Field label="Diffusion A"><NumberInput value={project.reactionDiffusion.diffusionA} min={0.05} max={2} step={0.01} ariaLabel="RD diffusion A" onChange={(value) => updateReactionDiffusion({ diffusionA: value ?? 1 })} /></Field>
                <Field label="Diffusion B"><NumberInput value={project.reactionDiffusion.diffusionB} min={0.05} max={1.5} step={0.01} ariaLabel="RD diffusion B" onChange={(value) => updateReactionDiffusion({ diffusionB: value ?? 0.5 })} /></Field>
                <Field label="Time step"><NumberInput value={project.reactionDiffusion.timeStep} min={0.1} max={2} step={0.05} ariaLabel="RD time step" onChange={(value) => updateReactionDiffusion({ timeStep: value ?? 1 })} /></Field>
                <Field label="Speed"><NumberInput value={project.reactionDiffusion.speed} min={0} max={120} step={1} ariaLabel="RD speed" onChange={(value) => updateReactionDiffusion({ speed: value ?? 12 })} /></Field>
                <Field label="Iterations / frame"><NumberInput value={project.reactionDiffusion.iterations} min={1} max={64} step={1} ariaLabel="RD iterations" onChange={(value) => updateReactionDiffusion({ iterations: value ?? 8 })} /></Field>
                <Field label="Resolution"><Select value={String(project.reactionDiffusion.resolution)} ariaLabel="RD resolution" options={[64,128,192,256,384,512,768,1024].map((value) => ({ value: String(value), label: `${value} × ${value}` }))} onChange={(value) => updateReactionDiffusion({ resolution: Number(value) })} /></Field>
              </div>
              <div className="form-grid form-grid--3">
                <Field label="Seed"><NumberInput value={project.reactionDiffusion.seed} min={1} step={1} ariaLabel="RD seed" onChange={(value) => updateReactionDiffusion({ seed: Math.max(1, Math.round(value ?? 1)) })} /></Field>
                <Field label="Contrast"><NumberInput value={project.reactionDiffusion.contrast} min={0.1} max={8} step={0.01} ariaLabel="RD contrast" onChange={(value) => updateReactionDiffusion({ contrast: value ?? 1 })} /></Field>
                <Field label="Threshold"><NumberInput value={project.reactionDiffusion.threshold} min={0} max={1} step={0.01} ariaLabel="RD threshold" onChange={(value) => updateReactionDiffusion({ threshold: value ?? 0.2 })} /></Field>
              </div>
              <div className="form-grid form-grid--3">
                <Field label="Injection strength"><NumberInput value={project.reactionDiffusion.injection} min={0} max={1} step={0.01} ariaLabel="RD injection strength" onChange={(value) => updateReactionDiffusion({ injection: value ?? 0 })} /></Field>
                <Field label="Brush radius"><NumberInput value={project.reactionDiffusion.injectionRadius} min={0.01} max={1} step={0.01} ariaLabel="RD injection radius" onChange={(value) => updateReactionDiffusion({ injectionRadius: value ?? 0.12 })} /></Field>
                <Field label="Paint chemical"><Select value={project.reactionDiffusion.paintChemical || 'B'} ariaLabel="RD paint chemical" options={[{value:'A',label:'Chemical A'},{value:'B',label:'Chemical B'}]} onChange={(value) => updateReactionDiffusion({ paintChemical: value as 'A' | 'B' })} /></Field>
              </div>
              <div className="row wrap"><Toggle checked={project.reactionDiffusion.paused} label="Pause simulation" onChange={(checked) => updateReactionDiffusion({ paused: checked })} /><Toggle checked={project.reactionDiffusion.invert} label="Invert output" onChange={(checked) => updateReactionDiffusion({ invert: checked })} /><Button size="sm" onClick={resetReactionDiffusion}>Reset simulation</Button></div>
              <p className="field-hint">Resolution changes and Reset rebuild GPU history. Feed, Kill, speed and contrast edits update the existing simulation.</p>
            </>}
            <div className="section-label"><span>Scene modifier stack</span></div>
            <ModifiersEditor modifiers={project.effects || []} target="scene" onChange={updateSceneEffects} />
            <div className="section-label"><span>Physics field stack</span></div>
            <ModifiersEditor modifiers={project.fields || []} target="field" onChange={updateFields} />
            <div className="section-label"><span>Camera effect stack</span></div>
            <ModifiersEditor modifiers={project.effects || []} target="camera" onChange={updateSceneEffects} />
          </div>
        </section>
      </div>
    </Dialog>
  );
}
