import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Boxes, Clock3, Copy, Grid3X3, Plus, Trash2, Upload, Zap } from 'lucide-react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { loadWorkspace, parseProjectFile } from '../../lib/migration';
import { projectStats } from '../../lib/project';
import { formatDate } from '../../lib/id';
import { isPortableProjectFile, readPortableProject } from '../../lib/portableProject';
import { Button, IconButton } from '../ui/Button';
import { Field, NumberInput, TextInput } from '../ui/Field';

export function Welcome() {
  const projects = useWorkspaceStore((state) => state.projects);
  const createNewProject = useWorkspaceStore((state) => state.createNewProject);
  const loadDemo = useWorkspaceStore((state) => state.loadDemo);
  const openProject = useWorkspaceStore((state) => state.openProject);
  const duplicateProject = useWorkspaceStore((state) => state.duplicateProject);
  const deleteProject = useWorkspaceStore((state) => state.deleteProject);
  const importProjectFile = useWorkspaceStore((state) => state.importProjectFile);
  const importLegacyRaw = useWorkspaceStore((state) => state.importLegacyRaw);
  const setImportReport = useUiStore((state) => state.setImportReport);
  const askConfirm = useUiStore((state) => state.askConfirm);
  const pushToast = useUiStore((state) => state.pushToast);

  const [name, setName] = useState('');
  const [width, setWidth] = useState<number | null>(14);
  const [depth, setDepth] = useState<number | null>(9);
  const [legacy, setLegacy] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const { legacyRaw } = loadWorkspace();
    setLegacy(legacyRaw || null);
  }, []);

  const submit = () => {
    const projectName = name.trim() || 'New project';
    createNewProject(projectName, width || 14, depth || 9);
    pushToast('Project created', 'success');
  };

  const onImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const portable = await isPortableProjectFile(file);
      const text = portable ? JSON.stringify((await readPortableProject(file)).project) : await file.text();
      const result = importProjectFile(text, file.name.replace(/\.(json|remorph|zip)$/i, ''), portable);
      setImportReport({
        title: 'Import project',
        warnings: result.warnings,
        projectName: result.project.name,
        objects: result.project.objects.length,
        connections: result.project.connections.length,
        legacy: !portable && /nodes/.test(text) && !/schemaVersion"\s*:\s*5/.test(text),
      });
      pushToast('Project imported', 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Could not read project', 'error');
    }
  };

  const onLegacy = () => {
    if (!legacy) return;
    try {
      const result = importLegacyRaw(legacy);
      setImportReport({
        title: 'Older Rig Grid project',
        warnings: result.warnings,
        projectName: result.project.name,
        objects: result.project.objects.length,
        connections: result.project.connections.length,
        legacy: true,
      });
      pushToast('Older project migrated', 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'Could not migrate project', 'error');
    }
  };

  return (
    <div className="welcome">
      <header className="welcome-top">
        <div className="brand">
          <span className="brand-mark">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
              <path d="M3 3h18v18H3zM9 3v18M15 3v18M3 9h18M3 15h18" />
            </svg>
          </span>
          <span className="brand-word">RE<span>:</span>GRID</span>
        </div>
        <div className="welcome-top-meta">
          <span>3D scene workspace</span>
        </div>
      </header>

      <main className="welcome-main">
        <section className="welcome-intro">
          <p className="welcome-eyebrow">3D models · Lighting · Real-time preview</p>
          <h1>Build and light your 3D scene</h1>
          <p className="welcome-lead">Import models, arrange objects and shape the lighting in real time.</p>
          <div className="welcome-actions">
            <Button type="button" icon={<ArrowRight />} onClick={loadDemo}>Explore demo</Button>
            <Button type="button" variant="ghost" icon={<Upload />} onClick={() => fileRef.current?.click()}>Import project</Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept=".json,.remorph,.zip,application/json,application/zip"
            hidden
            onChange={(event) => { void onImport(event.target.files?.[0]); event.target.value = ''; }}
          />
        </section>

        <section className="welcome-grid">
          <div className="welcome-library">
            <div className="welcome-library-head">
              <div>
                <h2>Projects</h2>
                <p>{projects.length ? `${projects.length} saved in this browser` : 'Create a project or explore the demo.'}</p>
              </div>
            </div>

            {projects.length ? (
              <div className="welcome-projects">
                {projects.map((project) => {
                  const stats = projectStats(project);
                  return (
                    <div className="welcome-project" key={project.id}>
                      <button type="button" className="welcome-project-main" onClick={() => openProject(project.id)}>
                        <span className="welcome-project-icon"><Grid3X3 /></span>
                        <span className="welcome-project-copy">
                          <span className="welcome-project-name">{project.name}</span>
                          <span className="welcome-project-meta">
                            <span className="inline"><Clock3 />{formatDate(project.updatedAt)}</span>
                            <span className="inline"><Boxes />{stats.devices} fixtures</span>
                            <span className="inline"><Boxes />{stats.models + stats.lights} scene objects</span>
                          </span>
                        </span>
                        <ArrowRight className="welcome-project-arrow" />
                      </button>
                      <div className="welcome-project-actions">
                        <IconButton label="Duplicate project" size="sm" onClick={() => duplicateProject(project.id)}>
                          <Copy />
                        </IconButton>
                        <IconButton
                          label="Delete project"
                          size="sm"
                          onClick={() => askConfirm({
                            title: 'Delete project?',
                            message: `"${project.name}" will be removed from this browser. This cannot be undone.`,
                            confirmLabel: 'Delete',
                            danger: true,
                            onConfirm: () => deleteProject(project.id),
                          })}
                        >
                          <Trash2 />
                        </IconButton>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : null}

            <div className="welcome-library-foot">
              {legacy ? (
                <div className="legacy-banner">
                  <div>
                    <strong>Older Rig Grid project found</strong>
                    <span>Its browser data can be migrated with recalculated coordinates.</span>
                  </div>
                  <Button size="sm" onClick={onLegacy}>Migrate</Button>
                </div>
              ) : (
                <div className="welcome-note">
                  <span>Projects are saved in this browser. Export JSON to keep a backup.</span>
                </div>
              )}
            </div>
          </div>

          <aside className="welcome-create">
            <figure className="welcome-demo-preview"><img src="/assets/demo-preview.jpg" alt="Demo 3D scene preview" /><figcaption>Visual scene · real-time 3D preview</figcaption></figure>
            <form className="welcome-create-body" onSubmit={(event) => { event.preventDefault(); submit(); }}>
              <div className="welcome-create-head">
                <h2>Create project</h2>
                <p>Start empty, then import a model or add a light.</p>
              </div>
              <Field label="Project name">
                <TextInput value={name} onChange={setName} placeholder="e.g. Club Platform" ariaLabel="Project name" autoFocus maxLength={120} />
              </Field>
              <Button type="submit" variant="primary" block icon={<Plus />}>Create project</Button>
            </form>
          </aside>
        </section>
      </main>
    </div>
  );
}
