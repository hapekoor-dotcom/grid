import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cx } from '../../lib/cx';

type ButtonVariant = 'default' | 'primary' | 'accent' | 'ghost' | 'danger';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: 'sm' | 'md';
  block?: boolean;
  icon?: ReactNode;
}

export function Button({ variant = 'default', size = 'md', block, icon, className, children, ...props }: ButtonProps) {
  return (
    <button
      type="button"
      className={cx(
        'btn',
        variant !== 'default' && `btn--${variant}`,
        size === 'sm' && 'btn--sm',
        block && 'btn--block',
        className,
      )}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
}

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  active?: boolean;
  size?: 'sm' | 'md';
  children: ReactNode;
}

export function IconButton({ label, active, size = 'md', className, children, ...props }: IconButtonProps) {
  return (
    <button
      type="button"
      className={cx('icon-btn', size === 'sm' && 'icon-btn--sm', active && 'icon-btn--active', className)}
      aria-label={label}
      title={label}
      {...props}
    >
      {children}
    </button>
  );
}
