import { useEffect, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';

export interface MenuItem {
  id: string;
  label?: string;
  icon?: ReactNode;
  shortcut?: string;
  danger?: boolean;
  disabled?: boolean;
  separator?: boolean;
  heading?: string;
  onSelect?: () => void;
}

interface ContextMenuProps {
  x: number;
  y: number;
  items: MenuItem[];
  onClose: () => void;
}

export function ContextMenu({ x, y, items, onClose }: ContextMenuProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onPointerDown = (event: PointerEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) onClose();
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopImmediatePropagation();
        onClose();
      }
    };
    window.addEventListener('pointerdown', onPointerDown, true);
    window.addEventListener('keydown', onKeyDown, true);
    return () => {
      window.removeEventListener('pointerdown', onPointerDown, true);
      window.removeEventListener('keydown', onKeyDown, true);
    };
  }, [onClose]);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const rect = element.getBoundingClientRect();
    if (rect.right > window.innerWidth - 8) element.style.left = `${Math.max(8, x - rect.width)}px`;
    if (rect.bottom > window.innerHeight - 8) element.style.top = `${Math.max(8, y - rect.height)}px`;
  }, [x, y]);

  return createPortal(
    <div ref={ref} className="menu context-menu" role="menu" style={{ position: 'fixed', left: x, top: y }} onContextMenu={(event) => event.preventDefault()}>
      {items.map((item) => item.separator ? (
        <div key={item.id} className="menu-sep" />
      ) : item.heading ? (
        <div key={item.id} className="menu-label">{item.heading}</div>
      ) : (
        <button
          key={item.id}
          type="button"
          role="menuitem"
          className="menu-item"
          data-danger={item.danger || undefined}
          disabled={item.disabled}
          onClick={() => { item.onSelect?.(); onClose(); }}
        >
          {item.icon}
          <span>{item.label}</span>
          {item.shortcut && <span className="shortcut kbd">{item.shortcut}</span>}
        </button>
      ))}
    </div>,
    document.body,
  );
}
