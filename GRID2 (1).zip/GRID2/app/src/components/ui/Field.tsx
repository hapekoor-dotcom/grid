import { useEffect, useId, useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import { cx } from '../../lib/cx';
import { useWorkspaceStore } from '../../store/workspaceStore';

interface FieldProps {
  label?: ReactNode;
  hint?: ReactNode;
  htmlFor?: string;
  children: ReactNode;
  className?: string;
}

export function Field({ label, hint, htmlFor, children, className }: FieldProps) {
  return (
    <div className={cx('field', className)}>
      {label && <label className="field-label" htmlFor={htmlFor}>{label}</label>}
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </div>
  );
}

interface TextInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  ariaLabel?: string;
  id?: string;
  mono?: boolean;
  autoFocus?: boolean;
  maxLength?: number;
  onKeyDown?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
  className?: string;
}

export function TextInput({ value, onChange, placeholder, ariaLabel, id, mono, autoFocus, maxLength, onKeyDown, className }: TextInputProps) {
  return (
    <input
      id={id}
      className={cx('input', mono && 'input--mono', className)}
      value={value}
      placeholder={placeholder}
      aria-label={ariaLabel}
      autoFocus={autoFocus}
      maxLength={maxLength}
      onKeyDown={onKeyDown}
      onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
    />
  );
}

interface NumberInputProps {
  value: number | null;
  onChange: (value: number | null) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  ariaLabel?: string;
  id?: string;
  placeholder?: string;
  allowEmpty?: boolean;
  className?: string;
}

export function NumberInput({ value, onChange, min, max, step = 1, suffix, ariaLabel, id, placeholder, allowEmpty = true, className }: NumberInputProps) {
  const [draft, setDraft] = useState(value === null ? '' : String(value));
  const focused = useRef(false);
  const committed = useRef(value);
  const startValue = useRef(value);
  const reverting = useRef(false);

  useEffect(() => {
    committed.current = value;
    if (!focused.current) setDraft(value === null ? '' : String(value));
  }, [value]);

  const normalized = (raw: string): number | null => {
    const parsed = Number(raw.replace(',', '.'));
    if (!Number.isFinite(parsed)) return null;
    let next = parsed;
    if (min !== undefined) next = Math.max(min, next);
    if (max !== undefined) next = Math.min(max, next);
    return Number((Math.round(next / step) * step).toFixed(4));
  };
  const commit = () => {
    focused.current = false;
    if (reverting.current) {
      reverting.current = false;
      setDraft(startValue.current === null ? '' : String(startValue.current));
      return;
    }
    if (draft.trim() === '' && allowEmpty) {
      onChange(null);
      useWorkspaceStore.getState().endTransaction();
      return;
    }
    const next = normalized(draft);
    if (next === null) {
      setDraft(value === null ? '' : String(value));
      useWorkspaceStore.getState().cancelTransaction();
      return;
    }
    if (next !== committed.current) {
      committed.current = next;
      onChange(next);
    }
    setDraft(String(next));
    useWorkspaceStore.getState().endTransaction();
  };

  return (
    <div className={cx('input-group', className)}>
      <input
        id={id}
        className="input input--mono"
        inputMode="decimal"
        value={draft}
        aria-label={ariaLabel}
        placeholder={placeholder}
        onFocus={() => { focused.current = true; startValue.current = value; useWorkspaceStore.getState().beginTransaction(); }}
        onChange={(event) => {
          const raw = event.target.value;
          setDraft(raw);
          const next = normalized(raw);
          if (next !== null && next !== committed.current) {
            committed.current = next;
            onChange(next);
          }
        }}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            event.preventDefault();
            const current = Number(draft.replace(',', '.'));
            const base = Number.isFinite(current) ? current : (value ?? 0);
            let next = base + (event.key === 'ArrowUp' ? step : -step);
            if (min !== undefined) next = Math.max(min, next);
            if (max !== undefined) next = Math.min(max, next);
            next = Number((Math.round(next / step) * step).toFixed(4));
            setDraft(String(next));
            committed.current = next;
            onChange(next);
            return;
          }
          if (event.key === 'Enter') {
            commit();
            (event.target as HTMLInputElement).blur();
          }
          if (event.key === 'Escape') {
            focused.current = false;
            reverting.current = true;
            committed.current = startValue.current;
            useWorkspaceStore.getState().cancelTransaction();
            setDraft(startValue.current === null ? '' : String(startValue.current));
            (event.target as HTMLInputElement).blur();
          }
        }}
      />
      {suffix && <span className="input-unit">{suffix}</span>}
    </div>
  );
}

interface SelectProps {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string; disabled?: boolean }[];
  ariaLabel?: string;
  id?: string;
  className?: string;
}

export function Select({ value, onChange, options, ariaLabel, id, className }: SelectProps) {
  return (
    <select
      id={id}
      className={cx('select', className)}
      value={value}
      aria-label={ariaLabel}
      onChange={(event) => onChange(event.target.value)}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value} disabled={option.disabled}>{option.label}</option>
      ))}
    </select>
  );
}

interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: ReactNode;
  ariaLabel?: string;
}

export function Toggle({ checked, onChange, label, ariaLabel }: ToggleProps) {
  return (
    <label className="switch-row">
      {label && <span className="field-label" style={{ color: 'var(--text-2)' }}>{label}</span>}
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={ariaLabel || (typeof label === 'string' ? label : 'Toggle')}
        className="switch"
        onClick={() => onChange(!checked)}
      />
    </label>
  );
}

interface SliderProps {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  ariaLabel: string;
  disabled?: boolean;
}

export function Slider({ value, min, max, step = 1, onChange, ariaLabel, disabled }: SliderProps) {
  const percent = max === min ? 0 : ((value - min) / (max - min)) * 100;
  return (
    <input
      className="slider"
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      aria-label={ariaLabel}
      disabled={disabled}
      style={{ ['--value' as string]: `${percent}%` } as React.CSSProperties}
      onChange={(event) => onChange(Number(event.target.value))}
    />
  );
}

interface SegmentedProps<T extends string> {
  value: T;
  onChange: (value: T) => void;
  options: { value: T; label: ReactNode; title?: string }[];
  ariaLabel?: string;
  className?: string;
}

export function Segmented<T extends string>({ value, onChange, options, ariaLabel, className }: SegmentedProps<T>) {
  return (
    <div className={cx('segmented', className)} role="tablist" aria-label={ariaLabel}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          role="tab"
          aria-selected={value === option.value}
          title={option.title}
          className="segmented-item"
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function useUniqueId(prefix: string): string {
  const id = useId();
  return `${prefix}-${id.replace(/:/g, '')}`;
}
