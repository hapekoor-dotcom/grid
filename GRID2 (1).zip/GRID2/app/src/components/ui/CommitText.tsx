import { useEffect, useRef, useState } from 'react';

interface CommitTextProps {
  value: string;
  onCommit: (value: string) => void;
  placeholder?: string;
  ariaLabel?: string;
  maxLength?: number;
  className?: string;
  multiline?: boolean;
}

export function CommitText({ value, onCommit, placeholder, ariaLabel, maxLength, className, multiline }: CommitTextProps) {
  const [draft, setDraft] = useState(value);
  const focused = useRef(false);

  useEffect(() => {
    if (!focused.current) setDraft(value);
  }, [value]);

  const commit = () => {
    focused.current = false;
    if (draft !== value) onCommit(draft);
  };

  if (multiline) {
    return (
      <textarea
        className={`textarea ${className || ''}`}
        value={draft}
        placeholder={placeholder}
        aria-label={ariaLabel}
        maxLength={maxLength}
        onFocus={() => { focused.current = true; }}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Escape') {
            focused.current = false;
            setDraft(value);
            (event.target as HTMLTextAreaElement).blur();
          }
        }}
      />
    );
  }

  return (
    <input
      className={`input ${className || ''}`}
      value={draft}
      placeholder={placeholder}
      aria-label={ariaLabel}
      maxLength={maxLength}
      onFocus={() => { focused.current = true; }}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={commit}
      onKeyDown={(event) => {
        if (event.key === 'Enter') {
          commit();
          (event.target as HTMLInputElement).blur();
        }
        if (event.key === 'Escape') {
          focused.current = false;
          setDraft(value);
          (event.target as HTMLInputElement).blur();
        }
      }}
    />
  );
}
