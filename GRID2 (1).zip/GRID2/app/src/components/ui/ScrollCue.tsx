import { useEffect, useState, type RefObject } from 'react';
import { ChevronDown } from 'lucide-react';

/**
 * A visible affordance for panels whose scrollbar is an overlay.
 * It disappears at the bottom and never adds a permanent control.
 */
export function ScrollCue({ containerRef, bottom = 8 }: { containerRef: RefObject<HTMLElement | null>; bottom?: number }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let scroller: HTMLElement | null = null;
    let frame = 0;

    const update = () => {
      frame = 0;
      if (!scroller) return;
      setVisible(scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight > 6);
    };
    const schedule = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };
    const observer = new ResizeObserver(schedule);
    observer.observe(container);

    const bind = () => {
      const next = container.querySelector<HTMLElement>('.panel-body');
      if (next === scroller) return;
      scroller?.removeEventListener('scroll', schedule);
      scroller = next;
      if (!scroller) return;
      scroller.addEventListener('scroll', schedule, { passive: true });
      observer.observe(scroller);
      schedule();
    };

    bind();
    const mutation = new MutationObserver(() => {
      bind();
      schedule();
    });
    mutation.observe(container, { childList: true, subtree: true });
    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      observer.disconnect();
      mutation.disconnect();
      scroller?.removeEventListener('scroll', schedule);
    };
  }, [containerRef]);

  if (!visible) return null;

  return (
    <button
      type="button"
      className="scroll-cue"
      style={{ bottom }}
      aria-label="Scroll panel down"
      title="Scroll down"
      onClick={() => {
        const scroller = containerRef.current?.querySelector<HTMLElement>('.panel-body');
        scroller?.scrollBy({ top: Math.max(80, scroller.clientHeight * 0.75), behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
      }}
    >
      <ChevronDown />
    </button>
  );
}
