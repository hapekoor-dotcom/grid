import { NumberInput, Slider } from './Field';
import { clampOverdrive, overdrivePercent, overdriveToSlider, sliderToOverdrive } from '../../lib/overdrive';

export function OverdriveControl({
  value,
  onChange,
  ariaLabel,
  onInteractionStart,
  onInteractionEnd,
  disabled = false,
}: {
  value: number;
  onChange: (value: number) => void;
  ariaLabel: string;
  onInteractionStart?: () => void;
  onInteractionEnd?: () => void;
  disabled?: boolean;
}) {
  const percent = overdrivePercent(value);
  return (
    <div className="overdrive-control" data-overdrive>
      <div className="overdrive-head">
        <div className="overdrive-head-actions">
          <NumberInput value={percent} min={0} max={10000} step={1} suffix="%" ariaLabel={`${ariaLabel} percent`} onChange={(next) => onChange(clampOverdrive((next ?? 100) / 100))} />
          <button type="button" className="overdrive-reset" onClick={() => onChange(1)} title="Reset to 100%" aria-label={`Reset ${ariaLabel} to 100%`}>Reset</button>
        </div>
      </div>
      <div onPointerDown={onInteractionStart} onPointerUp={onInteractionEnd} onPointerCancel={onInteractionEnd} onKeyDown={onInteractionStart} onKeyUp={onInteractionEnd}>
        <Slider
          value={overdriveToSlider(value) * 100}
          min={0}
          max={100}
          step={0.1}
          ariaLabel={ariaLabel}
          disabled={disabled}
          onChange={(next) => onChange(clampOverdrive(sliderToOverdrive(next / 100)))}
        />
      </div>
      <div className="overdrive-scale"><span style={{ left: '0%' }}>0%</span><span style={{ left: '60%' }}>100%</span><span style={{ left: '72.5%' }}>500%</span><span style={{ left: '85%' }}>1000%</span><span style={{ left: '100%' }}>10000%</span></div>
    </div>
  );
}
