import { AlertTriangle, Check, Info, X } from 'lucide-react';
import { useUiStore } from '../../store/uiStore';
import { cx } from '../../lib/cx';

export function Toasts() {
  const toasts = useUiStore((state) => state.toasts);
  const dismiss = useUiStore((state) => state.dismissToast);
  if (!toasts.length) return null;
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((toast) => (
        <div key={toast.id} className={cx('toast', toast.tone !== 'default' && `toast--${toast.tone}`)}>
          {toast.tone === 'success' ? <Check /> : toast.tone === 'error' || toast.tone === 'warning' ? <AlertTriangle /> : <Info />}
          <span style={{ flex: 1 }}>{toast.message}</span>
          <button type="button" className="icon-btn icon-btn--sm" aria-label="Dismiss" onClick={() => dismiss(toast.id)}><X /></button>
        </div>
      ))}
    </div>
  );
}
