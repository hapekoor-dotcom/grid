import { useEffect, useRef } from 'react';
import type { RefObject } from 'react';
import type { Project, SceneModifier } from '../../types/project';
import { applyTimelineToProject, sampleTimeline } from '../../lib/timeline';
import { getTimelineTime } from '../../lib/timelineClock';
import { modifierDefinition } from '../../lib/modifiers';
import { modulatedParams } from '../../lib/signals';

const POST_TYPES = new Set(['feedback', 'rgbSplit', 'kaleidoscopePost', 'pixelatePost', 'scanlinesPost', 'uvDistortPost']);

function canvas(width: number, height: number): HTMLCanvasElement {
  const element = document.createElement('canvas');
  element.width = width;
  element.height = height;
  return element;
}

export function FeedbackOverlay({ sourceRef, effects, project }: { sourceRef: RefObject<HTMLCanvasElement | null>; effects: SceneModifier[]; project?: Project | null }) {
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const effectCanvases = useRef<{ source: HTMLCanvasElement | null; temp: HTMLCanvasElement | null }>({ source: null, temp: null });
  const effectsRef = useRef(effects);
  effectsRef.current = effects;
  const projectRef = useRef(project);
  projectRef.current = project;
  const activeTypes = effects.filter((entry) => entry.enabled && POST_TYPES.has(entry.type)).map((entry) => entry.type);
  const activeKey = activeTypes.join('|');

  useEffect(() => {
    const overlay = overlayRef.current;
    if (!overlay) return;
    const context = overlay.getContext('2d');
    if (!context) return;
    if (!activeKey) {
      context.clearRect(0, 0, overlay.width, overlay.height);
      return;
    }
    let frame = 0;
    let timelineTick = 0;
    let timelineEffects: SceneModifier[] | null = null;
    const render = () => {
      frame = requestAnimationFrame(render);
      const source = sourceRef.current;
      if (!source) return;
      const width = source.clientWidth;
      const height = source.clientHeight;
      if (width < 2 || height < 2) return;
      if (overlay.width !== width || overlay.height !== height) {
        overlay.width = width; overlay.height = height;
      }
      if (!effectCanvases.current.source || effectCanvases.current.source.width !== width) {
        effectCanvases.current.source = canvas(width, height);
        effectCanvases.current.temp = canvas(width, height);
      }
      const frameCanvas = effectCanvases.current.source!;
      const temp = effectCanvases.current.temp!;
      const frameContext = frameCanvas.getContext('2d');
      const tempContext = temp.getContext('2d');
      if (!frameContext || !tempContext) return;
      frameContext.clearRect(0, 0, width, height);
      try { frameContext.drawImage(source, 0, 0, width, height); } catch { return; }

      const currentProject = projectRef.current;
      const hasEffectAnimation = !!currentProject?.timeline?.tracks?.some((track) => track.propertyPath.startsWith('effect.'));
      if (!hasEffectAnimation) timelineEffects = null;
      else if (currentProject && (timelineTick++ % 3 === 0)) {
        const overrides = sampleTimeline(currentProject, getTimelineTime());
        timelineEffects = applyTimelineToProject(currentProject, overrides).effects || null;
      }
      const enabled = (timelineEffects || effectsRef.current).filter((entry) => entry.enabled && POST_TYPES.has(entry.type));
      const get = (type: string) => enabled.find((entry) => entry.type === type);
      const paramsOf = (modifier: SceneModifier | undefined, type: string) => ({ ...modifierDefinition(type).defaults, ...(modifier ? modulatedParams(modifier, projectRef.current || null, getTimelineTime(), null) : {}) });

      // Pixelate is a spatial resample before the rest of the post stack.
      const pixelate = get('pixelatePost');
      if (pixelate) {
        const params = paramsOf(pixelate, 'pixelatePost');
        const size = Math.max(1, Math.round(Number(params.size ?? 8)));
        temp.width = Math.max(1, Math.ceil(width / size));
        temp.height = Math.max(1, Math.ceil(height / size));
        tempContext.imageSmoothingEnabled = false;
        tempContext.drawImage(frameCanvas, 0, 0, temp.width, temp.height);
        frameContext.imageSmoothingEnabled = false;
        frameContext.drawImage(temp, 0, 0, width, height);
        frameContext.imageSmoothingEnabled = true;
        temp.width = width; temp.height = height;
      }

      const kaleidoscope = get('kaleidoscopePost');
      if (kaleidoscope) {
        const params = paramsOf(kaleidoscope, 'kaleidoscopePost');
        const segments = Math.max(2, Math.round(Number(params.segments ?? 6)));
        const rotation = Number(params.rotation ?? 0) * Math.PI / 180;
        const zoom = Math.max(0.1, Number(params.zoom ?? 1));
        const cx = Number(params.centerX ?? 0.5) * width;
        const cy = Number(params.centerY ?? 0.5) * height;
        const slice = canvas(width, height);
        const sliceContext = slice.getContext('2d');
        if (sliceContext) {
          sliceContext.drawImage(frameCanvas, 0, 0);
          frameContext.clearRect(0, 0, width, height);
          for (let index = 0; index < segments; index += 1) {
            frameContext.save();
            frameContext.translate(cx, cy);
            frameContext.rotate(rotation + (index / segments) * Math.PI * 2);
            frameContext.beginPath();
            frameContext.moveTo(0, 0);
            frameContext.arc(0, 0, Math.max(width, height) * 1.5, 0, Math.PI * 2 / segments);
            frameContext.closePath();
            frameContext.clip();
            frameContext.scale(index % 2 === 0 ? zoom : -zoom, zoom);
            frameContext.translate(-cx, -cy);
            frameContext.drawImage(slice, 0, 0);
            frameContext.restore();
          }
        }
      }

      const uvDistort = get('uvDistortPost');
      if (uvDistort) {
        const params = paramsOf(uvDistort, 'uvDistortPost');
        const strength = Number(params.strength ?? 0);
        const scale = Math.max(0.5, Number(params.scale ?? 6));
        const speed = Number(params.speed ?? 0);
        const mix = Math.max(0, Math.min(1, Number(params.mix ?? 1)));
        tempContext.clearRect(0, 0, width, height);
        tempContext.drawImage(frameCanvas, 0, 0);
        frameContext.clearRect(0, 0, width, height);
        const time = performance.now() / 1000;
        for (let x = 0; x < width; x += 3) {
          const offset = Math.sin((x / width) * scale * Math.PI * 2 + time * speed * Math.PI * 2) * strength;
          frameContext.globalAlpha = mix;
          frameContext.drawImage(temp, x, 0, 3, height, x, offset, 3, height);
        }
        frameContext.globalAlpha = 1;
      }

      const split = get('rgbSplit');
      if (split) {
        const params = paramsOf(split, 'rgbSplit');
        const amount = Number(params.amount ?? 0);
        const angle = Number(params.angle ?? 0) * Math.PI / 180;
        const mix = Math.max(0, Math.min(1, Number(params.mix ?? 0.75)));
        const dx = Math.cos(angle) * amount;
        const dy = Math.sin(angle) * amount;
        tempContext.clearRect(0, 0, width, height);
        tempContext.drawImage(frameCanvas, 0, 0);
        frameContext.clearRect(0, 0, width, height);
        frameContext.globalCompositeOperation = 'lighter';
        frameContext.globalAlpha = mix;
        frameContext.drawImage(temp, -dx, -dy);
        frameContext.globalAlpha = mix * 0.65;
        frameContext.drawImage(temp, dx, dy);
        frameContext.globalCompositeOperation = 'source-over';
        frameContext.globalAlpha = 1;
      }

      const feedback = get('feedback');
      if (feedback) {
        const params = paramsOf(feedback, 'feedback');
        const persistence = Math.max(0, Math.min(0.99, Number(params.persistence ?? 0.72)));
        const intensity = Math.max(0, Math.min(1, Number(params.intensity ?? 0.45)));
        const softness = Math.max(0, Math.min(24, Number(params.softness ?? 1)));
        const ghost = params.ghost === true;
        context.globalCompositeOperation = 'destination-out';
        context.globalAlpha = 1;
        context.fillStyle = `rgba(0,0,0,${Math.max(0.01, 1 - persistence)})`;
        context.fillRect(0, 0, width, height);
        context.globalCompositeOperation = 'source-over';
        context.globalAlpha = ghost ? intensity * 0.55 : intensity;
        context.filter = softness > 0.01 ? `blur(${softness}px)` : 'none';
        context.drawImage(frameCanvas, 0, 0, width, height);
        context.filter = 'none';
        context.globalAlpha = 1;
      } else {
        context.clearRect(0, 0, width, height);
        context.drawImage(frameCanvas, 0, 0);
      }

      const scan = get('scanlinesPost');
      if (scan) {
        const params = paramsOf(scan, 'scanlinesPost');
        const density = Math.max(4, Number(params.density ?? 320));
        const opacity = Math.max(0, Math.min(1, Number(params.opacity ?? 0.18)));
        const offset = (performance.now() / 1000) * Number(params.speed ?? 0.2) * 30;
        context.globalCompositeOperation = 'source-over';
        context.globalAlpha = 1;
        context.fillStyle = `rgba(0,0,0,${opacity})`;
        for (let y = -24 + (offset % 4); y < height; y += Math.max(2, height / density) * 4) context.fillRect(0, y, width, 1);
        const glitch = Math.max(0, Math.min(1, Number(params.glitch ?? 0.05)));
        if (glitch > 0.001) {
          context.globalCompositeOperation = 'lighter';
          context.globalAlpha = glitch * 0.16;
          context.fillStyle = '#6be8ff';
          context.fillRect(0, (performance.now() * 0.05) % height, width, 1.5);
          context.globalAlpha = 1;
        }
      }
      context.globalCompositeOperation = 'source-over';
      context.globalAlpha = 1;
    };
    frame = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(frame);
      context.clearRect(0, 0, overlay.width, overlay.height);
    };
  }, [sourceRef, activeKey]);

  return <canvas ref={overlayRef} className="viewport-feedback" aria-hidden="true" />;
}
