import * as pc from 'playcanvas';

export interface CookieSet {
  spot: pc.Texture;
  bar: pc.Texture;
}

interface IesProfile {
  angles: number[];
  candela: number[];
  peak: number;
}

/** Minimal IESNA reader for the supplied rotationally symmetric profiles. */
function parseIes(text: string): IesProfile {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const tilt = lines.findIndex((line) => line.startsWith('TILT='));
  if (tilt < 0) throw new Error('IES: TILT not found');
  const counts = lines[tilt + 1].split(/\s+/).map(Number);
  const vertical = counts[3] || 0;
  const horizontal = counts[4] || 1;
  let index = tilt + 3;
  const angles: number[] = [];
  while (angles.length < vertical && index < lines.length) {
    lines[index].split(/\s+/).forEach((value) => angles.push(Number(value)));
    index++;
  }
  // The next line is the horizontal-angle list; both supplied files use one.
  index++;
  const candela: number[] = [];
  while (candela.length < vertical * horizontal && index < lines.length) {
    lines[index].split(/\s+/).forEach((value) => candela.push(Number(value)));
    index++;
  }
  return { angles, candela, peak: Math.max(1, ...candela) };
}

function sample(profile: IesProfile, angleRad: number): number {
  const degrees = Math.min(180, Math.max(0, (angleRad * 180) / Math.PI));
  let index = 0;
  while (index < profile.angles.length - 2 && profile.angles[index + 1] < degrees) index++;
  const a = profile.angles[index] ?? 0;
  const b = profile.angles[index + 1] ?? 180;
  const t = b === a ? 0 : (degrees - a) / (b - a);
  const value = (profile.candela[index] ?? 0) * (1 - t) + (profile.candela[index + 1] ?? 0) * t;
  return Math.max(0, value / profile.peak);
}

function makeCookie(device: pc.GraphicsDevice, profile: IesProfile, size = 256): pc.Texture {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('cookie canvas unavailable');
  const image = context.createImageData(size, size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = ((x + 0.5) / size) * 2 - 1;
      const ny = ((y + 0.5) / size) * 2 - 1;
      const radius = Math.hypot(nx, ny);
      let value = 0;
      if (radius < 1) {
        const angle = Math.min(Math.PI / 2, radius * (Math.PI / 2));
        const border = Math.min(1, Math.max(0, (1 - radius) / 0.06));
        value = sample(profile, angle) * border * border * (3 - 2 * border);
      }
      const offset = (y * size + x) * 4;
      const byte = Math.round(value * 255);
      image.data[offset] = byte;
      image.data[offset + 1] = byte;
      image.data[offset + 2] = byte;
      image.data[offset + 3] = 255;
    }
  }
  context.putImageData(image, 0, 0);
  const texture = new pc.Texture(device, {
    width: size,
    height: size,
    format: pc.PIXELFORMAT_RGBA8,
    mipmaps: false,
    minFilter: pc.FILTER_LINEAR,
    magFilter: pc.FILTER_LINEAR,
    addressU: pc.ADDRESS_CLAMP_TO_EDGE,
    addressV: pc.ADDRESS_CLAMP_TO_EDGE,
  });
  texture.setSource(canvas);
  return texture;
}

export async function loadIesCookies(device: pc.GraphicsDevice): Promise<CookieSet> {
  const [spotText, barText] = await Promise.all([
    fetch('/assets/ies/spot.ies').then((response) => response.text()),
    fetch('/assets/ies/bar.ies').then((response) => response.text()),
  ]);
  const spotProfile = parseIes(spotText);
  const barProfile = parseIes(barText);
  return {
    spot: makeCookie(device, spotProfile),
    bar: makeCookie(device, barProfile),
  };
}
