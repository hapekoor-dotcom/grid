import { useMemo, useRef } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, RepeatWrapping, SRGBColorSpace, type Mesh as ThreeMesh } from 'three';
import { useTexture } from '@react-three/drei';
import type { Project, SceneObject } from '../../types/project';
import { objectDims } from '../../lib/objects';

interface StructureProps {
  object: SceneObject;
  project: Project;
  selected: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
}

function useClick(object: SceneObject, onSelect: (id: string) => void, onHover: (id: string | null) => void) {
  return {
    onClick: (event: ThreeEvent<MouseEvent>) => { event.stopPropagation(); onSelect(object.id); },
    onPointerOver: (event: ThreeEvent<PointerEvent>) => { event.stopPropagation(); onHover(object.id); document.body.style.cursor = 'pointer'; },
    onPointerOut: (event: ThreeEvent<PointerEvent>) => { event.stopPropagation(); onHover(null); document.body.style.cursor = ''; },
  };
}

function SelectionOutline({ w, h, d, y = 0 }: { w: number; h: number; d: number; y?: number }) {
  return (
    <mesh position={[0, y, 0]}>
      <boxGeometry args={[w + 0.04, h + 0.04, d + 0.04]} />
      <meshBasicMaterial color="#E8B40A" wireframe transparent opacity={0.35} />
    </mesh>
  );
}

export function RoomMesh({ object, project, selected, onSelect, onHover }: StructureProps) {
  const dims = objectDims(object);
  const height = object.room?.wallHeight || dims.h || 4.5;
  const width = dims.w;
  const depth = dims.d;
  const thickness = 0.18;
  const rotation = (-object.rotation * Math.PI) / 180;
  const [wallMap, wallNormal, wallRoughness, floorNormal, floorRoughness] = useTexture([
    '/assets/materials/wall-painted-1k/color.jpg',
    '/assets/materials/wall-painted-1k/normal.png',
    '/assets/materials/wall-painted-1k/roughness.png',
    '/assets/materials/concrete-clean-1k/normal.png',
    '/assets/materials/concrete-clean-1k/roughness.png',
  ]);
  const concreteMap = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    if (context) {
      context.fillStyle = '#bcb7ae';
      context.fillRect(0, 0, 512, 512);
      for (let index = 0; index < 90; index++) {
        const x = (index * 73.17) % 512;
        const y = (index * 149.31) % 512;
        const radius = 18 + (index % 7) * 12;
        const gradient = context.createRadialGradient(x, y, 0, x, y, radius);
        const dark = index % 3 === 0;
        gradient.addColorStop(0, dark ? 'rgba(52,48,43,0.1)' : 'rgba(235,232,224,0.08)');
        gradient.addColorStop(1, 'rgba(0,0,0,0)');
        context.fillStyle = gradient;
        context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
      }
      context.fillStyle = 'rgba(35, 32, 28, 0.06)';
      for (let x = 0; x < 512; x += 96) context.fillRect(x, 0, 1, 512);
      for (let y = 0; y < 512; y += 96) context.fillRect(0, y, 512, 1);
    }
    const texture = new CanvasTexture(canvas);
    texture.colorSpace = SRGBColorSpace;
    texture.wrapS = texture.wrapT = RepeatWrapping;
    texture.repeat.set(5, 4);
    return texture;
  }, []);
  useMemo(() => {
    wallMap.colorSpace = SRGBColorSpace;
    wallMap.wrapS = wallMap.wrapT = RepeatWrapping;
    wallMap.repeat.set(4, 2);
    for (const texture of [wallNormal, wallRoughness]) {
      texture.wrapS = texture.wrapT = RepeatWrapping;
      texture.repeat.set(4, 2);
    }
    for (const texture of [floorNormal, floorRoughness]) {
      texture.wrapS = texture.wrapT = RepeatWrapping;
      texture.repeat.set(5, 4);
    }
  }, [wallNormal, wallRoughness, floorNormal, floorRoughness]);

  const wallRefs = useRef<(ThreeMesh | null)[]>([]);
  const walls = [
    { position: [0, height / 2, -depth / 2] as [number, number, number], size: [width, height, thickness] as [number, number, number], normal: -1 },
    { position: [0, height / 2, depth / 2] as [number, number, number], size: [width, height, thickness] as [number, number, number], normal: 1 },
    { position: [-width / 2, height / 2, 0] as [number, number, number], size: [thickness, height, depth] as [number, number, number], normal: -2 },
    { position: [width / 2, height / 2, 0] as [number, number, number], size: [thickness, height, depth] as [number, number, number], normal: 2 },
  ];

  useFrame(({ camera }) => {
    const show = project.lighting.showWalls;
    const dx = camera.position.x - object.position.x;
    const dz = camera.position.z - object.position.z;
    const localX = dx * Math.cos(rotation) - dz * Math.sin(rotation);
    const localZ = dx * Math.sin(rotation) + dz * Math.cos(rotation);
    wallRefs.current.forEach((mesh, index) => {
      if (!mesh) return;
      const wall = walls[index];
      const near =
        (wall.normal === 1 && localZ > depth / 2 - 0.35)
        || (wall.normal === -1 && localZ < -depth / 2 + 0.35)
        || (wall.normal === 2 && localX > width / 2 - 0.35)
        || (wall.normal === -2 && localX < -width / 2 + 0.35);
      mesh.visible = show && !near;
    });
  });

  return (
    <group position={[object.position.x, 0, object.position.z]} rotation={[0, rotation, 0]}>
      <mesh position={[0, -0.03, 0]} receiveShadow>
        <boxGeometry args={[width, 0.06, depth]} />
        <meshPhysicalMaterial
          color={object.room?.floorColor || '#6f6b63'}
          map={concreteMap}
          normalMap={floorNormal}
          normalScale={[0.82, 0.82]}
          roughnessMap={floorRoughness}
          roughness={0.7}
          metalness={0.03}
          clearcoat={0.28}
          clearcoatRoughness={0.55}
          envMapIntensity={0.9}
        />
      </mesh>
      {walls.map((wall, index) => (
        <mesh
          key={index}
          ref={(mesh) => { wallRefs.current[index] = mesh; }}
          position={wall.position}
          castShadow
          receiveShadow
        >
          <boxGeometry args={wall.size} />
          <meshPhysicalMaterial
            color={object.room?.wallColor || '#74736d'}
            map={wallMap}
            normalMap={wallNormal}
            normalScale={[0.5, 0.5]}
            roughnessMap={wallRoughness}
            roughness={0.95}
            metalness={0.01}
            clearcoat={0}
            envMapIntensity={0.35}
          />
        </mesh>
      ))}
      {[-depth / 2, depth / 2].map((z) => (
        <mesh key={`base-z-${z}`} position={[0, 0.06, z]} receiveShadow>
          <boxGeometry args={[width, 0.12, 0.035]} />
          <meshStandardMaterial color="#272a2c" roughness={0.5} metalness={0.35} />
        </mesh>
      ))}
      {[-width / 2, width / 2].map((x) => (
        <mesh key={`base-x-${x}`} position={[x, 0.06, 0]} receiveShadow>
          <boxGeometry args={[0.035, 0.12, depth]} />
          <meshStandardMaterial color="#272a2c" roughness={0.5} metalness={0.35} />
        </mesh>
      ))}
      <gridHelper args={[Math.max(width, depth) * 1.2, Math.max(8, Math.round(Math.max(width, depth) * 2)), '#3b3a36', '#272724']} position={[0, 0.006, 0]} />
      {selected && <SelectionOutline w={width} h={height} d={depth} y={height / 2} />}
    </group>
  );
}

export function StageMesh({ object, selected, onSelect, onHover }: StructureProps) {
  const dims = objectDims(object);
  const height = dims.h || 0.45;
  const click = useClick(object, onSelect, onHover);
  return (
    <group position={[object.position.x, 0, object.position.z]} rotation={[0, (-object.rotation * Math.PI) / 180, 0]} {...click}>
      <mesh position={[0, height / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[dims.w, height, dims.d]} />
        <meshStandardMaterial color={object.stage?.color || '#363b3e'} roughness={0.78} metalness={0.05} />
      </mesh>
      <mesh position={[0, height + 0.007, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[dims.w - 0.02, dims.d - 0.02]} />
        <meshPhysicalMaterial color="#b1aba0" roughness={0.68} metalness={0.03} clearcoat={0.16} clearcoatRoughness={0.55} envMapIntensity={0.65} />
      </mesh>
      <mesh position={[0, height / 2, dims.d / 2 + 0.003]} receiveShadow>
        <planeGeometry args={[dims.w - 0.02, height]} />
        <meshStandardMaterial color="#3c4144" roughness={0.84} metalness={0.05} />
      </mesh>
      {Array.from({ length: Math.max(3, Math.round(dims.w / 0.55)) }, (_, index) => {
        const count = Math.max(3, Math.round(dims.w / 0.55));
        return (
          <mesh key={index} position={[-dims.w / 2 + (dims.w / count) * (index + 0.5), height / 2, dims.d / 2 + 0.01]}>
            <boxGeometry args={[0.025, height * 0.82, 0.012]} />
            <meshStandardMaterial color="#2a3239" roughness={0.65} metalness={0.25} />
          </mesh>
        );
      })}
      <mesh position={[0, height + 0.012, dims.d / 2 - 0.015]}>
        <boxGeometry args={[dims.w - 0.04, 0.012, 0.012]} />
        <meshStandardMaterial color="#E8B40A" emissive="#E8B40A" emissiveIntensity={0.5} toneMapped={false} />
      </mesh>
      {selected && <SelectionOutline w={dims.w} h={height} d={dims.d} y={height / 2} />}
    </group>
  );
}

export function TrussMesh({ object, selected, onSelect, onHover }: StructureProps) {
  const dims = objectDims(object);
  const click = useClick(object, onSelect, onHover);
  const vertical = dims.h > dims.w && dims.h > dims.d;
  const length = vertical ? dims.h : dims.w;
  const thickness = vertical ? Math.min(dims.w, dims.d) : Math.min(dims.d, dims.h);
  const size = Math.max(0.18, Math.min(0.36, thickness));
  const chords: [number, number][] = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  const segments = Math.max(2, Math.round(length / 0.5));
  const braces: { position: [number, number, number]; rotation: [number, number, number]; length: number }[] = [];
  for (let i = 0; i < segments; i++) {
    const a = -length / 2 + (length / segments) * i;
    const b = a + length / segments;
    const mid = (a + b) / 2;
    const len = Math.hypot(length / segments, size * 2);
    const angle = Math.atan2(size * 2, length / segments);
    if (vertical) {
      braces.push({ position: [0, mid, -size / 2], rotation: [0, 0, Math.PI / 2 - angle], length: len });
      braces.push({ position: [0, mid, size / 2], rotation: [0, 0, Math.PI / 2 - angle], length: len });
      braces.push({ position: [0, mid, 0], rotation: [angle, 0, 0], length: len });
    } else {
      braces.push({ position: [mid, -size / 2, 0], rotation: [0, 0, angle], length: len });
      braces.push({ position: [mid, size / 2, 0], rotation: [0, 0, angle], length: len });
      braces.push({ position: [mid, 0, size / 2], rotation: [0, angle, 0], length: len });
    }
  }
  const baseY = vertical ? dims.h / 2 : object.elevation;
  return (
    <group position={[object.position.x, baseY, object.position.z]} rotation={[0, (-object.rotation * Math.PI) / 180, 0]} {...click}>
      {chords.map(([a, b]) => (
        <mesh key={`${a}${b}`} position={vertical ? [a * size / 2, 0, b * size / 2] : [0, a * size / 2, b * size / 2]} castShadow>
          <boxGeometry args={vertical ? [0.032, length, 0.032] : [length, 0.032, 0.032]} />
          <meshPhysicalMaterial color="#c0c7cc" metalness={0.68} roughness={0.34} envMapIntensity={1.35} />
        </mesh>
      ))}
      {braces.map((brace, index) => (
        <mesh key={index} position={brace.position} rotation={brace.rotation}>
          <boxGeometry args={[brace.length, 0.015, 0.015]} />
          <meshPhysicalMaterial color="#b4bcc2" metalness={0.64} roughness={0.38} envMapIntensity={1.2} />
        </mesh>
      ))}
      {selected && <SelectionOutline w={vertical ? size + 0.06 : length} h={vertical ? length : size + 0.06} d={vertical ? size + 0.06 : size + 0.06} />}
    </group>
  );
}

function useCurtainTexture(color: string): CanvasTexture {
  return useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext('2d');
    if (context) {
      context.fillStyle = color;
      context.fillRect(0, 0, 256, 256);
      for (let x = 0; x < 256; x += 14) {
        const gradient = context.createLinearGradient(x, 0, x + 14, 0);
        gradient.addColorStop(0, 'rgba(0,0,0,0.38)');
        gradient.addColorStop(0.5, 'rgba(255,255,255,0.05)');
        gradient.addColorStop(1, 'rgba(0,0,0,0.3)');
        context.fillStyle = gradient;
        context.fillRect(x, 0, 14, 256);
      }
    }
    const texture = new CanvasTexture(canvas);
    texture.wrapS = 1000;
    texture.wrapT = 1000;
    return texture;
  }, [color]);
}

export function CurtainMesh({ object, selected, onSelect, onHover }: StructureProps) {
  const dims = objectDims(object);
  const texture = useCurtainTexture('#2b323a');
  texture.repeat.set(Math.max(1, dims.w / 1.4), 1);
  const click = useClick(object, onSelect, onHover);
  return (
    <group position={[object.position.x, dims.h / 2, object.position.z]} rotation={[0, (-object.rotation * Math.PI) / 180, 0]} {...click}>
      <mesh castShadow receiveShadow>
        <planeGeometry args={[dims.w, dims.h]} />
        <meshStandardMaterial map={texture} color="#7c858e" roughness={0.96} metalness={0.02} emissive="#0c1114" emissiveIntensity={0.4} side={DoubleSide} />
      </mesh>
      {selected && <SelectionOutline w={dims.w} h={dims.h} d={0.05} />}
    </group>
  );
}

export function FurnitureMesh({ object, selected, onSelect, onHover }: StructureProps) {
  const dims = objectDims(object);
  const kind = object.deviceId || '';
  const click = useClick(object, onSelect, onHover);
  return (
    <group position={[object.position.x, 0, object.position.z]} rotation={[0, (-object.rotation * Math.PI) / 180, 0]} {...click}>
      {kind.includes('table') ? (
        <>
          <mesh position={[0, dims.h, 0]} castShadow receiveShadow>
            <boxGeometry args={[dims.w, 0.05, dims.d]} />
            <meshStandardMaterial color="#343b42" roughness={0.6} metalness={0.2} />
          </mesh>
          {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([x, z]) => (
            <mesh key={`${x}${z}`} position={[x * (dims.w / 2 - 0.06), dims.h / 2, z * (dims.d / 2 - 0.06)]} castShadow>
              <boxGeometry args={[0.04, dims.h, 0.04]} />
              <meshStandardMaterial color="#20262b" metalness={0.6} roughness={0.4} />
            </mesh>
          ))}
        </>
      ) : kind.includes('chair') ? (
        <>
          <mesh position={[0, 0.45, 0]} castShadow>
            <boxGeometry args={[dims.w, 0.06, dims.d]} />
            <meshStandardMaterial color="#2b3239" roughness={0.7} />
          </mesh>
          <mesh position={[0, 0.8, -dims.d / 2 + 0.03]} castShadow>
            <boxGeometry args={[dims.w, 0.65, 0.04]} />
            <meshStandardMaterial color="#252b31" roughness={0.75} />
          </mesh>
          <mesh position={[0, 0.22, 0]}>
            <boxGeometry args={[0.06, 0.44, 0.06]} />
            <meshStandardMaterial color="#14181c" metalness={0.5} />
          </mesh>
        </>
      ) : kind.includes('barricade') ? (
        <>
          {[-1, 1].map((side) => (
            <mesh key={side} position={[side * (dims.w / 2 - 0.05), dims.h / 2, 0]} castShadow>
              <boxGeometry args={[0.04, dims.h, 0.04]} />
              <meshStandardMaterial color="#7d858c" metalness={0.7} roughness={0.4} />
            </mesh>
          ))}
          {[0.4, 0.9].map((y) => (
            <mesh key={y} position={[0, dims.h * y, 0]} castShadow>
              <boxGeometry args={[dims.w, 0.03, 0.03]} />
              <meshStandardMaterial color="#8a9299" metalness={0.7} roughness={0.38} />
            </mesh>
          ))}
        </>
      ) : (
        <mesh position={[0, dims.h / 2, 0]} castShadow receiveShadow>
          <boxGeometry args={[dims.w, dims.h, dims.d]} />
          <meshStandardMaterial color="#2a3138" roughness={0.75} />
        </mesh>
      )}
      {selected && <SelectionOutline w={dims.w} h={dims.h} d={dims.d} y={dims.h / 2} />}
    </group>
  );
}
