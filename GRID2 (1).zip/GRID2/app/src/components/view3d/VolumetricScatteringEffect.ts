import { BlendFunction, Effect, EffectAttribute } from 'postprocessing';
import { Color, Matrix4, Uniform, Vector2, Vector3 } from 'three';
import type { VolumeSet } from '../../lib/volumetrics';

const fragmentShader = /* glsl */ `
uniform mat4 uInvProjection;
uniform mat4 uCameraWorld;
uniform vec2 uResolution;
uniform float uTime;
uniform float uDensity;
uniform float uAnisotropy;
uniform float uMaxDistance;
uniform float uRayIntensity;
uniform int uSamples;
uniform int uSpotCount;
uniform vec3 uSpotPos[8];
uniform vec3 uSpotDir[8];
uniform vec3 uSpotColor[8];
uniform float uSpotEnergy[8];
uniform float uSpotCosOuter[8];
uniform float uSpotCosInner[8];
uniform float uSpotRange[8];
uniform int uBarCount;
uniform vec3 uBarStart[4];
uniform vec3 uBarEnd[4];
uniform vec3 uBarDir[4];
uniform vec3 uBarColor[4];
uniform float uBarEnergy[4];
uniform float uBarRange[4];

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float hgPhase(float cosTheta, float g) {
  float g2 = g * g;
  return (1.0 - g2) / (12.56637 * pow(max(0.001, 1.0 + g2 - 2.0 * g * cosTheta), 1.5));
}

vec3 spotScatter(vec3 p, vec3 viewDir) {
  vec3 total = vec3(0.0);
  for (int i = 0; i < 8; i++) {
    if (i >= uSpotCount) break;
    vec3 toLight = uSpotPos[i] - p;
    float distanceSquared = dot(toLight, toLight);
    float distanceToLight = sqrt(distanceSquared);
    if (distanceToLight > uSpotRange[i]) continue;
    vec3 lightDir = toLight / max(distanceToLight, 0.001);
    float cone = dot(-lightDir, normalize(uSpotDir[i]));
    float edge = smoothstep(uSpotCosOuter[i], uSpotCosInner[i], cone);
    if (edge <= 0.0001) continue;
    float attenuation = 1.0 / (1.0 + distanceSquared * 0.16);
    float cosTheta = dot(-lightDir, viewDir);
    float phase = hgPhase(cosTheta, uAnisotropy);
    total += uSpotColor[i] * (uSpotEnergy[i] * attenuation * edge * phase);
  }
  return total;
}

vec3 barScatter(vec3 p, vec3 viewDir) {
  vec3 total = vec3(0.0);
  for (int i = 0; i < 4; i++) {
    if (i >= uBarCount) break;
    vec3 segment = uBarEnd[i] - uBarStart[i];
    float segmentLengthSq = max(0.0001, dot(segment, segment));
    float along = clamp(dot(p - uBarStart[i], segment) / segmentLengthSq, 0.0, 1.0);
    vec3 closest = uBarStart[i] + segment * along;
    vec3 toLight = closest - p;
    float distanceSquared = dot(toLight, toLight);
    float distanceToLight = sqrt(distanceSquared);
    if (distanceToLight > uBarRange[i]) continue;
    float attenuation = 1.0 / (1.0 + distanceSquared * 0.35);
    vec3 lightDir = toLight / max(distanceToLight, 0.001);
    float phase = hgPhase(dot(-lightDir, viewDir), uAnisotropy * 0.5);
    total += uBarColor[i] * (uBarEnergy[i] * attenuation * phase);
  }
  return total;
}

void mainImage(const in vec4 inputColor, const in vec2 uv, const in float depth, out vec4 outputColor) {
  if (uDensity <= 0.0001 || uSamples <= 0) {
    outputColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  vec2 ndc = uv * 2.0 - 1.0;
  vec4 viewRay = uInvProjection * vec4(ndc, 1.0, 1.0);
  viewRay.xyz /= viewRay.w;
  vec3 viewDir = normalize(mat3(uCameraWorld) * normalize(viewRay.xyz));
  vec3 cameraPosition = uCameraWorld[3].xyz;

  vec4 sceneClip = vec4(ndc, depth * 2.0 - 1.0, 1.0);
  vec4 sceneView = uInvProjection * sceneClip;
  sceneView.xyz /= sceneView.w;
  vec3 sceneWorld = (uCameraWorld * sceneView).xyz;
  float sceneDistance = depth > 0.999999 ? uMaxDistance : distance(cameraPosition, sceneWorld);
  float maxDistance = min(sceneDistance, uMaxDistance);
  if (maxDistance <= 0.02) {
    outputColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  float jitter = 0.5;
  float perLight = clamp(float(uSamples) / 4.0, 4.0, 16.0);
  float globalTransmittance = exp(-uDensity * maxDistance * 0.12);
  vec3 scattered = vec3(0.0);

  for (int i = 0; i < 8; i++) {
    if (i >= uSpotCount) break;
    vec3 lightPosition = uSpotPos[i];
    vec3 axis = normalize(uSpotDir[i]);
    vec3 originToLight = cameraPosition - lightPosition;
    float cosOuter = clamp(uSpotCosOuter[i], 0.0, 1.0);
    float cosInner = clamp(uSpotCosInner[i], cosOuter + 0.0001, 1.0);
    float k = cosOuter * cosOuter;
    float a = dot(viewDir, axis);
    float b = dot(originToLight, axis);
    float c = dot(originToLight, viewDir);
    float d2 = dot(originToLight, originToLight);
    float A = a * a - k;
    float B = 2.0 * (a * b - k * c);
    float C = b * b - k * d2;

    float tEnter = -1.0;
    float tExit = -1.0;
    if (abs(A) > 0.00001) {
      float discriminant = B * B - 4.0 * A * C;
      if (discriminant <= 0.0) continue;
      float root = sqrt(discriminant);
      float t0 = (-B - root) / (2.0 * A);
      float t1 = (-B + root) / (2.0 * A);
      tEnter = min(t0, t1);
      tExit = max(t0, t1);
    } else if (abs(B) > 0.00001) {
      float t = -C / B;
      if (B > 0.0) {
        tEnter = t;
        tExit = 100000.0;
      } else {
        tEnter = 0.0;
        tExit = t;
      }
    } else {
      continue;
    }

    tEnter = max(tEnter, 0.0);
    tExit = min(tExit, min(maxDistance, uSpotRange[i]));
    if (tExit <= tEnter + 0.01) continue;
    float mid = (tEnter + tExit) * 0.5;
    vec3 midPoint = cameraPosition + viewDir * mid;
    if (dot(midPoint - lightPosition, axis) <= 0.0) {
      // The camera may be looking through the back nappe of the mathematical cone.
      continue;
    }

    float span = tExit - tEnter;
    float sampleStep = span / perLight;
    for (int j = 0; j < 16; j++) {
      if (float(j) >= perLight) break;
      float t = tEnter + sampleStep * (float(j) + jitter);
      vec3 samplePosition = cameraPosition + viewDir * t;
      vec3 toLight = lightPosition - samplePosition;
      float distanceSquared = dot(toLight, toLight);
      float distanceToLight = sqrt(distanceSquared);
      if (distanceToLight <= 0.001) continue;
      vec3 lightDir = toLight / distanceToLight;
      float cone = dot(-lightDir, axis);
      float edge = smoothstep(cosOuter, cosInner, cone);
      if (edge <= 0.001) continue;
      float attenuation = 1.0 / (1.0 + distanceSquared * 0.16);
      float phase = hgPhase(dot(lightDir, viewDir), uAnisotropy);
      scattered += uSpotColor[i] * (uSpotEnergy[i] * attenuation * edge * phase * sampleStep * uDensity);
    }
  }

  // Linear LED bars are approximated as line emitters. Their direct contribution
  // to surfaces is handled by RectAreaLight; this term only adds the local haze.
  for (int i = 0; i < 4; i++) {
    if (i >= uBarCount) break;
    vec3 segment = uBarEnd[i] - uBarStart[i];
    float segmentLengthSq = max(0.0001, dot(segment, segment));
    float span = maxDistance;
    float sampleStep = span / 4.0;
    for (int j = 0; j < 4; j++) {
      float t = sampleStep * (float(j) + jitter);
      vec3 samplePosition = cameraPosition + viewDir * t;
      float along = clamp(dot(samplePosition - uBarStart[i], segment) / segmentLengthSq, 0.0, 1.0);
      vec3 closest = uBarStart[i] + segment * along;
      vec3 toLight = closest - samplePosition;
      float distanceSquared = dot(toLight, toLight);
      float distanceToLight = sqrt(distanceSquared);
      if (distanceToLight > uBarRange[i]) continue;
      vec3 lightDir = toLight / max(distanceToLight, 0.001);
      float directionLobe = smoothstep(-0.05, 0.65, dot(-lightDir, normalize(uBarDir[i])));
      if (directionLobe <= 0.001) continue;
      float attenuation = 1.0 / (1.0 + distanceSquared * 0.35);
      float phase = hgPhase(dot(lightDir, viewDir), uAnisotropy * 0.5);
      scattered += uBarColor[i] * (uBarEnergy[i] * attenuation * directionLobe * phase * sampleStep * uDensity);
    }
  }

  outputColor = vec4(scattered * uRayIntensity * globalTransmittance, 1.0);
}

`;

function vec3Uniforms(count: number): Vector3[] {
  return Array.from({ length: count }, () => new Vector3());
}

function scalarUniforms(count: number): number[] {
  return Array.from({ length: count }, () => 0);
}

export class VolumetricScatteringEffect extends Effect {
  declare uniforms: Map<string, Uniform<any>>;

  constructor() {
    super('VolumetricScattering', fragmentShader, {
      blendFunction: BlendFunction.ADD,
      attributes: EffectAttribute.DEPTH,
    });
    const values: [string, any][] = [
      ['uInvProjection', new Matrix4()],
      ['uCameraWorld', new Matrix4()],
      ['uResolution', new Vector2(1, 1)],
      ['uTime', 0],
      ['uDensity', 0],
      ['uAnisotropy', 0.55],
      ['uMaxDistance', 30],
      ['uRayIntensity', 6.0],
      ['uSamples', 16],
      ['uSpotCount', 0],
      ['uSpotPos', vec3Uniforms(8)],
      ['uSpotDir', vec3Uniforms(8)],
      ['uSpotColor', vec3Uniforms(8)],
      ['uSpotEnergy', scalarUniforms(8)],
      ['uSpotCosOuter', scalarUniforms(8)],
      ['uSpotCosInner', scalarUniforms(8)],
      ['uSpotRange', scalarUniforms(8)],
      ['uBarCount', 0],
      ['uBarStart', vec3Uniforms(4)],
      ['uBarEnd', vec3Uniforms(4)],
      ['uBarDir', vec3Uniforms(4)],
      ['uBarColor', vec3Uniforms(4)],
      ['uBarEnergy', scalarUniforms(4)],
      ['uBarRange', scalarUniforms(4)],
    ];
    for (const [name, value] of values) this.uniforms.set(name, new Uniform(value));
  }

  setCamera(invProjection: Matrix4, cameraWorld: Matrix4, width: number, height: number, time: number): void {
    (this.uniforms.get('uInvProjection')!.value as Matrix4).copy(invProjection);
    (this.uniforms.get('uCameraWorld')!.value as Matrix4).copy(cameraWorld);
    (this.uniforms.get('uResolution')!.value as Vector2).set(width, height);
    this.uniforms.get('uTime')!.value = time;
  }

  setAtmosphere(density: number, anisotropy: number, intensity: number, samples: number): void {
    this.uniforms.get('uDensity')!.value = density;
    this.uniforms.get('uAnisotropy')!.value = anisotropy;
    this.uniforms.get('uRayIntensity')!.value = intensity;
    this.uniforms.get('uSamples')!.value = samples;
  }

  setVolumes(volumes: VolumeSet): void {
    const spots = volumes.spots.slice(0, 8);
    const bars = volumes.bars.slice(0, 4);
    this.uniforms.get('uSpotCount')!.value = spots.length;
    this.uniforms.get('uBarCount')!.value = bars.length;
    const spotPos = this.uniforms.get('uSpotPos')!.value as Vector3[];
    const spotDir = this.uniforms.get('uSpotDir')!.value as Vector3[];
    const spotColor = this.uniforms.get('uSpotColor')!.value as Vector3[];
    const spotEnergy = this.uniforms.get('uSpotEnergy')!.value as number[];
    const spotOuter = this.uniforms.get('uSpotCosOuter')!.value as number[];
    const spotInner = this.uniforms.get('uSpotCosInner')!.value as number[];
    const spotRange = this.uniforms.get('uSpotRange')!.value as number[];
    spots.forEach((spot, index) => {
      spotPos[index].set(...spot.position);
      spotDir[index].set(...spot.direction);
      const spotTint = new Color(spot.color);
      spotColor[index].set(spotTint.r, spotTint.g, spotTint.b);
      spotEnergy[index] = spot.energy;
      spotOuter[index] = spot.cosOuter;
      spotInner[index] = spot.cosInner;
      spotRange[index] = spot.range;
    });
    const barStart = this.uniforms.get('uBarStart')!.value as Vector3[];
    const barEnd = this.uniforms.get('uBarEnd')!.value as Vector3[];
    const barDir = this.uniforms.get('uBarDir')!.value as Vector3[];
    const barColor = this.uniforms.get('uBarColor')!.value as Vector3[];
    const barEnergy = this.uniforms.get('uBarEnergy')!.value as number[];
    const barRange = this.uniforms.get('uBarRange')!.value as number[];
    bars.forEach((bar, index) => {
      barStart[index].set(...bar.start);
      barEnd[index].set(...bar.end);
      barDir[index].set(...bar.direction);
      const barTint = new Color(bar.color);
      barColor[index].set(barTint.r, barTint.g, barTint.b);
      barEnergy[index] = bar.energy;
      barRange[index] = bar.range;
    });
  }
}
