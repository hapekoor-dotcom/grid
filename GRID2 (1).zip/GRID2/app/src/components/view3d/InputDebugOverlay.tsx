import { useEffect, useState } from 'react';
import type { PlayCanvasRuntime } from './playcanvasRuntime';

type State = ReturnType<PlayCanvasRuntime['getInputDebug']>;

export function InputDebugOverlay({ getState }: { getState: () => State | null }) {
  const [state, setState] = useState<State | null>(null);
  useEffect(() => {
    const update = () => setState(getState());
    update();
    const timer = window.setInterval(update, 100);
    return () => window.clearInterval(timer);
  }, [getState]);
  if (!state) return null;
  const integrated = /intel|iris|uhd|radeon graphics|vega/i.test(state.gpu) && !/arc/i.test(state.gpu);
  const diagnostics = [
    'RE:MORPH renderer diagnostics',
    `GPU: ${state.gpu}`,
    `Vendor: ${state.gpuVendor}`,
    `Backend: ${state.backend}`,
    `API: ${state.api}`,
    `HDR: ${state.hdrFormat}`,
    `Anti-aliasing: ${state.aaMode}`,
    `TAA jitter: ${state.taaJitter}`,
    `TAA history resets: ${state.taaHistoryResets} (${state.taaLastResetReason})`,
    `Quality: ${state.quality}`,
    `DPR: ${state.dpr}`,
    `Canvas: ${state.canvasSize}`,
    `Backbuffer: ${state.backbufferSize}`,
    `FPS: ${state.fps}`,
    `Frame: ${state.frameTime} ms`,
    `Draw calls: ${state.drawCalls}`,
    `Triangles: ${state.triangles || 'unavailable'}`,
    `Lights: ${state.activeLights}`,
    `TAA: ${state.taaEnabled}`,
    `Dither: ${state.dithering}`,
    integrated ? 'WARNING: Integrated GPU active' : '',
  ].filter(Boolean).join('\n');
  const rows: [string, string | number | boolean | null][] = [
    ['pointerId', state.pointerId ?? '—'],
    ['buttons', state.buttons],
    ['leftButtonDown', state.leftButtonDown],
    ['pointerOwner', state.pointerOwner],
    ['pointerCaptureOwner', state.pointerCaptureOwner],
    ['pointerLockElement', state.pointerLockElement],
    ['activeTool', state.activeTool],
    ['activeGizmoHandle', state.activeGizmoHandle],
    ['cameraDragging', state.cameraDragging],
    ['gizmoDragging', state.gizmoDragging],
    ['selectionSuppressed', state.selectionSuppressed],
    ['viewportHovered', state.viewportHovered],
    ['inspectorHovered', state.inspectorHovered],
    ['cameraDistance', state.cameraDistance.toFixed(2)],
    ['cameraYaw', state.cameraYaw],
    ['cameraPitch', state.cameraPitch],
    ['nearClip', state.nearClip.toFixed(3)],
    ['farClip', state.farClip.toFixed(1)],
    ['sceneRadius', state.sceneRadius.toFixed(2)],
    ['hdrFormat', state.hdrFormat],
    ['dithering', state.dithering],
    ['ditherActive', state.ditherActive],
    ['lastChange', state.lastChange],
    ['lastDirty', state.lastDirty],
    ['runtimeUpdated', state.runtimeUpdated],
    ['renderRequested', state.renderRequested],
    ['lastAction', state.lastAction],
    ['lastRebuild', state.lastRebuild],
    ['materialSynced', state.materialSynced],
    ['shaderSynced', state.shaderSynced],
    ['bloomEnabled', state.bloomEnabled],
    ['fogEnabled', state.fogEnabled],
    ['taaEnabled', state.taaEnabled],
    ['aaMode', state.aaMode],
    ['taaJitter', state.taaJitter],
    ['taaHistoryResets', state.taaHistoryResets],
    ['taaLastResetReason', state.taaLastResetReason],
    ['fogSteps', state.fogSteps],
    ['fogScale', state.fogScale],
    ['renderScale', state.renderScale],
  ];
  return (
    <details className="input-debug" open>
      <summary>INPUT DEBUG</summary>
      <div className="input-debug-renderer">
        <div className="input-debug-renderer-head"><span>RENDERER</span><button type="button" onClick={() => { void navigator.clipboard?.writeText(diagnostics); }}>Copy renderer diagnostics</button></div>
        <div><span>GPU</span><b>{state.gpu}</b></div>
        <div><span>Vendor</span><b>{state.gpuVendor}</b></div>
        <div><span>Backend</span><b>{state.backend}</b></div>
        <div><span>API</span><b>{state.api}</b></div>
        <div><span>HDR</span><b>{state.hdrFormat}</b></div>
        <div><span>Quality</span><b>{state.quality}</b></div>
        <div><span>FPS / frame</span><b>{state.fps} / {state.frameTime.toFixed(1)} ms</b></div>
        <div><span>Draws / tris</span><b>{state.drawCalls} / {state.triangles || '—'}</b></div>
        <div><span>DPR</span><b>{state.dpr}</b></div>
        <div><span>Canvas</span><b>{state.canvasSize}</b></div>
        <div><span>Buffer</span><b>{state.backbufferSize}</b></div>
        {!state.gpuDetailed && <div className="input-debug-warning">Detailed GPU info unavailable</div>}
        {integrated && <div className="input-debug-warning">Integrated GPU active</div>}
        <div><span>Post pipeline</span><b>{state.postPipeline}</b></div>
        <div><span>Post passes</span><b>{state.postPasses}</b></div>
        <div><span>Scene color</span><b>{state.postSceneFormat}</b></div>
        <div><span>Post input / output</span><b>{state.postSceneFormat} → {state.postOutputFormat}</b></div>
        <div><span>Last camera action</span><b>{state.lastCameraAction}</b></div>
        <div><span>Camera distance before / after</span><b>{state.cameraDistanceBefore.toFixed(2)} / {state.cameraDistanceAfter.toFixed(2)}</b></div>
        <div><span>Focus radius / target</span><b>{state.focusBoundsRadius.toFixed(2)} / {state.focusTarget}</b></div>
        <div><span>Hover target</span><b>{state.hoverId || 'none'}</b></div>
        <div><span>Pick method / source</span><b>{state.pickMethod} / {state.pickSource}</b></div>
        <div><span>Post stage / effects</span><b>{state.postStage} / {state.postRegistrations}</b></div>
        <div><span>Post depth</span><b>{state.postDepth ? 'Available' : 'Unavailable'}</b></div>
        <div><span>Geometry ops</span><b>{state.geoOps || 'none'}</b></div>
        <div><span>Noise strength</span><b>{state.noiseStrength.toFixed(2)}</b></div>
        <div><span>Post history resets</span><b>{state.postHistoryResets}</b></div>
        <div><span>Post reset reason</span><b>{state.postHistoryResetReason}</b></div>
        <div><span>Post history state</span><b>{state.postHistoryStates || '—'}</b></div>
        <div><span>Post history</span><b>{state.postHistory ? 'Valid' : 'None'}</b></div>
        <div><span>TAA history</span><b>{state.taaEnabled ? 'Valid' : 'Off'}</b></div>
        <div><span>Post resolution</span><b>{state.postResolution}</b></div>
        <div><span>Cross-context copy</span><b>NO</b></div>
        <div><span>RD simulation</span><b>{state.rdEnabled ? (state.rdValid ? 'VALID' : 'INVALID') : 'Off'}</b></div>
        <div><span>RD resolution</span><b>{state.rdResolution}</b></div>
        <div><span>Graph nodes / edges</span><b>{state.graphNodes} / {state.graphConnections}</b></div>
        <div><span>Graph cycles</span><b>{state.graphCycles}</b></div>
        <div><span>Execution domains</span><b>{state.graphDomains}</b></div>
        <div><span>Clone instances</span><b>{state.cloneCount}</b></div>
        <div><span>RD consumers</span><b>{state.rdConsumers}</b></div>
        <div><span>RD used by</span><b>{state.rdConsumerList || 'none'}</b></div>
        <div><span>RD GPU readbacks/frame</span><b>{state.rdReadbacks}</b></div>
        <div><span>RD injections</span><b>{state.rdInjections}</b></div>
        <div><span>RD steps / resets</span><b>{state.rdSteps} / {state.rdResets} ({state.rdResetReason})</b></div>
        {state.postError && <div className="input-debug-warning">{state.postError}</div>}
      </div>
      <div className="input-debug-state">
        {rows.map(([key, value]) => <div key={key} className={value === true ? 'is-true' : ''}><span>{key}</span><b>{String(value)}</b></div>)}
      </div>
      <div className="input-debug-events">
        {state.events.length === 0 && <span className="dim">No events</span>}
        {state.events.map((event, index) => <div key={`${event.at}-${index}`}><time>{event.at.toFixed(0)}</time><b>{event.type}</b><span>{event.detail}</span></div>)}
      </div>
    </details>
  );
}
