import { useMemo } from 'react';
import type { Project, SceneObject } from '../../types/project';
import { barEmitter } from '../../lib/lightOptics';
import { VolumetricBeam } from './VolumetricBeam';

interface BarBeamsProps {
  object: SceneObject;
  project: Project;
  intensity: number;
  haze: number;
  visible: boolean;
}

export function BarBeams({ object, project, intensity, haze, visible }: BarBeamsProps) {
  const emitter = useMemo(() => barEmitter(object, project), [object, project]);
  const light = object.light;
  if (!light || !visible) return null;
  const segments = light.segments;
  return (
    <group>
      {emitter.lenses.map((lens, index) => {
        const segment = segments?.[index] ?? segments?.[0];
        const lensIntensity = segment?.intensity ?? 1;
        const color = segment?.color || light.color;
        return (
          <VolumetricBeam
            key={index}
            from={lens}
            to={emitter.targets[index]}
            color={color}
            intensity={intensity * lensIntensity}
            haze={haze}
            fieldAngle={emitter.profile.beamAngle}
            beamAngle={emitter.profile.beamAngle}
            alpha={emitter.profile.alpha}
            coreAlpha={0}
            softness={0.86}
            axialPower={2.6}
            strobe={light.strobe}
            visible={visible}
            core={false}
          />
        );
      })}
    </group>
  );
}
