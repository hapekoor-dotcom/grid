import {
  ADDRESS_CLAMP_TO_EDGE,
  FILTER_NEAREST,
  PIXELFORMAT_RGBA16F,
  Texture,
  type GraphicsDevice,
} from 'playcanvas';
import type { Project, ReactionDiffusionConfig } from '../../types/project';
import { defaultReactionDiffusion, modulatedReactionDiffusion, normalizeReactionDiffusion } from '../../lib/reactionDiffusion';
import { setReactionSampleProvider } from '../../lib/reactionField';

const VERTEX = `attribute vec2 aPosition; varying vec2 vUv; void main(void) { vUv = aPosition * 0.5 + 0.5; gl_Position = vec4(aPosition, 0.0, 1.0); }`;
const INJECT = `precision highp float;
uniform sampler2D uState;
uniform vec2 uCenter;
uniform float uRadius;
uniform float uStrength;
uniform float uChemical;
varying vec2 vUv;
void main(void) {
    vec4 state = texture2D(uState, vUv);
    float brush = 1.0 - smoothstep(0.0, max(0.0001, uRadius), distance(vUv, uCenter));
    if (uChemical < 0.5) state.r = clamp(state.r + brush * uStrength, 0.0, 1.0);
    else state.g = clamp(state.g + brush * uStrength, 0.0, 1.0);
    gl_FragColor = vec4(state.r, state.g, 0.0, 1.0);
}`;

const STEP = `precision highp float;
uniform sampler2D uState;
uniform vec2 uResolution;
uniform float uFeed;
uniform float uKill;
uniform float uDiffA;
uniform float uDiffB;
uniform float uStep;
varying vec2 vUv;
vec2 p(vec2 uv) { return texture2D(uState, uv).rg; }
void main(void) {
    vec2 texel = 1.0 / uResolution;
    vec2 c = p(vUv);
    vec2 lap = -c;
    lap += p(vUv + vec2(texel.x, 0.0)) * 0.2;
    lap += p(vUv - vec2(texel.x, 0.0)) * 0.2;
    lap += p(vUv + vec2(0.0, texel.y)) * 0.2;
    lap += p(vUv - vec2(0.0, texel.y)) * 0.2;
    lap += p(vUv + texel) * 0.05;
    lap += p(vUv - texel) * 0.05;
    lap += p(vUv + vec2(texel.x, -texel.y)) * 0.05;
    lap += p(vUv + vec2(-texel.x, texel.y)) * 0.05;
    float reaction = c.r * c.g * c.g;
    float a = c.r + (uDiffA * lap.x - reaction + uFeed * (1.0 - c.r)) * uStep;
    float b = c.g + (uDiffB * lap.y + reaction - (uKill + uFeed) * c.g) * uStep;
    gl_FragColor = vec4(clamp(a, 0.0, 1.0), clamp(b, 0.0, 1.0), 0.0, 1.0);
}`;

export interface ReactionDiffusionDiagnostics {
  enabled: boolean;
  valid: boolean;
  width: number;
  height: number;
  steps: number;
  resets: number;
  lastResetReason: string;
  texture: Texture | null;
}

export class ReactionDiffusionRuntime {
  private device: GraphicsDevice;
  private gl: WebGL2RenderingContext;
  private textures: Texture[] = [];
  private framebuffers: WebGLFramebuffer[] = [];
  private current = 0;
  private program: WebGLProgram | null = null;
  private injectProgram: WebGLProgram | null = null;
  private injections = 0;
  private sampleCache = new Map<string, number>();
  private readbacksThisFrame = 0;
  private quad: WebGLBuffer | null = null;
  private config: ReactionDiffusionConfig | null = null;
  private resolution = 0;
  private resetToken = -1;
  private seedValue = -1;
  private steps = 0;
  private resets = 0;
  private lastResetReason = 'none';
  private diagnosticsValue: ReactionDiffusionDiagnostics = { enabled: false, valid: false, width: 0, height: 0, steps: 0, resets: 0, lastResetReason: 'none', texture: null };

  constructor(device: GraphicsDevice) {
    this.device = device;
    this.gl = (device as unknown as { gl: WebGL2RenderingContext }).gl;
    this.program = this.createProgram(STEP);
    this.injectProgram = this.createProgram(INJECT);
    this.quad = this.gl.createBuffer();
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.quad);
    this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), this.gl.STATIC_DRAW);
    this.gl.bindBuffer(this.gl.ARRAY_BUFFER, null);
  }

  get diagnostics(): ReactionDiffusionDiagnostics { return this.diagnosticsValue; }
  get injectionCount(): number { return this.injections; }
  get readbackCount(): number { return this.readbacksThisFrame; }

  sampleOutput(output: string): number {
    if (!this.textures.length) return 0;
    const key = output === 'sampledScalar' ? 'scalar' : output;
    const cached = this.sampleCache.get(key);
    if (cached !== undefined) return cached;
    const gl = this.gl;
    if (this.resolution < 2) return 0;
    const center = Math.floor(this.resolution / 2);
    const data = new Float32Array(3 * 3 * 4);
    try {
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.framebuffers[this.current]);
      gl.readPixels(center - 1, center - 1, 3, 3, gl.RGBA, gl.FLOAT, data);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    } catch { return 0; }
    const at = (x: number, y: number) => data[((y * 3 + x) * 4) + 1];
    const scalar = at(1, 1);
    let value = scalar;
    if (key === 'mask') value = scalar >= 0.2 ? 1 : 0;
    else if (key === 'gradient') value = Math.hypot(at(2, 1) - at(0, 1), at(1, 2) - at(1, 0));
    else if (key === 'normal') value = at(2, 1) - at(0, 1);
    this.readbacksThisFrame += 1;
    this.sampleCache.set(key, value);
    return value;
  }

  paint(u: number, v: number, radius: number, strength: number, chemical: 'A' | 'B'): void {
    if (!this.injectProgram || this.textures.length < 2) return;
    const gl = this.gl;
    const source = this.textures[this.current];
    const targetFbo = this.framebuffers[1 - this.current];
    const sourceGl = (source.impl as unknown as { _glTexture: WebGLTexture })._glTexture;
    if (!sourceGl || !targetFbo) return;
    gl.useProgram(this.injectProgram);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    const position = gl.getAttribLocation(this.injectProgram, 'aPosition');
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, targetFbo);
    gl.viewport(0, 0, this.resolution, this.resolution);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, sourceGl);
    gl.uniform1i(gl.getUniformLocation(this.injectProgram, 'uState'), 0);
    gl.uniform2f(gl.getUniformLocation(this.injectProgram, 'uCenter'), u, v);
    gl.uniform1f(gl.getUniformLocation(this.injectProgram, 'uRadius'), Math.max(0.001, Math.min(0.5, radius)));
    gl.uniform1f(gl.getUniformLocation(this.injectProgram, 'uStrength'), Math.max(0, Math.min(1, strength)));
    gl.uniform1f(gl.getUniformLocation(this.injectProgram, 'uChemical'), chemical === 'A' ? 0 : 1);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.bindTexture(gl.TEXTURE_2D, null);
    gl.useProgram(null);
    this.current = 1 - this.current;
    this.injections += 1;
    this.diagnosticsValue = { ...this.diagnosticsValue, texture: this.texture };
  }
  get texture(): Texture | null { return this.textures[this.current] || null; }

  update(project: Project, dt: number, time = 0): void {
    const config = project.reactionDiffusion ? modulatedReactionDiffusion(normalizeReactionDiffusion(project.reactionDiffusion), project, time) : null;
    this.config = config;
    if (!config?.enabled) { this.diagnosticsValue = { ...this.diagnosticsValue, enabled: false, valid: false, texture: this.texture }; return; }
    if (!this.program) return;
    const resolution = config.resolution;
    if (resolution !== this.resolution || config.resetToken !== this.resetToken || config.seed !== this.seedValue) {
      const reason = resolution !== this.resolution ? 'resolution-change' : config.resetToken !== this.resetToken ? 'explicit-reset' : 'seed-change';
      this.allocate(config, reason);
      this.resetToken = config.resetToken;
      this.seedValue = config.seed;
      this.resolution = resolution;
    }
    this.sampleCache.clear();
    this.readbacksThisFrame = 0;
    if (!this.textures.length || config.paused) {
      this.diagnosticsValue = { enabled: true, valid: this.textures.length > 0, width: resolution, height: resolution, steps: this.steps, resets: this.resets, lastResetReason: this.lastResetReason, texture: this.texture };
      return;
    }
    const hidden = Math.min(4, Math.max(0, dt || 0.016));
    const speed = Math.max(0, Math.min(120, config.speed));
    const iterations = Math.max(0, Math.min(64, Math.round(config.iterations)));
    const step = Math.max(0.0005, Math.min(2, config.timeStep * speed * hidden * 0.25));
    const gl = this.gl;
    const width = this.resolution;
    gl.useProgram(this.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    const position = gl.getAttribLocation(this.program, 'aPosition');
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    const stateId = gl.getUniformLocation(this.program, 'uState');
    const resolutionId = gl.getUniformLocation(this.program, 'uResolution');
    const feedId = gl.getUniformLocation(this.program, 'uFeed');
    const killId = gl.getUniformLocation(this.program, 'uKill');
    const diffAId = gl.getUniformLocation(this.program, 'uDiffA');
    const diffBId = gl.getUniformLocation(this.program, 'uDiffB');
    const stepId = gl.getUniformLocation(this.program, 'uStep');
    gl.uniform2f(resolutionId, width, width);
    gl.uniform1f(feedId, config.feed);
    gl.uniform1f(killId, config.kill);
    gl.uniform1f(diffAId, config.diffusionA);
    gl.uniform1f(diffBId, config.diffusionB);
    gl.uniform1f(stepId, step);
    for (let iteration = 0; iteration < iterations; iteration += 1) {
      const source = this.textures[this.current];
      const target = this.textures[1 - this.current];
      const sourceGl = (source.impl as unknown as { _glTexture: WebGLTexture })._glTexture;
      const targetFbo = this.framebuffers[1 - this.current];
      if (!sourceGl || !targetFbo) break;
      gl.bindFramebuffer(gl.FRAMEBUFFER, targetFbo);
      gl.viewport(0, 0, width, width);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, sourceGl);
      gl.uniform1i(stateId, 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      this.current = 1 - this.current;
      this.steps += 1;
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.bindTexture(gl.TEXTURE_2D, null);
    gl.useProgram(null);
    this.diagnosticsValue = { enabled: true, valid: this.textures.length > 0, width: resolution, height: resolution, steps: this.steps, resets: this.resets, lastResetReason: this.lastResetReason, texture: this.texture };
  }

  reset(): void {
    if (this.config) this.allocate(this.config, 'explicit-reset');
  }

  destroy(): void {
    setReactionSampleProvider(null);
    this.textures.forEach((texture) => texture.destroy());
    this.framebuffers.forEach((framebuffer) => this.gl.deleteFramebuffer(framebuffer));
    if (this.program) this.gl.deleteProgram(this.program);
    if (this.injectProgram) this.gl.deleteProgram(this.injectProgram);
    if (this.quad) this.gl.deleteBuffer(this.quad);
    this.textures = []; this.framebuffers = []; this.program = null; this.quad = null;
  }

  private allocate(config: ReactionDiffusionConfig, reason: string): void {
    const gl = this.gl;
    this.textures.forEach((texture) => texture.destroy());
    this.framebuffers.forEach((framebuffer) => gl.deleteFramebuffer(framebuffer));
    this.textures = []; this.framebuffers = [];
    const size = Math.max(32, Math.min(1024, Math.round(config.resolution)));
    const seed = config.seed || 1;
    for (let index = 0; index < 2; index += 1) {
      const texture = new Texture(this.device, { name: `RD state ${index}`, width: size, height: size, format: PIXELFORMAT_RGBA16F, mipmaps: false, minFilter: FILTER_NEAREST, magFilter: FILTER_NEAREST, addressU: ADDRESS_CLAMP_TO_EDGE, addressV: ADDRESS_CLAMP_TO_EDGE });
      try { texture.upload(); } catch { /* storage is allocated below */ }
      const glTexture = (texture.impl as unknown as { _glTexture: WebGLTexture })._glTexture;
      if (!glTexture) { texture.destroy(); continue; }
      gl.bindTexture(gl.TEXTURE_2D, glTexture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, size, size, 0, gl.RGBA, gl.FLOAT, null);
      const fbo = gl.createFramebuffer();
      if (!fbo) { texture.destroy(); continue; }
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, glTexture, 0);
      const complete = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      if (!complete) { gl.deleteFramebuffer(fbo); texture.destroy(); continue; }
      this.textures.push(texture);
      this.framebuffers.push(fbo);
    }
    if (this.textures.length === 2) {
      const data = new Float32Array(size * size * 4);
      for (let y = 0; y < size; y += 1) for (let x = 0; x < size; x += 1) {
        const index = (y * size + x) * 4;
        data[index] = 1;
        const noise = Math.sin(x * 12.9898 + y * 78.233 + seed * 37.719) * 43758.5453;
        data[index + 1] = (noise - Math.floor(noise)) > 0.985 ? 0.9 : 0;
        data[index + 3] = 1;
      }
      const glTexture = (this.textures[0].impl as unknown as { _glTexture: WebGLTexture })._glTexture;
      gl.bindTexture(gl.TEXTURE_2D, glTexture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, size, size, 0, gl.RGBA, gl.FLOAT, data);
      gl.bindTexture(gl.TEXTURE_2D, null);
    }
    this.current = 0;
    this.resets += 1;
    this.lastResetReason = reason;
    this.diagnosticsValue = { enabled: true, valid: this.textures.length === 2, width: size, height: size, steps: this.steps, resets: this.resets, lastResetReason: reason, texture: this.texture };
  }

  private createProgram(fragmentSource: string): WebGLProgram | null {
    const gl = this.gl;
    const vertex = gl.createShader(gl.VERTEX_SHADER);
    const fragment = gl.createShader(gl.FRAGMENT_SHADER);
    if (!vertex || !fragment) return null;
    gl.shaderSource(vertex, VERTEX); gl.compileShader(vertex);
    gl.shaderSource(fragment, fragmentSource); gl.compileShader(fragment);
    if (!gl.getShaderParameter(vertex, gl.COMPILE_STATUS) || !gl.getShaderParameter(fragment, gl.COMPILE_STATUS)) {
      gl.deleteShader(vertex); gl.deleteShader(fragment); return null;
    }
    const program = gl.createProgram();
    if (!program) return null;
    gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
    gl.deleteShader(vertex); gl.deleteShader(fragment);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { gl.deleteProgram(program); return null; }
    return program;
  }
}
