import { Suspense, useLayoutEffect, useMemo, useRef } from 'react';
import { useGLTF } from '@react-three/drei';
import { Color, Matrix4, Mesh, MeshStandardMaterial, Quaternion, Vector3, type InstancedMesh } from 'three';
import type { ThreeEvent } from '@react-three/fiber';
import type { Project, SceneObject } from '../../types/project';
import { objectDims } from '../../lib/objects';

interface SeatingProps {
  object: SceneObject;
  project: Project;
  selected: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
}

function ChairInstances({ object, selected, onSelect, onHover }: SeatingProps) {
  const ref = useRef<InstancedMesh>(null);
  const { scene } = useGLTF('/assets/fixtures/seating-chair.glb');
  const dims = objectDims(object);
  const config = object.seating || { rows: 3, columns: 5, seatPitch: 0.62, rowPitch: 0.95 };
  const chair = useMemo(() => {
    scene.updateMatrixWorld(true);
    let mesh: Mesh | null = null;
    scene.traverse((entry) => {
      if (!mesh && (entry as Mesh).isMesh) mesh = entry as Mesh;
    });
    if (!mesh) return null;
    const source = mesh as Mesh;
    const geometry = source.geometry.clone();
    geometry.applyMatrix4(source.matrixWorld);
    geometry.computeBoundingBox();
    const box = geometry.boundingBox;
    if (!box) return null;
    const size = new Vector3();
    box.getSize(size);
    const scale = 0.55 / Math.max(0.2, Math.max(size.x, size.z));
    geometry.translate(-(box.min.x + box.max.x) / 2, -box.min.y, -(box.min.z + box.max.z) / 2);
    geometry.scale(scale, scale, scale);
    geometry.computeVertexNormals();
    const base = source.material as MeshStandardMaterial;
    const material = base.clone();
    material.color = new Color('#4d4c46');
    material.roughness = 0.72;
    material.metalness = 0.08;
    return { geometry, material };
  }, [scene]);

  const transforms = useMemo(() => {
    const count = config.rows * config.columns;
    const matrices: Matrix4[] = [];
    const totalW = config.columns * config.seatPitch;
    const totalD = config.rows * config.rowPitch;
    const quaternion = new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), Math.PI);
    const scale = new Vector3(1, 1, 1);
    for (let row = 0; row < config.rows; row++) {
      for (let column = 0; column < config.columns; column++) {
        const x = -totalW / 2 + config.seatPitch * (column + 0.5);
        const z = -totalD / 2 + config.rowPitch * (row + 0.5);
        matrices.push(new Matrix4().compose(new Vector3(x, 0, z), quaternion, scale));
      }
    }
    return { matrices, count };
  }, [config.rows, config.columns, config.seatPitch, config.rowPitch]);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    transforms.matrices.forEach((matrix, index) => mesh.setMatrixAt(index, matrix));
    mesh.instanceMatrix.needsUpdate = true;
  }, [transforms]);

  const click = (event: ThreeEvent<MouseEvent>) => {
    event.stopPropagation();
    onSelect(object.id);
  };
  const over = (event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    onHover(object.id);
    document.body.style.cursor = 'pointer';
  };
  const out = (event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    onHover(null);
    document.body.style.cursor = '';
  };

  if (!chair) return null;

  return (
    <group
      position={[object.position.x, object.elevation || 0, object.position.z]}
      rotation={[0, (-object.rotation * Math.PI) / 180, 0]}
      onClick={click}
      onPointerOver={over}
      onPointerOut={out}
    >
      <instancedMesh
        ref={ref}
        args={[chair.geometry, chair.material, transforms.count]}
        castShadow
        receiveShadow
      />
      {selected && (
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[Math.max(0.5, dims.w) + 0.08, 1.05, Math.max(0.5, dims.d) + 0.08]} />
          <meshBasicMaterial color="#E8B40A" wireframe transparent opacity={0.32} />
        </mesh>
      )}
    </group>
  );
}

function ChairFallback({ object, selected, onSelect, onHover }: Omit<SeatingProps, 'project'>) {
  const dims = objectDims(object);
  const config = object.seating || { rows: 2, columns: 4, seatPitch: 0.62, rowPitch: 0.95 };
  return (
    <group position={[object.position.x, object.elevation || 0, object.position.z]} rotation={[0, (-object.rotation * Math.PI) / 180, 0]}
      onClick={(event) => { event.stopPropagation(); onSelect(object.id); }}
      onPointerOver={(event) => { event.stopPropagation(); onHover(object.id); }}
      onPointerOut={(event) => { event.stopPropagation(); onHover(null); }}
    >
      {Array.from({ length: config.rows * config.columns }, (_, index) => {
        const row = Math.floor(index / config.columns);
        const column = index % config.columns;
        return (
          <mesh key={index} position={[-((config.columns - 1) * config.seatPitch) / 2 + column * config.seatPitch, 0.42, -((config.rows - 1) * config.rowPitch) / 2 + row * config.rowPitch]} castShadow>
            <boxGeometry args={[0.45, 0.84, 0.45]} />
            <meshStandardMaterial color="#3b3b37" roughness={0.8} />
          </mesh>
        );
      })}
      {selected && (
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[dims.w + 0.06, 1.05, dims.d + 0.06]} />
          <meshBasicMaterial color="#E8B40A" wireframe transparent opacity={0.3} />
        </mesh>
      )}
    </group>
  );
}

export function SeatingMesh(props: SeatingProps) {
  return (
    <Suspense fallback={<ChairFallback object={props.object} selected={props.selected} onSelect={props.onSelect} onHover={props.onHover} />}>
      <ChairInstances {...props} />
    </Suspense>
  );
}
