import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Object3D, RectAreaLight, SpotLight } from 'three';
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js';
import type { Project, SceneObject } from '../../types/project';
import { getDevice } from '../../lib/catalog';
import { fixtureAimPoint, fixtureMountY, isShadowCandidate } from '../../lib/stage3d';
import { barEmitter, opticalProfile } from '../../lib/lightOptics';
import { getQualityProfile } from '../../lib/renderQuality';

RectAreaLightUniformsLib.init();

interface FixtureLightProps {
  project: Project;
  object: SceneObject;
  index: number;
}

export function FixtureLight({ project, object, index }: FixtureLightProps) {
  const device = getDevice(object.deviceId);
  const light = object.light;
  const profile = useMemo(() => opticalProfile(object), [object]);
  const master = project.lighting.master ?? 0.9;
  const level = light?.on ? (light.intensity || 0) * master : 0;
  const strobe = light?.strobe || 0;
  const aim = useMemo(() => fixtureAimPoint(object, project), [object, project]);
  const bar = useMemo(() => (profile.family === 'bar' ? barEmitter(object, project) : null), [object, project, profile.family]);
  const targetObject = useMemo(() => new Object3D(), []);
  const spotRef = useRef<SpotLight>(null);
  const areaRef = useRef<RectAreaLight>(null);
  const quality = getQualityProfile(project.lighting.quality);
  const shadow = isShadowCandidate(object, index, project.lighting.quality);
  const shadowSize = quality.shadows >= 4 && (project.lighting.quality === 'ultra' || project.lighting.quality === 'photo') ? 2048 : 1024;

  useFrame(({ clock }) => {
    const flash = strobe > 0 ? ((clock.elapsedTime * strobe) % 1 < 0.55 ? 1 : 0.015) : 1;
    if (spotRef.current) spotRef.current.intensity = level * flash * profile.intensityScale * (profile.family === 'wash' ? 300 : profile.family === 'beam' ? 520 : 480);
    if (areaRef.current) {
      const base = profile.family === 'bar' ? 60 : profile.family === 'strobe' ? 30 : 20;
      areaRef.current.intensity = level * flash * profile.intensityScale * base;
    }
    targetObject.position.set(aim[0], aim[1], aim[2]);
    targetObject.updateMatrixWorld();
    if (areaRef.current) {
      if (bar) {
        const center = bar.lenses.reduce((sum, point) => [sum[0] + point[0] / bar.lenses.length, sum[1] + point[1] / bar.lenses.length, sum[2] + point[2] / bar.lenses.length], [0, 0, 0] as [number, number, number]);
        areaRef.current.position.set(center[0], center[1], center[2]);
        areaRef.current.lookAt(bar.target[0], bar.target[1], bar.target[2]);
      } else {
        areaRef.current.position.set(object.position.x, fixtureMountY(object), object.position.z + (profile.family === 'panel' ? 0.04 : 0));
        areaRef.current.lookAt(aim[0], aim[1], aim[2]);
      }
    }
  });

  if (!light || !device || !['light', 'effects'].includes(device.category)) return null;

  if (profile.area) {
    const width = bar ? bar.profile.areaWidth : profile.areaWidth;
    const height = bar ? bar.profile.areaHeight : profile.areaHeight;
    return (
      <rectAreaLight
        ref={areaRef}
        color={light.color}
        intensity={0}
        width={Math.max(0.05, width)}
        height={Math.max(0.03, height)}
        position={[
          object.position.x,
          fixtureMountY(object),
          object.position.z,
        ]}
      />
    );
  }

  return (
    <>
      <primitive object={targetObject} />
      <spotLight
        ref={spotRef}
        position={[
          object.position.x,
          Math.max(0.08, fixtureMountY(object) - (object.mount === 'truss' || object.mount === 'ceiling' ? 0.1 : 0)),
          object.position.z,
        ]}
        target={targetObject}
        color={light.color}
        intensity={0}
        angle={(Math.min(100, profile.fieldAngle) * Math.PI) / 360}
        penumbra={profile.penumbra}
        decay={2}
        distance={32}
        castShadow={shadow}
        shadow-mapSize={[shadowSize, shadowSize]}
        shadow-bias={-0.0006}
        shadow-normalBias={0.02}
        shadow-camera-near={0.2}
        shadow-camera-far={32}
      />
    </>
  );
}
