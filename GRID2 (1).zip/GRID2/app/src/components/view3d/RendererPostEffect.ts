import {
  CameraFrameEffect,
  Color,
  FRAMERESOURCE_DEPTH,
  PIXELFORMAT_RGBA16F,
  PIXELFORMAT_RG11B10F,
  ADDRESS_CLAMP_TO_EDGE,
  FILTER_LINEAR,
  RenderPassShaderQuad,
  RenderTarget,
  SEMANTIC_POSITION,
  ShaderUtils,
  Texture,
  type GraphicsDevice,
} from 'playcanvas';
import type { CustomShader, Project, ShaderInstance } from '../../types/project';
import { sampleTimeline } from '../../lib/timeline';
import { getTimelineTime } from '../../lib/timelineClock';
import { findSignal, signalValue } from '../../lib/signals';
import { compileCustomShader } from '../../lib/customShaders';

export interface RendererPostDiagnostics {
  active: boolean;
  passes: number;
  sceneFormat: string;
  depth: boolean;
  history: boolean;
  width: number;
  height: number;
  bypassed: number;
  error: string;
  outputFormat: string;
  stage: string;
  registrations: number;
  historyStates: { pass: string; valid: boolean; resets: number; reason: string }[];
}

const QUAD_VERTEX = `attribute vec2 aPosition;
varying vec2 vUv;
void main(void) {
    vUv = aPosition * 0.5 + 0.5;
    gl_Position = vec4(aPosition, 0.0, 1.0);
}`;

const COPY_FRAGMENT = `precision highp float;
uniform sampler2D uSource;
varying vec2 vUv;
void main(void) { gl_FragColor = texture2D(uSource, vUv); }`;

class PostQuadPass extends RenderPassShaderQuad {
  sourceTexture: Texture | null = null;
  previousTexture: Texture | null = null;
  depthTexture: Texture | null = null;
  reactionTexture: Texture | null = null;
  historyValid = true;
  width = 1;
  height = 1;
  time = 0;
  frame = 0;
  values: Record<string, number> = {};
  private sourceId: any;
  private sourceCopyId: any;
  private previousId: any;
  private depthId: any;
  private reactionId: any;
  private widthId: any;
  private heightId: any;
  private timeId: any;
  private frameId: any;
  private valueIds = new Map<string, any>();

  constructor(device: GraphicsDevice) {
    super(device);
    this.sourceId = device.scope.resolve('uScene');
    this.sourceCopyId = device.scope.resolve('uSource');
    this.previousId = device.scope.resolve('uPrevious');
    this.depthId = device.scope.resolve('uDepth');
    this.reactionId = device.scope.resolve('uReaction');
    this.widthId = device.scope.resolve('uResolution');
    this.heightId = this.widthId;
    this.timeId = device.scope.resolve('uTime');
    this.frameId = device.scope.resolve('uFrame');
  }

  execute(): void {
    if (this.sourceTexture) { this.sourceId.setValue(this.sourceTexture); this.sourceCopyId.setValue(this.sourceTexture); }
    if (this.previousTexture && this.historyValid) this.previousId.setValue(this.previousTexture);
    else if (this.sourceTexture) this.previousId.setValue(this.sourceTexture);
    if (this.depthTexture) this.depthId.setValue(this.depthTexture);
    if (this.reactionTexture) this.reactionId.setValue(this.reactionTexture);
    this.widthId.setValue([this.width, this.height]);
    this.timeId.setValue(this.time);
    this.frameId.setValue(this.frame);
    for (const [name, value] of Object.entries(this.values)) {
      let id = this.valueIds.get(name);
      if (!id) { id = this.device.scope.resolve(name); this.valueIds.set(name, id); }
      id.setValue(value);
    }
    super.execute();
    // Avoid a feedback loop: the history target is sampled by uPrevious and is
    // also the destination of the final copy pass. Release sampler bindings
    // before the next pass binds its own render target.
    this.sourceId.setValue(null);
    this.sourceCopyId.setValue(null);
    this.previousId.setValue(null);
    this.depthId.setValue(null);
  }
}

export class RendererPostEffect extends CameraFrameEffect {
  private stack: { instance: ShaderInstance; shader: CustomShader }[] = [];
  private project: Project | null = null;
  private passList: PostQuadPass[] = [];
  private targets: RenderTarget[] = [];
  private historyTargets: RenderTarget[] = [];
  private copyPasses: PostQuadPass[] = [];
  private historyTokens: number[] = [];
  private historyValid: boolean[] = [];
  private historyResets = 0;
  private historyResetReason = 'initial';
  private finalTarget: RenderTarget | null = null;
  private depth: Texture | null = null;
  private size = { width: 0, height: 0 };
  private failed: string[] = [];
  private sizeToken = 0;
  private resizeScheduled = false;
  private diagnosticsValue: RendererPostDiagnostics = { active: false, passes: 0, sceneFormat: 'none', depth: false, history: false, width: 0, height: 0, bypassed: 0, error: '', historyStates: [], outputFormat: 'RGBA16F', stage: 'resolveScene', registrations: 1 };
  private report: (value: RendererPostDiagnostics) => void;
  private reactionTexture: Texture | null = null;

  constructor(device: GraphicsDevice, report: (value: RendererPostDiagnostics) => void) {
    super(device, 'reCustomPost', { requires: [FRAMERESOURCE_DEPTH] });
    this.report = report;
    this.enabled = false;
  }

  get diagnostics(): RendererPostDiagnostics { return this.diagnosticsValue; }

  setReactionTexture(texture: Texture | null): void { this.reactionTexture = texture; }

  sync(project: Project): void {
    const next = (project.postShaders || []).filter((instance) => instance.enabled).map((instance) => ({ instance, shader: project.customShaders?.find((shader) => shader.id === instance.shaderId) })).filter((entry): entry is { instance: ShaderInstance; shader: CustomShader } => !!entry.shader && entry.shader.context === 'post');
    const changed = JSON.stringify([next.map((entry) => [entry.shader.id, entry.shader.lastWorking?.fragment || entry.shader.fragment]), this.enabled]) !== JSON.stringify([this.stack.map((entry) => [entry.shader.id, entry.shader.lastWorking?.fragment || entry.shader.fragment]), this.stack.length > 0]);
    this.project = project;
    this.stack = next;
    this.enabled = next.length > 0;
    if (changed && this.cameraFrame) this.cameraFrame.update();
  }

  buildKey(): string {
    return `${this.stack.map((entry) => `${entry.shader.id}:${entry.shader.lastWorking?.fragment || entry.shader.fragment}`).join('|')}:${this.sizeToken}`;
  }

  createPasses(_resources: any, passes: any): void {
    this.destroyPasses();
    this.failed = [];
    if (!this.stack.length || !this.cameraFrame) { this.reportDiagnostics(); return; }
    const frame = this.cameraFrame;
    const scale = frame.rendering.renderTargetScale || 1;
    const width = Math.max(2, Math.floor((this.device.backBuffer?.width || 1) * scale));
    const height = Math.max(2, Math.floor((this.device.backBuffer?.height || 1) * scale));
    this.size = { width, height };
    // Intermediate post color is always linear RGBA16F. This is filterable
    // on all supported WebGL2 devices and never downgrades an HDR scene.
    const format = PIXELFORMAT_RGBA16F;
    this.depth = (_resources?.depth?.texture as Texture | undefined) || null;

    const makeTarget = (): RenderTarget => {
      const texture = new Texture(this.device, { name: 'RE custom post', width, height, format, mipmaps: false, srgb: false, minFilter: FILTER_LINEAR, magFilter: FILTER_LINEAR, addressU: ADDRESS_CLAMP_TO_EDGE, addressV: ADDRESS_CLAMP_TO_EDGE });
      return new RenderTarget({ colorBuffer: texture, depth: false });
    };
    const makePass = (shader: CustomShader, target: RenderTarget): PostQuadPass | null => {
      try {
        const source = shader.lastWorking || shader;
        if (!compileCustomShader({ ...shader, vertex: source.vertex, fragment: source.fragment, lastWorking: undefined }).ok) { this.failed.push(shader.name || shader.id); return null; }
        const compile = ShaderUtils.createShader(this.device, {
          uniqueName: `re_post_${shader.id}_${this.sizeToken}`,
          attributes: { aPosition: SEMANTIC_POSITION },
          vertexGLSL: QUAD_VERTEX,
          fragmentGLSL: source.fragment,
        });
        const pass = new PostQuadPass(this.device);
        pass.shader = compile;
        pass.init(target);
        pass.setClearColor(new Color(0, 0, 0, 1));
        return pass;
      } catch {
        this.failed.push(shader.name || shader.id);
        return null;
      }
    };

    const built: { pass: PostQuadPass; target: RenderTarget }[] = [];
    for (const entry of this.stack) {
      const target = makeTarget();
      const pass = makePass(entry.shader, target);
      if (pass) built.push({ pass, target });
      else { target.colorBuffer?.destroy(); target.destroy(); }
    }
    if (!built.length) { this.reportDiagnostics(); return; }
    const copyShader = ShaderUtils.createShader(this.device, { uniqueName: `re_post_history_${this.sizeToken}`, attributes: { aPosition: SEMANTIC_POSITION }, vertexGLSL: QUAD_VERTEX, fragmentGLSL: COPY_FRAGMENT });
    this.finalTarget = built[built.length - 1].target;
    this.targets = built.map((entry) => entry.target);
    this.passList = built.map((entry) => entry.pass);
    this.historyTargets = [];
    this.copyPasses = [];
    this.historyTokens = [];
    this.historyValid = [];
    passes.resolve = passes.resolve || [];
    for (let index = 0; index < built.length; index += 1) {
      const history = makeTarget();
      const copyPass = new PostQuadPass(this.device);
      copyPass.shader = copyShader;
      copyPass.init(history);
      copyPass.setClearColor(new Color(0, 0, 0, 1));
      copyPass.sourceTexture = built[index].target.colorBuffer;
      this.historyTargets.push(history);
      this.copyPasses.push(copyPass);
      this.historyTokens.push(this.stack[index]?.instance.historyResetToken || 0);
      this.historyValid.push(false);
      passes.resolve.push(built[index].pass);
      passes.resolve.push(copyPass);
    }
    this.reportDiagnostics();
  }

  destroyPasses(): void {
    this.passList.forEach((pass) => pass.destroy());
    this.copyPasses.forEach((pass) => pass.destroy());
    this.targets.forEach((target) => { target.colorBuffer?.destroy(); target.destroy(); });
    this.historyTargets.forEach((target) => { target.colorBuffer?.destroy(); target.destroy(); });
    this.passList = []; this.copyPasses = []; this.targets = []; this.historyTargets = []; this.historyTokens = []; this.historyValid = []; this.finalTarget = null;
  }

  get resetCount(): number { return this.historyResets; }

  get resetReason(): string { return this.historyResetReason; }

  get historyStates(): { pass: string; valid: boolean; resets: number; reason: string }[] {
    return this.historyValid.map((valid, index) => ({ pass: this.stack[index]?.shader.name || `pass ${index + 1}`, valid, resets: this.historyResets, reason: this.historyResetReason }));
  }

  resolveScene(scene: any): void {
    if (!this.passList.length || !this.finalTarget) return;
    const sourceScene = scene.texture;
    this.passList[0].sourceTexture = sourceScene;
    for (let index = 1; index < this.passList.length; index += 1) this.passList[index].sourceTexture = this.targets[index - 1].colorBuffer;
    for (let index = 0; index < this.passList.length; index += 1) {
      const pass = this.passList[index];
      const instance = this.stack[index]?.instance;
      if (!instance) continue;
      const token = instance.historyResetToken || 0;
      if (token !== this.historyTokens[index]) {
        this.historyTokens[index] = token;
        this.historyValid[index] = false;
        this.historyResets += 1;
        this.historyResetReason = 'user-reset';
      }
      pass.previousTexture = this.historyValid[index] ? this.historyTargets[index]?.colorBuffer || null : null;
      pass.historyValid = this.historyValid[index];
      this.historyValid[index] = true;
    }
    scene.texture = this.finalTarget.colorBuffer;
    this.reportDiagnostics();
  }

  frameUpdate(frame: any): void {
    if (!this.project || !this.stack.length) return;
    const width = Math.max(2, Math.floor((this.device.backBuffer?.width || 1) * (this.cameraFrame?.rendering.renderTargetScale || 1)));
    const height = Math.max(2, Math.floor((this.device.backBuffer?.height || 1) * (this.cameraFrame?.rendering.renderTargetScale || 1)));
    if ((width !== this.size.width || height !== this.size.height) && this.cameraFrame && !this.resizeScheduled) {
      this.resizeScheduled = true;
      this.sizeToken += 1;
      // Never rebuild the frame from inside its own update callback.
      requestAnimationFrame(() => { this.resizeScheduled = false; this.cameraFrame?.update(); });
    }
    const overrides = sampleTimeline(this.project, getTimelineTime());
    const time = (frame?.time || performance.now() * 0.001) as number;
    for (let index = 0; index < this.passList.length; index += 1) {
      const pass = this.passList[index];
      const entry = this.stack[index];
      if (!entry) continue;
      pass.depthTexture = this.depth;
      pass.reactionTexture = this.reactionTexture;
      pass.width = this.size.width;
      pass.height = this.size.height;
      pass.time = time;
      pass.frame = Math.floor(time * 60);
      const values: Record<string, number> = {};
      for (const param of entry.shader.params) {
        if (param.type === 'float' || param.type === 'int') values[param.id] = Number(entry.instance.values[param.id] ?? param.default ?? 0);
      }
      for (const [key, value] of overrides) {
        const prefix = `scene:scene.post.${entry.instance.id || entry.shader.id}.`;
        if (key.startsWith(prefix)) values[key.slice(prefix.length)] = Number(value);
      }
      for (const [key, modulator] of Object.entries(entry.instance.modulators || {})) {
        if (!modulator.enabled) continue;
        const signal = findSignal(this.project, modulator.sourceId);
        if (signal) values[key] = Number(values[key] ?? 0) + Number(modulator.offset ?? 0) + signalValue(signal, this.project, time, null) * Number(modulator.amount ?? 0);
      }
      pass.values = values;
    }
  }

  private reportDiagnostics(): void {
    this.diagnosticsValue = {
      active: this.passList.length > 0,
      passes: this.passList.length,
      sceneFormat: this.cameraFrame ? (this.cameraFrame.hdrFormat === PIXELFORMAT_RGBA16F ? 'RGBA16F' : this.cameraFrame.hdrFormat === PIXELFORMAT_RG11B10F ? 'RG11B10F' : String(this.cameraFrame.hdrFormat)) : 'none',
      depth: !!this.depth,
      history: this.historyTargets.length > 0,
      width: this.size.width,
      height: this.size.height,
      bypassed: Math.max(0, this.stack.length - this.passList.length),
      error: this.failed.length ? `Bypassed failed pass: ${this.failed.join(', ')}` : '',
      outputFormat: 'RGBA16F',
      stage: 'resolveScene',
      registrations: 1,
      historyStates: this.historyStates,
    };
    this.report(this.diagnosticsValue);
  }
}
