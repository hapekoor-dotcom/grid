import { useMemo } from 'react';
import type { ThreeEvent } from '@react-three/fiber';
import { CanvasTexture, SRGBColorSpace } from 'three';
import type { CatalogDevice } from '../../types/catalog';
import type { Project, SceneObject } from '../../types/project';
import { objectDims } from '../../lib/objects';
import { fixtureAimPoint, fixtureMountY } from '../../lib/stage3d';
import { opticalProfile } from '../../lib/lightOptics';
import { VolumetricBeam } from './VolumetricBeam';
import { BarBeams } from './BarBeams';
import { getQualityProfile } from '../../lib/renderQuality';

interface FixtureModelProps {
  object: SceneObject;
  device: CatalogDevice | null;
  project: Project;
  selected: boolean;
  hovered: boolean;
  beamVisible: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
  onFocus: (id: string) => void;
}

function BodyMaterial({ color = '#222a31', metalness = 0.45, roughness = 0.45 }: { color?: string; metalness?: number; roughness?: number }) {
  return <meshStandardMaterial color={color} metalness={metalness} roughness={roughness} />;
}

export function FixtureModel({ object, device, project, selected, hovered, beamVisible, onSelect, onHover, onFocus }: FixtureModelProps) {
  const dims = objectDims(object);
  const y = fixtureMountY(object);
  const kind = device?.kind || 'other';
  const light = object.light;
  const target = useMemo(() => fixtureAimPoint(object, project), [object, project]);
  const color = light?.color || '#ffffff';
  const on = !!light?.on && (light?.intensity || 0) > 0.01;
  const intensity = light?.intensity ?? 0;
  const optics = opticalProfile(object);
  const quality = getQualityProfile(project.lighting.quality);
  const useConeFallback = !quality.raymarch;
  const beamAngle = optics.beamAngle;
  const yaw = useMemo(() => {
    const aiming = ['head', 'beam', 'spot', 'par', 'flood', 'effectlight'].includes(kind);
    if (!aiming) return (-object.rotation * Math.PI) / 180;
    return Math.atan2(target[0] - object.position.x, target[2] - object.position.z);
  }, [kind, object.rotation, object.position.x, object.position.z, target[0], target[2]]);
  const isHung = object.mount === 'truss' || object.mount === 'ceiling';
  const beamFrom: [number, number, number] = [object.position.x, Math.max(0.05, y - (isHung ? 0.08 : 0)), object.position.z];

  const handleClick = (event: ThreeEvent<MouseEvent>) => {
    event.stopPropagation();
    onSelect(object.id);
  };
  const handleDoubleClick = (event: ThreeEvent<MouseEvent>) => {
    event.stopPropagation();
    onFocus(object.id);
  };
  const handleOver = (event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    onHover(object.id);
    document.body.style.cursor = 'pointer';
  };
  const handleOut = (event: ThreeEvent<PointerEvent>) => {
    event.stopPropagation();
    onHover(null);
    document.body.style.cursor = '';
  };

  const housing = kind === 'head' || kind === 'beam' || kind === 'spot';
  const bar = ['bar', 'pixel', 'panel', 'strobe', 'blinder'].includes(kind);
  const par = ['par', 'flood', 'effectlight'].includes(kind);
  const furnitureDevice = ['table', 'chair', 'barricade', 'truss', 'trussTower', 'stage', 'curtain'].includes(kind);
  const consoleDevice = ['console', 'controller', 'mixer'].includes(kind);
  const rackDevice = ['node', 'splitter', 'switch', 'interface', 'receiver', 'transmitter'].includes(kind);
  const powerDevice = ['outlet', 'distro', 'dimmer', 'battery', 'generator', 'solar'].includes(kind);
  const computerDevice = ['laptop', 'computer', 'player'].includes(kind);
  const videoDevice = ['ledwall', 'tv', 'projector', 'processor'].includes(kind);
  const screenTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 288;
    const context = canvas.getContext('2d');
    if (context) {
      const gradient = context.createLinearGradient(0, 0, 512, 288);
      gradient.addColorStop(0, '#464f57');
      gradient.addColorStop(0.52, '#353d44');
      gradient.addColorStop(1, '#262d33');
      context.fillStyle = gradient;
      context.fillRect(0, 0, 512, 288);
      context.fillStyle = 'rgba(7, 10, 13, 0.14)';
      for (let y = 0; y < 288; y += 4) context.fillRect(0, y, 512, 1);
      context.fillStyle = 'rgba(255, 255, 255, 0.05)';
      context.fillRect(36, 34, 440, 220);
    }
    const texture = new CanvasTexture(canvas);
    texture.colorSpace = SRGBColorSpace;
    return texture;
  }, []);
  const effectDevice = ['haze', 'fog', 'snow', 'bubble', 'co2', 'confetti', 'flame', 'fan'].includes(kind);
  const cellCount = Math.min(16, Math.max(3, device?.lensCount || 6));

  return (
    <>
      <group
        position={[object.position.x, y, object.position.z]}
        rotation={[0, yaw, 0]}
        onClick={handleClick}
        onDoubleClick={handleDoubleClick}
        onPointerOver={handleOver}
        onPointerOut={handleOut}
      >
        <mesh position={[0, -0.08, 0]}>
          <boxGeometry args={[Math.max(0.32, dims.w * 1.3), Math.max(0.36, dims.h * 1.4), Math.max(0.32, dims.d * 1.3)]} />
          <meshBasicMaterial transparent opacity={0} depthWrite={false} />
        </mesh>
        {housing && (
          <group>
            <mesh position={[0, isHung ? 0.05 : 0, 0]} castShadow>
              <boxGeometry args={[dims.w * 0.9, 0.055, dims.d * 0.9]} />
              <BodyMaterial color="#2a333b" metalness={0.6} roughness={0.35} />
            </mesh>
            <mesh position={[0, isHung ? -0.01 : 0.02, 0]}>
              <boxGeometry args={[dims.w * 0.22, 0.04, dims.d * 0.22]} />
              <BodyMaterial color="#161c21" />
            </mesh>
            {[-1, 1].map((side) => (
              <mesh key={side} position={[side * dims.w * 0.26, -0.1, 0]} castShadow>
                <boxGeometry args={[0.032, 0.24, dims.d * 0.3]} />
                <BodyMaterial color="#2a333b" metalness={0.55} />
              </mesh>
            ))}
            <group position={[0, -0.24, 0]}>
              <mesh castShadow>
                <boxGeometry args={[dims.w * 0.62, dims.h * 0.95, dims.d * 0.72]} />
                <BodyMaterial color="#252e36" metalness={0.5} roughness={0.4} />
              </mesh>
              <mesh position={[0, 0, dims.d * 0.37]} rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[dims.w * 0.24, dims.w * 0.24, 0.03, 24]} />
                <meshStandardMaterial color="#0b0e10" metalness={0.3} roughness={0.25} />
              </mesh>
              <mesh position={[0, 0, dims.d * 0.39]} rotation={[Math.PI / 2, 0, 0]}>
                <circleGeometry args={[dims.w * 0.18, 24]} />
                <meshStandardMaterial color={color} emissive={color} emissiveIntensity={on ? 2.2 + intensity * 3 : 0.02} toneMapped={false} />
              </mesh>
              <mesh position={[0, dims.h * 0.5, 0]}>
                <boxGeometry args={[dims.w * 0.48, 0.02, dims.d * 0.3]} />
                <BodyMaterial color="#171d22" />
              </mesh>
            </group>
            <mesh position={[0, -0.52, 0]}>
              <boxGeometry args={[dims.w * 0.16, 0.04, dims.d * 0.16]} />
              <BodyMaterial color="#0f1418" metalness={0.3} />
            </mesh>
          </group>
        )}

        {bar && (
          <group position={[0, 0, 0]}>
            <mesh castShadow>
              <boxGeometry args={[dims.w, Math.max(0.08, dims.h), Math.max(0.08, dims.d)]} />
              <BodyMaterial color="#2c353d" metalness={0.45} roughness={0.42} />
            </mesh>
            {Array.from({ length: cellCount }, (_, index) => {
              const cell = dims.w / cellCount;
              const segment = light?.segments?.[index] ?? light?.segments?.[0];
              const cellColor = segment?.color || color;
              const cellLevel = segment ? segment.intensity : 1;
              return (
                <mesh key={index} position={[-dims.w / 2 + cell * (index + 0.5), dims.h * 0.12, dims.d / 2 + 0.002]}>
                  <boxGeometry args={[Math.max(0.02, cell - 0.012), Math.max(0.02, dims.h * 0.45), 0.006]} />
                  <meshStandardMaterial color={cellColor} emissive={cellColor} emissiveIntensity={on ? (1.4 + intensity * 2.4) * cellLevel : 0.015} toneMapped={false} />
                </mesh>
              );
            })}
            {['bar', 'pixel'].includes(kind) && (
              <mesh position={[0, dims.h * 0.08, -dims.d / 2 - 0.004]}>
                <boxGeometry args={[dims.w * 0.92, Math.max(0.012, dims.h * 0.16), 0.004]} />
                <meshStandardMaterial color={color} emissive={color} emissiveIntensity={on ? 1.2 : 0.015} toneMapped={false} />
              </mesh>
            )}
            {!isHung && (
              <mesh position={[0, -dims.h * 0.6, 0]}>
                <boxGeometry args={[0.16, 0.1, 0.16]} />
                <BodyMaterial color="#141a1f" />
              </mesh>
            )}
          </group>
        )}

        {par && (
          <group>
            <mesh castShadow>
              <boxGeometry args={[dims.w, dims.h, dims.d]} />
              <BodyMaterial color="#2b343c" metalness={0.4} roughness={0.45} />
            </mesh>
            <mesh position={[0, 0, dims.d / 2 + 0.005]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[dims.w * 0.3, dims.w * 0.3, 0.02, 24]} />
              <meshStandardMaterial color="#0a0d0f" metalness={0.2} roughness={0.3} />
            </mesh>
            <mesh position={[0, 0, dims.d / 2 + 0.018]} rotation={[Math.PI / 2, 0, 0]}>
              <circleGeometry args={[dims.w * 0.23, 24]} />
              <meshStandardMaterial color={color} emissive={color} emissiveIntensity={on ? 1.8 + intensity * 3 : 0.02} toneMapped={false} />
            </mesh>
            <mesh position={[0, -dims.h * 0.62, 0]}>
              <boxGeometry args={[0.12, 0.1, 0.12]} />
              <BodyMaterial color="#13181c" />
            </mesh>
          </group>
        )}

        {furnitureDevice && (
          <mesh castShadow receiveShadow>
            <boxGeometry args={[Math.max(0.08, dims.w), Math.max(0.08, dims.h), Math.max(0.08, dims.d)]} />
            <BodyMaterial color="#232a30" metalness={0.15} roughness={0.7} />
          </mesh>
        )}

        {consoleDevice && (
          <group>
            <mesh position={[0, 0, 0]} castShadow receiveShadow>
              <boxGeometry args={[dims.w, Math.max(0.08, dims.h), dims.d]} />
              <BodyMaterial color="#1c2228" metalness={0.35} roughness={0.5} />
            </mesh>
            <mesh position={[0, dims.h / 2 + 0.006, -dims.d * 0.18]}>
              <boxGeometry args={[dims.w * 0.92, 0.006, dims.d * 0.5]} />
              <BodyMaterial color="#11161a" metalness={0.2} roughness={0.7} />
            </mesh>
            <mesh position={[0, dims.h / 2 + 0.06, -dims.d * 0.3]} rotation={[-0.38, 0, 0]}>
              <boxGeometry args={[dims.w * 0.34, 0.005, dims.d * 0.23]} />
              <meshStandardMaterial color="#102a3d" emissive="#2a8ac0" emissiveIntensity={0.55} toneMapped={false} />
            </mesh>
            {Array.from({ length: 8 }, (_, index) => (
              <mesh key={index} position={[-dims.w * 0.32 + index * dims.w * 0.09, dims.h / 2 + 0.013, dims.d * 0.1]}>
                <boxGeometry args={[0.016, 0.012, dims.d * 0.22]} />
                <meshStandardMaterial color="#3b434a" metalness={0.4} roughness={0.45} />
              </mesh>
            ))}
            {[-0.22, 0.22].map((x) => (
              <mesh key={x} position={[dims.w * x, dims.h / 2 + 0.014, -dims.d * 0.16]}>
                <cylinderGeometry args={[0.035, 0.035, 0.012, 20]} />
                <meshStandardMaterial color="#2a3238" metalness={0.6} roughness={0.4} />
              </mesh>
            ))}
          </group>
        )}

        {rackDevice && (
          <group>
            <mesh castShadow>
              <boxGeometry args={[dims.w, Math.max(0.07, dims.h), dims.d]} />
              <BodyMaterial color="#1d2429" metalness={0.5} roughness={0.4} />
            </mesh>
            <mesh position={[0, 0, dims.d / 2 + 0.003]}>
              <boxGeometry args={[dims.w * 0.94, Math.max(0.055, dims.h) * 0.78, 0.004]} />
              <BodyMaterial color="#12171b" metalness={0.25} roughness={0.6} />
            </mesh>
            {Array.from({ length: 4 }, (_, index) => (
              <mesh key={index} position={[-dims.w * 0.32 + index * dims.w * 0.2, dims.h * 0.15, dims.d / 2 + 0.007]}>
                <boxGeometry args={[0.028, 0.018, 0.008]} />
                <meshStandardMaterial color={index % 2 === 0 ? '#35fc72' : '#355cfc'} emissive={index % 2 === 0 ? '#35fc72' : '#355cfc'} emissiveIntensity={1.2} toneMapped={false} />
              </mesh>
            ))}
            <mesh position={[dims.w * 0.34, 0, dims.d / 2 + 0.006]}>
              <ringGeometry args={[0.012, 0.02, 16]} />
              <meshStandardMaterial color="#35fc72" emissive="#35fc72" emissiveIntensity={1} toneMapped={false} />
            </mesh>
          </group>
        )}

        {powerDevice && (
          <group>
            <mesh castShadow receiveShadow>
              <boxGeometry args={[dims.w, Math.max(0.06, dims.h), dims.d]} />
              <BodyMaterial color={kind === 'distro' ? '#242b31' : '#1d2429'} metalness={0.45} roughness={0.45} />
            </mesh>
            {kind === 'outlet' ? (
              Array.from({ length: Math.max(1, Math.round(dims.w / 0.14)) }, (_, index) => (
                <mesh key={index} position={[-dims.w / 2 + 0.08 + index * 0.14, 0, dims.d / 2 + 0.004]}>
                  <boxGeometry args={[0.06, 0.04, 0.006]} />
                  <meshStandardMaterial color="#0d1114" metalness={0.2} roughness={0.6} />
                </mesh>
              ))
            ) : (
              <group>
                {Array.from({ length: 4 }, (_, index) => (
                  <mesh key={index} position={[-dims.w * 0.3 + index * dims.w * 0.2, dims.h * 0.22, dims.d / 2 + 0.004]}>
                    <boxGeometry args={[0.045, 0.028, 0.008]} />
                    <meshStandardMaterial color={index === 0 ? '#E8B40A' : '#30383f'} emissive={index === 0 ? '#E8B40A' : '#000000'} emissiveIntensity={index === 0 ? 0.7 : 0} />
                  </mesh>
                ))}
                {Array.from({ length: 4 }, (_, index) => (
                  <mesh key={`out-${index}`} position={[-dims.w * 0.3 + index * dims.w * 0.2, -dims.h * 0.24, dims.d / 2 + 0.004]}>
                    <cylinderGeometry args={[0.022, 0.022, 0.008, 16]} />
                    <meshStandardMaterial color="#0b0f12" metalness={0.3} roughness={0.5} />
                  </mesh>
                ))}
                <mesh position={[dims.w * 0.38, 0, dims.d / 2 + 0.006]}>
                  <boxGeometry args={[0.012, 0.05, 0.006]} />
                  <meshStandardMaterial color="#E8B40A" emissive="#E8B40A" emissiveIntensity={1.5} toneMapped={false} />
                </mesh>
              </group>
            )}
          </group>
        )}

        {computerDevice && (
          <group>
            <mesh position={[0, -dims.h * 0.15, 0]} castShadow>
              <boxGeometry args={[dims.w, Math.max(0.015, dims.h * 0.25), dims.d]} />
              <BodyMaterial color="#20272d" metalness={0.6} roughness={0.35} />
            </mesh>
            {kind === 'laptop' && (
              <mesh position={[0, dims.h * 0.28, -dims.d / 2 + 0.02]} rotation={[-0.18, 0, 0]}>
                <boxGeometry args={[dims.w * 0.92, dims.h * 0.55, 0.012]} />
                <meshStandardMaterial color="#0c1013" metalness={0.4} roughness={0.35} />
              </mesh>
            )}
            {kind === 'laptop' && (
              <mesh position={[0, dims.h * 0.29, -dims.d / 2 + 0.03]} rotation={[-0.18, 0, 0]}>
                <planeGeometry args={[dims.w * 0.82, dims.h * 0.44]} />
                <meshStandardMaterial color="#1b3f5e" emissive="#3b8fc4" emissiveIntensity={0.6} toneMapped={false} />
              </mesh>
            )}
            {kind !== 'laptop' && (
              <mesh position={[0, dims.h * 0.35, -dims.d * 0.3]}>
                <boxGeometry args={[dims.w * 0.16, dims.h * 0.6, dims.w * 0.16]} />
                <BodyMaterial color="#11161a" />
              </mesh>
            )}
          </group>
        )}

        {videoDevice && (
          <group>
            <mesh castShadow>
              <boxGeometry args={[dims.w, Math.max(0.05, dims.h), Math.max(0.04, dims.d)]} />
              <BodyMaterial color="#111519" metalness={0.35} roughness={0.55} />
            </mesh>
            <mesh position={[0, 0, dims.d / 2 + 0.004]}>
              <planeGeometry args={[dims.w * 0.965, Math.max(0.04, dims.h) * 0.9]} />
              {['ledwall', 'tv'].includes(kind) ? (
                <meshStandardMaterial map={screenTexture} emissiveMap={screenTexture} color="#d5dbe0" emissive="#687985" emissiveIntensity={kind === 'ledwall' ? 0.16 : 0.11} roughness={0.72} metalness={0.01} />
              ) : (
                <meshStandardMaterial color="#0b1820" emissive="#103a52" emissiveIntensity={0.35} toneMapped={false} />
              )}
            </mesh>
            {kind === 'tv' && Array.from({ length: 5 }, (_, index) => (
              <mesh key={index} position={[0, -Math.max(0.04, dims.h) * 0.32 + index * Math.max(0.04, dims.h) * 0.16, dims.d / 2 + 0.008]}>
                <boxGeometry args={[dims.w * 0.9, 0.002, 0.002]} />
                <meshStandardMaterial color="#1a5c7c" emissive="#1a5c7c" emissiveIntensity={0.4} toneMapped={false} />
              </mesh>
            ))}
          </group>
        )}

        {effectDevice && (
          <group>
            <mesh castShadow>
              <boxGeometry args={[dims.w, Math.max(0.1, dims.h), dims.d]} />
              <BodyMaterial color="#222a31" metalness={0.35} roughness={0.5} />
            </mesh>
            <mesh position={[0, 0, dims.d / 2 + 0.03]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[dims.w * 0.12, dims.w * 0.16, 0.06, 16]} />
              <BodyMaterial color="#141a1f" metalness={0.5} />
            </mesh>
            <mesh position={[dims.w * 0.32, -dims.h * 0.3, dims.d / 2 + 0.004]}>
              <boxGeometry args={[0.03, 0.012, 0.006]} />
              <meshStandardMaterial color="#E8B40A" emissive="#E8B40A" emissiveIntensity={0.8} toneMapped={false} />
            </mesh>
          </group>
        )}

        {!housing && !bar && !par && !furnitureDevice && !consoleDevice && !rackDevice && !powerDevice && !computerDevice && !videoDevice && !effectDevice && (
          <group>
            <mesh castShadow>
              <boxGeometry args={[Math.max(0.1, dims.w), Math.max(0.08, dims.h), Math.max(0.08, dims.d)]} />
              <BodyMaterial color="#2b343c" metalness={0.4} roughness={0.45} />
            </mesh>
          </group>
        )}

        {selected && (
          <>
            <mesh position={[0, 0.012 - y, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[Math.max(0.16, dims.w * 0.65), Math.max(0.2, dims.w * 0.75), 40]} />
              <meshBasicMaterial color="#E8B40A" transparent opacity={0.85} side={2} />
            </mesh>
            <mesh>
              <boxGeometry args={[dims.w * 1.18, dims.h * 1.3, dims.d * 1.18]} />
              <meshBasicMaterial color="#E8B40A" wireframe transparent opacity={0.28} />
            </mesh>
          </>
        )}
        {hovered && !selected && (
          <mesh position={[0, 0.01 - y, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[Math.max(0.14, dims.w * 0.6), Math.max(0.18, dims.w * 0.7), 32]} />
            <meshBasicMaterial color="#cfcbc3" transparent opacity={0.35} side={2} />
          </mesh>
        )}
      </group>

      {useConeFallback && light && ['light', 'effects'].includes(device?.category || '') && beamVisible && project.lighting.volumetric && object.visible && (
        optics.family === 'bar' ? (
          <BarBeams
            object={object}
            project={project}
            intensity={on ? intensity * (project.lighting.master || 0.9) : 0}
            haze={project.lighting.haze}
            visible={on}
          />
        ) : optics.family === 'panel' || optics.family === 'strobe' ? null : (
          <VolumetricBeam
            from={beamFrom}
            to={target}
            color={color}
            intensity={on ? intensity * (project.lighting.master || 0.9) : 0}
            haze={project.lighting.haze}
            fieldAngle={optics.fieldAngle}
            beamAngle={beamAngle}
            alpha={optics.alpha}
            coreAlpha={optics.coreAlpha}
            softness={optics.family === 'wash' ? 0.94 : optics.family === 'beam' ? 0.42 : 0.7}
            axialPower={optics.family === 'wash' ? 1.35 : optics.family === 'beam' ? 2.6 : 2.0}
            strobe={light?.strobe || 0}
            visible={on}
          />
        )
      )}
    </>
  );
}
