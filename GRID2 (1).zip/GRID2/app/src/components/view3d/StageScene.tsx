import { useEffect, useMemo } from 'react';
import { Color, DoubleSide, Mesh, MeshBasicMaterial, PlaneGeometry, Scene } from 'three';
import { useThree } from '@react-three/fiber';
import { ContactShadows } from '@react-three/drei';
import { PMREMGenerator } from 'three';
import { Bloom, BrightnessContrast, EffectComposer, HueSaturation, Noise, SSAO, ToneMapping, Vignette } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import type { Project } from '../../types/project';
import { getDevice } from '../../lib/catalog';
import { FixtureModel } from './FixtureModel';
import { FixtureLight } from './FixtureLight';
import { CurtainMesh, FurnitureMesh, RoomMesh, StageMesh, TrussMesh } from './StructureMeshes';
import { SeatingMesh } from './SeatingMesh';
import { VolumetricScattering } from './VolumetricScattering';
import { getQualityProfile } from '../../lib/renderQuality';

interface StageSceneProps {
  project: Project;
  selectedIds: string[];
  hoveredId: string | null;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
  onFocus: (id: string) => void;
  beamVisible: boolean;
}

function StudioEnvironment() {
  const { gl, scene } = useThree();
  useEffect(() => {
    const environmentScene = new Scene();
    environmentScene.background = new Color('#020304');
    const geometry = new PlaneGeometry(8, 6);
    const cards = [
      { color: new Color(1.9, 1.7, 1.4), position: [0, 8, 0] as [number, number, number], rotation: [Math.PI / 2, 0, 0] as [number, number, number] },
      { color: new Color(0.22, 0.24, 0.27), position: [-9, 3, -2] as [number, number, number], rotation: [0, Math.PI / 2, 0] as [number, number, number] },
      { color: new Color(0.28, 0.22, 0.18), position: [9, 3, -2] as [number, number, number], rotation: [0, -Math.PI / 2, 0] as [number, number, number] },
      { color: new Color(0.08, 0.08, 0.085), position: [0, 0, -8] as [number, number, number], rotation: [0, 0, 0] as [number, number, number] },
    ];
    const materials: MeshBasicMaterial[] = [];
    for (const card of cards) {
      const material = new MeshBasicMaterial({ color: card.color, toneMapped: false });
      materials.push(material);
      const mesh = new Mesh(geometry, material);
      mesh.position.set(...card.position);
      mesh.rotation.set(...card.rotation);
      environmentScene.add(mesh);
    }
    const pmrem = new PMREMGenerator(gl);
    pmrem.compileEquirectangularShader();
    const environment = pmrem.fromScene(environmentScene, 0.04);
    const previous = scene.environment;
    scene.environment = environment.texture;
    scene.environmentIntensity = 0.16;
    return () => {
      scene.environment = previous;
      scene.environmentIntensity = 1;
      environment.dispose();
      geometry.dispose();
      materials.forEach((material) => material.dispose());
      pmrem.dispose();
    };
  }, [gl, scene]);
  return null;
}

export function StageScene({ project, selectedIds, hoveredId, onSelect, onHover, onFocus, beamVisible }: StageSceneProps) {
  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const { gl } = useThree();
  gl.toneMappingExposure = Math.min(1.8, Math.max(0.55, project.lighting.exposure));
  const fixtures = project.objects.filter((object) => object.type === 'device' && object.visible);
  let lightIndex = 0;
  const work = project.lighting.workLight;
  const quality = getQualityProfile(project.lighting.quality);
  const layoutKey = useMemo(() => project.objects.map((object) => `${object.id}:${object.visible}:${object.position.x.toFixed(2)},${object.position.z.toFixed(2)},${object.rotation},${object.elevation?.toFixed(2) || 0},${object.size?.w?.toFixed(2) || 0},${object.size?.h?.toFixed(2) || 0}`).join('|'), [project.objects]);

  return (
    <>
      <color attach="background" args={['#050607']} />
      <fog attach="fog" args={['#08090b', 26, 78]} />

      <ambientLight intensity={work ? 0.2 + project.lighting.ambient * 0.25 : 0.11 + project.lighting.ambient * 0.06} color="#b9c1cb" />
      <hemisphereLight args={['#9cabbc', '#111315', work ? 0.22 : 0.09]} />
      <directionalLight position={[7, 11, 9]} intensity={work ? 0.5 : 0.16} color="#dce6f2" castShadow={work && project.lighting.quality === 'high'} shadow-mapSize={[1024, 1024]} />
      <directionalLight position={[-6, 7, -6]} intensity={work ? 0.16 : 0.07} color="#8095ad" />

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]} receiveShadow>
        <planeGeometry args={[90, 90]} />
        <meshStandardMaterial color="#0a0b0c" roughness={0.96} metalness={0.02} side={DoubleSide} />
      </mesh>
      <gridHelper args={[60, 120, '#1c1f22', '#121416']} position={[0, -0.008, 0]} />

      {project.objects.filter((object) => object.visible && object.type === 'room').map((object) => (
        <RoomMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />
      ))}
      {project.objects.filter((object) => object.visible && object.type === 'stage').map((object) => {
        const device = getDevice(object.deviceId);
        if (device?.kind === 'curtain') {
          return <CurtainMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />;
        }
        return <StageMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />;
      })}
      {project.objects.filter((object) => object.visible && object.type === 'truss').map((object) => (
        <TrussMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />
      ))}
      {project.objects.filter((object) => object.visible && object.type === 'furniture').map((object) => (
        <FurnitureMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />
      ))}
      {project.objects.filter((object) => object.visible && object.type === 'seating').map((object) => (
        <SeatingMesh key={object.id} object={object} project={project} selected={selectedSet.has(object.id)} onSelect={onSelect} onHover={onHover} />
      ))}

      {fixtures.map((object) => {
        const device = getDevice(object.deviceId);
        return (
          <FixtureModel
            key={object.id}
            object={object}
            device={device}
            project={project}
            selected={selectedSet.has(object.id)}
            hovered={hoveredId === object.id}
            beamVisible={beamVisible}
            onSelect={onSelect}
            onHover={onHover}
            onFocus={onFocus}
          />
        );
      })}

      {project.objects.filter((object) => object.visible && object.type === 'device' && object.light).map((object) => {
        const index = lightIndex++;
        return <FixtureLight key={`light-${object.id}`} project={project} object={object} index={index} />;
      })}

      <StudioEnvironment />
      {quality.contactShadows && beamVisible && (
        <ContactShadows key={layoutKey} position={[0, 0.012, 0]} scale={20} blur={2.4} far={2.2} opacity={0.5} resolution={512} frames={1} color="#000000" />
      )}
      <EffectComposer key={quality.contactShadows ? 'ao' : 'no-ao'} multisampling={quality.msaa} enableNormalPass={quality.contactShadows}>
        {quality.contactShadows && (
          <SSAO samples={10} rings={4} radius={0.12} intensity={1.35} distanceThreshold={1.2} rangeThreshold={0.4} luminanceInfluence={0.35} resolutionScale={0.55} />
        )}
        {quality.raymarch && project.lighting.volumetric && (
          <VolumetricScattering project={project} beamVisible={beamVisible} />
        )}
        {quality.bloom && (
          <Bloom intensity={Math.min(0.3, project.lighting.bloom * 0.6)} luminanceThreshold={0.88} luminanceSmoothing={0.3} mipmapBlur />
        )}
        <ToneMapping mode={ToneMappingMode.AGX} />
        <HueSaturation saturation={0.12} />
        <BrightnessContrast contrast={0.08} />
        <Vignette offset={0.24} darkness={0.5} />
        <Noise opacity={0.018} premultiply />
      </EffectComposer>
    </>
  );
}
