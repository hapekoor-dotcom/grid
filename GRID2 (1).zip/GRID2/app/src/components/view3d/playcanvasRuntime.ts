import * as pc from 'playcanvas';
import { CameraControls } from 'playcanvas/scripts/esm/camera-controls.mjs';
import type { CustomShader, MaterialMapKind, MaterialTextureLayer, ObjectMaterial, Project, SceneObject, ShaderInstance } from '../../types/project';
import { getAsset } from '../../lib/assetStore';
import { MATERIAL_MAP_BY_KIND, MATERIAL_MAP_DEFINITIONS, type MaterialSourceSlotInfo } from '../../lib/materialMaps';
import { getDevice } from '../../lib/catalog';
import { objectDims } from '../../lib/objects';
import { fixtureAimPoint, fixtureMountY, getRoomBounds, getStageCenter } from '../../lib/stage3d';
import { barEmitter, opticalProfile } from '../../lib/lightOptics';
import areaLightLuts from '../../data/area-light-luts.json';
import { loadIesCookies, type CookieSet } from './playcanvasCookies';
import { clampOverdrive } from '../../lib/overdrive';
import { antiAliasingFor } from '../../lib/renderQuality';
import type { SceneModifier } from '../../types/project';
import { modifierDefinition } from '../../lib/modifiers';
import { effectiveModifiers, findSignal, modulatedParams, signalValue } from '../../lib/signals';
import { compileModifierOrder } from '../../lib/graphRouting';
import { compileExecutionPlan, executionOrderedModifiers } from '../../lib/modifiers';
import { reactionConsumers } from '../../lib/reactionConsumers';
import { impactDecay, normalizePhysics, setPhysicsSignalState } from '../../lib/physics';
import { RendererPostEffect, type RendererPostDiagnostics } from './RendererPostEffect';
import { setReactionSampleProvider } from '../../lib/reactionField';
import { ReactionDiffusionRuntime, type ReactionDiffusionDiagnostics } from './ReactionDiffusionRuntime';
import { buildCustomEmissiveChunk, buildCustomVertexChunk, compileCustomShader, customShadersForObject } from '../../lib/customShaders';
import type * as CANNON from 'cannon-es';
import { setTimelineRange, getTimelineTime } from '../../lib/timelineClock';
import { applyTimelineToProject, sampleTimeline } from '../../lib/timeline';
import { EFFECT_EMISSIVE_CHUNK, EFFECT_GLOSS_CHUNK, EFFECT_METALNESS_CHUNK, EFFECT_OPACITY_CHUNK, EFFECT_VERTEX_CHUNK } from './modifierShader';

type ViewPreset = 'perspective' | 'top' | 'front' | 'side';

interface RuntimeCallbacks {
  onSelect: (id: string | null, additive?: boolean) => void;
  onSelectMany?: (ids: string[], additive: boolean, subtractive: boolean) => void;
  onFocus: (id: string) => void;
  onGizmoTransform: (id: string, patch: Partial<SceneObject>, commit: boolean) => void;
  onGizmoMultiTransform?: (patches: { id: string; patch: Partial<SceneObject> }[], commit: boolean) => void;
  onError: (error: Error) => void;
  onReady?: () => void;
  onAssetError?: (message: string) => void;
  onAssetMaterials?: (assetId: string, names: string[]) => void;
  onAssetMaterialMaps?: (assetId: string, slots: MaterialSourceSlotInfo[]) => void;
  onMeshCapabilities?: (capabilities: Record<string, { uv0: boolean; uv1: boolean; normals: boolean; tangents: boolean; colors: boolean }>) => void;
}

interface PickTarget {
  id: string;
  center: pc.Vec3;
  size: pc.Vec3;
}

type AnyEntity = pc.Entity & { __rid?: string };
type InputOwner = 'NONE' | 'SELECT' | 'SELECT_MARQUEE' | 'GIZMO' | 'CAMERA' | 'TIMELINE' | 'PANEL_RESIZE' | 'UI';
type InputDebugEvent = { at: number; type: string; detail: string };

const DOWN = new pc.Vec3(0, -1, 0);
const UP = new pc.Vec3(0, 1, 0);

function colorFrom(hex: string, intensity = 1): pc.Color {
  const color = new pc.Color();
  color.fromString(hex || '#ffffff');
  if (intensity !== 1) color.mulScalar(intensity);
  return color;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function disposeEntity(entity: pc.Entity): void {
  entity.destroy();
}

export class PlayCanvasRuntime {
  private app: pc.AppBase | null = null;
  private device: pc.GraphicsDevice | null = null;
  private camera: pc.Entity | null = null;
  private cameraFrame: pc.CameraFrame | null = null;
  private ditherEffect: pc.CameraFrameEffect | null = null;
  private cameraControls: any = null;
  private cameraInputBlocked = false;
  private gizmoLayer: pc.Layer | null = null;
  private translateGizmo: pc.TranslateGizmo | null = null;
  private rotateGizmo: pc.RotateGizmo | null = null;
  private scaleGizmo: pc.ScaleGizmo | null = null;
  private gizmoDragging = false;
  private gizmoMode: 'select' | 'move' | 'rotate' | 'scale' = 'select';
  private gizmoFrame = 0;
  private gizmoPivot: pc.Entity | null = null;
  private multiGizmoStart: {
    pivotPosition: pc.Vec3; pivotQuaternion: pc.Quat; pivotScale: pc.Vec3;
    items: { id: string; root: pc.Entity; startPosition: pc.Vec3; startRotation: pc.Quat; startScale: pc.Vec3; object: SceneObject }[];
  } | null = null;
  private gizmoStart: {
    id: string; root: pc.Entity; position: { x: number; z: number }; elevation: number;
    rotation: number; rotationX: number; rotationZ: number; scale: { x: number; y: number; z: number };
    rootPosition: pc.Vec3; rootEuler: pc.Vec3;
  } | null = null;
  private world: pc.Entity | null = null;
  private lightsRoot: pc.Entity | null = null;
  private geometrySignature = '';
  private lightSignature = '';
  private deviceLightNodes = new Map<string, pc.Entity>();
  private genericLightSources = new Map<string, pc.Entity>();
  private genericLightLenses = new Map<string, pc.StandardMaterial>();
  private primitiveNodes = new Map<string, pc.Entity>();
  private motionRoots = new Map<string, pc.Entity>();
  private animTime = 0;
  private timelineApplied = false;
  private timelineProject: Project | null = null;
  private animatedModifierIds = new Set<string>();
  private shaderEffectTargets = new Map<string, { mesh: pc.MeshInstance; source: pc.Material; customSignature?: string }[]>();
  private effectTextures = new Map<string, pc.Texture>();
  private physicsWorld: CANNON.World | null = null;
  private physicsNamespace: typeof import('cannon-es') | null = null;
  private physicsBodies = new Map<string, { body: CANNON.Body; entity: pc.Entity; shape: pc.Entity }>();
  private physicsSignature = '';
  private sceneBounds = new pc.BoundingBox();
  private sceneRadius = 10;
  private physicsLoading = false;
  private physicsResetToken = -1;
  private physicsStepToken = -1;
  private effectTexturePending = new Set<string>();
  private radialClones = new Map<string, { signature: string; clones: pc.Entity[] }>();
  private fallbackEffectTexture: pc.Texture | null = null;
  private materialTargets = new Map<string, { mesh: pc.MeshInstance; source: pc.Material; slot: string }[]>();
  private materialSignature = '';
  private areaLightSources = new Map<string, pc.Entity>();
  private areaLightLenses = new Map<string, pc.StandardMaterial>();
  private picker: pc.Picker | null = null;
  private marquee: { startX: number; startY: number; currentX: number; currentY: number; pointerId: number; additive: boolean; subtractive: boolean } | null = null;
  private marqueeElement: HTMLDivElement | null = null;
  private hoverId: string | null = null;
  private hoverMarker: pc.Entity | null = null;
  private pickMethod = 'none';
  private pickSource = 'none';
  private selection: pc.Entity | null = null;
  private project: Project | null = null;
  private callbacks: RuntimeCallbacks;
  private canvas: HTMLCanvasElement;
  private resizeObserver: ResizeObserver | null = null;
  private pickTargets: PickTarget[] = [];
  private selectedIds: string[] = [];
  private viewInitialized = false;
  private floorVisible = true;
  private objectRoots = new Map<string, pc.Entity>();
  private modelBodyRoots = new Map<string, pc.Entity>();
  private modelAssets = new Map<string, { template: pc.Entity; center: pc.Vec3; minY: number; size: pc.Vec3; materials: string[] }>();
  private modelLoading = new Set<string>();
  private roomBounds: { minX: number; maxX: number; minZ: number; maxZ: number; height: number } | null = null;
  private wallNodes: pc.Entity[] = [];
  private floorNode: pc.Entity | null = null;
  private blockerLayer: pc.Layer | null = null;
  private softwareRenderer = false;
  private testMode = false;
  private noFog = false;
  private noGlow = false;
  private legacyPerfProfile = false;
  private chairTemplate: pc.Entity | null = null;
  private headTemplate: pc.Entity | null = null;
  private trussTemplate: pc.Entity | null = null;
  private stageTemplate: pc.Entity | null = null;
  private soundTemplate: pc.Entity | null = null;
  private soundBounds: { center: pc.Vec3; minY: number; size: pc.Vec3 } | null = null;
  private stageBounds: { center: pc.Vec3; minY: number; size: pc.Vec3 } | null = null;
  private barTemplate: pc.Entity | null = null;
  private chairScale = 1;
  private chairMinY = 0;
  private cookies: CookieSet | null = null;
  private textures: { floorColor?: pc.Texture; floorNormal?: pc.Texture; floorRough?: pc.Texture; wallColor?: pc.Texture } = {};
  private ownedMaterials: pc.Material[] = [];
  private textureCache = new Map<string, pc.Texture>();
  private textureLoading = new Set<string>();
  private destroyed = false;
  private target = new pc.Vec3();
  private yaw = 0.22;
  private pitch = 0.34;
  private distance = 13;
  private pointer = { x: 0, y: 0, moved: 0, button: -1, active: false };
  private lastPointer = { x: 0, y: 0 };
  private pointerReleased = true;
  private interactionOwner: InputOwner = 'NONE';
  private activePointerId: number | null = null;
  private pressedButtons = 0;
  private flyKeys = new Set<string>();
  private navigationMode: 'orbit' | 'fly' = 'orbit';
  private inputEvents: InputDebugEvent[] = [];
  private debugVisibilityHandler: (() => void) | null = null;
  private debugEscapeHandler: ((event: KeyboardEvent) => void) | null = null;
  private renderPending = false;
  private syncDebug = { change: 'none', dirty: 'NONE', updated: false, renderRequested: false, action: 'none', rebuild: false, materialSync: false, shaderSync: false };
  private rendererInfo = { gpu: 'Unknown GPU', vendor: 'Unknown', backend: 'WebGL 2', api: 'Unknown', detailed: false };
  private rendererInfoReady = false;
  private aaMode: 'off' | 'msaa' | 'taa' = 'off';
  private qualitySignature = '';
  private fogSignature = '';
  private postEffect: RendererPostEffect | null = null;
  private rd: ReactionDiffusionRuntime | null = null;
  private rdFallback: pc.Texture | null = null;
  private lastGeoOps: number[] = [];
  private lastNoiseStrength = 0;
  private springStates = new Map<string, { x: number; y: number; z: number; vx: number; vy: number; vz: number }>();
  private reactionPaintMode = false;
  private rdDiagnostics: ReactionDiffusionDiagnostics = { enabled: false, valid: false, width: 0, height: 0, steps: 0, resets: 0, lastResetReason: 'none', texture: null };
  private lastCameraAction = 'none';
  private cameraDistanceBefore = 0;
  private cameraDistanceAfter = 0;
  private focusBoundsRadius = 0;
  private focusTarget = 'none';
  private postDiagnostics: RendererPostDiagnostics = { active: false, passes: 0, sceneFormat: 'none', depth: false, history: false, width: 0, height: 0, bypassed: 0, error: '', historyStates: [], outputFormat: 'RGBA16F', stage: 'resolveScene', registrations: 1 };
  private taaHistoryResets = 0;
  private taaLastResetReason = 'none';

  constructor(canvas: HTMLCanvasElement, callbacks: RuntimeCallbacks) {
    this.canvas = canvas;
    this.callbacks = callbacks;
  }

  async init(): Promise<void> {
    try {
      const device = await pc.createGraphicsDevice(this.canvas, {
        deviceTypes: [pc.DEVICETYPE_WEBGL2],
        antialias: true,
        alpha: false,
        depth: true,
        displayFormat: pc.DISPLAYFORMAT_HDR,
        powerPreference: 'high-performance',
        // PlayCanvas' public type omits this WebGL context flag, but the
        // WebGL2 device forwards it to getContext.
        ...({ preserveDrawingBuffer: true } as object),
      });
      if (this.destroyed) {
        device.destroy();
        return;
      }
      this.device = device;
      device.maxPixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
      const gl = (device as unknown as { gl?: WebGL2RenderingContext }).gl;
      const deviceType = String((device as unknown as { deviceType?: string }).deviceType || '');
      if (deviceType === pc.DEVICETYPE_WEBGPU) {
        const adapter = (device as unknown as { _adapter?: GPUAdapter; adapter?: GPUAdapter; gpuAdapter?: GPUAdapter })._adapter
          || (device as unknown as { adapter?: GPUAdapter }).adapter
          || (device as unknown as { gpuAdapter?: GPUAdapter }).gpuAdapter;
        const info = adapter?.info as (GPUAdapterInfo & { description?: string }) | undefined;
        this.rendererInfo = {
          gpu: info?.description || info?.device || info?.architecture || 'WebGPU adapter',
          vendor: info?.vendor || 'Unknown',
          backend: 'WebGPU',
          api: info?.architecture || 'WebGPU',
          detailed: !!(info?.description || info?.device),
        };
      } else {
        const debugInfo = gl?.getExtension('WEBGL_debug_renderer_info');
        const unmaskedRenderer = debugInfo ? String(gl?.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || '') : '';
        const unmaskedVendor = debugInfo ? String(gl?.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || '') : '';
        const fallbackRenderer = String(gl?.getParameter(gl.RENDERER) || '');
        const fallbackVendor = String(gl?.getParameter(gl.VENDOR) || '');
        const rendererName = unmaskedRenderer || fallbackRenderer;
        this.rendererInfo = {
          gpu: rendererName || 'Detailed GPU info unavailable',
          vendor: unmaskedVendor || fallbackVendor || 'Detailed GPU info unavailable',
          backend: gl ? 'WebGL 2' : 'WebGL',
          api: /ANGLE/i.test(rendererName) ? (/Direct3D/i.test(rendererName) ? 'ANGLE / Direct3D' : /Metal/i.test(rendererName) ? 'ANGLE / Metal' : 'ANGLE / OpenGL') : rendererName || 'Unknown',
          detailed: !!unmaskedRenderer,
        };
        this.softwareRenderer = /swiftshader|llvmpipe|software/i.test(rendererName);
      }
      this.rendererInfoReady = true;
      const params = new URLSearchParams(window.location.search);
      this.testMode = params.has('lighttest');
      this.noFog = params.get('fog') === '0';
      this.noGlow = params.get('glow') === '0';
      this.legacyPerfProfile = params.get('perf') === 'legacy';

      const options = new pc.AppOptions();
      options.graphicsDevice = device;
      options.componentSystems = [
        pc.RenderComponentSystem,
        pc.CameraComponentSystem,
        pc.LightComponentSystem,
        pc.ScriptComponentSystem,
      ];
      options.resourceHandlers = [pc.TextureHandler, pc.ContainerHandler, pc.JsonHandler, pc.ScriptHandler];
      const app = new pc.AppBase(this.canvas);
      app.init(options);
      this.app = app;
      app.setCanvasFillMode(pc.FILLMODE_NONE);
      app.setCanvasResolution(pc.RESOLUTION_AUTO);
      app.scene.lighting.cells = new pc.Vec3(30, 2, 30);
      app.scene.lighting.maxLightsPerCell = 64;
      app.scene.lighting.areaLightsEnabled = true;
      app.scene.lighting.shadowsEnabled = true;
      app.scene.lighting.cookiesEnabled = true;
      app.scene.ambientLight = new pc.Color(0.088, 0.092, 0.1);
      app.scene.exposure = 1.5;
      const blockerLayer = new pc.Layer({ name: 'LightBlockers' });
      app.scene.layers.insert(blockerLayer, 1);
      this.blockerLayer = blockerLayer;

      const camera = new pc.Entity('camera');
      camera.addComponent('camera', {
        clearColor: new pc.Color(0, 0, 0),
        layers: [pc.LAYERID_WORLD],
        fov: 50,
        nearClip: 0.08,
        farClip: 180,
      });
      app.root.addChild(camera);
      camera.setPosition(0, 3, 9);
      this.camera = camera;

      // Official CameraControls script, configured as standard orbit / pan / zoom navigation.
      camera.addComponent('script');
      const cameraControls = camera.script?.create(CameraControls, {
        properties: {
          focusPoint: new pc.Vec3(0, 1, 0),
          enableOrbit: true,
          enableFly: false,
          enablePan: true,
          leftButton: 'none',
          middleButton: 'orbit',
          rightButton: 'orbit',
          rotateSpeed: 0.2,
          rotateDamping: 0.72,
          moveDamping: 0.8,
          zoomDamping: 0.8,
        },
      });
      this.cameraControls = cameraControls;

      // Official transform gizmos, sharing one render layer.
      const gizmoLayer = pc.Gizmo.createLayer(app);
      this.gizmoLayer = gizmoLayer;
      this.translateGizmo = new pc.TranslateGizmo(camera.camera!, gizmoLayer);
      this.rotateGizmo = new pc.RotateGizmo(camera.camera!, gizmoLayer);
      this.scaleGizmo = new pc.ScaleGizmo(camera.camera!, gizmoLayer);
      for (const gizmo of [this.translateGizmo, this.rotateGizmo, this.scaleGizmo]) {
        this.restrictGizmoPointerDown(gizmo);
        gizmo.on('transform:start', () => this.onGizmoStart());
        gizmo.on('transform:move', () => this.onGizmoMove());
        gizmo.on('transform:end', () => this.onGizmoEnd());
        gizmo.on('pointer:down', (_x: number, _y: number, meshInstance: pc.MeshInstance | null) => {
          if (meshInstance) this.setCameraInputBlocked(true);
        });
        gizmo.on('pointer:up', () => {
          // The library keeps its pointer id after pointerup. Clear it so a later
          // plain click cannot be mistaken for the tail of this gizmo drag.
          const internal = gizmo as unknown as { _pointerId?: number };
          if (typeof internal._pointerId === 'number') internal._pointerId = -1;
          // Do not clear our click state or unlock the camera here; transform:end
          // owns that transition.
          this.pointerReleased = true;
        });
        gizmo.detach();
      }

      const frame = new pc.CameraFrame(app, camera.camera!);
      this.cameraFrame = frame;
      this.rdFallback = new pc.Texture(device, { name: 'RD fallback', width: 1, height: 1, format: pc.PIXELFORMAT_RGBA8, mipmaps: false });
      try { this.rdFallback.upload(); } catch { /* default black texture */ }
      this.rd = new ReactionDiffusionRuntime(device);
      setReactionSampleProvider((output) => this.rd?.sampleOutput(output) || 0);
      this.postEffect = new RendererPostEffect(device, (value) => { this.postDiagnostics = value; });
      frame.addEffect(this.postEffect);
      frame.rendering.toneMapping = pc.TONEMAP_ACES;
      frame.rendering.renderTargetScale = 1;
      frame.taa.enabled = false;
      frame.bloom.intensity = 0.012;
      frame.bloom.threshold = 0.95;
      frame.colorEnhance.enabled = true;
      frame.colorEnhance.shadows = -0.02;
      frame.colorEnhance.highlights = 0.06;
      frame.colorEnhance.midtones = 0.08;
      frame.colorEnhance.vibrance = 0.06;
      frame.colorEnhance.dehaze = 0.04;
      frame.grading.enabled = false;
      frame.ssao.type = pc.SSAOTYPE_NONE;
      frame.vignette.intensity = 0.14;
      frame.rendering.sharpness = 0.3;
      frame.volumetricFog.enabled = true;
      frame.volumetricFog.localSpotLights = true;
      frame.volumetricFog.localOmniLights = false;
      frame.volumetricFog.steps = 16;
      frame.volumetricFog.localSteps = 8;
      frame.volumetricFog.scale = 0.7;
      frame.volumetricFog.maxDistance = 45;
      frame.volumetricFog.heightBase = 0;
      frame.volumetricFog.heightFalloff = 0.04;
      frame.volumetricFog.extinction = 1;
      app.scene.lighting.shadowAtlasResolution = 2048;
      app.scene.lighting.cookieAtlasResolution = 1024;
      frame.volumetricFog.ambientColor = new pc.Color(0.08, 0.11, 0.16);
      frame.volumetricFog.ambientIntensity = 0.014;
      // Prefer a true 16-bit HDR intermediate. CameraFrame allocates this on its
      // first graph build, so set it before enabling/updating the frame.
      frame.rendering.renderFormats = [pc.PIXELFORMAT_RGBA16F, pc.PIXELFORMAT_RG11B10F, pc.PIXELFORMAT_RGBA8];
      this.ditherEffect = new pc.CameraFrameEffect(device, 'redither', {
        slot: pc.COMPOSESLOT_OUTPUT,
        glsl: `
          uniform float uDitherStrength;
          uniform float uDitherTime;
          float reditherNoise(vec2 p) {
            return fract(sin(dot(p + uDitherTime, vec2(12.9898, 78.233))) * 43758.5453);
          }
          vec3 applyRedither(vec3 color, vec2 uv) {
            float n = reditherNoise(gl_FragCoord.xy) - 0.5;
            return color + n * (uDitherStrength / 255.0);
          }
        `,
      });
      this.ditherEffect.setUniform('uDitherStrength', 1);
      this.ditherEffect.setUniform('uDitherTime', 0);
      frame.addEffect(this.ditherEffect);
      frame.update();

      try {
        this.cookies = await loadIesCookies(device);
      } catch {
        this.cookies = null;
      }
      await this.loadMaterialTextures();
      app.on('update', (dt: number) => { this.applyTimeline(dt); this.rd?.update(this.timelineProject || this.project || ({} as Project), dt, this.animTime + dt); this.rdDiagnostics = this.rd?.diagnostics || this.rdDiagnostics; this.postEffect?.setReactionTexture(this.rd?.texture || null); if (!this.timelineApplied) this.applyModifiers(dt); this.applySceneEffectStack(dt); this.updatePhysics(dt); this.updateFlyMovement(dt); this.updateCameraRange(); });
      app.start();
      app.setAreaLightLuts(areaLightLuts.LTC_MAT_1, areaLightLuts.LTC_MAT_2);
      this.setupInput();
      window.addEventListener('blur', this.clearCameraInput);
      document.addEventListener('focusin', this.onFocusIn);
      document.addEventListener('focusout', this.onFocusOut);
      this.loadChairTemplate();
      this.loadPropTemplates();
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(this.canvas.parentElement || this.canvas);
      window.addEventListener('resize', this.resize);
      this.resize();
      this.callbacks.onReady?.();
    } catch (error) {
      this.callbacks.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }

  private textureThumbnail(texture: pc.Texture | null | undefined): string | undefined {
    try {
      const resource = texture?.getSource?.() as CanvasImageSource | undefined;
      if (!resource) return undefined;
      const canvas = document.createElement('canvas');
      canvas.width = 48;
      canvas.height = 48;
      const context = canvas.getContext('2d');
      if (!context) return undefined;
      context.drawImage(resource, 0, 0, 48, 48);
      return canvas.toDataURL('image/jpeg', 0.7);
    } catch {
      return undefined;
    }
  }

  private async loadMaterialTextures(): Promise<void> {
    try {
      const loadImage = async (url: string): Promise<HTMLImageElement> => {
        const image = new Image();
        image.decoding = 'async';
        image.src = url;
        await image.decode();
        return image;
      };
      const [floorColorImage, floorNormalImage, floorRoughImage, wallColorImage] = await Promise.all([
        loadImage('/assets/materials/metal-plates/color.webp'),
        loadImage('/assets/materials/metal-plates/normal.webp'),
        loadImage('/assets/materials/metal-plates/roughness.webp'),
        loadImage('/assets/materials/wall-painted-color.jpg'),
      ]);
      const colorTexture = (source: HTMLImageElement, srgb = false): pc.Texture => {
        const map = new pc.Texture(this.device!, {
          width: source.naturalWidth,
          height: source.naturalHeight,
          mipmaps: true,
          minFilter: pc.FILTER_LINEAR_MIPMAP_LINEAR,
          magFilter: pc.FILTER_LINEAR,
          addressU: pc.ADDRESS_REPEAT,
          addressV: pc.ADDRESS_REPEAT,
          srgb,
        });
        map.setSource(source);
        map.upload();
        return map;
      };
      this.textures = { floorColor: colorTexture(floorColorImage, true), floorNormal: colorTexture(floorNormalImage), floorRough: colorTexture(floorRoughImage), wallColor: colorTexture(wallColorImage, true) };
    } catch {
      this.textures = {};
    }
  }

  private loadChairTemplate(): void {
    if (!this.app) return;
    this.app.assets.loadFromUrl('/assets/fixtures/event-chair.glb', 'container', (error, asset) => {
      if (error || !asset?.resource) return;
      try {
        const template = asset.resource.instantiateRenderEntity({ castShadows: true, receiveShadows: true });
        const bounds = new pc.BoundingBox();
        template.findComponents('render').forEach((render) => {
          render.meshInstances.forEach((mesh) => bounds.add(mesh.aabb));
        });
        const size = bounds.halfExtents.clone().mulScalar(2);
        const maxHorizontal = Math.max(size.x, size.z, 0.2);
        this.chairTemplate = template;
        this.chairScale = 0.55 / maxHorizontal;
        this.chairMinY = bounds.center.y - bounds.halfExtents.y;
        if (this.project && this.world) this.rebuild(this.project);
      } catch {
        this.chairTemplate = null;
      }
    });
  }

  private loadPropTemplates(): void {
    if (!this.app) return;
    const load = (url: string, assign: (template: pc.Entity, asset: pc.Asset) => void) => {
      this.app!.assets.loadFromUrl(url, 'container', (error, asset) => {
        if (error || !asset?.resource) return;
        try {
          const template = asset.resource.instantiateRenderEntity({ castShadows: true, receiveShadows: true });
          assign(template, asset);
          if (this.project && this.world) this.rebuild(this.project);
        } catch {
          // Keep the primitive fallback when a prop asset cannot be instanced.
        }
      });
    };
    load('/assets/models/motorised-spotlight.glb', (template) => { this.headTemplate = template; });
    load('/assets/models/simple-truss.glb', (template) => { this.trussTemplate = template; });
    load('/assets/models/ubl12h.glb', (template) => { this.barTemplate = template; });
    load('/assets/models/sound-booth.glb', (template) => {
      this.soundBounds = {
        center: new pc.Vec3(1.454, 1.084, -1.422),
        minY: 0,
        size: new pc.Vec3(0.752, 2.168, 0.598),
      };
      this.soundTemplate = template;
    });
    load('/assets/models/abstract-loop.glb', (template, asset) => {
      // Abstract loop sculpture supplied for the stage. The bounds are the
      // authored world bounds from the GLB inspector.
      this.stageBounds = {
        center: new pc.Vec3(0.4182, -0.0152, 0.0015),
        minY: -3.5001,
        size: new pc.Vec3(6.6299, 6.9697, 3.4642),
      };
      this.stageTemplate = template;
    });
  }

  registerModelAsset(assetId: string, url: string): void {
    if (!this.app || this.modelAssets.has(assetId) || this.modelLoading.has(assetId)) return;
    this.modelLoading.add(assetId);
    this.app.assets.loadFromUrl(url, 'container', (error, asset) => {
      this.modelLoading.delete(assetId);
      if (error || !asset?.resource) {
        this.callbacks.onAssetError?.('The imported model could not be decoded.');
        return;
      }
      try {
        const template = asset.resource.instantiateRenderEntity({ castShadows: true, receiveShadows: true });
        const bounds = new pc.BoundingBox();
        template.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => bounds.add(mesh.aabb)));
        const materialNames: string[] = [];
        const materialSources: { name: string; material: any }[] = [];
        const seen = new Set<unknown>();
        template.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => {
          const material = mesh.material as unknown as { name?: string };
          if (seen.has(material)) return;
          seen.add(material);
          const name = (material?.name?.trim() || `Material ${materialNames.length + 1}`).replace(/-flatShaded$/i, '');
          materialNames.push(name);
          if (material) materialSources.push({ name, material });
        }));
        this.modelAssets.set(assetId, {
          template,
          center: bounds.center.clone(),
          minY: bounds.halfExtents.y - bounds.center.y,
          size: new pc.Vec3(Math.max(0.001, bounds.halfExtents.x * 2), Math.max(0.001, bounds.halfExtents.y * 2), Math.max(0.001, bounds.halfExtents.z * 2)),
          materials: materialNames,
        });
        this.callbacks.onAssetMaterials?.(assetId, materialNames);
        this.callbacks.onAssetMaterialMaps?.(assetId, materialSources.map(({ name, material }) => ({
          slot: name,
          maps: Object.fromEntries(MATERIAL_MAP_DEFINITIONS.map((definition) => {
            const texture = material[definition.property] as pc.Texture | null;
            const thumbnail = this.textureThumbnail(texture);
            return [definition.kind, { present: !!texture, ...(thumbnail ? { thumbnail } : {}) }];
          })),
        })));
        if (this.project && this.world) this.rebuild(this.project);
      } catch {
        this.callbacks.onAssetError?.('The imported model could not be instantiated.');
      }
    });
  }

  setTransformMode(mode: 'select' | 'move' | 'rotate' | 'scale'): void {
    this.resetPointerInteraction('tool-change');
    this.gizmoMode = mode;
    this.syncGizmo();
  }

  setReactionPaintMode(enabled: boolean): void { this.reactionPaintMode = enabled; this.resetPointerInteraction('rd-paint-mode'); }

  paintReaction(clientX: number, clientY: number): void {
    if (!this.rd || !this.project?.reactionDiffusion?.enabled) return;
    const rect = this.canvas.getBoundingClientRect();
    const u = Math.max(0, Math.min(1, (clientX - rect.left) / Math.max(1, rect.width)));
    const v = Math.max(0, Math.min(1, 1 - (clientY - rect.top) / Math.max(1, rect.height)));
    const config = this.project.reactionDiffusion;
    this.rd.paint(u, v, Number(config.injectionRadius ?? 0.12), Math.max(0.01, Number(config.injection ?? 1)), config.paintChemical || 'B');
    this.requestRender();
  }

  setFloorVisible(visible: boolean): void {
    if (visible === this.floorVisible) return;
    this.floorVisible = visible;
    const room = this.project?.objects.find((object) => object.type === 'room');
    const roomVisible = !room || (room.visible && room.modelVisible !== false);
    if (this.floorNode) this.floorNode.enabled = roomVisible && visible;
    this.syncDebug = { change: 'room.floor.visible', dirty: 'VISIBILITY', updated: true, renderRequested: false, action: `floorNode.enabled = ${roomVisible && visible}`, rebuild: false, materialSync: false, shaderSync: false };
    this.requestRender();
  }

  private resetTaaHistory(reason: string): void {
    if (this.aaMode !== 'taa' || !this.cameraFrame?.taa.enabled) return;
    this.taaHistoryResets += 1;
    this.taaLastResetReason = reason;
    // CameraFrame does not expose a public history reset in this PlayCanvas
    // version. Recreating the TAA passes is the supported way to drop history.
    try {
      if (this.cameraFrame?.taa.enabled) {
        this.cameraFrame.taa.enabled = false;
        this.cameraFrame.taa.enabled = true;
        this.cameraFrame.update();
      }
    } catch { /* history reset is best effort */ }
  }

  private resize(): void {
    if (!this.app) return;
    const previousWidth = this.canvas.width;
    const previousHeight = this.canvas.height;
    this.app.resizeCanvas();
    if (previousWidth && previousHeight && (Math.abs(this.canvas.width - previousWidth) > 8 || Math.abs(this.canvas.height - previousHeight) > 8)) this.resetTaaHistory('major-resize');
    if (this.picker) this.picker.resize(this.canvas.width, this.canvas.height);
    if (this.cameraFrame) this.cameraFrame.update();
    this.updateGizmoSize();
  }

  private recordInput(type: string, detail = ''): void {
    this.inputEvents.push({ at: performance.now(), type, detail });
    if (this.inputEvents.length > 10) this.inputEvents.shift();
  }

  private debugCaptureOwner(): string {
    if (this.activePointerId !== null && this.canvas.hasPointerCapture?.(this.activePointerId)) return 'canvas';
    for (const gizmo of [this.translateGizmo, this.rotateGizmo, this.scaleGizmo]) {
      const pointerId = (gizmo as unknown as { _pointerId?: number } | null)?._pointerId;
      if (typeof pointerId === 'number' && pointerId >= 0) return 'gizmo';
    }
    return 'none';
  }

  getPickingDebug(): { hoverId: string | null; pickMethod: string; pickSource: string; bounds: { id: string; minX: number; maxX: number; minY: number; maxY: number; original: [number, number, number]; effective: [number, number, number] }[] } {
    const bounds = this.effectivePickTargets().flatMap((target) => {
      const rect = this.screenRectFor(target);
      if (!rect) return [];
      const original = this.pickTargets.find((entry) => entry.id === target.id)?.size;
      return [{ id: target.id, ...rect, original: original ? [original.x, original.y, original.z] as [number, number, number] : [0, 0, 0] as [number, number, number], effective: [target.size.x, target.size.y, target.size.z] as [number, number, number] }];
    });
    return { hoverId: this.hoverId, pickMethod: this.pickMethod, pickSource: this.pickSource, bounds };
  }

  getInputDebug(): { pointerId: number | null; buttons: number; leftButtonDown: boolean; pointerOwner: InputOwner; pointerCaptureOwner: string; pointerLockElement: string; activeTool: string; activeGizmoHandle: string; cameraDragging: boolean; gizmoDragging: boolean; selectionSuppressed: boolean; viewportHovered: boolean; inspectorHovered: boolean; cameraDistance: number; cameraYaw: number; cameraPitch: number; aaMode: string; taaJitter: number; taaHistoryResets: number; taaLastResetReason: string; nearClip: number; farClip: number; sceneRadius: number; hdrFormat: string; dithering: string; ditherActive: boolean; lastAction: string; lastRebuild: boolean; materialSynced: boolean; shaderSynced: boolean; gpu: string; gpuVendor: string; backend: string; api: string; gpuDetailed: boolean; fps: number; frameTime: number; drawCalls: number; triangles: number; activeLights: number; canvasSize: string; backbufferSize: string; dpr: number; quality: string; lastChange: string; lastDirty: string; runtimeUpdated: boolean; renderRequested: boolean; postPipeline: string; postPasses: number; postSceneFormat: string; postDepth: boolean; postHistory: boolean; postError: string; postResolution: string; postHistoryStates: string; postHistoryResets: number; geoOps: string; noiseStrength: number; postHistoryResetReason: string;
      postOutputFormat: string;
      postStage: string;
      postRegistrations: number;
      hoverId: string | null;
      pickMethod: string;
      pickSource: string;
      lastCameraAction: string;
      cameraDistanceBefore: number;
      cameraDistanceAfter: number;
      focusBoundsRadius: number;
      focusTarget: string; rdEnabled: boolean; rdValid: boolean; rdResolution: string; rdSteps: number; rdResets: number; rdResetReason: string; rdConsumers: number; rdConsumerList: string; rdPaintMode: boolean; rdInjections: number; rdReadbacks: number; graphNodes: number; graphConnections: number; graphCycles: number; graphDomains: string; cloneCount: number; bloomEnabled: boolean; fogEnabled: boolean; taaEnabled: boolean; fogSteps: number; fogScale: number; renderScale: number; events: InputDebugEvent[] } {
    const typing = this.isTypingTarget(document.activeElement);
    return {
      pointerId: this.activePointerId,
      buttons: this.pressedButtons,
      leftButtonDown: (this.pressedButtons & 1) === 1,
      pointerOwner: this.interactionOwner,
      pointerCaptureOwner: this.debugCaptureOwner(),
      pointerLockElement: document.pointerLockElement === this.canvas ? 'canvas' : document.pointerLockElement ? document.pointerLockElement.tagName.toLowerCase() : 'none',
      activeTool: this.gizmoMode,
      activeGizmoHandle: this.gizmoDragging ? 'dragging' : 'none',
      cameraDragging: this.interactionOwner === 'CAMERA',
      gizmoDragging: this.gizmoDragging,
      selectionSuppressed: this.interactionOwner === 'GIZMO' || this.cameraInputBlocked,
      viewportHovered: this.canvas.matches(':hover'),
      inspectorHovered: !!document.querySelector('.right-panel')?.matches(':hover'),
      cameraDistance: this.camera ? this.camera.getPosition().distance(this.sceneBounds.center) : 0,
      cameraYaw: this.camera ? Math.round(this.camera.getEulerAngles().y * 10) / 10 : 0,
      aaMode: this.aaMode,
      taaJitter: this.cameraFrame?.taa.jitter ?? 0,
      taaHistoryResets: this.taaHistoryResets,
      taaLastResetReason: this.taaLastResetReason,
      postPipeline: 'renderer',
      postPasses: this.postDiagnostics.passes,
      postSceneFormat: this.postDiagnostics.sceneFormat,
      postDepth: this.postDiagnostics.depth,
      postHistory: this.postDiagnostics.history,
      postError: this.postDiagnostics.error,
      postResolution: `${this.postDiagnostics.width} × ${this.postDiagnostics.height}`,
      geoOps: this.lastGeoOps.join(','),
      noiseStrength: this.lastNoiseStrength,
      postHistoryResets: (this.project?.postShaders || []).reduce((total, entry) => total + (entry.historyResetToken || 0), 0),
      postOutputFormat: this.postDiagnostics.outputFormat,
      postStage: this.postDiagnostics.stage,
      postRegistrations: this.postDiagnostics.registrations,
      hoverId: this.hoverId,
      pickMethod: this.pickMethod,
      pickSource: this.pickSource,
      lastCameraAction: this.lastCameraAction,
      cameraDistanceBefore: this.cameraDistanceBefore,
      cameraDistanceAfter: this.cameraDistanceAfter,
      focusBoundsRadius: this.focusBoundsRadius,
      focusTarget: this.focusTarget,
      postHistoryResetReason: (this.project?.postShaders || []).some((entry) => (entry.historyResetToken || 0) > 0) ? 'user-reset' : 'initial',
      postHistoryStates: (this.postEffect?.historyStates || []).length ? this.postEffect!.historyStates.map((entry) => `${entry.pass}:${entry.valid ? 'valid' : 'empty'}`).join(' · ') : (this.project?.postShaders || []).map((entry) => {
        const shader = this.project?.customShaders?.find((item) => item.id === entry.shaderId);
        return `${shader?.name || 'Post'}:${(entry.historyResetToken || 0) > 0 ? 'resetting' : 'valid'}`;
      }).join(' · '),
      graphNodes: (this.project ? (this.project.signals?.length || 0) + (this.project.reactionDiffusion?.enabled ? 1 : 0) + (this.project.effects?.length || 0) + this.project.objects.reduce((total, object) => total + (object.modifiers?.length || 0), 0) : 0),
      graphConnections: (this.project?.fieldLinks?.length || 0) + (this.project ? this.project.objects.reduce((total, object) => total + Object.values(object.modifiers || {}).reduce((count, modifier) => count + Object.values(modifier.modulators || {}).filter((modulator) => modulator.sourceType === 'modifier' || modulator.sourceType === 'reaction').length, 0), 0) : 0),
      graphDomains: (() => { if (!this.project) return 'none'; const modifiers = [...(this.project.effects || []), ...this.project.objects.flatMap((object) => object.modifiers || [])]; const plan = compileExecutionPlan(modifiers as never); return Object.entries(plan.domains).filter(([, ids]) => ids.length).map(([domain, ids]) => `${domain}:${ids.length}`).join(' · '); })(),
      graphCycles: (() => { if (!this.project) return 0; const modifiers = [...(this.project.effects || []), ...this.project.objects.flatMap((object) => object.modifiers || [])]; return compileModifierOrder(modifiers as never).cycles.length; })(),
      rdEnabled: this.rdDiagnostics.enabled,
      rdValid: this.rdDiagnostics.valid,
      rdResolution: `${this.rdDiagnostics.width} × ${this.rdDiagnostics.height}`,
      rdSteps: this.rdDiagnostics.steps,
      rdResets: this.rdDiagnostics.resets,
      rdResetReason: this.rdDiagnostics.lastResetReason,
      rdPaintMode: this.reactionPaintMode,
      rdInjections: this.rd?.injectionCount || 0,
      rdReadbacks: this.rd?.readbackCount || 0,
      cloneCount: [...this.radialClones.values()].reduce((total, entry) => total + entry.clones.length, 0),
      rdConsumers: reactionConsumers(this.project).reduce((total, consumer) => total + consumer.usageCount, 0),
      rdConsumerList: reactionConsumers(this.project).map((consumer) => `${consumer.ownerName} → ${consumer.module}.${consumer.parameter}`).join(' · '),
      cameraPitch: this.camera ? Math.round(this.camera.getEulerAngles().x * 10) / 10 : 0,
      nearClip: this.camera?.camera?.nearClip ?? 0,
      farClip: this.camera?.camera?.farClip ?? 0,
      sceneRadius: this.sceneRadius,
      hdrFormat: this.cameraFrame ? (this.cameraFrame.hdrFormat === pc.PIXELFORMAT_RGBA16F ? 'RGBA16F' : this.cameraFrame.hdrFormat === pc.PIXELFORMAT_RG11B10F ? 'RG11B10F' : this.cameraFrame.hdrFormat === pc.PIXELFORMAT_RGBA32F ? 'RGBA32F' : this.cameraFrame.hdrFormat === pc.PIXELFORMAT_RGBA8 ? 'RGBA8' : String(this.cameraFrame.hdrFormat)) : 'none',
      dithering: `${this.project?.lighting.dithering ?? 'temporal'} ${Math.round((this.project?.lighting.ditherStrength ?? 1) * 100)}%`,
      ditherActive: this.ditherEffect?.active === true,
      lastAction: this.syncDebug.action,
      lastRebuild: this.syncDebug.rebuild,
      materialSynced: this.syncDebug.materialSync,
      shaderSynced: this.syncDebug.shaderSync,
      gpu: this.rendererInfo.gpu,
      gpuVendor: this.rendererInfo.vendor,
      backend: this.rendererInfo.backend,
      api: this.rendererInfo.api,
      gpuDetailed: this.rendererInfo.detailed,
      fps: Math.round(this.app?.stats.frame.fps || 0),
      frameTime: Math.round((this.app?.stats.frame.ms || 0) * 10) / 10,
      drawCalls: this.app?.stats.drawCalls.total || 0,
      triangles: this.app?.stats.frame.primitives || 0,
      activeLights: this.project?.objects.filter((object) => object.light?.on && object.visible).length || 0,
      canvasSize: `${Math.round(this.canvas.clientWidth)} × ${Math.round(this.canvas.clientHeight)}`,
      backbufferSize: `${this.canvas.width} × ${this.canvas.height}`,
      dpr: Math.round((window.devicePixelRatio || 1) * 100) / 100,
      quality: this.project?.lighting.quality || 'unknown',
      lastChange: this.syncDebug.change,
      lastDirty: this.syncDebug.dirty,
      runtimeUpdated: this.syncDebug.updated,
      renderRequested: this.syncDebug.renderRequested,
      bloomEnabled: !!this.cameraFrame && !this.noGlow,
      fogEnabled: !!this.project?.lighting.volumetric && !this.noFog,
      taaEnabled: this.cameraFrame?.taa.enabled === true,
      fogSteps: this.cameraFrame?.volumetricFog.steps ?? 0,
      fogScale: this.cameraFrame?.volumetricFog.scale ?? 0,
      renderScale: this.cameraFrame?.rendering.renderTargetScale ?? 0,
      events: [...this.inputEvents],
    };
  }

  resetPointerInteraction(reason: string): void {
    const pointerId = this.activePointerId;
    if (pointerId !== null) {
      try { if (this.canvas.hasPointerCapture?.(pointerId)) this.canvas.releasePointerCapture(pointerId); } catch { /* capture already gone */ }
    }
    for (const gizmo of [this.translateGizmo, this.rotateGizmo, this.scaleGizmo]) {
      const internal = gizmo as unknown as { _pointerId?: number } | null;
      if (internal && typeof internal._pointerId === 'number' && internal._pointerId >= 0) internal._pointerId = -1;
    }
    this.pointer.active = false;
    this.pointerReleased = true;
    this.gizmoDragging = false;
    this.interactionOwner = 'NONE';
    this.activePointerId = null;
    this.pressedButtons = 0;
    this.cameraInputBlocked = this.isTypingTarget(document.activeElement);
    if (this.cameraControls) this.cameraControls.enabled = !this.cameraInputBlocked;
    this.canvas.style.cursor = '';
    this.hideMarquee();
    this.recordInput('reset', reason);
    this.syncGizmo();
  }

  private setupInput(): void {
    const canvas = this.canvas;
    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('mousedown', this.onMouseDown);
    canvas.addEventListener('mouseup', this.onMouseUp);
    canvas.addEventListener('click', this.onClick);
    document.addEventListener('pointerlockchange', this.onPointerLockDebug);
    document.addEventListener('visibilitychange', this.onVisibilityChange);
    window.addEventListener('keydown', this.onDebugEscape);
    window.addEventListener('keydown', this.onFlyKeyDown);
    window.addEventListener('keyup', this.onFlyKeyUp);
    window.addEventListener('blur', this.onFlyBlur);
    canvas.addEventListener('pointermove', this.onPointerMove);
    canvas.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('pointercancel', this.onPointerUp);
    canvas.addEventListener('lostpointercapture', this.onLostPointerCapture);
    window.addEventListener('pointerup', this.onWindowPointerEnd);
    window.addEventListener('pointercancel', this.onWindowPointerEnd);
    window.addEventListener('blur', this.onWindowBlur);
    canvas.addEventListener('wheel', this.onWheel, { passive: false });
    canvas.addEventListener('contextmenu', this.onContextMenu);
    canvas.addEventListener('dblclick', this.onDoubleClick);
    canvas.addEventListener('keydown', this.onKeyDown);
    canvas.tabIndex = 0;
    canvas.setAttribute('aria-label', '3D scene. Arrow keys rotate the camera, plus and minus zoom.');
  }

  private onKeyDown = (_event: KeyboardEvent): void => {
    // Camera keyboard input is handled by the official CameraControls script.
  };

  private isTypingTarget(target: EventTarget | null): boolean {
    const element = target as HTMLElement | null;
    return !!element && (
      element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' ||
      element.tagName === 'SELECT' || element.isContentEditable
    );
  }

  private setCameraInputBlocked(blocked: boolean): void {
    this.gizmoDragging = blocked;
    this.cameraInputBlocked = blocked || this.isTypingTarget(document.activeElement);
    if (this.cameraControls) this.cameraControls.enabled = !this.cameraInputBlocked;
  }

  private onFocusIn = (event: FocusEvent): void => {
    if (this.isTypingTarget(event.target)) {
      this.cameraInputBlocked = true;
      this.interactionOwner = 'UI';
      if (this.cameraControls) this.cameraControls.enabled = false;
    }
  };

  private onFocusOut = (): void => {
    if (this.gizmoDragging) return;
    this.cameraInputBlocked = false;
    if (this.interactionOwner === 'UI') this.interactionOwner = 'NONE';
    if (this.cameraControls) this.cameraControls.enabled = true;
  };

  private clearCameraInput = (): void => {
    const source = this.cameraControls?._desktopInput;
    if (source) {
      source._keyNow?.fill?.(0);
      source._clearButtons?.();
    }
    if (this.cameraControls) this.cameraControls.enabled = !this.cameraInputBlocked;
  };

  private updateGizmoSize(): void {
    const dim = Math.max(1, this.canvas.clientHeight);
    const size = 1200 / dim;
    for (const gizmo of [this.translateGizmo, this.rotateGizmo, this.scaleGizmo]) {
      if (gizmo) gizmo.size = size;
    }
  }

  /**
   * PlayCanvas gizmos capture the canvas on every pointerdown, even when no
   * handle is hit. Keep the neutral selection path free of capture: the library
   * pointerdown only runs when _getSelection actually finds a gizmo handle.
   */
  private restrictGizmoPointerDown(gizmo: pc.TransformGizmo): void {
    const internal = gizmo as unknown as { _onPointerDown?: (event: PointerEvent) => void; _getSelection?: (x: number, y: number) => unknown[] };
    const original = internal._onPointerDown;
    if (!original) return;
    const handler = (event: PointerEvent) => {
      if (!gizmo.enabled) {
        original.call(gizmo, event);
        return;
      }
      const selection = internal._getSelection?.(event.offsetX, event.offsetY) || [];
      if (!selection[0]) return;
      original.call(gizmo, event);
    };
    this.canvas.removeEventListener('pointerdown', original as EventListener);
    this.canvas.addEventListener('pointerdown', handler);
    internal._onPointerDown = handler;
  }

  private syncGizmo(): void {
    if (this.gizmoDragging) return;
    if (!this.translateGizmo || !this.rotateGizmo || !this.scaleGizmo) return;
    this.translateGizmo.detach();
    this.rotateGizmo.detach();
    this.scaleGizmo.detach();
    if (this.gizmoPivot) this.gizmoPivot.enabled = false;
    if (this.gizmoMode === 'select') return;
    if (!this.project) return;
    const selected = this.project.objects.filter((object) => this.selectedIds.includes(object.id) && object.visible && object.modelVisible !== false);
    if (selected.length > 1) {
      const roots = selected.map((object) => ({ object, root: this.objectRoots.get(object.id) })).filter((entry): entry is { object: SceneObject; root: pc.Entity } => !!entry.root);
      if (!roots.length) return;
      if (!this.gizmoPivot) {
        this.gizmoPivot = new pc.Entity('gizmo-pivot');
        this.world?.addChild(this.gizmoPivot);
      }
      this.gizmoPivot.enabled = true;
      const center = new pc.Vec3();
      roots.forEach(({ root }) => center.add(root.getPosition()));
      center.mulScalar(1 / roots.length);
      this.gizmoPivot.setPosition(center);
      this.gizmoPivot.setEulerAngles(0, 0, 0);
      this.gizmoPivot.setLocalScale(1, 1, 1);
      if (this.gizmoMode === 'move') this.translateGizmo.attach(this.gizmoPivot);
      else if (this.gizmoMode === 'rotate') this.rotateGizmo.attach(this.gizmoPivot);
      else if (roots.some(({ object }) => object.type === 'model')) this.scaleGizmo.attach(this.gizmoPivot);
      return;
    }
    if (this.gizmoPivot) this.gizmoPivot.enabled = false;
    const object = selected[0];
    const root = object ? this.objectRoots.get(object.id) : null;
    if (!object || !root) return;
    if (this.gizmoMode === 'move') this.translateGizmo.attach(root);
    else if (this.gizmoMode === 'rotate') this.rotateGizmo.attach(root);
    else if (object.type === 'model') this.scaleGizmo.attach(root);
  }

  private gizmoPatch(): Partial<SceneObject> | null {
    const start = this.gizmoStart;
    if (!start) return null;
    const position = start.root.getPosition();
    const euler = start.root.getEulerAngles();
    const scale = start.root.getLocalScale();
    const patch: Partial<SceneObject> = {
      position: {
        x: Math.round((start.position.x + position.x - start.rootPosition.x) * 1000) / 1000,
        z: Math.round((start.position.z + position.z - start.rootPosition.z) * 1000) / 1000,
      },
      elevation: Math.round((start.elevation + position.y - start.rootPosition.y) * 1000) / 1000,
      rotation: Math.round(-euler.y * 1000) / 1000,
      rotationX: Math.round(euler.x * 1000) / 1000,
      rotationZ: Math.round(euler.z * 1000) / 1000,
    };
    const object = this.project?.objects.find((entry) => entry.id === start.id);
    if (object?.type === 'model') {
      patch.scale = {
        x: Math.round(scale.x * 1000) / 1000,
        y: Math.round(scale.y * 1000) / 1000,
        z: Math.round(scale.z * 1000) / 1000,
      };
    }
    return patch;
  }

  private multiGizmoPatches(): { id: string; patch: Partial<SceneObject> }[] {
    const start = this.multiGizmoStart;
    const pivot = this.gizmoPivot;
    if (!start || !pivot) return [];
    const position = pivot.getPosition();
    const rotation = pivot.getRotation();
    const scale = pivot.getLocalScale();
    const deltaPosition = new pc.Vec3().sub2(position, start.pivotPosition);
    const deltaRotation = new pc.Quat().mul2(rotation, start.pivotQuaternion.clone().invert());
    const deltaScale = new pc.Vec3(scale.x / Math.max(0.0001, start.pivotScale.x), scale.y / Math.max(0.0001, start.pivotScale.y), scale.z / Math.max(0.0001, start.pivotScale.z));
    return start.items.map((item) => {
      let nextPosition = item.startPosition.clone();
      let nextRotation = item.startRotation.clone();
      let nextScale = item.startScale.clone();
      if (this.gizmoMode === 'move') nextPosition.add(deltaPosition);
      else if (this.gizmoMode === 'rotate') {
        const relative = new pc.Vec3().sub2(item.startPosition, start.pivotPosition);
        nextPosition = start.pivotPosition.clone().add(deltaRotation.transformVector(relative));
        nextRotation = new pc.Quat().mul2(deltaRotation, item.startRotation);
      } else if (item.object.type === 'model') {
        const relative = new pc.Vec3().sub2(item.startPosition, start.pivotPosition);
        nextPosition = start.pivotPosition.clone().add(new pc.Vec3(relative.x * deltaScale.x, relative.y * deltaScale.y, relative.z * deltaScale.z));
        nextScale = new pc.Vec3(item.startScale.x * deltaScale.x, item.startScale.y * deltaScale.y, item.startScale.z * deltaScale.z);
      }
      const euler = nextRotation.getEulerAngles();
      const patch: Partial<SceneObject> = {
        position: { x: Math.round(nextPosition.x * 1000) / 1000, z: Math.round(nextPosition.z * 1000) / 1000 },
        elevation: Math.round(nextPosition.y * 1000) / 1000,
        rotation: Math.round(-euler.y * 1000) / 1000,
        rotationX: Math.round(euler.x * 1000) / 1000,
        rotationZ: Math.round(euler.z * 1000) / 1000,
      };
      if (item.object.type === 'model') patch.scale = { x: Math.max(0.001, Math.round(nextScale.x * 1000) / 1000), y: Math.max(0.001, Math.round(nextScale.y * 1000) / 1000), z: Math.max(0.001, Math.round(nextScale.z * 1000) / 1000) };
      return { id: item.id, patch };
    });
  }

  private onGizmoStart(): void {
    this.interactionOwner = 'GIZMO';
    const gizmo = this.gizmoMode === 'move' ? this.translateGizmo : this.gizmoMode === 'rotate' ? this.rotateGizmo : this.scaleGizmo;
    const pointerId = (gizmo as unknown as { _pointerId?: number } | null)?._pointerId;
    if (typeof pointerId === 'number' && pointerId >= 0) this.activePointerId = pointerId;
    this.recordInput('gizmo-start', `tool=${this.gizmoMode}`);
    // The PlayCanvas gizmo owns pointer capture for this interaction. Never
    // release it here: mouse pointer ids are reused, so releasing the previous
    // id would release the current gizmo's capture and lose pointerup outside
    // the canvas.
    this.pointerReleased = false;
    this.pointer.active = false;
    if (this.gizmoFrame) cancelAnimationFrame(this.gizmoFrame);
    this.gizmoFrame = 0;
    if (this.selectedIds.length > 1 && this.gizmoPivot) {
      const items = this.selectedIds.map((selectedId) => {
        const object = this.project?.objects.find((entry) => entry.id === selectedId);
        const root = this.objectRoots.get(selectedId);
        return object && root ? { id: selectedId, object, root, startPosition: root.getPosition().clone(), startRotation: root.getRotation().clone(), startScale: root.getLocalScale().clone() } : null;
      }).filter((entry): entry is NonNullable<typeof entry> => !!entry);
      if (items.length > 1) {
        this.multiGizmoStart = { pivotPosition: this.gizmoPivot.getPosition().clone(), pivotQuaternion: this.gizmoPivot.getRotation().clone(), pivotScale: this.gizmoPivot.getLocalScale().clone(), items };
        this.gizmoDragging = true;
        this.setCameraInputBlocked(true);
        return;
      }
    }
    const id = this.selectedIds[0];
    const object = id ? this.project?.objects.find((entry) => entry.id === id) : null;
    const root = id ? this.objectRoots.get(id) : null;
    if (!object || !root) return;
    this.gizmoStart = {
      id,
      root,
      position: { ...object.position },
      elevation: object.elevation,
      rotation: object.rotation,
      rotationX: object.rotationX || 0,
      rotationZ: object.rotationZ || 0,
      scale: object.scale || { x: 1, y: 1, z: 1 },
      rootPosition: root.getPosition().clone(),
      rootEuler: root.getEulerAngles().clone(),
    };
    this.setCameraInputBlocked(true);
  }

  private onGizmoMove(): void {
    if ((!this.gizmoStart && !this.multiGizmoStart) || this.gizmoFrame) return;
    // The gizmo applies its new transform after the event. Read it on the next frame
    // so the inspector/store receives the same value the renderer is using.
    this.gizmoFrame = requestAnimationFrame(() => {
      this.gizmoFrame = 0;
      if (this.multiGizmoStart) {
        this.callbacks.onGizmoMultiTransform?.(this.multiGizmoPatches(), false);
        return;
      }
      if (!this.gizmoStart) return;
      const patch = this.gizmoPatch();
      if (patch) this.callbacks.onGizmoTransform(this.gizmoStart.id, patch, false);
    });
  }

  private onGizmoEnd(): void {
    // Restore input immediately; store commit/rebind can finish on the next frame.
    this.interactionOwner = 'NONE';
    this.gizmoDragging = false;
    this.pointerReleased = true;
    this.pointer.active = false;
    this.setCameraInputBlocked(false);
    this.recordInput('gizmo-end', this.multiGizmoStart ? 'multi' : 'single');
    if (this.multiGizmoStart) {
      if (this.gizmoFrame) { cancelAnimationFrame(this.gizmoFrame); this.gizmoFrame = 0; }
      const patches = this.multiGizmoPatches();
      this.multiGizmoStart = null;
      requestAnimationFrame(() => {
        this.callbacks.onGizmoMultiTransform?.(patches, true);
        this.gizmoDragging = false;
        this.setCameraInputBlocked(false);
        this.syncGizmo();
      });
      this.resetPointerInteraction('gizmo-end-multi');
      return;
    }
    if (!this.gizmoStart) return;
    if (this.gizmoFrame) {
      cancelAnimationFrame(this.gizmoFrame);
      this.gizmoFrame = 0;
    }
    const start = this.gizmoStart;
    requestAnimationFrame(() => {
      const patch = this.gizmoStart ? this.gizmoPatch() : null;
      if (patch) this.callbacks.onGizmoTransform(start.id, patch, true);
      this.gizmoStart = null;
      this.gizmoDragging = false;
      this.setCameraInputBlocked(false);
      this.syncGizmo();
    });
    this.resetPointerInteraction('gizmo-end');
  }

  private onContextMenu = (event: MouseEvent): void => {
    event.preventDefault();
  };

  private ensureMarqueeElement(): HTMLDivElement {
    if (!this.marqueeElement) {
      const element = document.createElement('div');
      element.className = 'viewport-marquee';
      element.style.cssText = 'position:fixed;pointer-events:none;z-index:80;border:1px solid #63dcff;background:rgba(78,190,255,.14);box-shadow:0 0 0 1px rgba(0,0,0,.2);display:none;';
      document.body.appendChild(element);
      this.marqueeElement = element;
    }
    return this.marqueeElement;
  }

  private updateMarqueeElement(): void {
    if (!this.marquee) return;
    const element = this.ensureMarqueeElement();
    const left = Math.min(this.marquee.startX, this.marquee.currentX);
    const top = Math.min(this.marquee.startY, this.marquee.currentY);
    element.style.display = 'block';
    element.style.left = `${left}px`;
    element.style.top = `${top}px`;
    element.style.width = `${Math.abs(this.marquee.currentX - this.marquee.startX)}px`;
    element.style.height = `${Math.abs(this.marquee.currentY - this.marquee.startY)}px`;
  }

  private hideMarquee(): void {
    this.marquee = null;
    if (this.marqueeElement) this.marqueeElement.style.display = 'none';
  }

  private selectMarquee(marquee: NonNullable<PlayCanvasRuntime['marquee']>): void {
    const left = Math.min(marquee.startX, marquee.currentX);
    const right = Math.max(marquee.startX, marquee.currentX);
    const top = Math.min(marquee.startY, marquee.currentY);
    const bottom = Math.max(marquee.startY, marquee.currentY);
    const fullyInside = marquee.currentX >= marquee.startX;
    const ids: string[] = [];
    for (const target of this.effectivePickTargets()) {
      const rect = this.screenRectFor(target);
      if (!rect) continue;
      const intersects = rect.maxX >= left && rect.minX <= right && rect.maxY >= top && rect.minY <= bottom;
      const inside = rect.minX >= left && rect.maxX <= right && rect.minY >= top && rect.maxY <= bottom;
      if (fullyInside ? inside : intersects) ids.push(target.id);
    }
    this.recordInput('marquee', `${ids.length} selected mode=${fullyInside ? 'inside' : 'touch'} add=${marquee.additive} sub=${marquee.subtractive}`);
    if (this.callbacks.onSelectMany) this.callbacks.onSelectMany(ids, marquee.additive, marquee.subtractive);
    else if (ids.length && !marquee.additive && !marquee.subtractive) this.callbacks.onSelect(ids[0], false);
    this.hideMarquee();
  }

  private onPointerDown = (event: PointerEvent): void => {
    if (this.gizmoDragging) return;
    if (this.reactionPaintMode && event.button === 0) {
      this.paintReaction(event.clientX, event.clientY);
      this.interactionOwner = 'UI';
      this.pointer.active = false;
      this.pointerReleased = true;
      return;
    }
    if (event.button !== 0 && event.button !== 1 && event.button !== 2) return;
    this.pointer = { x: event.clientX, y: event.clientY, moved: 0, button: event.button, active: true };
    this.lastPointer = { x: event.clientX, y: event.clientY };
    this.pointerReleased = false;
    this.activePointerId = event.pointerId;
    this.pressedButtons = event.buttons;
    this.interactionOwner = event.button === 0 ? 'SELECT' : 'CAMERA';
    if (event.button === 0) {
      this.marquee = { startX: event.clientX, startY: event.clientY, currentX: event.clientX, currentY: event.clientY, pointerId: event.pointerId, additive: event.shiftKey || event.ctrlKey || event.metaKey, subtractive: event.altKey };
    }
    this.recordInput('pointerdown', `id=${event.pointerId} button=${event.button} buttons=${event.buttons}`);
  };

  private onPointerMove = (event: PointerEvent): void => {
    if (!this.pointer.active) { this.updateHover(event.clientX, event.clientY); return; }
    const dx = event.clientX - this.lastPointer.x;
    const dy = event.clientY - this.lastPointer.y;
    this.lastPointer = { x: event.clientX, y: event.clientY };
    this.pointer.moved += Math.abs(dx) + Math.abs(dy);
    if (event.buttons === 0 && this.interactionOwner !== 'NONE' && !this.marquee) {
      this.resetPointerInteraction('buttons-zero');
      return;
    }
    if (this.interactionOwner === 'SELECT' && (event.buttons & 6) !== 0) {
      this.interactionOwner = 'CAMERA';
      this.hideMarquee();
      this.recordInput('owner', 'SELECT -> CAMERA (RMB/MMB drag)');
    }
    if ((this.interactionOwner === 'SELECT' || this.interactionOwner === 'SELECT_MARQUEE') && this.marquee && this.pointer.button === 0 && (event.buttons & 1) !== 0) {
      this.marquee.currentX = event.clientX;
      this.marquee.currentY = event.clientY;
      if (this.pointer.moved > 4) { this.updateMarqueeElement(); if (this.interactionOwner === 'SELECT') { this.interactionOwner = 'SELECT_MARQUEE'; this.recordInput('owner', 'SELECT -> SELECT_MARQUEE'); } }
    }
  };

  private onPointerUp = (event: PointerEvent): void => {
    if (!this.pointer.active) return;
    const moved = this.pointer.moved;
    const wasLeft = this.pointer.button === 0;
    this.recordInput('pointerup', `id=${event.pointerId} button=${event.button} moved=${Math.round(moved)}`);
    // We never call setPointerCapture for normal viewport clicks; the camera
    // and gizmo libraries own capture.
    if (this.gizmoDragging) return;
    if (wasLeft && moved >= 6 && this.marquee) {
      this.selectMarquee(this.marquee);
      this.resetPointerInteraction('marquee-end');
      return;
    }
    if (wasLeft && moved < 6) {
      this.pickAt(event.clientX, event.clientY, false, event.ctrlKey || event.metaKey || event.shiftKey);
    }
    this.resetPointerInteraction('pointerup');
  };

  private onWindowPointerEnd = (event: PointerEvent): void => {
    this.recordInput(event.type, `id=${event.pointerId} buttons=${event.buttons}`);
    if (this.gizmoDragging) return;
    this.resetPointerInteraction(`window-${event.type}`);
  };

  private onLostPointerCapture = (event: PointerEvent): void => {
    this.recordInput('lostpointercapture', `id=${event.pointerId}`);
    if (this.gizmoDragging) this.cancelGizmoInteraction();
    else this.resetPointerInteraction('lostpointercapture');
  };

  private onWindowBlur = (): void => {
    this.recordInput('blur');
    if (this.gizmoDragging) this.cancelGizmoInteraction();
    this.resetPointerInteraction('blur');
  };

  /** Force the library gizmo back to idle when pointerup was lost (blur, capture loss, Escape). */
  private cancelGizmoInteraction(): void {
    if (!this.gizmoDragging && !this.gizmoStart && !this.multiGizmoStart) {
      this.pointer.active = false;
      this.pointerReleased = true;
      this.setCameraInputBlocked(false);
      return;
    }
    let endedViaGizmo = false;
    const gizmos = [this.translateGizmo, this.rotateGizmo, this.scaleGizmo];
    for (const gizmo of gizmos) {
      if (!gizmo) continue;
      const active = gizmo as unknown as { _pointerId?: number; fire: (name: string, x?: number, y?: number, mesh?: null) => void };
      const pointerId = typeof active._pointerId === 'number' ? active._pointerId : -1;
      if (pointerId < 0) continue;
      try { if (this.canvas.hasPointerCapture(pointerId)) this.canvas.releasePointerCapture(pointerId); } catch { /* capture already gone */ }
      active._pointerId = -1;
      try { active.fire('pointer:up', 0, 0, null); } catch { /* keep input usable even if a library handler throws */ }
      endedViaGizmo = true;
    }
    if (!endedViaGizmo && (this.gizmoStart || this.multiGizmoStart)) this.onGizmoEnd();
    this.pointer.active = false;
    this.pointerReleased = true;
    this.gizmoDragging = false;
    this.setCameraInputBlocked(false);
    this.syncGizmo();
  }

  private canFlyKeys(event: KeyboardEvent): boolean {
    if (this.isTypingTarget(event.target)) return false;
    if (document.querySelector('.overlay [role="dialog"]')) return false;
    if (event.metaKey || event.ctrlKey) return false;
    return true;
  }

  private onFlyKeyDown = (event: KeyboardEvent): void => {
    if (!this.canFlyKeys(event)) return;
    const key = event.code;
    if (!['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyC', 'Space', 'ShiftLeft', 'ShiftRight', 'AltLeft', 'AltRight'].includes(key)) return;
    if (key === 'Space') event.preventDefault();
    this.flyKeys.add(key);
  };

  private onFlyKeyUp = (event: KeyboardEvent): void => {
    this.flyKeys.delete(event.code);
  };

  private onFlyBlur = (): void => { this.flyKeys.clear(); };

  setNavigationMode(mode: 'orbit' | 'fly'): void {
    this.navigationMode = mode;
    if (mode !== 'fly') this.flyKeys.clear();
  }

  private updateFlyMovement(dt: number): void {
    if (!this.camera || !this.cameraControls || !this.flyKeys.size) return;
    if (document.querySelector('.overlay [role="dialog"]')) return;
    const forward = this.camera.forward.clone();
    const right = this.camera.right.clone();
    const move = new pc.Vec3();
    if (this.flyKeys.has('KeyW')) move.add(forward);
    if (this.flyKeys.has('KeyS')) move.sub(forward);
    if (this.flyKeys.has('KeyD')) move.add(right);
    if (this.flyKeys.has('KeyA')) move.sub(right);
    if (this.flyKeys.has('Space')) move.y += 1;
    if (this.flyKeys.has('KeyC')) move.y -= 1;
    if (move.lengthSq() === 0) return;
    const focus = this.cameraControls.focusPoint as pc.Vec3 | undefined;
    const distance = focus ? this.camera.getPosition().distance(focus) : this.sceneRadius;
    let speed = clamp(distance * 0.45, 0.5, 500);
    if (this.flyKeys.has('ShiftLeft') || this.flyKeys.has('ShiftRight')) speed *= 4;
    if (this.flyKeys.has('AltLeft') || this.flyKeys.has('AltRight')) speed *= 0.25;
    const delta = move.normalize().mulScalar(speed * Math.min(dt, 0.1));
    this.camera.setPosition(this.camera.getPosition().clone().add(delta));
    if (focus) { const next = focus.clone().add(delta); this.cameraControls.focusPoint = next; }
  }

  private onMouseDown = (event: MouseEvent): void => { this.recordInput('mousedown', `button=${event.button} buttons=${event.buttons}`); };
  private onMouseUp = (event: MouseEvent): void => { this.recordInput('mouseup', `button=${event.button} buttons=${event.buttons}`); };
  private onClick = (event: MouseEvent): void => { this.recordInput('click', `button=${event.button}`); };
  private onPointerLockDebug = (): void => { this.recordInput('pointerlockchange', document.pointerLockElement === this.canvas ? 'canvas' : 'none'); this.resetPointerInteraction('pointerlock-exit'); };
  private onVisibilityChange = (): void => { if (document.hidden) { this.recordInput('visibilitychange', 'hidden'); if (this.gizmoDragging) this.cancelGizmoInteraction(); this.resetPointerInteraction('visibility-hidden'); } };
  private onDebugEscape = (event: KeyboardEvent): void => { if (event.key !== 'Escape' || this.isTypingTarget(event.target)) return; this.recordInput('Escape'); if (this.gizmoDragging) this.cancelGizmoInteraction(); this.resetPointerInteraction('Escape'); };

  private onDoubleClick = (event: MouseEvent): void => {
    // Double-click is an ordinary selection gesture. Camera framing is explicit:
    // F (selection) or Shift+F (scene).
    this.recordInput('doubleclick', `detail=${event.detail} — selection only`);
    this.pickAt(event.clientX, event.clientY, false, event.ctrlKey || event.metaKey || event.shiftKey);
  };

  private onWheel = (_event: WheelEvent): void => {
    // Camera wheel input is handled by the official CameraControls script.
  };

  private pickAt(clientX: number, clientY: number, focus: boolean, additive = false): void {
    if (!this.app || !this.camera) return;
    const rect = this.canvas.getBoundingClientRect();
    const x = (clientX - rect.left) * (this.canvas.width / rect.width);
    const y = (clientY - rect.top) * (this.canvas.height / rect.height);
    if (!this.picker || this.picker.width !== this.canvas.width || this.picker.height !== this.canvas.height) {
      this.picker?.destroy();
      this.picker = new pc.Picker(this.app, this.canvas.width, this.canvas.height);
    }
    const id = this.pickIdAt(clientX, clientY);
    if (focus && id) {
      this.callbacks.onFocus(id);
      this.focusObject(id);
      return;
    }
    this.callbacks.onSelect(id, additive);
  }

  private pickIdAt(clientX: number, clientY: number): string | null {
    if (!this.app || !this.camera) return null;
    const rect = this.canvas.getBoundingClientRect();
    const x = (clientX - rect.left) * (this.canvas.width / rect.width);
    const y = (clientY - rect.top) * (this.canvas.height / rect.height);
    if (!this.picker || this.picker.width !== this.canvas.width || this.picker.height !== this.canvas.height) {
      this.picker?.destroy();
      this.picker = new pc.Picker(this.app, this.canvas.width, this.canvas.height);
    }
    this.picker.prepare(this.camera.camera!, this.app.scene);
    const selection = this.picker.getSelection(x, y);
    const idForMesh = (mesh: pc.MeshInstance | pc.GSplatComponent): string | null => {
      const direct = (mesh as unknown as { __rid?: string }).__rid;
      if (direct) return direct;
      const node = (mesh as unknown as { node?: AnyEntity; _node?: AnyEntity }).node
        || (mesh as unknown as { _node?: AnyEntity })._node;
      return node?.__rid || null;
    };
    const picked = selection.find((mesh) => !!idForMesh(mesh));
    if (picked) { this.pickMethod = 'picker'; this.pickSource = 'gpu-picker'; return idForMesh(picked); }
    const screenHit = this.pickScreenAt(clientX, clientY);
    if (screenHit) { this.pickMethod = 'effective-bounds'; this.pickSource = 'screen-bounds'; return screenHit; }
    this.pickMethod = 'ray-fallback';
    this.pickSource = 'ray';
    return this.fallbackPick(x, y);
  }

  private effectivePickTargets(): { id: string; object: SceneObject; center: pc.Vec3; size: pc.Vec3; expansion: number }[] {
    if (!this.project) return [];
    const targets: { id: string; object: SceneObject; center: pc.Vec3; size: pc.Vec3; expansion: number }[] = [];
    for (const object of this.project.objects) {
      if (!object.visible || object.modelVisible === false) continue;
      if (object.type === 'room') continue;
      const existingTarget = this.pickTargets.find((entry) => entry.id === object.id);
      const fallbackDims = objectDims(object);
      const target = existingTarget || { id: object.id, center: new pc.Vec3(object.position.x, object.elevation + fallbackDims.h * 0.5, object.position.z), size: new pc.Vec3(fallbackDims.w, fallbackDims.h, fallbackDims.d) };
      const modifiers = effectiveModifiers(object, this.project);
      let expansion = 0;
      for (const modifier of modifiers) {
        if (!modifier.enabled) continue;
        const params = modifier.params;
        const displacement = Math.abs(Number(params.strength ?? params.amount ?? params.displacement ?? params.magnitude ?? 0));
        expansion += displacement * 0.5;
        if (modifier.type === 'radialClone' || modifier.type === 'gridClone' || modifier.type === 'spiralClone' || modifier.type === 'sphereClone') {
          expansion += Math.max(Number(params.radius ?? 0), Number(params.spacing ?? 0) * Math.max(1, Number(params.count ?? 1)) * 0.5);
        }
      }
      for (const entry of customShadersForObject(this.project, object)) expansion += Math.max(0, entry.shader.boundsExpansion || 0);
      const size = new pc.Vec3(target.size.x + expansion * 2, target.size.y + expansion * 2, target.size.z + expansion * 2);
      targets.push({ id: object.id, object, center: target.center, size, expansion });
    }
    return targets;
  }

  private screenRectFor(target: { center: pc.Vec3; size: pc.Vec3 }): { minX: number; maxX: number; minY: number; maxY: number } | null {
    if (!this.camera?.camera) return null;
    const camera = this.camera.camera;
    const rect = this.canvas.getBoundingClientRect();
    const half = target.size.clone().mulScalar(0.5);
    let minX = Infinity; let maxX = -Infinity; let minY = Infinity; let maxY = -Infinity; let visible = false;
    for (let sx = -1; sx <= 1; sx += 2) for (let sy = -1; sy <= 1; sy += 2) for (let sz = -1; sz <= 1; sz += 2) {
      const world = new pc.Vec3(target.center.x + half.x * sx, target.center.y + half.y * sy, target.center.z + half.z * sz);
      const screen = camera.worldToScreen(world, undefined, this.canvas.width, this.canvas.height);
      if (!Number.isFinite(screen.x) || !Number.isFinite(screen.y) || screen.z < 0) continue;
      const x = rect.left + (screen.x / Math.max(1, this.canvas.width)) * rect.width;
      const y = rect.top + (screen.y / Math.max(1, this.canvas.height)) * rect.height;
      minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); visible = true;
    }
    return visible ? { minX, maxX, minY, maxY } : null;
  }

  private pickScreenAt(clientX: number, clientY: number, tolerance = 8): string | null {
    let best: { id: string; area: number; depth: number } | null = null;
    for (const target of this.effectivePickTargets()) {
      const rect = this.screenRectFor(target);
      if (!rect) continue;
      const inside = clientX >= rect.minX - tolerance && clientX <= rect.maxX + tolerance && clientY >= rect.minY - tolerance && clientY <= rect.maxY + tolerance;
      if (!inside) continue;
      const area = Math.max(1, (rect.maxX - rect.minX) * (rect.maxY - rect.minY));
      const depth = this.camera!.getPosition().distance(target.center);
      if (!best || area < best.area || (area === best.area && depth < best.depth)) best = { id: target.id, area, depth };
    }
    return best?.id || null;
  }

  private updateHover(clientX: number, clientY: number): void {
    const id = this.pickScreenAt(clientX, clientY, 6);
    if (id === this.hoverId) return;
    this.hoverId = id;
    if (!this.world) return;
    if (!id) { if (this.hoverMarker) this.hoverMarker.enabled = false; this.canvas.style.cursor = ''; return; }
    const target = this.effectivePickTargets().find((entry) => entry.id === id);
    if (!target) return;
    if (!this.hoverMarker) {
      const material = this.material({ color: '#59d8ff', emissive: '#59d8ff', opacity: 0.22, unlit: true, transparent: true });
      const entity = new pc.Entity('hover-target');
      entity.addComponent('render', { type: 'box', material });
      entity.render?.meshInstances.forEach((mesh) => { mesh.renderStyle = pc.RENDERSTYLE_WIREFRAME; (mesh as unknown as { __noPick?: boolean }).__noPick = true; });
      this.world.addChild(entity);
      this.hoverMarker = entity;
    }
    this.hoverMarker.enabled = true;
    this.hoverMarker.setLocalPosition(target.center.x, target.center.y, target.center.z);
    this.hoverMarker.setLocalScale(target.size.x * 1.04, target.size.y * 1.04, target.size.z * 1.04);
    this.hoverMarker.setEulerAngles(0, -target.object.rotation, 0);
    this.canvas.style.cursor = 'pointer';
  }

  private fallbackPick(x: number, y: number): string | null {
    if (!this.camera) return null;
    const near = this.camera.camera!.screenToWorld(x, y, this.camera.camera!.nearClip);
    const far = this.camera.camera!.screenToWorld(x, y, this.camera.camera!.farClip);
    const direction = new pc.Vec3().sub2(far, near).normalize();
    let best: { id: string; distance: number } | null = null;
    for (const target of this.pickTargets) {
      const toCenter = new pc.Vec3().sub2(target.center, near);
      const distance = toCenter.dot(direction);
      if (distance <= 0) continue;
      const closest = near.clone().add(direction.clone().mulScalar(distance));
      const radius = Math.max(target.size.x, target.size.y, target.size.z) * 0.6;
      if (closest.distance(target.center) <= radius && (!best || distance < best.distance)) {
        best = { id: target.id, distance };
      }
    }
    return best?.id || null;
  }

  setSelected(selectedIds: string[]): void {
    this.selectedIds = selectedIds;
    if (this.cameraControls) {
      const object = selectedIds.length === 1 ? this.project?.objects.find((entry) => entry.id === selectedIds[0]) : null;
      if (object) {
        const dims = objectDims(object);
        this.cameraControls.focusPoint = new pc.Vec3(object.position.x, object.elevation + dims.h * 0.5, object.position.z);
      } else if (!selectedIds.length && this.sceneRadius) {
        this.cameraControls.focusPoint = this.sceneBounds.center.clone();
      }
    }
    this.updateSelectionMarker();
    this.syncGizmo();
  }

  private updateSelectionMarker(): void {
    if (!this.app || !this.world) return;
    if (!this.selection) {
      const material = this.material({ color: '#e8b40a', emissive: '#e8b40a', opacity: 0.13, unlit: true, transparent: true });
      const entity = new pc.Entity('selection');
      entity.addComponent('render', { type: 'box', material });
      entity.render?.meshInstances.forEach((mesh) => { mesh.renderStyle = pc.RENDERSTYLE_WIREFRAME; });
      this.selection = entity;
      this.world.addChild(entity);
    }
    const id = this.selectedIds[0];
    const object = id ? this.project?.objects.find((entry) => entry.id === id) : null;
    if (!object || !object.visible) {
      this.selection.enabled = false;
      return;
    }
    const effective = this.effectivePickTargets().find((entry) => entry.id === id);
    const dims = effective ? { w: effective.size.x, h: effective.size.y, d: effective.size.z } : objectDims(object);
    const y = effective ? effective.center.y : (object.type === 'device' ? fixtureMountY(object) : object.type === 'stage' ? dims.h / 2 : object.elevation + dims.h / 2);
    this.selection.enabled = true;
    this.selection.setLocalPosition(effective?.center.x ?? object.position.x, y, effective?.center.z ?? object.position.z);
    this.selection.setLocalScale(dims.w * 1.08, Math.max(0.12, dims.h * 1.12), dims.d * 1.08);
    this.selection.setEulerAngles(0, -object.rotation, 0);
  }

  private requestRender(): void {
    if (this.app) this.app.renderNextFrame = true;
    this.syncDebug.renderRequested = true;
  }

  setProject(project: Project, selectedIds: string[]): void {
    this.postEffect?.sync(project);
    this.syncDebug = { change: 'project.update', dirty: 'PROJECT_SYNC', updated: true, renderRequested: false, action: 'sync runtime', rebuild: false, materialSync: false, shaderSync: false };
    this.project = project;
    this.selectedIds = selectedIds;
    if (!this.app || !this.cameraFrame) return;
    if (project.timeline) setTimelineRange(project.timeline.duration, project.timeline.loop);
    const signature = this.projectGeometrySignature(project);
    if (this.world && signature === this.geometrySignature) {
      const lightSignature = this.deviceLightSignature(project);
      if (lightSignature !== this.lightSignature) {
        this.updateLighting(project);
        this.lightSignature = lightSignature;
      }
      this.project = project;
      this.postEffect?.sync(project);
      this.applySceneSettings(project);
      this.syncRoomVisibility(project);
      this.applyObjectTransforms(project);
      this.applyMaterialOverrides(project);
      this.syncModifierVisuals(project);
      this.applyIncrementalLights(project);
      this.updateSelectionMarker();
      this.syncGizmo();
      // CameraFrame is updated only when its own inputs change (post stack,
      // quality, TAA, resize). Arbitrary project edits must not rebuild it.
      if (this.project) this.collectMeshCapabilities(this.project);
      this.requestRender();
      return;
    }
    this.rebuild(project, signature);
  }

  private projectGeometrySignature(project: Project): string {
    const objects = project.objects.map(({ light: _light, modelVisible: _modelVisible, position: _position, elevation: _elevation, rotation: _rotation, rotationX: _rotationX, rotationZ: _rotationZ, scale: _scale, size, primitive, modifiers: _modifiers, materialSlots: _materialSlots, material: _material, materialOverrides: _materialOverrides, ...geometry }) => ({ ...geometry, size: primitive ? null : size, primitiveKind: primitive?.kind ?? null }));
    const roomVisibility = project.objects.filter((object) => object.type === 'room').map((object) => [object.id, object.modelVisible]);
    return JSON.stringify({ objects, roomVisibility, connections: project.connections });
  }

  private deviceLightSignature(project: Project): string {
    return JSON.stringify([project.lighting.quality, project.lighting.master, project.lighting.workLight, project.objects.filter((object) => object.type === 'device').map((object) => [object.id, object.light, object.mount])]);
  }

  private applyObjectTransforms(project: Project): void {
    for (const object of project.objects) {
      const root = this.objectRoots.get(object.id);
      if (!root) continue;
      const dims = objectDims(object);
      const scale = object.scale || { x: 1, y: 1, z: 1 };
      root.setPosition(object.position.x, object.type === 'device' ? fixtureMountY(object) : object.elevation, object.position.z);
      root.setEulerAngles(object.rotationX || 0, -object.rotation, object.rotationZ || 0);
      if (object.type === 'model') root.setLocalScale(scale.x, scale.y, scale.z);
      else root.setLocalScale(1, 1, 1);
      if (object.primitive) this.updatePrimitive(object, root);
      const bodyRoot = this.modelBodyRoots.get(object.id);
      if (bodyRoot) bodyRoot.enabled = object.modelVisible !== false;
      else root.enabled = object.modelVisible !== false;
      if (object.type === 'device' && dims.d > 0) {
        root.setLocalScale(1, 1, 1);
        const node = this.deviceLightNodes.get(object.id);
        if (node && object.light?.on) {
          const profile = opticalProfile(object);
          const isBar = profile.family === 'bar';
          const targetPoint = isBar ? this.barTarget(object, project) : fixtureAimPoint(object, project);
          const barPos = isBar ? this.fitBarPosition(object, objectDims(object)) : null;
          const position = isBar && barPos
            ? new pc.Vec3(barPos.x, fixtureMountY(object) + Math.max(0.08, objectDims(object).h / 2) + 0.03, barPos.z)
            : new pc.Vec3(object.position.x, Math.max(0.08, fixtureMountY(object) - (object.mount === 'truss' || object.mount === 'ceiling' ? 0.1 : 0)), object.position.z);
          const aim = new pc.Vec3(targetPoint[0], targetPoint[1], targetPoint[2]);
          const direction = new pc.Vec3().sub2(aim, position);
          if (direction.lengthSq() < 0.0001) direction.set(0, -1, 0);
          direction.normalize();
          node.setPosition(position);
          node.setRotation(new pc.Quat().setFromDirections(DOWN, direction));
          if (isBar) {
            const d = objectDims(object);
            node.setLocalScale(d.w, 1, Math.max(0.08, d.d * 0.7));
          }
        }
      }
    }
  }

  private applySceneSettings(project: Project): void {
    if (!this.app) return;
    this.app.scene.exposure = clamp(Number(project.lighting.exposure) || 1.5, 0.4, 3.5) * 0.985;
    this.app.scene.ambientLight = project.lighting.workLight
      ? new pc.Color(0.128, 0.136, 0.148)
      : new pc.Color(0.088, 0.092, 0.1);
    this.applyFog(project);
    this.applyQuality(project);
  }

  private updateLighting(project: Project): void {
    if (!this.app || !this.world) return;
    this.applySceneSettings(project);
    this.lightsRoot?.destroy();
    this.deviceLightNodes.clear();
    this.genericLightSources.clear();
    this.genericLightLenses.clear();
    this.primitiveNodes.clear();
    this.motionRoots.clear();
    this.animatedModifierIds.clear();
    this.shaderEffectTargets.clear();
    this.materialTargets.clear();
    this.materialSignature = '';
    this.radialClones.forEach((entry) => entry.clones.forEach((clone) => clone.destroy()));
    this.radialClones.clear();
    this.animTime = 0;
    this.areaLightSources.clear();
    this.areaLightLenses.clear();
    const lightsRoot = new pc.Entity('rig-grid-lights');
    this.world.addChild(lightsRoot);
    this.lightsRoot = lightsRoot;
    this.buildLights(project, lightsRoot);
    this.updateSelectionMarker();
    this.cameraFrame?.update();
  }

  private rebuild(project: Project, signature = this.projectGeometrySignature(project)): void {
    if (!this.app || !this.cameraFrame) return;
    this.postEffect?.sync(project);
    this.resetTaaHistory('renderer-recreation');
    this.project = project;
    this.lightSignature = this.deviceLightSignature(project);
    if (this.world) {
      this.world.destroy();
    }
    this.lightsRoot = null;
    this.geometrySignature = signature;
    this.ownedMaterials.forEach((material) => material.destroy());
    this.ownedMaterials = [];
    this.textureCache.forEach((texture) => texture.destroy());
    this.textureCache.clear();
    this.textureLoading.clear();
    this.pickTargets = [];
    this.objectRoots.clear();
    this.modelBodyRoots.clear();
    this.deviceLightNodes.clear();
    this.genericLightSources.clear();
    this.genericLightLenses.clear();
    this.primitiveNodes.clear();
    this.motionRoots.clear();
    this.animatedModifierIds.clear();
    this.shaderEffectTargets.clear();
    this.materialTargets.clear();
    this.materialSignature = '';
    this.radialClones.forEach((entry) => entry.clones.forEach((clone) => clone.destroy()));
    this.radialClones.clear();
    this.animTime = 0;
    this.areaLightSources.clear();
    this.areaLightLenses.clear();
    const world = new pc.Entity('rig-grid-scene');
    this.app.root.addChild(world);
    this.world = world;
    this.selection = null;

    const bounds = getRoomBounds(project);
    this.roomBounds = { minX: bounds.minX, maxX: bounds.maxX, minZ: bounds.minZ, maxZ: bounds.maxZ, height: bounds.height };
    const stage = getStageCenter(project);
    this.applySceneSettings(project);
    if (!this.viewInitialized) {
      this.viewInitialized = true;
      // Hero opening: a restrained front-facing composition with the stage
      // centred. Walls are presented by default on the View layer, not baked
      // into this camera.
      this.setView((project.view?.cameraPreset as ViewPreset) || 'front');
    }
    this.buildObjects(project, world);
    this.buildRoom(project, world, bounds);
    this.buildStageModel(project, world);
    this.buildModelObjects(project, world);
    this.buildGenericLights(project, world);
    this.applyMaterialOverrides(project);
    this.syncModifierVisuals(project);
    for (const object of project.objects) {
      if (object.visible && object.type === 'areabar') this.buildAreaBar(world, object);
    }
    const lightsRoot = new pc.Entity('rig-grid-lights');
    world.addChild(lightsRoot);
    this.lightsRoot = lightsRoot;
    this.buildLights(project, lightsRoot);
    this.applyObjectTransforms(project);
    this.applyIncrementalLights(project);
    this.updateCamera();
    this.updateSelectionMarker();
    this.syncGizmo();
    this.collectMeshCapabilities(project);
    this.cameraFrame.update();
  }

  private applyFog(project: Project): void {
    if (!this.cameraFrame) return;
    const fogKey = JSON.stringify([project.lighting.volumetric, project.lighting.haze, project.lighting.anisotropy, project.lighting.quality, this.noFog]);
    const fogChanged = fogKey !== this.fogSignature;
    this.fogSignature = fogKey;
    const fog = this.cameraFrame.volumetricFog;
    const haze = project.lighting.volumetric ? project.lighting.haze : 0;
    fog.enabled = !this.noFog && haze > 0.002;
    fog.density = Math.max(0.0005, haze * 0.0052);
    fog.localIntensity = 0.8 + Math.min(2, haze) * 0.7;
    fog.anisotropy = clamp(project.lighting.anisotropy ?? 0.55, -0.2, 0.9);
    fog.localSteps = project.lighting.quality === 'low' ? 12 : project.lighting.quality === 'medium' ? 20 : 28;
    fog.steps = project.lighting.quality === 'low' ? 16 : project.lighting.quality === 'medium' ? 24 : 32;
    // Render fog at native resolution: the previous half/third-res upsample
    // produced visible vertical bands on large walls.
    fog.scale = 1;
    fog.maxDistance = 50;
    if (fogChanged) this.cameraFrame.update();
  }

  private applyQuality(project: Project): void {
    if (!this.cameraFrame || !this.app) return;
    const qualityKey = JSON.stringify([project.lighting.quality, project.lighting.antiAliasing, project.lighting.taaJitter, project.lighting.dithering, project.lighting.ditherStrength, project.lighting.bloomStrength, this.softwareRenderer, this.noGlow, this.legacyPerfProfile]);
    const qualityChanged = qualityKey !== this.qualitySignature;
    this.qualitySignature = qualityKey;
    const highPrecision = project.lighting.quality === 'high' || project.lighting.quality === 'ultra' || project.lighting.quality === 'photo';
    this.cameraFrame.rendering.renderFormats = highPrecision ? [pc.PIXELFORMAT_RGBA16F, pc.PIXELFORMAT_RG11B10F, pc.PIXELFORMAT_RGBA8] : [pc.PIXELFORMAT_RG11B10F, pc.PIXELFORMAT_RGBA16F, pc.PIXELFORMAT_RGBA8];
    const dither = project.lighting.dithering ?? 'temporal';
    if (this.ditherEffect) {
      this.ditherEffect.enabled = dither !== 'off';
      this.ditherEffect.setUniform('uDitherStrength', Math.max(0, Number(project.lighting.ditherStrength ?? 1)));
      this.ditherEffect.setUniform('uDitherTime', dither === 'temporal' ? (performance.now() * 0.001) % 64 : 0);
    }
    if (qualityChanged) this.cameraFrame.update();
    if (this.legacyPerfProfile) {
      this.cameraFrame.taa.enabled = true;
      this.cameraFrame.rendering.renderTargetScale = 1;
      this.cameraFrame.volumetricFog.scale = 0.55;
      this.cameraFrame.volumetricFog.localSteps = 24;
      this.cameraFrame.volumetricFog.steps = 32;
      this.app.scene.lighting.shadowsEnabled = true;
      this.app.scene.lighting.shadowAtlasResolution = 4096;
      this.app.scene.lighting.cookieAtlasResolution = 2048;
      this.app.scene.lighting.maxLightsPerCell = 64;
      this.app.resizeCanvas();
      this.cameraFrame.update();
      return;
    }
    const quality = project.lighting.quality;
    const low = quality === 'low';
    const aaMode = antiAliasingFor(project.lighting);
    const aaChanged = aaMode !== this.aaMode;
    this.aaMode = aaMode;
    this.cameraFrame.taa.enabled = aaMode === 'taa' && !this.softwareRenderer;
    this.cameraFrame.taa.jitter = Math.max(0, Math.min(1, Number(project.lighting.taaJitter ?? 1)));
    this.cameraFrame.rendering.samples = aaMode === 'msaa' && !this.softwareRenderer ? 4 : 1;
    if (aaChanged) this.resetTaaHistory('anti-aliasing-mode');
    this.device!.maxPixelRatio = quality === 'photo' ? Math.min(window.devicePixelRatio || 1, 2) : quality === 'ultra' ? 1.5 : quality === 'high' ? 1.25 : 1;
    this.cameraFrame.ssao.type = pc.SSAOTYPE_NONE;
    this.cameraFrame.rendering.renderTargetScale = this.softwareRenderer ? 0.45 : low ? 0.72 : quality === 'medium' ? 0.85 : 1;
    this.cameraFrame.volumetricFog.scale = this.softwareRenderer ? 0.25 : low ? 0.7 : quality === 'medium' ? 0.85 : 1;
    this.cameraFrame.volumetricFog.localSteps = this.softwareRenderer ? 4 : low ? 6 : quality === 'medium' ? 12 : quality === 'high' ? 24 : 32;
    this.cameraFrame.volumetricFog.steps = this.softwareRenderer ? 8 : low ? 12 : quality === 'medium' ? 20 : quality === 'high' ? 32 : 48;
    const bloomBase = quality === 'photo' ? 0.1 : quality === 'ultra' ? 0.06 : quality === 'high' ? 0.04 : quality === 'medium' ? 0.03 : 0.02;
    this.cameraFrame.bloom.intensity = this.softwareRenderer || this.noGlow ? 0 : bloomBase * clamp(project.lighting.bloomStrength ?? 1, 0, 10);
    this.app.scene.lighting.shadowsEnabled = !this.softwareRenderer && !low;
    this.app.scene.lighting.shadowAtlasResolution = low ? 1024 : quality === 'medium' ? 2048 : 4096;
    this.app.scene.lighting.cookieAtlasResolution = low ? 512 : quality === 'medium' ? 1024 : 2048;
    this.app.scene.lighting.maxLightsPerCell = low ? 24 : quality === 'medium' ? 40 : 64;
    this.app.scene.lighting.areaLightsEnabled = project.objects.some((object) => object.lightType === 'area' || object.type === 'areabar');
    if (this.softwareRenderer) this.device!.maxPixelRatio = 0.75;
    if (qualityChanged) this.app.resizeCanvas();
    if (qualityChanged) this.cameraFrame.update();
  }

  private material(options: {
    color?: string;
    emissive?: string;
    opacity?: number;
    metalness?: number;
    gloss?: number;
    unlit?: boolean;
    transparent?: boolean;
    emissiveIntensity?: number;
    doubleSided?: boolean;
  }): pc.StandardMaterial {
    const material = new pc.StandardMaterial();
    material.diffuse = colorFrom(options.color || '#777777');
    material.useMetalness = true;
    material.metalness = options.metalness ?? 0;
    material.gloss = options.gloss ?? 0.35;
    if (options.emissive) {
      material.emissive = colorFrom(options.emissive);
      material.emissiveIntensity = options.emissiveIntensity ?? 1.4;
    }
    if (options.opacity !== undefined) {
      material.opacity = options.opacity;
      material.blendType = pc.BLEND_NORMAL;
      material.depthWrite = false;
    }
    if (options.transparent) {
      material.blendType = pc.BLEND_NORMAL;
    }
    if (options.unlit) {
      material.useLighting = false;
    }
    if (options.doubleSided) material.cull = pc.CULLFACE_NONE;
    material.update();
    this.ownedMaterials.push(material);
    return material;
  }

  private box(parent: pc.Entity, name: string, size: [number, number, number], position: [number, number, number], material: pc.StandardMaterial, rotationY = 0, cast = false, receive = true): pc.Entity {
    const entity = new pc.Entity(name);
    entity.addComponent('render', { type: 'box', material });
    entity.setLocalPosition(...position);
    entity.setLocalScale(...size);
    entity.setLocalEulerAngles(0, rotationY, 0);
    entity.render!.castShadows = cast;
    entity.render!.receiveShadows = receive;
    parent.addChild(entity);
    return entity;
  }

  private registerPick(entity: pc.Entity, object: SceneObject): void {
    const dims = objectDims(object);
    const y = object.type === 'device' ? fixtureMountY(object) : object.type === 'stage' ? dims.h / 2 : object.elevation + dims.h / 2;
    this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, y, object.position.z), size: new pc.Vec3(dims.w, dims.h, dims.d) });
    const mark = (node: pc.Entity): void => {
      (node as AnyEntity).__rid = object.id;
      node.findComponents('render').forEach((render) => {
        render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; });
      });
      node.children.forEach((child) => mark(child as pc.Entity));
    };
    mark(entity);
  }

  private syncRoomVisibility(project: Project): void {
    const room = project.objects.find((object) => object.type === 'room');
    const roomVisible = !room || (room.visible && room.modelVisible !== false);
    if (this.floorNode) this.floorNode.enabled = roomVisible && project.lighting.showFloor !== false;
    const wallsVisible = roomVisible && project.lighting.showWalls && room?.room?.walls !== false;
    this.wallNodes.forEach((node) => { node.enabled = wallsVisible; });
  }

  private buildRoom(project: Project, world: pc.Entity, bounds: ReturnType<typeof getRoomBounds>): void {
    const room = project.objects.find((object) => object.type === 'room');
    const floorColor = room?.room?.floorColor || '#6f6b63';
    const wallColor = room?.room?.wallColor || '#88847b';
    const width = bounds.maxX - bounds.minX;
    const depth = bounds.maxZ - bounds.minZ;
    const floorMat = this.material({ color: floorColor, metalness: 0.05, gloss: 0.24 });
    const wallMat = this.material({ color: wallColor, metalness: 0, gloss: 0.03 });
    // Area lights use an LTC specular approximation; on a large flat wall it
    // shows up as a faint diamond grid. Walls are matte, so remove specular.
    wallMat.specular = new pc.Color(0, 0, 0);
    wallMat.update();
    const roomVisible = !room || (room.visible && room.modelVisible !== false);
    this.floorNode = null;
    this.wallNodes = [];
    if (roomVisible) {
      this.floorNode = this.box(world, 'floor', [width, 0.08, depth], [bounds.centerX, -0.04, bounds.centerZ], floorMat, 0, true, true);
      this.floorNode.enabled = project.lighting.showFloor !== false;
    }
    if (roomVisible && room?.room?.walls !== false) {
      // Walls are matte light-receiving surfaces. Shadow maps from 22 area bars
      // overlap on them and produce vertical banding; only the floor needs
      // received shadows. Blockers still cast and contain the light volume.
      this.wallNodes = [
        this.box(world, 'wall-back', [width, bounds.height, 0.1], [bounds.centerX, bounds.height / 2, bounds.minZ], wallMat, 0, true, false),
        this.box(world, 'wall-left', [0.1, bounds.height, depth], [bounds.minX, bounds.height / 2, bounds.centerZ], wallMat, 0, true, false),
        this.box(world, 'wall-right', [0.1, bounds.height, depth], [bounds.maxX, bounds.height / 2, bounds.centerZ], wallMat, 0, true, false),
      ];
      this.wallNodes.forEach((node) => { node.enabled = project.lighting.showWalls; });
    }
    // Invisible light blockers: they close the room from the front and above
    // so beams and area-light spill cannot leave the venue, but the camera
    // sees straight through them.
    const blockerMat = this.material({ color: '#000000', unlit: true });
    const ceilingBlocker = this.box(world, 'light-blocker-ceiling', [width, 0.1, depth], [bounds.centerX, bounds.height, bounds.centerZ], blockerMat, 0, true, false);
    const frontBlocker = this.box(world, 'light-blocker-front', [width, bounds.height, 0.1], [bounds.centerX, bounds.height / 2, bounds.maxZ], blockerMat, 0, true, false);
    if (this.blockerLayer) {
      ceilingBlocker.render!.layers = [this.blockerLayer.id];
      frontBlocker.render!.layers = [this.blockerLayer.id];
    }
  }

  private buildAreaBar(world: pc.Entity, object: SceneObject): void {
    const dims = objectDims(object);
    const light = object.light;
    if (!light) return;
    const root = new pc.Entity(object.name);
    root.setPosition(object.position.x, object.elevation, object.position.z);
    root.setEulerAngles(0, -object.rotation, 0);
    world.addChild(root);
    this.objectRoots.set(object.id, root);
    const bounds = getRoomBounds(this.project!);
    const yaw = (object.rotation * Math.PI) / 180;
    const faceSign = Math.sin(yaw) * (bounds.centerX - object.position.x) + Math.cos(yaw) * (bounds.centerZ - object.position.z) >= 0 ? 1 : -1;
    const bodyRoot = new pc.Entity('area-bar-body');
    bodyRoot.enabled = object.modelVisible !== false;
    root.addChild(bodyRoot);
    this.modelBodyRoots.set(object.id, bodyRoot);
    {
      const housing = this.material({ color: '#050608', metalness: 0.8, gloss: 0.28 });
      this.box(bodyRoot, 'area-bar-housing', [dims.w, Math.max(0.08, dims.h), Math.max(0.08, dims.d)], [0, 0, 0], housing, 0, true);
      const tube = this.material({ color: light.on ? '#ffffff' : '#050608', emissive: light.on && !this.noGlow ? '#ffffff' : '#000000', unlit: true });
      this.areaLightLenses.set(object.id, tube);
      this.box(bodyRoot, 'area-bar-tube', [dims.w * 0.94, 0.024, 0.012], [0, 0, faceSign * (dims.d / 2 + 0.008)], tube);
    }
    const spot = new pc.Entity('area-bar-light');
    spot.setLocalPosition(0, 0, faceSign * (dims.d / 2 + 0.012));
    spot.setLocalEulerAngles(faceSign > 0 ? -90 : 90, 0, 0);
    spot.setLocalScale(dims.w * 0.94, 1, 0.1);
    spot.addComponent('light', {
      type: 'spot',
      shape: pc.LIGHTSHAPE_RECT,
      color: colorFrom(light.color),
      intensity: light.intensity * 20,
      range: 16,
      innerConeAngle: clamp(light.zoom, 10, 80),
      outerConeAngle: clamp(light.zoom + 30, 20, 89),
      castShadows: false,
      falloffMode: pc.LIGHTFALLOFF_INVERSESQUARED,
      volumetricScattering: 0.2,
    });
    spot.enabled = light.on && light.intensity > 0.001;
    root.addChild(spot);
    this.areaLightSources.set(object.id, spot);
    (root as AnyEntity).__rid = object.id;
    root.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
    this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation, object.position.z), size: new pc.Vec3(dims.w, Math.max(0.2, dims.h), Math.max(0.2, dims.d)) });
  }

  private worldBoundsOf(root: pc.Entity): pc.BoundingBox {
    root.syncHierarchy();
    const min = new pc.Vec3(Infinity, Infinity, Infinity);
    const max = new pc.Vec3(-Infinity, -Infinity, -Infinity);
    root.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => {
      const aabb = mesh.aabb;
      const matrix = mesh.node.getWorldTransform();
      for (let i = 0; i < 8; i++) {
        const point = new pc.Vec3(
          aabb.center.x + (i & 1 ? 1 : -1) * aabb.halfExtents.x,
          aabb.center.y + (i & 2 ? 1 : -1) * aabb.halfExtents.y,
          aabb.center.z + (i & 4 ? 1 : -1) * aabb.halfExtents.z,
        );
        matrix.transformPoint(point, point);
        min.x = Math.min(min.x, point.x); min.y = Math.min(min.y, point.y); min.z = Math.min(min.z, point.z);
        max.x = Math.max(max.x, point.x); max.y = Math.max(max.y, point.y); max.z = Math.max(max.z, point.z);
      }
    }));
    if (!Number.isFinite(min.x)) return new pc.BoundingBox(new pc.Vec3(), new pc.Vec3(0.5, 0.5, 0.5));
    return new pc.BoundingBox(new pc.Vec3().add2(min, max).mulScalar(0.5), new pc.Vec3().sub2(max, min).mulScalar(0.5));
  }

  private primitiveScale(object: SceneObject): { x: number; y: number; z: number } {
    const p = object.primitive?.params || {};
    const kind = object.primitive?.kind || 'box';
    if (kind === 'box') return { x: p.width ?? 1, y: p.height ?? 1, z: p.depth ?? 1 };
    if (kind === 'sphere') return { x: (p.radius ?? 0.5) * 2, y: (p.radius ?? 0.5) * 2, z: (p.radius ?? 0.5) * 2 };
    if (kind === 'cylinder' || kind === 'cone') return { x: (p.radius ?? 0.5) * 2, y: p.height ?? 1, z: (p.radius ?? 0.5) * 2 };
    if (kind === 'plane') return { x: p.width ?? 2, y: p.height ?? 2, z: 1 };
    return { x: 1, y: 1, z: 1 };
  }

  private buildPrimitive(object: SceneObject): pc.Entity {
    const primitive = object.primitive!;
    const entity = new pc.Entity('primitive');
    const baseMaterial = this.material({ color: '#7d8791', metalness: 0.1, gloss: 0.35 });
    entity.addComponent('render', { type: primitive.kind === 'plane' ? 'plane' : primitive.kind, material: baseMaterial });
    if (entity.render?.meshInstances[0]) this.materialTargets.set(object.id, [{ mesh: entity.render.meshInstances[0], source: baseMaterial, slot: 'Material 1' }]);
    const scale = this.primitiveScale(object);
    if (primitive.kind === 'torus') {
      this.applyTorusMesh(entity, primitive.params.majorRadius ?? 0.7, primitive.params.minorRadius ?? 0.2);
      entity.setLocalPosition(0, primitive.params.minorRadius ?? 0.2, 0);
      (entity as unknown as { __primParams?: string }).__primParams = JSON.stringify(primitive.params);
    } else {
      entity.setLocalScale(scale.x, scale.y, scale.z);
      if (primitive.kind === 'plane') entity.setLocalEulerAngles(-90, 0, 0);
      const height = primitive.kind === 'sphere' ? (primitive.params.radius ?? 0.5) : primitive.kind === 'plane' ? 0.01 : (primitive.params.height ?? 1) / 2;
      entity.setLocalPosition(0, height, 0);
    }
    return entity;
  }

  private applyTorusMesh(entity: pc.Entity, major: number, minor: number): void {
    if (!entity.render || !this.device) return;
    const geometry = new pc.TorusGeometry({ ringRadius: Math.max(0.02, major), tubeRadius: Math.max(0.01, minor), segments: 36, sides: 20 });
    const mesh = pc.Mesh.fromGeometry(this.device, geometry);
    const instance = entity.render.meshInstances[0];
    if (instance) {
      const previous = instance.mesh as unknown as { destroy?: () => void };
      instance.mesh = mesh;
      previous?.destroy?.();
    }
    entity.setLocalScale(1, 1, 1);
  }

  private updatePrimitive(object: SceneObject, root: pc.Entity): void {
    const node = this.primitiveNodes.get(object.id);
    if (!node || !object.primitive) return;
    if (object.primitive.kind === 'torus') {
      const major = object.primitive.params.majorRadius ?? 0.7;
      const minor = object.primitive.params.minorRadius ?? 0.2;
      const key = JSON.stringify(object.primitive.params);
      if ((node as unknown as { __primParams?: string }).__primParams !== key) {
        this.applyTorusMesh(node, major, minor);
        (node as unknown as { __primParams?: string }).__primParams = key;
      }
      node.setLocalPosition(0, minor, 0);
    } else {
      const scale = this.primitiveScale(object);
      node.setLocalScale(scale.x, scale.y, scale.z);
      const height = object.primitive.kind === 'sphere' ? (object.primitive.params.radius ?? 0.5) : object.primitive.kind === 'plane' ? 0.01 : (object.primitive.params.height ?? 1) / 2;
      node.setLocalPosition(0, height, 0);
    }
  }

  private buildModelObjects(project: Project, world: pc.Entity): void {
    for (const object of project.objects) {
      if (!object.visible || object.type !== 'model') continue;
      const data = object.assetId ? this.modelAssets.get(object.assetId) : null;
      const dims = objectDims(object);
      const root = new pc.Entity(object.name);
      const scale = object.scale || { x: 1, y: 1, z: 1 };
      root.setPosition(object.position.x, object.elevation, object.position.z);
      root.setEulerAngles(object.rotationX || 0, -object.rotation, object.rotationZ || 0);
      root.setLocalScale(scale.x, scale.y, scale.z);
      world.addChild(root);
      this.objectRoots.set(object.id, root);
      const motionRoot = new pc.Entity('motion-root');
      root.addChild(motionRoot);
      this.motionRoots.set(object.id, motionRoot);
      if (object.primitive) {
        const primitive = this.buildPrimitive(object);
        motionRoot.addChild(primitive);
        this.primitiveNodes.set(object.id, primitive);
      } else if (data) {
        const base = 2.4 / Math.max(data.size.x, data.size.y, data.size.z);
        const model = data.template.clone();
        let materialIndex = 0;
        model.findComponents('render').forEach((render) => {
          render.castShadows = object.castShadows !== false;
          render.receiveShadows = object.receiveShadows !== false;
          render.meshInstances.forEach((mesh) => {
            const slotName = data.materials[materialIndex] || `Material ${materialIndex + 1}`;
            materialIndex += 1;
            const source = mesh.material;
            if (source) {
              const list = this.materialTargets.get(object.id) || [];
              list.push({ mesh, source, slot: slotName });
              this.materialTargets.set(object.id, list);
            }
            const slotOverride = object.materialOverrides?.[slotName];
            const lookMaterial = project.looks?.find((look) => look.id === object.lookId)?.material;
            const override = (lookMaterial || object.material || slotOverride) ? { ...(lookMaterial || {}), ...(object.material || {}), ...(slotOverride || {}) } : null;
            if (!override) return;
            if (!source || typeof source.clone !== 'function') return;
            const material = source.clone() as any;
            if (override.color) material.diffuse = colorFrom(override.color);
            if (override.metalness !== undefined) material.metalness = override.metalness;
            if (override.roughness !== undefined) material.gloss = 1 - override.roughness;
            if (override.emissive) material.emissive = colorFrom(override.emissive);
            if (override.emissiveIntensity !== undefined) material.emissiveIntensity = clampOverdrive(override.emissiveIntensity);
            if (override.doubleSided !== undefined) material.cull = override.doubleSided ? pc.CULLFACE_NONE : pc.CULLFACE_BACK;
            if (override.opacity !== undefined) {
              material.opacity = override.opacity;
              material.blendType = override.opacity < 1 ? pc.BLEND_NORMAL : pc.BLEND_NONE;
            }
            this.applyCreativeMaterial(material, override);
            this.applyTextureMaps(material, source, override, mesh);
            material.update();
            mesh.material = material;
            this.ownedMaterials.push(material);
          });
        });
        const holder = new pc.Entity('model-holder');
        holder.setLocalScale(base, base, base);
        holder.setLocalPosition(-data.center.x * base, -data.minY * base, -data.center.z * base);
        holder.addChild(model);
        motionRoot.addChild(holder);
        const worldBox = this.worldBoundsOf(root);
        holder.setLocalPosition(
          holder.getLocalPosition().x,
          holder.getLocalPosition().y + (object.elevation - (worldBox.center.y - worldBox.halfExtents.y)) / Math.max(0.001, Math.abs(scale.y)),
          holder.getLocalPosition().z,
        );
      } else {
        const missing = this.material({ color: '#293039', metalness: 0.2, gloss: 0.3 });
        this.box(motionRoot, 'model-placeholder', [dims.w * 0.6, dims.h * 0.6, dims.d * 0.6], [0, dims.h * 0.3, 0], missing);
      }
      const mark = (node: pc.Entity): void => {
        (node as AnyEntity).__rid = object.id;
        node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
        node.children.forEach((child) => mark(child as pc.Entity));
      };
      mark(root);
      const modelSize = data ? new pc.Vec3(data.size.x, data.size.y, data.size.z).mul(new pc.Vec3(2.4 / Math.max(data.size.x, data.size.y, data.size.z), 2.4 / Math.max(data.size.x, data.size.y, data.size.z), 2.4 / Math.max(data.size.x, data.size.y, data.size.z))) : new pc.Vec3(dims.w, dims.h, dims.d);
      this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation + (modelSize.y * scale.y) / 2, object.position.z), size: new pc.Vec3(modelSize.x * Math.abs(scale.x), Math.max(0.2, modelSize.y * Math.abs(scale.y)), modelSize.z * Math.abs(scale.z)) });
    }
  }

  private buildGenericLights(project: Project, world: pc.Entity): void {
    for (const object of project.objects) {
      if (!object.visible || object.type !== 'light') continue;
      const light = object.light;
      const dims = objectDims(object);
      const root = new pc.Entity(object.name);
      const scale = object.scale || { x: 1, y: 1, z: 1 };
      root.setPosition(object.position.x, object.elevation, object.position.z);
      root.setEulerAngles(object.rotationX || 0, -object.rotation, object.rotationZ || 0);
      root.setLocalScale(scale.x, scale.y, scale.z);
      world.addChild(root);
      this.objectRoots.set(object.id, root);
      const motionRoot = new pc.Entity('motion-root');
      root.addChild(motionRoot);
      this.motionRoots.set(object.id, motionRoot);
      {
        const bodyRoot = new pc.Entity('generic-light-body');
        bodyRoot.enabled = object.modelVisible !== false;
        motionRoot.addChild(bodyRoot);
        this.modelBodyRoots.set(object.id, bodyRoot);
        const bodyMat = this.material({ color: '#14191e', metalness: 0.55, gloss: 0.35 });
        if (object.lightType === 'directional') {
          const cone = new pc.Entity('directional-helper');
          cone.addComponent('render', { type: 'cone', material: this.material({ color: '#ffd166', emissive: '#ffd166', unlit: true }) });
          cone.setLocalScale(0.22, 0.5, 0.22);
          cone.setLocalEulerAngles(180, 0, 0);
          bodyRoot.addChild(cone);
          this.box(bodyRoot, 'directional-ring', [0.55, 0.015, 0.55], [0, 0.28, 0], bodyMat);
        } else if (object.lightType === 'area') {
          this.box(bodyRoot, 'area-light-body', [dims.w * scale.x, Math.max(0.08, dims.h * scale.y), Math.max(0.08, dims.d * scale.z)], [0, 0, 0], bodyMat, 0, true);
          const lens = this.material({ color: light?.on ? light.color : '#050608', emissive: light?.on && !this.noGlow ? light.color : '#000000', unlit: true });
          this.genericLightLenses.set(object.id, lens);
          this.box(bodyRoot, 'area-light-lens', [dims.w * 0.94 * scale.x, 0.018, 0.012], [0, 0, dims.d * scale.z / 2 + 0.008], lens);
        } else {
          const body = new pc.Entity('light-body');
          body.addComponent('render', { type: object.lightType === 'point' ? 'sphere' : 'cylinder', material: bodyMat });
          body.setLocalScale(dims.w * scale.x, dims.h * scale.y, dims.d * scale.z);
          bodyRoot.addChild(body);
          const lens = this.material({ color: light?.on ? light.color : '#050608', emissive: light?.on && !this.noGlow ? light.color : '#000000', unlit: true });
          this.genericLightLenses.set(object.id, lens);
          this.box(bodyRoot, 'light-lens', [dims.w * 0.55 * scale.x, 0.016, dims.d * 0.55 * scale.z], [0, dims.h * 0.5 * scale.y, -dims.d * 0.5 * scale.z - 0.008], lens);
        }
        const mark = (node: pc.Entity): void => {
          (node as AnyEntity).__rid = object.id;
          node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
          node.children.forEach((child) => mark(child as pc.Entity));
        };
        mark(root);
        this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation + dims.h * scale.y / 2, object.position.z), size: new pc.Vec3(Math.max(0.35, dims.w * scale.x), Math.max(0.35, dims.h * scale.y), Math.max(0.35, dims.d * scale.z)) });
      }
      if (light) {
        const source = new pc.Entity('generic-light-source');
        const common = {
          color: colorFrom(light.color),
          intensity: light.intensity * (object.lightType === 'directional' ? 0.5 : 12) * (this.project?.lighting.master ?? 1),
          range: object.range || 16,
          castShadows: object.castShadows === true,
          falloffMode: pc.LIGHTFALLOFF_INVERSESQUARED,
          volumetricScattering: object.volumetric ?? 0.2,
        };
        if (object.lightType === 'directional') {
          source.addComponent('light', { ...common, type: 'directional', shadowDistance: 40, normalOffsetBias: 0.1 });
        } else {
          source.setLocalEulerAngles(90, 0, 0);
          if (object.lightType === 'point') {
            source.addComponent('light', { ...common, type: 'omni' });
          } else {
            source.addComponent('light', {
              ...common,
              type: 'spot',
              shape: object.lightType === 'area' ? pc.LIGHTSHAPE_RECT : pc.LIGHTSHAPE_PUNCTUAL,
              innerConeAngle: clamp(object.beamInner ?? light.zoom ?? 35, 1, 89),
              outerConeAngle: clamp(object.beamOuter ?? ((object.beamInner ?? light.zoom ?? 35) + 10), 2, 89),
            });
            if (object.lightType === 'area') source.setLocalScale(dims.w * scale.x, 1, 0.1);
          }
        }
        motionRoot.addChild(source);
        source.enabled = light.on && light.intensity > 0.001;
        this.genericLightSources.set(object.id, source);
      }
    }
  }

  private applyIncrementalLights(project: Project): void {
    for (const object of project.objects) {
      const light = object.light;
      if (!light) continue;
      if (object.type === 'light') {
        const source = this.genericLightSources.get(object.id);
        if (source?.light) {
          const component = source.light;
          source.enabled = light.on && light.intensity > 0.001;
          component.enabled = light.on;
          component.color = colorFrom(light.color);
          component.intensity = light.intensity * 12;
          component.range = object.range || 16;
          component.intensity = light.intensity * (object.lightType === 'directional' ? 0.5 : 12) * (project.lighting.master ?? 1);
          component.castShadows = object.castShadows === true;
          component.volumetricScattering = object.volumetric ?? 0.2;
          if (object.lightType === 'spot' || object.lightType === 'area') {
            component.innerConeAngle = clamp(object.beamInner ?? light.zoom ?? 35, 1, 89);
            component.outerConeAngle = clamp(object.beamOuter ?? ((object.beamInner ?? light.zoom ?? 35) + 10), 2, 89);
          }
        }
        const lens = this.genericLightLenses.get(object.id);
        if (lens) {
          const active = light.on && !this.noGlow;
          lens.diffuse = colorFrom(active ? light.color : '#050608');
          lens.emissive = colorFrom(active ? light.color : '#000000');
          lens.update();
        }
      } else if (object.type === 'areabar') {
        const source = this.areaLightSources.get(object.id);
        if (source?.light) {
          source.enabled = light.on && light.intensity > 0.001;
          source.light.color = colorFrom(light.color);
          source.light.intensity = light.intensity * 20;
          source.light.innerConeAngle = clamp(light.zoom, 10, 80);
          source.light.outerConeAngle = clamp(light.zoom + 30, 20, 89);
        }
        const lens = this.areaLightLenses.get(object.id);
        if (lens) {
          const active = light.on && !this.noGlow;
          lens.diffuse = colorFrom(active ? '#ffffff' : '#050608');
          lens.emissive = colorFrom(active ? '#ffffff' : '#000000');
          lens.update();
        }
      }
    }
  }

  private async loadMaterialTexture(assetId: string, srgb: boolean): Promise<pc.Texture | null> {
    if (this.destroyed) return null;
    const key = `${assetId}:${srgb ? 'srgb' : 'linear'}`;
    const cached = this.textureCache.get(key);
    if (cached) return cached;
    if (this.textureLoading.has(key) || !this.device) return null;
    this.textureLoading.add(key);
    try {
      const asset = await getAsset(assetId);
      if (this.destroyed) return null;
      if (!asset) throw new Error(`Missing texture asset: ${assetId}`);
      const blob = new Blob([asset.data], { type: asset.mime || 'image/png' });
      let image: ImageBitmap | HTMLImageElement;
      if (typeof createImageBitmap === 'function') {
        image = await createImageBitmap(blob);
      } else {
        const url = URL.createObjectURL(blob);
        try {
          image = await new Promise<HTMLImageElement>((resolve, reject) => {
            const element = new Image();
            element.onload = () => resolve(element);
            element.onerror = () => reject(new Error('The texture image could not be decoded.'));
            element.src = url;
          });
        } finally {
          URL.revokeObjectURL(url);
        }
      }
      const texture = new pc.Texture(this.device, {
        width: image.width,
        height: image.height,
        format: pc.PIXELFORMAT_RGBA8,
        mipmaps: true,
        minFilter: pc.FILTER_LINEAR_MIPMAP_LINEAR,
        magFilter: pc.FILTER_LINEAR,
        addressU: pc.ADDRESS_REPEAT,
        addressV: pc.ADDRESS_REPEAT,
        anisotropy: 4,
        srgb,
      });
      texture.setSource(image);
      texture.upload();
      this.textureCache.set(key, texture);
      this.materialSignature = '';
      if (this.project && this.world) this.applyMaterialOverrides(this.project);
      return texture;
    } catch (error) {
      this.callbacks.onAssetError?.(error instanceof Error ? error.message : 'A texture map could not be loaded.');
      return null;
    } finally {
      this.textureLoading.delete(key);
    }
  }

  private meshHasUv0(mesh: pc.MeshInstance): boolean {
    const elements = (mesh.mesh as unknown as { vertexBuffer?: { format?: { elements?: { semantic?: string; name?: string }[] } } })?.vertexBuffer?.format?.elements || [];
    return elements.some((element) => element.semantic === pc.SEMANTIC_TEXCOORD0 || /texcoord0/i.test(element.name || ''));
  }

  private applyTextureMaps(material: any, source: any, override: ObjectMaterial, mesh?: pc.MeshInstance): void {
    // A StandardMaterial texture map requires UV0. On meshes without it the
    // material shader references an attribute that does not exist, producing
    // `vertex_texCoord0 : undeclared identifier`. Drop map sampling for that
    // mesh and keep the base material instead.
    if (mesh && !this.meshHasUv0(mesh)) return;
    if (!override.maps) return;
    for (const [kind, layer] of Object.entries(override.maps) as [MaterialMapKind, MaterialTextureLayer | undefined][]) {
      if (!layer) continue;
      const definition = MATERIAL_MAP_BY_KIND.get(kind);
      if (!definition) continue;
      let map = material[definition.property] as pc.Texture | null;
      if (layer.assetId) {
        map = this.textureCache.get(`${layer.assetId}:${definition.srgb ? 'srgb' : 'linear'}`) || null;
        if (!map) {
          void this.loadMaterialTexture(layer.assetId, !!definition.srgb);
          map = source[definition.property] as pc.Texture | null;
        }
      } else {
        map = source[definition.property] as pc.Texture | null;
      }
      if (map) material[definition.property] = map;
      if (layer.uv !== undefined) material[definition.uvProperty] = Math.max(0, Math.min(7, Math.round(layer.uv)));
      if (layer.tiling) material[definition.tilingProperty] = new pc.Vec2(layer.tiling.x, layer.tiling.y);
      if (layer.offset) material[definition.offsetProperty] = new pc.Vec2(layer.offset.x, layer.offset.y);
      if (layer.rotation !== undefined) material[definition.rotationProperty] = layer.rotation;
      if (definition.channelProperty && layer.channel) material[definition.channelProperty] = layer.channel;
      if (kind === 'roughness' && layer.invert !== undefined) material.glossInvert = layer.invert;
      if (kind === 'emissive' && layer.intensity !== undefined) material.emissiveIntensity = clampOverdrive(layer.intensity);
      if (kind === 'opacity') {
        material.opacity = override.opacity ?? material.opacity ?? 1;
        material.blendType = pc.BLEND_NORMAL;
        material.depthWrite = false;
      }
    }
  }

  private applyCreativeMaterial(material: any, override: { baseColorGain?: number; saturation?: number; contrast?: number; specularGain?: number; reflectionGain?: number; normalStrength?: number; roughnessRemap?: number; roughnessContrast?: number; metalnessResponseGain?: number; emissiveGain?: number }): void {
    const gain = Number(override.baseColorGain ?? 1);
    const saturation = Number(override.saturation ?? 1);
    const contrast = Number(override.contrast ?? 1);
    if (material.diffuse && (gain !== 1 || saturation !== 1 || contrast !== 1)) {
      const source = material.diffuse;
      const luminance = source.r * 0.2126 + source.g * 0.7152 + source.b * 0.0722;
      material.diffuse = new pc.Color(
        Math.max(0, (luminance + (source.r - luminance) * saturation - 0.5) * contrast + 0.5) * gain,
        Math.max(0, (luminance + (source.g - luminance) * saturation - 0.5) * contrast + 0.5) * gain,
        Math.max(0, (luminance + (source.b - luminance) * saturation - 0.5) * contrast + 0.5) * gain,
      );
    }
    const specularGain = Number(override.specularGain ?? 1);
    const reflectionGain = Number(override.reflectionGain ?? 1);
    if (material.specular && (specularGain !== 1 || reflectionGain !== 1)) {
      material.specular = new pc.Color(material.specular.r * specularGain * reflectionGain, material.specular.g * specularGain * reflectionGain, material.specular.b * specularGain * reflectionGain);
    }
    if (override.reflectionGain !== undefined) {
      (material as { specularityFactor?: number }).specularityFactor = reflectionGain;
    }
    if (override.normalStrength !== undefined) material.bumpiness = override.normalStrength;
    if (override.roughnessRemap !== undefined || override.roughnessContrast !== undefined) {
      const gloss = Number(material.gloss ?? 0.5);
      let roughness = 1 - gloss + Number(override.roughnessRemap ?? 0);
      roughness = (roughness - 0.5) * Number(override.roughnessContrast ?? 1) + 0.5;
      material.gloss = Math.max(0, Math.min(1, 1 - roughness));
    }
    if (override.metalnessResponseGain !== undefined) material.metalness = Math.max(0, Math.min(1, Number(material.metalness ?? 0) * override.metalnessResponseGain));
    if (override.emissiveGain !== undefined) material.emissiveIntensity = clampOverdrive(Number(material.emissiveIntensity ?? 1) * override.emissiveGain);
  }

  private applyMaterialOverrides(project: Project): void {
    const signature = JSON.stringify({
      objects: project.objects.map((object) => [object.id, object.lookId, object.material, object.materialOverrides]),
      looks: (project.looks || []).map((look) => [look.id, look.material]),
    });
    if (signature === this.materialSignature) return;
    this.materialSignature = signature;
    for (const object of project.objects) {
      const targets = this.materialTargets.get(object.id);
      if (!targets?.length) continue;
      if (this.shaderEffectTargets.has(object.id)) {
        this.shaderEffectTargets.delete(object.id);
      }
      targets.forEach((target) => {
        const lookMaterial = project.looks?.find((look) => look.id === object.lookId)?.material;
        const override = { ...(lookMaterial || {}), ...(object.material || {}), ...(object.materialOverrides?.[target.slot] || {}) };
        if (Object.keys(override).length === 0) {
          target.mesh.material = target.source;
          return;
        }
        const material = target.source.clone() as any;
        if (override.color) material.diffuse = colorFrom(override.color);
        if (override.metalness !== undefined) material.metalness = override.metalness;
        if (override.roughness !== undefined) material.gloss = 1 - override.roughness;
        if (override.emissive) material.emissive = colorFrom(override.emissive);
        if (override.emissiveIntensity !== undefined) material.emissiveIntensity = clampOverdrive(override.emissiveIntensity);
        if (override.doubleSided !== undefined) material.cull = override.doubleSided ? pc.CULLFACE_NONE : pc.CULLFACE_BACK;
        if (override.opacity !== undefined) {
          material.opacity = override.opacity;
          material.blendType = override.opacity < 1 ? pc.BLEND_NORMAL : pc.BLEND_NONE;
        }
        this.applyCreativeMaterial(material, override);
        this.applyTextureMaps(material, target.source, override, target.mesh);
        material.update();
        target.mesh.material = material;
      });
    }
  }

  private shaderModifiers(object: SceneObject, project: Project): SceneModifier[] {
    return executionOrderedModifiers(effectiveModifiers(object, project).filter((modifier) => modifier.enabled && modifierDefinition(modifier.type).runtime === 'shader'));
  }

  private hasShaderModifiers(object: SceneObject, project: Project): boolean {
    return this.shaderModifiers(object, project).length > 0 || customShadersForObject(project, object).length > 0;
  }

  private ensureEffectTexture(dataUrl: string): pc.Texture | null {
    if (!dataUrl) return null;
    const cached = this.effectTextures.get(dataUrl);
    if (cached) return cached;
    if (!this.fallbackEffectTexture) {
      this.fallbackEffectTexture = new pc.Texture(this.device!, { width: 1, height: 1, mipmaps: false });
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;
      const context = canvas.getContext('2d');
      if (context) { context.fillStyle = '#ffffff'; context.fillRect(0, 0, 1, 1); }
      this.fallbackEffectTexture.setSource(canvas);
      this.fallbackEffectTexture.upload();
    }
    if (!this.effectTexturePending.has(dataUrl)) {
      this.effectTexturePending.add(dataUrl);
      const image = new Image();
      image.onload = () => {
        if (!this.device) return;
        const texture = new pc.Texture(this.device, { mipmaps: true, addressU: pc.ADDRESS_REPEAT, addressV: pc.ADDRESS_REPEAT });
        texture.setSource(image);
        texture.upload();
        this.effectTextures.set(dataUrl, texture);
        this.effectTexturePending.delete(dataUrl);
        if (this.project) this.applyShaderUniforms(this.project);
      };
      image.onerror = () => this.effectTexturePending.delete(dataUrl);
      image.src = dataUrl;
    }
    return this.fallbackEffectTexture;
  }

  private needsOpacityChunk(object: SceneObject, project: Project, source?: pc.Material): boolean {
    const sourceOpacity = Number((source as unknown as { opacity?: number } | undefined)?.opacity ?? 1);
    if (sourceOpacity < 0.999) return true;
    return effectiveModifiers(object, project).some((modifier) => {
      if (!modifier.enabled) return false;
      if (modifier.type === 'dissolve' || modifier.type === 'hologram' || modifier.type === 'ghost') return true;
      if (modifier.type === 'reactionSurface' && Number(modifier.params.opacity ?? 0) > 0.0001) return true;
      return false;
    });
  }

  private installShaderEffect(mesh: pc.MeshInstance, sourceMaterial?: pc.Material, custom?: CustomShader, opacityChunk = true): pc.Material | null {
    if (custom) {
      const candidate = custom.lastWorking || custom;
      const validation = compileCustomShader({ ...custom, vertex: candidate.vertex, fragment: candidate.fragment, lastWorking: undefined });
      if (!validation.ok) {
        // Never replace a valid material with a shader that cannot compile.
        return null;
      }
    }
    if (custom?.mode === 'full-custom') {
      const sourceCode = custom.lastWorking || custom;
      try {
        const elements = (mesh.mesh as unknown as { vertexBuffer?: { format?: { elements?: { semantic?: string; name?: string }[] } } })?.vertexBuffer?.format?.elements || [];
        const has = (needle: string) => elements.some((element) => String(element.semantic || '').toLowerCase().includes(needle) || String(element.name || '').toLowerCase().includes(needle));
        const attributes: Record<string, string> = { aPosition: pc.SEMANTIC_POSITION };
        if (has('normal')) attributes.aNormal = pc.SEMANTIC_NORMAL;
        if (has('texcoord0')) attributes.aUv0 = pc.SEMANTIC_TEXCOORD0;
        if (has('texcoord1')) attributes.aUv1 = pc.SEMANTIC_TEXCOORD1;
        if (has('tangent')) attributes.aTangent = pc.SEMANTIC_TANGENT;
        if (has('color')) attributes.aColor = pc.SEMANTIC_COLOR;
        const material = new pc.ShaderMaterial({
          uniqueName: `re_custom_${custom.id}_${mesh.node?.name || 'mesh'}`,
          vertexGLSL: sourceCode.vertex,
          fragmentGLSL: sourceCode.fragment,
          attributes,
        });
        // Expose the active Look/GLB base-color texture as a sampler. Shaders
        // that do not declare uTexture simply ignore it.
        const sourceMaterialAny = sourceMaterial as unknown as { diffuseMap?: pc.Texture } | undefined;
        if (sourceMaterialAny?.diffuseMap) {
          (material as unknown as { setParameter: (name: string, value: unknown) => void }).setParameter('uTexture', sourceMaterialAny.diffuseMap);
          (material as unknown as { setParameter: (name: string, value: unknown) => void }).setParameter('uHasTexture', 1);
        } else {
          (material as unknown as { setParameter: (name: string, value: unknown) => void }).setParameter('uHasTexture', 0);
        }
        mesh.material = material;
        mesh.cull = false;
        return material;
      } catch (error) {
        console.warn('Full custom shader could not be installed', error);
        return null;
      }
    }
    const source = (sourceMaterial || mesh.material) as unknown as pc.StandardMaterial;
    if (!source || typeof (source as any).clone !== 'function') return null;
    const material = source.clone() as unknown as pc.StandardMaterial;
    // A shader must not silently turn an opaque source material transparent.
    const sourceOpacity = Number((source as unknown as { opacity?: number }).opacity ?? 1);
    if (sourceOpacity >= 0.999) {
      material.opacity = 1;
      material.blendType = pc.BLEND_NONE;
      material.depthWrite = true;
      material.alphaTest = 0;
    }
    try {
      (material as unknown as { shaderChunksVersion?: string }).shaderChunksVersion = '2.24';
      const chunks = (material as unknown as { getShaderChunks: (language: string) => { set: (name: string, source: string) => void } }).getShaderChunks(pc.SHADERLANGUAGE_GLSL);
      const customSource = custom?.lastWorking ? { ...custom, vertex: custom.lastWorking.vertex, fragment: custom.lastWorking.fragment } : custom;
      chunks.set('transformCoreVS', customSource ? buildCustomVertexChunk(EFFECT_VERTEX_CHUNK, customSource) : EFFECT_VERTEX_CHUNK);
      chunks.set('emissivePS', customSource ? buildCustomEmissiveChunk(EFFECT_EMISSIVE_CHUNK, customSource) : EFFECT_EMISSIVE_CHUNK);
      if (opacityChunk) chunks.set('opacityPS', EFFECT_OPACITY_CHUNK);
      chunks.set('glossPS', EFFECT_GLOSS_CHUNK);
      chunks.set('metalnessPS', EFFECT_METALNESS_CHUNK);
      material.update();
    } catch (error) {
      console.warn('Modifier shader could not be installed', error);
      return null;
    }
    mesh.material = material;
    // Conservative culling policy for shader-deformed geometry. CPU AABBs do
    // not include vertex displacement, so this mesh must stay in the draw list.
    mesh.cull = false;
    return material as unknown as pc.Material;
  }

  private collectMeshCapabilities(project: Project): void {
    const result: Record<string, { uv0: boolean; uv1: boolean; normals: boolean; tangents: boolean; colors: boolean }> = {};
    for (const object of project.objects) {
      const root = this.objectRoots.get(object.id);
      if (!root) continue;
      const semantics = new Set<string>();
      root.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => {
        const elements = (mesh.mesh as unknown as { vertexBuffer?: { format?: { elements?: { semantic?: string; name?: string }[] } } })?.vertexBuffer?.format?.elements || [];
        for (const element of elements) {
          if (element.semantic) semantics.add(String(element.semantic).toLowerCase());
          if (element.name) semantics.add(String(element.name).toLowerCase());
        }
      }));
      result[object.id] = {
        uv0: [...semantics].some((value) => value.includes('texcoord0')),
        uv1: [...semantics].some((value) => value.includes('texcoord1')),
        normals: [...semantics].some((value) => value.includes('normal')),
        tangents: [...semantics].some((value) => value.includes('tangent')),
        colors: [...semantics].some((value) => value.includes('color')),
      };
    }
    this.callbacks.onMeshCapabilities?.(result);
  }

  private syncModifierVisuals(project: Project): void {
    for (const object of project.objects) {
      const targets = this.shaderEffectTargets.get(object.id);
      const customEntry = customShadersForObject(project, object)[0];
      const opacityChunk = this.needsOpacityChunk(object, project);
      const customSignature = customEntry ? JSON.stringify({ id: customEntry.shader.id, source: customEntry.shader.lastWorking || customEntry.shader.vertex + customEntry.shader.fragment, opacityChunk }) : (opacityChunk ? 'opacity' : '');
      if (!this.hasShaderModifiers(object, project)) {
        if (targets) {
          targets.forEach((target) => {
            target.mesh.material = target.source;
            target.mesh.cull = true;
            // Uniforms set with MeshInstance#setParameter survive a material swap.
            // Clear them or a disabled/deleted shader keeps deforming geometry.
            target.mesh.clearParameters();
          });
          this.shaderEffectTargets.delete(object.id);
        }
      } else if (targets && customSignature !== (targets[0] as { customSignature?: string }).customSignature) {
        targets.forEach((target) => {
          target.mesh.material = target.source;
          const material = this.installShaderEffect(target.mesh, target.source, customEntry?.shader, opacityChunk);
          if (material) (target as { customSignature?: string }).customSignature = customSignature;
        });
      } else {
        const root = this.objectRoots.get(object.id);
        if (!root) continue;
        if (!targets) {
          const next: { mesh: pc.MeshInstance; source: pc.Material; customSignature?: string }[] = [];
          root.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => {
            const source = mesh.material;
            if (!source) return;
            const material = this.installShaderEffect(mesh, source, customEntry?.shader, opacityChunk);
            if (material) next.push({ mesh, source, customSignature });
          }));
          if (next.length) this.shaderEffectTargets.set(object.id, next);
        }
      }
    }
    this.syncRadialClones(project);
    // New radial clones reuse the original materials; include their meshes in the target list.
    for (const object of project.objects) {
      const root = this.objectRoots.get(object.id);
      if (!root || !this.hasShaderModifiers(object, project)) continue;
      const targets = this.shaderEffectTargets.get(object.id) || [];
      const known = new Set(targets.map((entry) => entry.mesh));
      root.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => {
        if (known.has(mesh) || !mesh.material) return;
        mesh.cull = false;
        targets.push({ mesh, source: mesh.material });
        known.add(mesh);
      }));
      this.shaderEffectTargets.set(object.id, targets);
    }
    this.applyShaderUniforms(project);
    this.recomputeSceneBounds(project);
  }

  private syncRadialClones(project: Project): void {
    for (const object of project.objects) {
      const cloneTypes = ['radialClone', 'gridClone', 'spiralClone', 'sphereClone'];
      const modifier = effectiveModifiers(object, project).find((entry) => cloneTypes.includes(entry.type) && entry.enabled);
      const motionRoot = this.motionRoots.get(object.id);
      const root = this.objectRoots.get(object.id);
      if (!modifier || !motionRoot || !root) {
        const existing = this.radialClones.get(object.id);
        existing?.clones.forEach((clone) => clone.destroy());
        this.radialClones.delete(object.id);
        continue;
      }
      const signature = JSON.stringify(modifier.params);
      const existing = this.radialClones.get(object.id);
      if (existing?.signature === signature) continue;
      existing?.clones.forEach((clone) => clone.destroy());
      const clones: pc.Entity[] = [];
      const count = Math.max(1, Math.min(200, Math.round(Number(modifier.params.count ?? 8))));
      for (let index = 0; index < count; index += 1) {
        const clone = motionRoot.clone();
        clone.name = `radial-clone-${index}`;
        root.addChild(clone);
        clones.push(clone);
      }
      this.radialClones.set(object.id, { signature, clones });
    }
  }

  private applyRadialTransforms(project: Project | null = this.project): void {
    if (!project) return;
    for (const object of project.objects) {
      const cloneTypes = ['radialClone', 'gridClone', 'spiralClone', 'sphereClone'];
      const modifier = effectiveModifiers(object, project).find((entry) => cloneTypes.includes(entry.type) && entry.enabled);
      const group = this.radialClones.get(object.id);
      if (!modifier || !group) continue;
      const count = Math.max(1, group.clones.length);
      const radius = Number(modifier.params.radius ?? 2);
      const angleOffset = Number(modifier.params.angleOffset ?? 0) * Math.PI / 180;
      const scaleVariation = Math.max(0, Math.min(1, Number(modifier.params.scaleVariation ?? 0)));
      const orbit = modifier.params.orbit === true ? this.animTime * Number(modifier.params.orbitSpeed ?? 0.2) * Math.PI * 2 : 0;
      const pattern = modifier.type === 'gridClone' ? 'grid' : modifier.type === 'spiralClone' ? 'spiral' : modifier.type === 'sphereClone' ? 'sphere' : String(modifier.params.pattern || 'ring');
      const spacing = Math.max(0.01, Number(modifier.params.spacing ?? 1.5));
      const height = Number(modifier.params.height ?? 0);
      const phase = Number(modifier.params.phase ?? 0);
      const randomness = Math.max(0, Math.min(1, Number(modifier.params.randomness ?? 0)));
      const scaleProgression = Number(modifier.params.scaleProgression ?? 0);
      const pulse = Math.max(0, Number(modifier.params.pulse ?? 0));
      const pulseSpeed = Number(modifier.params.pulseSpeed ?? 1);
      const gridSide = Math.max(1, Math.ceil(Math.sqrt(count)));
      const golden = Math.PI * (3 - Math.sqrt(5));
      group.clones.forEach((clone, index) => {
        const progress = count > 1 ? index / (count - 1) : 0;
        const angle = angleOffset + orbit + phase + (index / count) * Math.PI * 2;
        let x = Math.cos(angle) * radius;
        let y = 0;
        let z = Math.sin(angle) * radius;
        if (pattern === 'linear') {
          x = (index - (count - 1) / 2) * spacing; y = height; z = 0;
        } else if (pattern === 'grid') {
          const column = index % gridSide;
          const row = Math.floor(index / gridSide);
          x = (column - (gridSide - 1) / 2) * spacing;
          z = (row - (Math.ceil(count / gridSide) - 1) / 2) * spacing;
          y = height;
        } else if (pattern === 'spiral') {
          const spiralAngle = phase + index * 2.39996 + orbit;
          const currentRadius = radius * progress;
          x = Math.cos(spiralAngle) * currentRadius;
          z = Math.sin(spiralAngle) * currentRadius;
          y = height + (progress - 0.5) * spacing * count * 0.15;
        } else if (pattern === 'helix') {
          x = Math.cos(angle) * radius;
          z = Math.sin(angle) * radius;
          y = height + (index - (count - 1) / 2) * spacing;
        } else if (pattern === 'sphere') {
          const latitude = Math.acos(1 - 2 * ((index + 0.5) / count));
          const longitude = golden * index + phase + orbit;
          x = Math.sin(latitude) * Math.cos(longitude) * radius;
          y = Math.cos(latitude) * radius + height;
          z = Math.sin(latitude) * Math.sin(longitude) * radius;
        } else {
          y = height;
        }
        if (randomness > 0) {
          const seed = index * 12.9898 + phase;
          x += Math.sin(seed * 1.7) * randomness * spacing;
          y += Math.cos(seed * 2.1) * randomness * spacing;
          z += Math.sin(seed * 2.9) * randomness * spacing;
        }
        const pulseScale = 1 + (pulse > 0 ? Math.sin(this.animTime * Math.PI * 2 * pulseSpeed + index * phase + phase) * pulse : 0);
        const scale = Math.max(0.001, (1 + progress * scaleProgression) * (1 + Math.sin(index * 12.9898) * scaleVariation) * pulseScale);
        clone.setLocalPosition(x, y, z);
        clone.setLocalEulerAngles(0, modifier.params.rotationFollow === true ? -(angle) * 180 / Math.PI : 0, 0);
        clone.setLocalScale(scale, scale, scale);
      });
    }
  }

  private applyShaderUniforms(project: Project): void {
    if (!this.app) return;
    const time = this.animTime;
    const axisValue = (axis: unknown): number => String(axis) === 'x' ? 0 : String(axis) === 'y' ? 1 : 2;
    for (const object of project.objects) {
      const targets = this.shaderEffectTargets.get(object.id);
      if (!targets?.length) continue;
      const customEntry = customShadersForObject(project, object)[0];
      const modifiers = this.shaderModifiers(object, project).map((modifier) => ({ ...modifier, params: modulatedParams(modifier, project, time, object) }));
      const get = (type: string) => modifiers.find((modifier) => modifier.type === type);
      const twist = get('twist');
      const noise = get('noiseDisplace');
      const texture = get('textureDisplace');
      const fresnel = get('fresnel');
      const dissolve = get('dissolve');
      const domain = get('domainWarp');
      const vortex = get('vortexField');
      const attractor = get('attractorField');
      const bend = get('bend');
      const taper = get('taper');
      const shear = get('shear');
      const melt = get('melt');
      const spherize = get('spherize');
      const ripple = get('ripple');
      const waveField = get('waveField');
      const fold = get('fold');
      const explode = get('explode');
      const quantizeGeometry = get('quantizeGeometry');
      const inflate = get('inflate');
      const slice = get('slice');
      const mirrorGeometry = get('mirrorGeometry');
      const spiralWarp = get('spiralWarp');
      const cylindrify = get('cylindrify');
      const reactionSurface = get('reactionSurface');
      const reactionDisplace = get('reactionDisplace');
      const reactionMapping = String(reactionDisplace?.params.mapping || reactionSurface?.params.mapping || 'auto');
      const orderedCodes: Record<string, number> = { domainWarp: 1, twist: 2, spherize: 3, noiseDisplace: 4, inflate: 5, ripple: 6, vortexField: 7, taper: 8, shear: 9, quantizeGeometry: 10, melt: 11, attractorField: 12, bend: 13, cylindrify: 14, spiralWarp: 15, fold: 16, explode: 17, mirrorGeometry: 18, slice: 19, pinch: 20, fbmDisplace: 21, multiWave: 22 };
      const orderedOps = modifiers.filter((modifier) => modifier.enabled && orderedCodes[modifier.type]).slice(0, 16).map((modifier) => orderedCodes[modifier.type]);
      this.lastGeoOps = orderedOps;
      this.lastNoiseStrength = noise ? Number(noise.params.strength ?? 0) : 0;
      const orderActive = orderedOps.length > 0;
      const twistFirst = false;
      const voronoiSurface = get('voronoiSurface');
      const animatedGradient = get('animatedGradient');
      const glitchSurface = get('glitchSurface');
      const liquidChrome = get('liquidChrome');
      const mercury = get('mercury');
      const liquid = liquidChrome || mercury;
      const magma = get('magma');
      const plasma = get('plasma');
      const hologram = get('hologram');
      const iridescent = get('iridescentFilm');
      const triplanar = get('triplanar');
      const xray = get('xray');
      const ghost = get('ghost');
      const glass = get('glass');
      const neonEdge = get('neonEdge');
      const scanlinesSurface = get('scanlinesSurface');
      const chromaticSurface = get('chromaticSurface');
      const noiseSurface = get('noiseSurface');
      const digitalMatter = get('digitalMatter');
      const checkerSurface = get('checkerSurface');
      const wavesSurface = get('wavesSurface');
      const ringsSurface = get('ringsSurface');
      const wireframeSurface = get('wireframeSurface');
      const textureValue = texture ? this.ensureEffectTexture(String(texture.params.texture || '')) : null;
      const twistAnimated = twist?.params.animate === true;
      const dissolveAnimated = dissolve?.params.animate === true;
      for (const target of targets) {
        const set = (name: string, value: number | number[] | Int32Array | pc.Texture | null): void => {
          target.mesh.setParameter(name, value as never);
          const material = target.mesh.material as unknown as { setParameter?: (key: string, value: unknown) => void };
          material?.setParameter?.(name, value);
        };
        set('uEffectTime', time);
        set('uOrderActive', orderActive ? 1 : 0);
        set('uGeoOpCount', orderedOps.length);
        set('uPinchAmount', modifiers.find((m) => m.type === 'pinch') ? Number(modifiers.find((m) => m.type === 'pinch')?.params.amount ?? 0) : 0);
        set('uPinchRadius', modifiers.find((m) => m.type === 'pinch') ? Number(modifiers.find((m) => m.type === 'pinch')?.params.radius ?? 1) : 1);
        const pinchCenter = modifiers.find((m) => m.type === 'pinch')?.params;
        const fbm = modifiers.find((m) => m.type === 'fbmDisplace');
        set('uFbmStrength', fbm ? Number(fbm.params.strength ?? 0) : 0);
        set('uFbmScale', fbm ? Number(fbm.params.scale ?? 2) : 2);
        set('uFbmSpeed', fbm ? Number(fbm.params.speed ?? 0) : 0);
        set('uFbmOctaves', fbm ? Number(fbm.params.octaves ?? 4) : 4);
        set('uFbmSeed', fbm ? Number(fbm.params.seed ?? 0) : 0);
        set('uFbmMask', fbm ? [fbm.params.maskX !== false ? 1 : 0, fbm.params.maskY !== false ? 1 : 0, fbm.params.maskZ !== false ? 1 : 0] : [0, 0, 0]);
        const multiWave = modifiers.find((m) => m.type === 'multiWave');
        set('uMultiWaveStrength', multiWave ? Number(multiWave.params.strength ?? 0) : 0);
        set('uMultiWaveFrequency', multiWave ? Number(multiWave.params.frequency ?? 3) : 3);
        set('uMultiWaveSpeed', multiWave ? Number(multiWave.params.speed ?? 0) : 0);
        set('uPinchCenter', pinchCenter ? [Number(pinchCenter.centerX ?? 0), Number(pinchCenter.centerY ?? 0), Number(pinchCenter.centerZ ?? 0)] : [0, 0, 0]);
        for (let opIndex = 0; opIndex < 16; opIndex += 1) set(`uGeoOp${opIndex}`, orderedOps[opIndex] || 0);
        set('uOrderTwistFirst', 0);
        set('uOrderDomainStrength', domain ? Number(domain.params.strength ?? 0) : 0);
        set('uOrderTwistAmount', twist ? Number(twist.params.amount ?? 0) : 0);
        const reactionTexture = this.rd?.texture || this.rdFallback;
        set('uReaction', reactionTexture);
        set('uReactionEnabled', reactionSurface || reactionDisplace ? 1 : 0);
        set('uReactionDisplace', reactionDisplace ? Number(reactionDisplace.params.amount ?? 0) : 0);
        set('uReactionEmission', reactionSurface ? Number(reactionSurface.params.emission ?? 0) : 0);
        set('uReactionOpacity', reactionSurface ? Number(reactionSurface.params.opacity ?? 0) : 0);
        set('uReactionBaseColor', reactionSurface ? Number(reactionSurface.params.baseColor ?? 0) : 0);
        set('uReactionRoughness', reactionSurface ? Number(reactionSurface.params.roughness ?? 0) : 0);
        set('uReactionMetallic', reactionSurface ? Number(reactionSurface.params.metallic ?? 0) : 0);
        const reactionColorB = colorFrom(String(reactionSurface?.params.colorB || '#ff2bd6'));
        set('uReactionColorB', [reactionColorB.r, reactionColorB.g, reactionColorB.b]);
        const reactionOutput = String(reactionSurface?.params.output || reactionDisplace?.params.output || 'scalar');
        const fieldLink = (project.fieldLinks || []).find((link) => link.modifierId === reactionSurface?.id || link.modifierId === reactionDisplace?.id);
        set('uFieldAdapter', fieldLink?.adapter === 'threshold' ? 1 : fieldLink?.adapter === 'remap' ? 2 : fieldLink?.adapter === 'invert' ? 3 : fieldLink?.adapter === 'smoothstep' ? 4 : fieldLink?.adapter === 'multiply' ? 5 : fieldLink?.adapter === 'add' ? 6 : fieldLink?.adapter === 'power' ? 7 : fieldLink?.adapter === 'quantize' ? 8 : 0);
        set('uFieldA', fieldLink?.params?.a ?? (fieldLink?.adapter === 'threshold' || fieldLink?.adapter === 'smoothstep' ? 0.5 : 0));
        set('uFieldB', fieldLink?.params?.b ?? 1);
        set('uReactionOutput', reactionOutput === 'mask' ? 1 : reactionOutput === 'gradient' ? 2 : reactionOutput === 'normal' ? 3 : reactionOutput === 'vector' ? 4 : 0);
        const reactionColor = colorFrom(String(reactionSurface?.params.color || '#42e8ff'));
        set('uReactionColor', [reactionColor.r, reactionColor.g, reactionColor.b]);
        set('uReactionMapping', reactionMapping === 'uv' ? 1 : reactionMapping === 'object' ? 2 : reactionMapping === 'world' ? 3 : reactionMapping === 'spherical' ? 4 : 0);
        set('uReactionHasUv', this.meshHasUv0(target.mesh) ? 1 : 0);
        set('uReactionContrast', Number(project.reactionDiffusion?.contrast ?? 1));
        set('uReactionThreshold', Number(project.reactionDiffusion?.threshold ?? 0.2));
        set('uReactionInvert', project.reactionDiffusion?.invert === true ? 1 : 0);
        if (customEntry) {
          const values: Record<string, unknown> = { ...Object.fromEntries(customEntry.shader.params.map((param) => [param.id, param.default])), ...customEntry.instance.values };
          for (const [key, modulator] of Object.entries(customEntry.instance.modulators || {})) {
            if (!modulator.enabled) continue;
            const param = customEntry.shader.params.find((entry) => entry.id === key);
            const source = findSignal(project, modulator.sourceId);
            if (!param || !source) continue;
            const base = Number(values[key] ?? param.default ?? 0);
            let driven = base + Number(modulator.offset ?? 0) + signalValue(source, project, time, object) * Number(modulator.amount ?? 0);
            if (param.hardClamp) driven = Math.max(param.recommendedMin ?? -Infinity, Math.min(param.recommendedMax ?? Infinity, driven));
            values[key] = driven;
          }
          for (const [key, value] of Object.entries(values)) set(key, value as number);
        }
        set('uTwistAmount', twist ? Number(twist.params.amount ?? 0) * (twistAnimated ? Math.sin(time * Math.PI * 2 * Number(twist.params.speed ?? 0.4) + Number(twist.params.phase ?? 0)) : 1) : 0);
        set('uTwistAxis', twist ? axisValue(twist.params.axis) : 1);
        set('uTwistFalloff', twist ? Math.max(0.001, Number(twist.params.falloff ?? 1)) : 1);
        set('uTwistPivot', twist ? [Number(twist.params.pivotX ?? 0), Number(twist.params.pivotY ?? 0), Number(twist.params.pivotZ ?? 0)] : [0, 0, 0]);
        set('uNoiseStrength', noise ? Number(noise.params.strength ?? 0) : 0);
        set('uNoiseScale', noise ? Number(noise.params.scale ?? 2) : 2);
        set('uNoiseSpeed', noise ? Number(noise.params.speed ?? 0) : 0);
        set('uNoiseSeed', noise ? Number(noise.params.seed ?? 0) : 0);
        set('uNoiseMask', noise ? [noise.params.maskX !== false ? 1 : 0, noise.params.maskY !== false ? 1 : 0, noise.params.maskZ !== false ? 1 : 0] : [0, 0, 0]);
        set('uTextureStrength', texture ? Number(texture.params.strength ?? 0) : 0);
        set('uTextureInvert', texture && texture.params.invert === true ? 1 : 0);
        set('uTextureOffset', texture ? [Number(texture.params.offsetX ?? 0), Number(texture.params.offsetY ?? 0)] : [0, 0]);
        set('uTextureTiling', texture ? [Number(texture.params.tilingX ?? 1), Number(texture.params.tilingY ?? 1)] : [1, 1]);
        set('uTexturePlanar', texture && texture.params.projection === 'planar' ? 1 : 0);
        set('uTextureUv1', texture && texture.params.uvChannel === 'uv1' ? 1 : 0);
        set('uTextureMode', texture ? ({ radial: 0, vector: 1, normal: 2, world: 3 } as Record<string, number>)[String(texture.params.mode)] ?? 0 : 0);
        set('uTextureChannel', texture ? ({ r: 0, g: 1, b: 2, a: 3 } as Record<string, number>)[String(texture.params.channel)] ?? 0 : 0);
        set('uTextureMidpoint', texture ? Number(texture.params.midpoint ?? 0) : 0);
        set('uTextureFallback', texture ? Number(texture.params.fallback ?? 0.3) : 0);
        set('uHasDisplaceMap', textureValue ? 1 : 0);
        set('uDisplaceMap', textureValue);
        set('uDomainStrength', domain ? Number(domain.params.strength ?? 0) : 0);
        set('uDomainScale', domain ? Number(domain.params.scale ?? 2) : 2);
        set('uDomainSpeed', domain ? Number(domain.params.speed ?? 0) : 0);
        set('uDomainOctaves', domain ? Number(domain.params.octaves ?? 4) : 4);
        set('uDomainLacunarity', domain ? Number(domain.params.lacunarity ?? 2) : 2);
        set('uDomainPersistence', domain ? Number(domain.params.persistence ?? 0.5) : 0.5);
        set('uDomainSeed', domain ? Number(domain.params.seed ?? 0) : 0);
        set('uDomainAxis', domain ? axisValue(domain.params.axis) : 1);
        set('uVortexStrength', vortex ? Number(vortex.params.strength ?? 0) : 0);
        set('uVortexRadius', vortex ? Number(vortex.params.radius ?? 3) : 3);
        set('uVortexAxis', vortex ? axisValue(vortex.params.axis) : 1);
        set('uVortexFalloff', vortex ? Number(vortex.params.falloff ?? 1) : 1);
        set('uVortexCenter', vortex ? [Number(vortex.params.centerX ?? 0), Number(vortex.params.centerY ?? 0), Number(vortex.params.centerZ ?? 0)] : [0, 0, 0]);
        set('uVortexAnimate', vortex?.params.animate === true ? 1 : 0);
        set('uVortexSpeed', vortex ? Number(vortex.params.speed ?? 0) : 0);
        set('uAttractStrength', attractor ? Number(attractor.params.strength ?? 0) : 0);
        set('uAttractRadius', attractor ? Number(attractor.params.radius ?? 4) : 4);
        set('uAttractFalloff', attractor ? Number(attractor.params.falloff ?? 1) : 1);
        set('uAttractPoint', attractor ? [Number(attractor.params.pointX ?? 0), Number(attractor.params.pointY ?? 0), Number(attractor.params.pointZ ?? 0)] : [0, 0, 0]);
        set('uAttractRepel', attractor?.params.mode === 'repel' ? 1 : 0);
        set('uBendAmount', bend ? Number(bend.params.amount ?? 0) : 0);
        set('uBendAxis', bend ? axisValue(bend.params.axis) : 1);
        set('uBendStart', bend ? Number(bend.params.start ?? -2) : -2);
        set('uBendEnd', bend ? Number(bend.params.end ?? 2) : 2);
        set('uBendFalloff', bend ? Number(bend.params.falloff ?? 1) : 1);
        set('uBendPivot', bend ? [Number(bend.params.pivotX ?? 0), Number(bend.params.pivotY ?? 0), Number(bend.params.pivotZ ?? 0)] : [0, 0, 0]);
        set('uBendAnimate', bend?.params.animate === true ? 1 : 0);
        set('uBendSpeed', bend ? Number(bend.params.speed ?? 0) : 0);
        set('uTaperAmount', taper ? Number(taper.params.amount ?? 0) : 0);
        set('uTaperAxis', taper ? axisValue(taper.params.axis) : 1);
        set('uTaperCenter', taper ? Number(taper.params.center ?? 0) : 0);
        set('uTaperFalloff', taper ? Number(taper.params.falloff ?? 1) : 1);
        set('uTaperBulge', taper ? Number(taper.params.bulge ?? 0) : 0);
        set('uShearX', shear ? Number(shear.params.shearX ?? 0) : 0);
        set('uShearZ', shear ? Number(shear.params.shearZ ?? 0) : 0);
        set('uQuantize', shear ? Number(shear.params.quantize ?? 0) : 0);
        set('uShearAxis', shear ? axisValue(shear.params.axis) : 1);
        set('uMeltAmount', melt ? Number(melt.params.amount ?? 0) : 0);
        set('uMeltViscosity', melt ? Number(melt.params.viscosity ?? 0.5) : 0.5);
        set('uMeltNoise', melt ? Number(melt.params.noise ?? 1) : 1);
        set('uMeltThreshold', melt ? Number(melt.params.threshold ?? 0.25) : 0.25);
        set('uMeltAxis', melt ? axisValue(melt.params.axis) : 1);
        set('uSpherizeAmount', spherize ? Number(spherize.params.amount ?? 0) : 0);
        set('uSpherizeRadius', spherize ? Number(spherize.params.radius ?? 1) : 1);
        set('uRippleStrength', ripple ? Number(ripple.params.strength ?? 0) : 0);
        set('uRippleFrequency', ripple ? Number(ripple.params.frequency ?? 4) : 4);
        set('uRippleSpeed', ripple ? Number(ripple.params.speed ?? 0) : 0);
        set('uRippleCenter', ripple ? [Number(ripple.params.centerX ?? 0), Number(ripple.params.centerY ?? 0), Number(ripple.params.centerZ ?? 0)] : [0, 0, 0]);
        set('uRippleRadius', ripple ? Number(ripple.params.radius ?? 8) : 8);
        set('uWaveStrength', waveField ? Number(waveField.params.strength ?? 0) : 0);
        set('uWaveFrequency', waveField ? Number(waveField.params.frequency ?? 3) : 3);
        set('uWaveSpeed', waveField ? Number(waveField.params.speed ?? 0) : 0);
        set('uWaveTravel', waveField ? axisValue(waveField.params.direction) : 1);
        set('uWaveAxis', waveField ? axisValue(waveField.params.axis) : 1);
        set('uFoldAmount', fold ? Number(fold.params.amount ?? 0) : 0);
        set('uFoldAxis', fold ? axisValue(fold.params.axis) : 0);
        set('uFoldPosition', fold ? Number(fold.params.position ?? 0) : 0);
        set('uFoldSharpness', fold ? Number(fold.params.sharpness ?? 1) : 1);
        set('uExplodeAmount', explode ? Number(explode.params.amount ?? 0) : 0);
        set('uExplodeSeed', explode ? Number(explode.params.seed ?? 0) : 0);
        set('uExplodeThreshold', explode ? Number(explode.params.threshold ?? 0) : 0);
        set('uExplodeAxis', explode ? axisValue(explode.params.axis) : 1);
        set('uQuantizeGrid', quantizeGeometry ? Number(quantizeGeometry.params.grid ?? 0) : 0);
        set('uQuantizeRadial', quantizeGeometry ? Number(quantizeGeometry.params.radial ?? 0) : 0);
        set('uQuantizeAngular', 0);
        set('uInflateAmount', inflate ? Number(inflate.params.amount ?? 0) : 0);
        set('uInflateFalloff', inflate ? Number(inflate.params.falloff ?? 1) : 1);
        set('uInflateCenter', inflate ? Number(inflate.params.center ?? 0) : 0);
        set('uSliceBands', slice ? Number(slice.params.bands ?? 1) : 1);
        set('uSliceGap', slice ? Number(slice.params.gap ?? 0) : 0);
        set('uSliceAxis', slice ? axisValue(slice.params.axis) : 1);
        set('uMirrorAmount', mirrorGeometry ? Number(mirrorGeometry.params.amount ?? 0) : 0);
        set('uMirrorAxis', mirrorGeometry ? axisValue(mirrorGeometry.params.axis) : 0);
        set('uMirrorPosition', mirrorGeometry ? Number(mirrorGeometry.params.position ?? 0) : 0);
        set('uSpiralAmount', spiralWarp ? Number(spiralWarp.params.amount ?? 0) : 0);
        set('uSpiralRadius', spiralWarp ? Number(spiralWarp.params.radius ?? 1) : 1);
        set('uSpiralTwist', spiralWarp ? Number(spiralWarp.params.twist ?? 1) : 1);
        set('uSpiralAxis', spiralWarp ? axisValue(spiralWarp.params.axis) : 1);
        set('uCylindrifyAmount', cylindrify ? Number(cylindrify.params.amount ?? 0) : 0);
        set('uCylindrifyRadius', cylindrify ? Number(cylindrify.params.radius ?? 1) : 1);
        set('uCylindrifyAxis', cylindrify ? axisValue(cylindrify.params.axis) : 1);
        set('uTwistStart', twist ? Number(twist.params.start ?? -1000000) : -1000000);
        set('uTwistEnd', twist ? Number(twist.params.end ?? 1000000) : 1000000);
        set('uFresnelIntensity', fresnel ? Number(fresnel.params.intensity ?? 0) : 0);
        set('uFresnelBias', fresnel ? Number(fresnel.params.bias ?? 0) : 0);
        set('uFresnelPower', fresnel ? Number(fresnel.params.power ?? 3) : 3);
        set('uFresnelMode', fresnel?.params.colorMode === 'solid' ? 1 : 0);
        const fcolor = colorFrom(String(fresnel?.params.color || '#57d7ff'));
        set('uFresnelColor', [fcolor.r, fcolor.g, fcolor.b]);
        set('uFresnelIridescence', fresnel ? Number(fresnel.params.iridescence ?? 0) : 0);
        set('uFresnelBlend', fresnel ? Number(fresnel.params.blend ?? 1) : 0);
        const amount = dissolve ? Math.max(0, Math.min(1, Number(dissolve.params.amount ?? 0) + (dissolveAnimated ? Math.sin(time * Math.PI * 2 * Number(dissolve.params.speed ?? 0.3)) * 0.25 : 0))) : 0;
        set('uDissolveAmount', amount);
        set('uDissolveEdgeWidth', dissolve ? Number(dissolve.params.edgeWidth ?? 0.03) : 0.03);
        const dcolor = colorFrom(String(dissolve?.params.edgeColor || '#39e6ff'));
        set('uDissolveEdgeColor', [dcolor.r, dcolor.g, dcolor.b]);
        set('uDissolveEdgeGlow', dissolve ? Number(dissolve.params.edgeGlow ?? 0) : 0);
        set('uDissolveNoiseScale', dissolve ? Number(dissolve.params.noiseScale ?? 3) : 3);
        set('uDissolveSeed', dissolve ? Number(dissolve.params.seed ?? 0) : 0);
        const surfaceColor = (value: unknown, fallback: string): number[] => { const color = colorFrom(String(value || fallback)); return [color.r, color.g, color.b]; };
        set('uLiquidAmount', liquid ? 1 : 0);
        set('uLiquidTint', surfaceColor(liquid?.params.tint, '#cfe8ff'));
        set('uLiquidAccent', surfaceColor(liquid?.params.accent, '#7fdcff'));
        set('uLiquidFresnel', liquid ? Number(liquid.params.fresnel ?? 1) : 0);
        set('uLiquidEmission', liquid ? Number(liquid.params.emission ?? 0.3) : 0);
        set('uLiquidDistortion', liquid ? Number(liquid.params.distortion ?? 0) : 0);
        set('uLiquidFlow', liquid ? Number(liquid.params.flowSpeed ?? 0) : 0);
        set('uLiquidScale', liquid ? Number(liquid.params.noiseScale ?? 2) : 2);
        set('uMagmaAmount', magma ? 1 : 0);
        set('uMagmaCrust', surfaceColor(magma?.params.crust, '#120b08'));
        set('uMagmaLava', surfaceColor(magma?.params.lava, '#ff5a12'));
        set('uMagmaHot', surfaceColor(magma?.params.hot, '#ffd36a'));
        set('uMagmaScale', magma ? Number(magma.params.noiseScale ?? 2.5) : 2.5);
        set('uMagmaCrackWidth', magma ? Number(magma.params.crackWidth ?? 0.1) : 0.1);
        set('uMagmaTemperature', magma ? Number(magma.params.temperature ?? 1) : 1);
        set('uMagmaEmission', magma ? Number(magma.params.emission ?? 2) : 0);
        set('uMagmaFlow', magma ? Number(magma.params.flowSpeed ?? 0) : 0);
        set('uMagmaDistortion', magma ? Number(magma.params.distortion ?? 0) : 0);
        set('uPlasmaAmount', plasma ? 1 : 0);
        set('uPlasmaA', surfaceColor(plasma?.params.colorA, '#1a0033'));
        set('uPlasmaB', surfaceColor(plasma?.params.colorB, '#00e5ff'));
        set('uPlasmaC', surfaceColor(plasma?.params.colorC, '#ff21c8'));
        set('uPlasmaScale', plasma ? Number(plasma.params.scale ?? 2.8) : 2.8);
        set('uPlasmaSpeed', plasma ? Number(plasma.params.speed ?? 0.4) : 0.4);
        set('uPlasmaTurbulence', plasma ? Number(plasma.params.turbulence ?? 1) : 1);
        set('uPlasmaEmission', plasma ? Number(plasma.params.emission ?? 2) : 0);
        set('uPlasmaEdge', plasma ? Number(plasma.params.edgeGlow ?? 1) : 0);
        set('uHoloAmount', hologram ? 1 : 0);
        set('uHoloA', surfaceColor(hologram?.params.colorA, '#35d9ff'));
        set('uHoloB', surfaceColor(hologram?.params.colorB, '#ff3df2'));
        set('uHoloScanDensity', hologram ? Number(hologram.params.scanlineDensity ?? 60) : 60);
        set('uHoloScanSpeed', hologram ? Number(hologram.params.scanlineSpeed ?? 1) : 1);
        set('uHoloFlicker', hologram ? Number(hologram.params.flicker ?? 0) : 0);
        set('uHoloGlitch', hologram ? Number(hologram.params.glitch ?? 0) : 0);
        set('uHoloBreakup', hologram ? Number(hologram.params.breakup ?? 0) : 0);
        set('uHoloNoise', hologram ? Number(hologram.params.noiseDistortion ?? 0) : 0);
        set('uHoloChromatic', hologram ? Number(hologram.params.chromatic ?? 0) : 0);
        set('uHoloOpacity', hologram ? Number(hologram.params.opacity ?? 0.7) : 1);
        set('uHoloEmission', hologram ? Number(hologram.params.emission ?? 2) : 0);
        set('uIridAmount', iridescent ? 1 : 0);
        set('uIridThickness', iridescent ? Number(iridescent.params.thickness ?? 420) : 420);
        set('uIridIOR', iridescent ? Number(iridescent.params.ior ?? 1.38) : 1.38);
        set('uIridHue', iridescent ? Number(iridescent.params.hueShift ?? 0) : 0);
        set('uIridFresnel', iridescent ? Number(iridescent.params.fresnel ?? 2) : 2);
        set('uIridScale', iridescent ? Number(iridescent.params.scale ?? 1) : 1);
        set('uIridTint', surfaceColor(iridescent?.params.tint, '#ffffff'));
        set('uTriAmount', triplanar ? 1 : 0);
        set('uTriA', surfaceColor(triplanar?.params.colorA, '#0a0d12'));
        set('uTriB', surfaceColor(triplanar?.params.colorB, '#6be7ff'));
        set('uTriScale', triplanar ? Number(triplanar.params.scale ?? 2) : 2);
        set('uTriSpeed', triplanar ? Number(triplanar.params.speed ?? 0.1) : 0);
        set('uTriBlend', triplanar ? Number(triplanar.params.blend ?? 0.5) : 0.5);
        set('uTriEmission', triplanar ? Number(triplanar.params.emission ?? 1) : 0);
        set('uXrayAmount', xray ? Number(xray.params.intensity ?? 0) : 0);
        set('uXrayColor', surfaceColor(xray?.params.color, '#67d9ff'));
        set('uXrayPower', xray ? Number(xray.params.fresnelPower ?? 2) : 2);
        set('uGhostAmount', ghost ? Number(ghost.params.intensity ?? 0) : 0);
        set('uGhostColor', surfaceColor(ghost?.params.color, '#dff6ff'));
        set('uGhostPower', ghost ? Number(ghost.params.fresnelPower ?? 3) : 3);
        set('uGlassAmount', glass ? 1 : 0);
        set('uGlassColor', surfaceColor(glass?.params.tint, '#bfefff'));
        set('uNeonAmount', neonEdge ? Number(neonEdge.params.intensity ?? 0) : 0);
        set('uNeonColor', surfaceColor(neonEdge?.params.color, '#48ffe8'));
        set('uNeonPower', neonEdge ? Number(neonEdge.params.fresnelPower ?? 2.4) : 2.4);
        set('uNeonWidth', neonEdge ? Number(neonEdge.params.width ?? 0.65) : 0.65);
        set('uScanSurfAmount', scanlinesSurface ? Number(scanlinesSurface.params.intensity ?? 0) : 0);
        set('uScanSurfColor', surfaceColor(scanlinesSurface?.params.color, '#68f4ff'));
        set('uScanDensity', scanlinesSurface ? Number(scanlinesSurface.params.density ?? 80) : 80);
        set('uScanSpeed', scanlinesSurface ? Number(scanlinesSurface.params.speed ?? 0) : 0);
        set('uChromaticAmount', chromaticSurface ? Number(chromaticSurface.params.strength ?? 0) : 0);
        set('uChromaticA', surfaceColor(chromaticSurface?.params.colorA, '#ff2a6d'));
        set('uChromaticB', surfaceColor(chromaticSurface?.params.colorB, '#05d9e8'));
        set('uChromaticScale', chromaticSurface ? Number(chromaticSurface.params.scale ?? 2) : 2);
        set('uChromaticSpeed', chromaticSurface ? Number(chromaticSurface.params.speed ?? 0) : 0);
        set('uNoiseSurfAmount', noiseSurface ? Number(noiseSurface.params.intensity ?? 0) : 0);
        set('uNoiseSurfA', surfaceColor(noiseSurface?.params.colorA, '#11131a'));
        set('uNoiseSurfB', surfaceColor(noiseSurface?.params.colorB, '#d9f7ff'));
        set('uNoiseSurfScale', noiseSurface ? Number(noiseSurface.params.scale ?? 3) : 3);
        set('uNoiseSurfSpeed', noiseSurface ? Number(noiseSurface.params.speed ?? 0) : 0);
        set('uDigitalSurfAmount', digitalMatter ? Number(digitalMatter.params.intensity ?? 0) : 0);
        set('uDigitalColor', surfaceColor(digitalMatter?.params.color, '#8affd8'));
        set('uDigitalBlocks', digitalMatter ? Number(digitalMatter.params.blocks ?? 12) : 12);
        set('uDigitalSpeed', digitalMatter ? Number(digitalMatter.params.speed ?? 0) : 0);
        set('uCheckerAmount', checkerSurface ? Number(checkerSurface.params.intensity ?? 0) : 0);
        set('uCheckerA', surfaceColor(checkerSurface?.params.colorA, '#05070a'));
        set('uCheckerB', surfaceColor(checkerSurface?.params.colorB, '#f2f2f2'));
        set('uCheckerScale', checkerSurface ? Number(checkerSurface.params.scale ?? 4) : 4);
        set('uWavesSurfAmount', wavesSurface ? Number(wavesSurface.params.intensity ?? 0) : 0);
        set('uWavesColor', surfaceColor(wavesSurface?.params.color, '#55ffcc'));
        set('uWavesScale', wavesSurface ? Number(wavesSurface.params.scale ?? 3) : 3);
        set('uWavesSpeed', wavesSurface ? Number(wavesSurface.params.speed ?? 0) : 0);
        set('uRingsSurfAmount', ringsSurface ? Number(ringsSurface.params.intensity ?? 0) : 0);
        set('uRingsColor', surfaceColor(ringsSurface?.params.color, '#ffd166'));
        set('uRingsFreq', ringsSurface ? Number(ringsSurface.params.frequency ?? 8) : 8);
        set('uRingsSpeed', ringsSurface ? Number(ringsSurface.params.speed ?? 0) : 0);
        set('uWireAmount', wireframeSurface ? Number(wireframeSurface.params.intensity ?? 0) : 0);
        set('uWireColor', surfaceColor(wireframeSurface?.params.color, '#59ffdf'));
        set('uVoronoiAmount', voronoiSurface ? 1 : 0);
        set('uVoronoiScale', voronoiSurface ? Number(voronoiSurface.params.scale ?? 4) : 4);
        set('uVoronoiBorder', voronoiSurface ? Number(voronoiSurface.params.border ?? 0.08) : 0.08);
        set('uVoronoiA', surfaceColor(voronoiSurface?.params.colorA, '#05070b'));
        set('uVoronoiB', surfaceColor(voronoiSurface?.params.colorB, '#ff4bd8'));
        set('uVoronoiEmission', voronoiSurface ? Number(voronoiSurface.params.emission ?? 1) : 0);
        set('uGradientAmount', animatedGradient ? 1 : 0);
        set('uGradientA', surfaceColor(animatedGradient?.params.colorA, '#0b1020'));
        set('uGradientB', surfaceColor(animatedGradient?.params.colorB, '#ff2fd0'));
        set('uGradientC', surfaceColor(animatedGradient?.params.colorC, '#4be1ff'));
        set('uGradientScale', animatedGradient ? Number(animatedGradient.params.scale ?? 1) : 1);
        set('uGradientSpeed', animatedGradient ? Number(animatedGradient.params.speed ?? 0) : 0);
        set('uGradientAngle', animatedGradient ? Number(animatedGradient.params.angle ?? 0) : 0);
        set('uGradientEmission', animatedGradient ? Number(animatedGradient.params.emission ?? 1) : 0);
        set('uGlitchSurfaceAmount', glitchSurface ? 1 : 0);
        set('uGlitchSurfaceBlocks', glitchSurface ? Number(glitchSurface.params.blocks ?? 10) : 10);
        set('uGlitchSurfaceShift', glitchSurface ? Number(glitchSurface.params.shift ?? 0) : 0);
        set('uGlitchSurfaceEmission', glitchSurface ? Number(glitchSurface.params.emission ?? 1) : 0);
        set('uGlitchSurfaceColor', surfaceColor(glitchSurface?.params.color, '#7df9ff'));
        const material = target.mesh.material as unknown as { alphaTest?: number; blendType?: number; depthWrite?: boolean; update?: () => void; __effectDissolve?: boolean; __effectSurface?: string; metalness?: number; gloss?: number; useMetalness?: boolean; roughness?: number; opacity?: number; diffuse?: pc.Color; wireframe?: boolean; refraction?: number };
        const sourceMaterial = target.source as unknown as { metalness?: number; gloss?: number; useMetalness?: boolean; blendType?: number; depthWrite?: boolean; opacity?: number; diffuse?: pc.Color; wireframe?: boolean };
        const surfaceKey = JSON.stringify([
          liquid ? { id: liquid.id, metalness: liquid.params.metalness, roughness: liquid.params.roughness } : null,
          magma?.id, plasma?.id, hologram?.id, iridescent?.id, triplanar?.id, voronoiSurface?.id, animatedGradient?.id, glitchSurface?.id, xray?.id, ghost?.id, glass?.id, neonEdge?.id, scanlinesSurface?.id, chromaticSurface?.id, noiseSurface?.id, digitalMatter?.id, checkerSurface?.id, wavesSurface?.id, ringsSurface?.id, wireframeSurface?.id, dissolve?.id,
        ]);
        if (material && material.__effectSurface !== surfaceKey) {
          material.__effectSurface = surfaceKey;
          material.metalness = sourceMaterial.metalness ?? 0;
          material.gloss = sourceMaterial.gloss ?? 0.5;
          material.useMetalness = sourceMaterial.useMetalness ?? true;
          material.blendType = sourceMaterial.blendType ?? pc.BLEND_NONE;
          material.depthWrite = sourceMaterial.depthWrite ?? true;
          material.opacity = sourceMaterial.opacity ?? 1;
          if (sourceMaterial.diffuse) material.diffuse = sourceMaterial.diffuse.clone();
          (material as { wireframe?: boolean }).wireframe = sourceMaterial.wireframe ?? false;
          material.alphaTest = 0;
          if (liquid) {
            material.metalness = Number(liquid.params.metalness ?? 1);
            material.gloss = 1 - clamp(Number(liquid.params.roughness ?? 0.08), 0, 1);
            material.useMetalness = true;
          }
          if (magma) {
            material.metalness = 0;
            material.gloss = 0.05;
            material.useMetalness = false;
          }
          if (hologram) {
            material.blendType = pc.BLEND_NORMAL;
            material.depthWrite = false;
          }
          if (xray) { material.opacity = Math.max(0, Math.min(1, Number(xray.params.opacity ?? 0.4))); material.blendType = pc.BLEND_NORMAL; material.depthWrite = false; }
          if (ghost) { material.opacity = Math.max(0, Math.min(1, Number(ghost.params.opacity ?? 0.22))); material.blendType = pc.BLEND_NORMAL; material.depthWrite = false; }
          if (glass) {
            material.opacity = Math.max(0, Math.min(1, Number(glass.params.opacity ?? 0.38)));
            material.gloss = 1 - Math.max(0, Math.min(1, Number(glass.params.roughness ?? 0.04)));
            material.blendType = pc.BLEND_NORMAL;
            material.depthWrite = false;
            (material as { refraction?: number }).refraction = Number(glass.params.refraction ?? 1.45);
            material.diffuse = colorFrom(String(glass.params.tint || '#bfefff'));
          }
          (material as { wireframe?: boolean }).wireframe = !!wireframeSurface;
          if (dissolve) {
            material.alphaTest = 0.01;
            material.blendType = pc.BLEND_NORMAL;
            material.depthWrite = false;
          }
          material.update?.();
        }
      }
    }
  }

  private applyTimeline(dt: number): void {
    if (!this.project) return;
    const project = this.project;
    const timeline = project.timeline;
    if (!timeline) {
      this.timelineProject = null;
      if (this.timelineApplied) this.restoreTimelineBase(project);
      return;
    }
    setTimelineRange(timeline.duration, timeline.loop);
    const time = getTimelineTime();
    const overrides = sampleTimeline(project, time);
    if (!overrides.size) {
      this.timelineProject = null;
      if (this.timelineApplied) this.restoreTimelineBase(project);
      return;
    }
    const effective = applyTimelineToProject(project, overrides);
    this.timelineProject = effective;
    this.timelineApplied = true;
    this.applyObjectTransforms(effective);
    this.applyIncrementalLights(effective);
    this.applyDeviceLightStates(effective);
    this.applyTimelineScene(effective);
    this.applyMaterialOverrides(effective);
    this.applyModifiers(dt, effective);
  }

  private applyDeviceLightStates(project: Project): void {
    const master = project.lighting.master ?? 1;
    for (const object of project.objects) {
      if (object.type !== 'device' || !object.light) continue;
      const node = this.deviceLightNodes.get(object.id);
      const component = node?.light;
      if (!component) continue;
      const light = object.light;
      node.enabled = light.on && light.intensity > 0.001;
      component.enabled = light.on;
      component.color = colorFrom(light.color);
      const profile = opticalProfile(object);
      const isBar = profile.family === 'bar';
      const device = getDevice(object.deviceId);
      const kind = device?.kind || 'spot';
      const level = light.intensity * master;
      component.intensity = level * (isBar ? 9 : kind === 'par' ? 1.5 : kind === 'beam' ? 6 : 8);
      if (!isBar) {
        component.innerConeAngle = clamp(light.zoom / 2, 2, 80);
        component.outerConeAngle = clamp(light.zoom, 3, 89);
      }
    }
  }

  private physicsLayerBit(layer: string): number {
    const index = ['world', 'objects', 'particles', 'triggers', 'camera', 'custom1', 'custom2', 'custom3', 'custom4'].indexOf(layer);
    return 1 << Math.max(0, index);
  }

  private physicsMask(object: SceneObject): number {
    const collision = object.collision;
    if (!collision || collision.mode === 'off') return 0;
    return collision.mask.reduce((mask, layer) => mask | this.physicsLayerBit(layer), 0);
  }

  private disposePhysicsWorld(): void {
    for (const entry of this.physicsBodies.values()) {
      entry.entity.destroy();
      entry.shape.destroy();
    }
    this.physicsBodies.clear();
    this.physicsWorld = null;
    this.physicsSignature = '';
  }

  private physicsConfigSignature(project: Project): string {
    return JSON.stringify({
      settings: project.physics ? { enabled: project.physics.enabled, gravity: project.physics.gravity, quality: project.physics.quality } : null,
      objects: project.objects.filter((object) => object.physics?.mode !== 'off' || object.collision?.mode === 'on' || object.collision?.mode === 'trigger').map((object) => ({ id: object.id, physics: object.physics, collision: object.collision, position: object.position, elevation: object.elevation, size: object.size, rotation: object.rotation, type: object.type, visible: object.visible })),
    });
  }

  private buildPhysicsWorld(project: Project): void {
    const CANNON = this.physicsNamespace;
    if (!CANNON || !this.world) return;
    this.disposePhysicsWorld();
    const settings = normalizePhysics(project.physics);
    const world = new CANNON.World({ gravity: new CANNON.Vec3(settings.gravity.x, settings.gravity.y, settings.gravity.z) });
    world.allowSleep = true;
    world.broadphase = new CANNON.SAPBroadphase(world);
    this.physicsWorld = world;
    const ground = new CANNON.Body({ mass: 0, shape: new CANNON.Plane(), collisionFilterGroup: this.physicsLayerBit('world'), collisionFilterMask: -1 });
    ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    world.addBody(ground);
    for (const object of project.objects) {
      if (!object.visible) continue;
      const mode = object.physics?.mode || 'off';
      const collisionMode = object.collision?.mode || 'off';
      if (mode === 'off' && collisionMode === 'off') continue;
      const dims = objectDims(object);
      const shapeName = object.collision?.shape || 'auto';
      let shape: CANNON.Shape;
      if (shapeName === 'sphere' || (shapeName === 'auto' && object.primitive?.kind === 'sphere')) {
        shape = new CANNON.Sphere(Math.max(dims.w, dims.d, dims.h) * 0.5);
      } else if (shapeName === 'cylinder' || shapeName === 'cone' || shapeName === 'capsule') {
        shape = new CANNON.Cylinder(dims.w * 0.5, dims.w * 0.5, dims.h, 10);
      } else {
        shape = new CANNON.Box(new CANNON.Vec3(dims.w * 0.5, dims.h * 0.5, dims.d * 0.5));
      }
      const dynamic = mode === 'dynamic';
      const body = new CANNON.Body({
        mass: dynamic ? Math.max(0.0001, Number(object.physics?.mass ?? 1)) : 0,
        shape,
        type: mode === 'kinematic' ? CANNON.Body.KINEMATIC : dynamic ? CANNON.Body.DYNAMIC : CANNON.Body.STATIC,
        position: new CANNON.Vec3(object.position.x, object.elevation + dims.h * 0.5, object.position.z),
        collisionFilterGroup: this.physicsLayerBit(object.collision?.layer || 'objects'),
        collisionFilterMask: collisionMode === 'off' ? 0 : this.physicsMask(object),
        linearDamping: Number(object.physics?.linearDamping ?? 0.1),
        angularDamping: Number(object.physics?.angularDamping ?? 0.2),
      });
      body.allowSleep = true;
      body.sleepSpeedLimit = 0.12;
      body.sleepTimeLimit = 0.8;
      if (collisionMode === 'trigger') {
        body.collisionResponse = false;
        body.isTrigger = true;
      }
      if (object.physics) {
        body.velocity.set(object.physics.velocity.x, object.physics.velocity.y, object.physics.velocity.z);
        body.angularVelocity.set(object.physics.angularVelocity.x, object.physics.angularVelocity.y, object.physics.angularVelocity.z);
      }
      body.addEventListener('collide', (event: { body: CANNON.Body; contact: CANNON.ContactEquation }) => {
        const other = project.objects.find((candidate) => (event.body as unknown as { __rid?: string }).__rid === candidate.id);
        if (!other) return;
        const relative = Math.abs(body.velocity.y - event.body.velocity.y) + Math.abs(body.velocity.x - event.body.velocity.x) + Math.abs(body.velocity.z - event.body.velocity.z);
        const impact = Math.min(20, relative);
        setPhysicsSignalState(object.id, { impact, trigger: object.collision?.mode === 'trigger' ? 1 : 0 });
        setPhysicsSignalState(other.id, { impact, trigger: other.collision?.mode === 'trigger' ? 1 : 0 });
        if (this.rd && this.project?.reactionDiffusion?.enabled && (this.project.reactionDiffusion.injection ?? 0) > 0 && this.roomBounds) {
          const bounds = this.roomBounds;
          const u = (object.position.x - bounds.minX) / Math.max(0.001, bounds.maxX - bounds.minX);
          const v = (object.position.z - bounds.minZ) / Math.max(0.001, bounds.maxZ - bounds.minZ);
          const config = this.project.reactionDiffusion;
          this.rd.paint(u, v, config.injectionRadius ?? 0.12, (config.injection ?? 0) * Math.min(1, impact / 8 + 0.15), config.paintChemical || 'B');
        }
      });
      (body as unknown as { __rid: string }).__rid = object.id;
      world.addBody(body);
      const debug = new pc.Entity(`physics-debug-${object.id}`);
      const debugMaterial = this.material({ color: collisionMode === 'trigger' ? '#ff4bd8' : '#5ea8ff', emissive: collisionMode === 'trigger' ? '#ff4bd8' : '#5ea8ff', unlit: true, transparent: true, opacity: 0.35 });
      (debugMaterial as unknown as { wireframe?: boolean }).wireframe = true;
      debugMaterial.update();
      debug.addComponent('render', { type: shapeName === 'sphere' ? 'sphere' : 'box', material: debugMaterial, castShadows: false });
      debug.setLocalScale(dims.w, dims.h, dims.d);
      debug.enabled = settings.debug;
      this.world.addChild(debug);
      this.physicsBodies.set(object.id, { body, entity: debug, shape: debug });
    }
    this.physicsSignature = this.physicsConfigSignature(project);
  }

  private applyPhysicsFields(project: Project, time: number): void {
    const CANNON = this.physicsNamespace;
    if (!CANNON) return;
    const fields = (project.fields || []).filter((field) => field.enabled);
    if (!fields.length) return;
    for (const [objectId, entry] of this.physicsBodies) {
      const body = entry.body;
      if (body.mass <= 0 || body.type !== CANNON.Body.DYNAMIC) continue;
      for (const rawField of fields) {
        if (modifierDefinition(rawField.type).runtime !== 'field') continue;
        const params = modulatedParams(rawField, project, time, project.objects.find((object) => object.id === objectId));
        const strength = Number(params.strength ?? 0);
        if (!Number.isFinite(strength) || strength === 0) continue;
        const mass = Math.max(0.0001, body.mass);
        const force = new CANNON.Vec3();
        if (rawField.type === 'fieldDirectionalGravity') {
          const dir = new CANNON.Vec3(Number(params.directionX ?? 0), Number(params.directionY ?? -1), Number(params.directionZ ?? 0));
          if (dir.length() > 0.0001) dir.normalize();
          force.set(dir.x, dir.y, dir.z);
          force.scale(strength * (params.affectMass === false ? 1 : mass), force);
        } else if (rawField.type === 'fieldAttractor' || rawField.type === 'fieldVortex' || rawField.type === 'fieldOrbit') {
          const center = new CANNON.Vec3(Number(params.centerX ?? 0), Number(params.centerY ?? 0), Number(params.centerZ ?? 0));
          const relative = new CANNON.Vec3(body.position.x - center.x, body.position.y - center.y, body.position.z - center.z);
          const distance = Math.max(0.0001, relative.length());
          const falloff = Math.pow(Math.max(0, 1 - distance / Math.max(0.001, Number(params.radius ?? 8))), Math.max(0.05, Number(params.falloff ?? 1)));
          if (rawField.type === 'fieldAttractor') {
            relative.scale((params.mode === 'repel' ? 1 : -1) * strength * falloff * mass / distance, force);
          } else if (rawField.type === 'fieldVortex') {
            const axis = String(params.axis || 'y');
            const tangent = axis === 'x' ? new CANNON.Vec3(0, -relative.z, relative.y) : axis === 'z' ? new CANNON.Vec3(relative.y, -relative.x, 0) : new CANNON.Vec3(relative.z, 0, -relative.x);
            tangent.normalize();
            tangent.scale(strength * falloff * mass, force);
          } else {
            const tangent = new CANNON.Vec3(relative.z, 0, -relative.x);
            tangent.normalize();
            const radial = new CANNON.Vec3(relative.x, 0, relative.z);
            radial.normalize();
            force.set(tangent.x * strength * mass + radial.x * strength * 0.25 * mass, 0, tangent.z * strength * mass + radial.z * strength * 0.25 * mass);
          }
        } else if (rawField.type === 'fieldWind') {
          const turbulence = Number(params.turbulence ?? 0);
          const noise = Math.sin(time * Number(params.speed ?? 0.5) * 3.1 + body.position.y * 0.7);
          force.set((Number(params.directionX ?? 1) + noise * turbulence) * strength * mass, noise * turbulence * strength * mass * 0.3, Number(params.directionZ ?? 0) * strength * mass);
        } else if (rawField.type === 'fieldNoise') {
          const scale = Math.max(0.001, Number(params.scale ?? 2));
          const seed = Number(params.seed ?? 0);
          const x = Math.sin(body.position.y * scale + time * Number(params.speed ?? 0) + seed) * Math.cos(body.position.z * scale * 0.7);
          const y = Math.sin(body.position.z * scale + time * Number(params.speed ?? 0) * 1.3 + seed) * Math.cos(body.position.x * scale * 0.6);
          const z = Math.sin(body.position.x * scale + time * Number(params.speed ?? 0) * 0.8 + seed) * Math.cos(body.position.y * scale * 0.9);
          force.set(x * strength * mass, y * strength * mass, z * strength * mass);
        } else if (rawField.type === 'fieldDrag') {
          force.set(-body.velocity.x * strength * mass, -body.velocity.y * strength * mass, -body.velocity.z * strength * mass);
        }
        body.applyForce(force, body.position);
      }
    }
  }

  private updatePhysics(dt: number): void {
    if (!this.project) return;
    const settings = normalizePhysics(this.project.physics);
    if (!settings.enabled) {
      if (this.physicsWorld) { this.disposePhysicsWorld(); this.restoreTimelineBase(this.project); }
      return;
    }
    const signature = this.physicsConfigSignature(this.project);
    if (!this.physicsWorld && !this.physicsLoading) {
      this.physicsLoading = true;
      import('cannon-es').then((CANNON) => {
        this.physicsLoading = false;
        this.physicsNamespace = CANNON;
        if (this.project) this.buildPhysicsWorld(this.project);
      }).catch(() => { this.physicsLoading = false; });
    }
    if (!this.physicsWorld) return;
    if (signature !== this.physicsSignature) this.buildPhysicsWorld(this.project);
    const world = this.physicsWorld;
    const CANNON = this.physicsNamespace;
    if (!CANNON) return;
    world.gravity.set(settings.gravity.x, settings.gravity.y, settings.gravity.z);
    if (this.physicsResetToken !== settings.resetToken) {
      this.physicsResetToken = settings.resetToken;
      this.buildPhysicsWorld(this.project);
      for (const object of this.project.objects) {
        const root = this.objectRoots.get(object.id);
        if (root) { root.setPosition(object.position.x, object.elevation, object.position.z); root.setEulerAngles(object.rotationX || 0, -object.rotation, object.rotationZ || 0); }
      }
      return;
    }
    const shouldStep = !settings.paused || this.physicsStepToken !== settings.stepToken;
    if (this.physicsStepToken !== settings.stepToken) this.physicsStepToken = settings.stepToken;
    if (shouldStep) {
      this.applyPhysicsFields(this.project, this.animTime);
      const subSteps = settings.quality === 'low' ? 1 : settings.quality === 'high' ? 5 : settings.quality === 'extreme' ? 8 : 3;
      world.step(1 / 60, Math.min(0.1, dt) * settings.timeScale, subSteps);
      impactDecay(dt);
    }
    for (const object of this.project.objects) {
      const entry = this.physicsBodies.get(object.id);
      const root = this.objectRoots.get(object.id);
      if (!entry || !root) continue;
      entry.shape.enabled = settings.debug;
      if (object.physics?.mode === 'kinematic') {
        const dims = objectDims(object);
        entry.body.position.set(object.position.x, object.elevation + dims.h * 0.5, object.position.z);
        const quaternion = new pc.Quat().setFromEulerAngles(object.rotationX || 0, -object.rotation, object.rotationZ || 0);
        entry.body.quaternion.set(quaternion.x, quaternion.y, quaternion.z, quaternion.w);
      } else if (object.physics?.mode === 'dynamic') {
        const dims = objectDims(object);
        root.setPosition(entry.body.position.x, entry.body.position.y - dims.h * 0.5, entry.body.position.z);
        const euler = new pc.Quat(entry.body.quaternion.x, entry.body.quaternion.y, entry.body.quaternion.z, entry.body.quaternion.w).getEulerAngles();
        root.setEulerAngles(euler.x, -euler.y, euler.z);
      }
      entry.shape.setPosition(entry.body.position.x, entry.body.position.y, entry.body.position.z);
      entry.shape.setEulerAngles(new pc.Quat(entry.body.quaternion.x, entry.body.quaternion.y, entry.body.quaternion.z, entry.body.quaternion.w).getEulerAngles());
      setPhysicsSignalState(object.id, {
        velocity: entry.body.velocity.length(),
        angularSpeed: entry.body.angularVelocity.length(),
        height: entry.body.position.y,
        distanceToGround: Math.max(0, entry.body.position.y - objectDims(object).h * 0.5),
        sleeping: entry.body.sleepState === CANNON.Body.SLEEPING ? 1 : 0,
      });
    }
  }

  private applySceneEffectStack(_dt: number): void {
    if (!this.app || !this.project || !this.cameraFrame) return;
    const project = this.project;
    const effects = (project.effects || []).filter((entry) => entry.enabled && modifierDefinition(entry.type).runtime === 'scene');
    if (!effects.length) return;
    const time = this.animTime;
    let exposure = clamp(Number(project.lighting.exposure) || 1.5, 0.4, 3.5) * 0.985;
    let ambient = project.lighting.workLight ? new pc.Color(0.128, 0.136, 0.148) : new pc.Color(0.088, 0.092, 0.1);
    let fogMultiplier = 1;
    let fogNoise = 0;
    const get = (type: string) => {
      const modifier = effects.find((entry) => entry.type === type);
      return modifier ? { ...modifier, params: modulatedParams(modifier, project, time, null) } : undefined;
    };
    const fov = get('cameraFovPulse');
    if (this.camera) {
      let cameraFov = 50;
      if (fov) {
        const phase = time * Number(fov.params.speed ?? 0.25) * Math.PI * 2 + Number(fov.params.phase ?? 0);
        const wave = fov.params.waveform === 'pulse' ? (Math.sin(phase) > 0 ? 1 : -1) : fov.params.waveform === 'noise' ? Math.sin(phase * 1.7) * Math.sin(phase * 0.31) : Math.sin(phase);
        cameraFov += wave * Number(fov.params.amount ?? 0);
      }
      this.camera.camera!.fov = clamp(cameraFov, 5, 140);
    }
    const pulse = get('environmentExposure');
    if (pulse) {
      const speed = Number(pulse.params.speed ?? 0.2) * 6.2831853;
      const wave = pulse.params.wave === 'pulse' ? (Math.sin(time * speed + Number(pulse.params.phase ?? 0)) > 0 ? 1 : 0) : pulse.params.wave === 'noise' ? Math.sin(time * speed * 1.7) * Math.sin(time * speed * 0.37) : Math.sin(time * speed + Number(pulse.params.phase ?? 0));
      exposure *= Math.max(0.01, 1 + wave * Number(pulse.params.amount ?? 0));
    }
    const drift = get('ambientColorDrift');
    if (drift) {
      const mix = 0.5 + 0.5 * Math.sin(time * Number(drift.params.speed ?? 0.05) * 6.2831853 + Number(drift.params.phase ?? 0));
      const a = colorFrom(String(drift.params.colorA || '#150022'));
      const b = colorFrom(String(drift.params.colorB || '#003344'));
      const amount = Math.max(0, Math.min(1, Number(drift.params.amount ?? 0.5)));
      ambient = new pc.Color(ambient.r + (a.r + (b.r - a.r) * mix - ambient.r) * amount, ambient.g + (a.g + (b.g - a.g) * mix - ambient.g) * amount, ambient.b + (a.b + (b.b - a.b) * mix - ambient.b) * amount);
    }
    const fog = get('fogField');
    if (fog) {
      const flow = Math.sin(time * Number(fog.params.speed ?? 0.15) * 6.2831853);
      fogMultiplier *= Math.max(0, 1 + Number(fog.params.amount ?? 0.5) * (0.5 + flow * 0.5));
      fogNoise = Number(fog.params.noiseAmount ?? 0) * (0.5 + 0.5 * Math.sin(time * 2.3 + Number(fog.params.noiseScale ?? 2)));
    }
    const turbulence = get('fogTurbulence');
    if (turbulence) {
      fogMultiplier *= Math.max(0, 1 + Math.sin(time * Number(turbulence.params.speed ?? 0.4) * Number(turbulence.params.frequency ?? 2.5) * 6.2831853) * Number(turbulence.params.amount ?? 0.4));
    }
    this.app.scene.exposure = exposure;
    this.app.scene.ambientLight = ambient;
    const volumetricFog = this.cameraFrame.volumetricFog;
    if (project.lighting.volumetric && project.lighting.haze > 0.002) {
      volumetricFog.enabled = !this.noFog;
      volumetricFog.density = Math.max(0.0005, project.lighting.haze * 0.0052 * fogMultiplier + fogNoise * 0.004);
    }
  }

  private applyTimelineScene(project: Project): void {
    if (!this.app) return;
    this.app.scene.exposure = clamp(Number(project.lighting.exposure) || 1.5, 0.4, 3.5) * 0.985;
    this.app.scene.ambientLight = project.lighting.workLight ? new pc.Color(0.128, 0.136, 0.148) : new pc.Color(0.088, 0.092, 0.1);
    this.applyFog(project);
    if (this.cameraFrame) {
      const quality = project.lighting.quality;
      const base = quality === 'photo' ? 0.1 : quality === 'ultra' ? 0.06 : quality === 'high' ? 0.04 : quality === 'medium' ? 0.03 : 0.02;
      this.cameraFrame.bloom.intensity = this.softwareRenderer || this.noGlow ? 0 : base * clamp(project.lighting.bloomStrength ?? 1, 0, 10);
    }
  }

  private restoreTimelineBase(project: Project): void {
    this.timelineApplied = false;
    this.timelineProject = null;
    this.applyObjectTransforms(project);
    this.applyIncrementalLights(project);
    this.applyDeviceLightStates(project);
    this.applySceneSettings(project);
    this.applyMaterialOverrides(project);
    this.applyShaderUniforms(project);
  }

  private applyModifiers(dt: number, project: Project | null = this.project): void {
    this.animTime += Math.min(dt, 0.1);
    if (!project) return;
    for (const object of project.objects) {
      const root = this.motionRoots.get(object.id);
      if (!root) continue;
      const modifiers = executionOrderedModifiers(effectiveModifiers(object, project));
      if (!modifiers?.length) {
        if (this.animatedModifierIds.delete(object.id)) {
          root.setLocalPosition(0, 0, 0);
          root.setLocalEulerAngles(0, 0, 0);
          root.setLocalScale(1, 1, 1);
        }
        continue;
      }
      this.animatedModifierIds.add(object.id);
      const position = { x: 0, y: 0, z: 0 };
      const rotation = { x: 0, y: 0, z: 0 };
      let scale = 1;
      for (const rawModifier of modifiers) {
        if (!rawModifier.enabled) continue;
        const modifier = { ...rawModifier, params: modulatedParams(rawModifier, project, this.animTime, object) };
        const axis = String(modifier.params.axis || 'y') as 'x' | 'y' | 'z';
        const speed = Number(modifier.params.speed ?? 1);
        const phase = Number(modifier.params.phase ?? 0);
        const wave = Math.sin(this.animTime * Math.PI * 2 * speed + phase);
        if (modifier.type === 'rotate' && modifier.params.autoPlay !== false) rotation[axis] += this.animTime * speed * Number(modifier.params.direction ?? 1);
        else if (modifier.type === 'float') position[axis] += wave * Number(modifier.params.amplitude ?? 0.3);
        else if (modifier.type === 'rotateOsc') rotation[axis] += wave * Number(modifier.params.amplitude ?? 20);
        else if (modifier.type === 'scalePulse') scale *= Math.max(0.01, 1 + wave * Number(modifier.params.amplitude ?? 0.2));
        else if (modifier.type === 'orbitMotion') {
          const radius = Number(modifier.params.radius ?? 2);
          const angle = this.animTime * Number(modifier.params.speed ?? 0.25) * Math.PI * 2 + Number(modifier.params.phase ?? 0);
          position.x += Number(modifier.params.centerX ?? 0) + Math.cos(angle) * radius;
          position.y += Number(modifier.params.centerY ?? 0) + Number(modifier.params.height ?? 0);
          position.z += Number(modifier.params.centerZ ?? 0) + Math.sin(angle) * radius;
        } else if (modifier.type === 'curlNoiseMotion') {
          const noise = (x: number, y: number, z: number) => { const v = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453; return (v - Math.floor(v)) * 2 - 1; };
          const t = this.animTime * Number(modifier.params.speed ?? 0.35) + Number(modifier.params.seed ?? 1);
          const s = Math.max(0.01, Number(modifier.params.scale ?? 1.5));
          const amp = Number(modifier.params.amplitude ?? 0.4);
          position.x += noise(object.position.x * s + t, object.position.z * s, t) * amp;
          position.y += noise(object.elevation * s + 17.1, t, object.position.x * s) * amp;
          position.z += noise(t, object.position.z * s + 31.7, object.elevation * s) * amp;
        } else if (modifier.type === 'noiseRotation') {
          const noise = (v: number) => Math.sin(v * 12.9898 + Number(modifier.params.seed ?? 2)) * 43758.5453;
          const n = (noise(this.animTime * Number(modifier.params.speed ?? 0.5)) - Math.floor(noise(this.animTime * Number(modifier.params.speed ?? 0.5)))) * 2 - 1;
          rotation[axis] += n * Number(modifier.params.amount ?? 0);
        } else if (modifier.type === 'lookAtMotion') {
          const dx = Number(modifier.params.targetX ?? 0) - object.position.x;
          const dz = Number(modifier.params.targetZ ?? 0) - object.position.z;
          const yaw = Math.atan2(dx, dz) * 180 / Math.PI;
          const targetAxis = String(modifier.params.axis || 'y') as 'x' | 'y' | 'z';
          rotation[targetAxis] += (yaw - (targetAxis === 'y' ? object.rotation : 0)) * Number(modifier.params.strength ?? 1);
        }
      }
      const spring = modifiers.find((modifier) => modifier.enabled && modifier.type === 'springFollow');
      if (spring) {
        const params = modulatedParams(spring, project, this.animTime, object);
        const state = this.springStates.get(object.id) || { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0 };
        const targetX = Number(params.targetX ?? 0) - object.position.x;
        const targetY = Number(params.targetY ?? 1) - object.elevation;
        const targetZ = Number(params.targetZ ?? 0) - object.position.z;
        const stiffness = Math.max(0.1, Number(params.stiffness ?? 20));
        const damping = Math.max(0, Number(params.damping ?? 6));
        state.vx += (targetX - state.x) * stiffness * dt - state.vx * damping * dt;
        state.vy += (targetY - state.y) * stiffness * dt - state.vy * damping * dt;
        state.vz += (targetZ - state.z) * stiffness * dt - state.vz * damping * dt;
        state.x += state.vx * dt; state.y += state.vy * dt; state.z += state.vz * dt;
        const maxOffset = Math.max(0.1, Number(params.maxOffset ?? 10));
        state.x = Math.max(-maxOffset, Math.min(maxOffset, state.x));
        state.y = Math.max(-maxOffset, Math.min(maxOffset, state.y));
        state.z = Math.max(-maxOffset, Math.min(maxOffset, state.z));
        this.springStates.set(object.id, state);
        position.x += state.x; position.y += state.y; position.z += state.z;
      } else if (this.springStates.delete(object.id)) { /* clean */ }
      root.setLocalPosition(position.x, position.y, position.z);
      root.setLocalEulerAngles(rotation.x, rotation.y, rotation.z);
      root.setLocalScale(scale, scale, scale);
      this.applyLightEffects(object, project, root, modifiers);
    }
    this.applyRadialTransforms(project);
    this.applyShaderUniforms(project);
  }

  private applyLightEffects(object: SceneObject, project: Project, motionRoot: pc.Entity, modifiers: SceneModifier[]): void {
    if (!object.light) return;
    const effects = modifiers.filter((modifier) => modifier.enabled && modifierDefinition(modifier.type).runtime === 'light');
    if (!effects.length) return;
    const time = this.animTime;
    const get = (type: string) => {
      const modifier = effects.find((entry) => entry.type === type);
      return modifier ? { ...modifier, params: modulatedParams(modifier, project, time, object) } : undefined;
    };
    let factor = 1;
    let coneFactor = 1;
    let color = colorFrom(object.light.color);
    const noise = get('lightIntensityNoise');
    if (noise) {
      const seed = Number(noise.params.seed ?? 0);
      const value = Math.sin(time * Number(noise.params.speed ?? 1) * 6.2831853 + seed) * 0.5 + Math.sin(time * 2.13 + seed * 2.7) * 0.5;
      factor *= 1 + value * Number(noise.params.amount ?? 0);
    }
    const drift = get('lightColorDrift');
    if (drift) {
      const mixA = 0.5 + 0.5 * Math.sin(time * Number(drift.params.speed ?? 0.1) * 6.2831853 + Number(drift.params.seed ?? 0));
      const a = colorFrom(String(drift.params.colorA || '#ff3d00'));
      const b = colorFrom(String(drift.params.colorB || '#00e5ff'));
      const amount = Math.max(0, Math.min(1, Number(drift.params.amount ?? 0.5)));
      color = new pc.Color(
        color.r + (a.r + (b.r - a.r) * mixA - color.r) * amount,
        color.g + (a.g + (b.g - a.g) * mixA - color.g) * amount,
        color.b + (a.b + (b.b - a.b) * mixA - color.b) * amount,
      );
    }
    const pulse = get('lightBeamPulse');
    if (pulse) {
      const wave = Math.sin(time * Number(pulse.params.frequency ?? 1) * 6.2831853 * Number(pulse.params.speed ?? 1));
      factor *= Math.max(0, 1 + wave * Number(pulse.params.amount ?? 0));
      coneFactor *= Math.max(0.1, 1 + wave * Number(pulse.params.coneAmount ?? 0));
    }
    const strobe = get('lightStrobePattern');
    if (strobe) {
      const rate = Math.max(0.001, Number(strobe.params.rate ?? 8));
      const duty = Math.max(0.01, Math.min(1, Number(strobe.params.duty ?? 0.25)));
      let phase = time * rate;
      if (strobe.params.pattern === 'accelerate') phase = time * time * rate * 0.35;
      if (strobe.params.pattern === 'decelerate') phase = Math.sqrt(Math.max(0, time)) * rate * 1.5;
      let gate = (phase - Math.floor(phase)) < duty ? 1 : 0;
      if (strobe.params.pattern === 'random') gate = Math.sin(Math.floor(phase) * 91.7 + Number(time)) > 0.25 ? 1 : 0;
      if (strobe.params.pattern === 'morse') gate = ((Math.floor(phase) % 5) < 2 || (Math.floor(phase) % 11) < 5) ? 1 : 0;
      factor *= 1 - (1 - gate) * Number(strobe.params.amount ?? 1);
    }
    const volumetric = get('lightVolumetricMod');
    if (volumetric) {
      const wave = 0.5 + 0.5 * Math.sin(time * Number(volumetric.params.speed ?? 0.5) * 6.2831853 + Number(volumetric.params.seed ?? 0));
      const component = object.type === 'light' ? this.genericLightSources.get(object.id)?.light : this.deviceLightNodes.get(object.id)?.light;
      if (component) component.volumetricScattering = (object.volumetric ?? 0.2) * (1 + wave * Number(volumetric.params.amount ?? 0.3));
    }
    const orbit = get('lightOrbit');
    if (orbit) {
      const angle = time * Number(orbit.params.speed ?? 0.2) * Math.PI * 2 + Number(orbit.params.phase ?? 0);
      motionRoot.setLocalPosition(Math.cos(angle) * Number(orbit.params.radius ?? 2), Number(orbit.params.height ?? 0), Math.sin(angle) * Number(orbit.params.radius ?? 2));
    }
    const walk = get('lightRandomWalk');
    if (walk) {
      const amount = Number(walk.params.amount ?? 1);
      const speed = Number(walk.params.speed ?? 0.3);
      const seed = Number(walk.params.seed ?? 0);
      motionRoot.setLocalPosition(
        Math.sin(time * speed * 1.73 + seed) * amount,
        Math.sin(time * speed * 2.11 + seed * 1.7) * amount * 0.4,
        Math.cos(time * speed * 1.37 + seed * 2.3) * amount,
      );
    }
    const component = object.type === 'light' ? this.genericLightSources.get(object.id)?.light : this.deviceLightNodes.get(object.id)?.light;
    if (!component) return;
    const master = project.lighting.master ?? 1;
    if (object.type === 'light') {
      const base = object.light.intensity * (object.lightType === 'directional' ? 0.5 : 12) * master;
      component.intensity = base * factor;
      if (object.lightType !== 'directional' && component.type === 'spot') {
        component.innerConeAngle = clamp((object.beamInner ?? object.light.zoom) * coneFactor, 1, 89);
        component.outerConeAngle = clamp((object.beamOuter ?? ((object.beamInner ?? object.light.zoom) + 10)) * coneFactor, 2, 89);
      }
    } else {
      const profile = opticalProfile(object);
      const device = getDevice(object.deviceId);
      const isBar = profile.family === 'bar';
      const scale = isBar ? 9 : device?.kind === 'par' ? 1.5 : device?.kind === 'beam' ? 6 : 8;
      component.intensity = object.light.intensity * master * scale * factor;
      if (!isBar) {
        component.innerConeAngle = clamp((object.light.zoom / 2) * coneFactor, 2, 80);
        component.outerConeAngle = clamp(object.light.zoom * coneFactor, 3, 89);
      }
    }
    component.color = color;
    component.enabled = object.light.on;
  }

  private buildStageModel(project: Project, world: pc.Entity): void {
    if (!this.stageTemplate || !this.stageBounds) return;
    for (const object of project.objects) {
      if (object.type !== 'stage' || !object.visible) continue;
      const dims = objectDims(object);
      if (dims.d < 1) continue;
      const scale = Math.min(
        (dims.w * 0.92) / Math.max(0.01, this.stageBounds.size.x),
        (dims.d * 0.92) / Math.max(0.01, this.stageBounds.size.z),
        4.45 / Math.max(0.01, this.stageBounds.size.y),
      );
      const root = new pc.Entity(`stage-model-${object.id}`);
      root.setPosition(object.position.x, object.elevation, object.position.z);
      root.setEulerAngles(0, -object.rotation, 0);
      const model = this.stageTemplate.clone();
      model.findComponents('render').forEach((render) => {
        render.castShadows = true;
        render.receiveShadows = true;
      });
      // Keep the authored GLB root transform; scale a wrapper instead.
      const holder = new pc.Entity('stage-holder');
      holder.setLocalScale(scale, scale, scale);
      holder.setLocalPosition(
        -this.stageBounds.center.x * scale,
        -this.stageBounds.minY * scale,
        -this.stageBounds.center.z * scale,
      );
      holder.addChild(model);
      root.addChild(holder);
      world.addChild(root);
      this.objectRoots.set(object.id, root);
      (root as AnyEntity).__rid = object.id;
      const markStage = (node: pc.Entity): void => {
        (node as AnyEntity).__rid = object.id;
        node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
        node.children.forEach((child) => markStage(child as pc.Entity));
      };
      markStage(root);
      this.pickTargets.push({
        id: object.id,
        center: new pc.Vec3(object.position.x, object.elevation + 1.7, object.position.z),
        size: new pc.Vec3(4.2, 3.4, 3.2),
      });
    }
  }

  private buildObjects(project: Project, world: pc.Entity): void {
    for (const object of project.objects) {
      if (!object.visible || object.type !== 'device') continue;
      const device = getDevice(object.deviceId);
      const kind = device?.kind || object.type;
      if (!this.testMode && kind !== 'bar' && kind !== 'head' && kind !== 'speaker' && kind !== 'soundbooth') continue;
      this.buildFixture(project, world, object, objectDims(object), kind, -object.rotation);
    }
  }

  private buildDecorTruss(project: Project, world: pc.Entity): void {
    if (!this.trussTemplate || project.objects.some((object) => object.type === 'truss')) return;
    const mounted = project.objects.filter((object) => object.type === 'device' && object.visible && object.elevation > 3);
    if (mounted.length < 2) return;
    const xs = mounted.map((object) => object.position.x);
    const zs = mounted.map((object) => object.position.z);
    const centerX = (Math.min(...xs) + Math.max(...xs)) / 2;
    const z = zs.reduce((sum, value) => sum + value, 0) / zs.length;
    const y = Math.max(...mounted.map((object) => object.elevation));
    const width = Math.max(2, Math.max(...xs) - Math.min(...xs) + 1.2);
    const truss = this.trussTemplate.clone();
    const trussMat = this.material({ color: '#7d858b', metalness: 0.7, gloss: 0.58 });
    truss.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { mesh.material = trussMat; }));
    const scale = width / 204;
    truss.setLocalScale(scale, scale, scale);
    truss.setLocalEulerAngles(0, 90, 0);
    truss.setLocalPosition(centerX, y, z);
    world.addChild(truss);
  }

  private buildSeating(project: Project, world: pc.Entity, object: SceneObject): void {
    const config = object.seating || { rows: 3, columns: 5, seatPitch: 0.62, rowPitch: 0.95 };
    const root = new pc.Entity(object.name);
    root.setPosition(object.position.x, object.elevation, object.position.z);
    root.setEulerAngles(0, -object.rotation, 0);
    world.addChild(root);
    if (this.chairTemplate) {
      const totalW = config.columns * config.seatPitch;
      const totalD = config.rows * config.rowPitch;
      for (let row = 0; row < config.rows; row++) {
        for (let column = 0; column < config.columns; column++) {
          const x = -totalW / 2 + config.seatPitch * (column + 0.5);
          const z = -totalD / 2 + config.rowPitch * (row + 0.5);
          const chair = this.chairTemplate.clone();
          chair.setLocalPosition(x, -this.chairMinY * this.chairScale, z);
          chair.setLocalScale(this.chairScale, this.chairScale, this.chairScale);
          chair.setLocalEulerAngles(0, 180, 0);
          root.addChild(chair);
        }
      }
      (root as AnyEntity).__rid = object.id;
      const markSeat = (node: pc.Entity): void => {
        (node as AnyEntity).__rid = object.id;
        node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
        node.children.forEach((child) => markSeat(child as pc.Entity));
      };
      markSeat(root);
      this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, 0.5, object.position.z), size: new pc.Vec3(totalW, 1.1, totalD) });
      return;
    }
    const seatMat = this.material({ color: '#363737', metalness: 0.08, gloss: 0.28 });
    const legMat = this.material({ color: '#1a1d1f', metalness: 0.3, gloss: 0.25 });
    const totalW = config.columns * config.seatPitch;
    const totalD = config.rows * config.rowPitch;
    for (let row = 0; row < config.rows; row++) {
      for (let column = 0; column < config.columns; column++) {
        const x = -totalW / 2 + config.seatPitch * (column + 0.5);
        const z = -totalD / 2 + config.rowPitch * (row + 0.5);
        this.box(root, 'seat', [0.46, 0.08, 0.44], [x, 0.48, z], seatMat);
        this.box(root, 'back', [0.46, 0.5, 0.07], [x, 0.73, z - 0.19], seatMat);
        this.box(root, 'leg', [0.06, 0.46, 0.06], [x, 0.23, z], legMat);
      }
    }
    (root as AnyEntity).__rid = object.id;
    this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, 0.5, object.position.z), size: new pc.Vec3(totalW, 1.1, totalD) });
  }


  private buildTruss(world: pc.Entity, object: SceneObject, dims: { w: number; d: number; h: number }): void {
    const mat = this.material({ color: '#9aa0a4', metalness: 0.7, gloss: 0.65 });
    const root = new pc.Entity(object.name);
    root.setPosition(object.position.x, object.elevation, object.position.z);
    root.setEulerAngles(0, -object.rotation, 0);
    world.addChild(root);
    const h = Math.max(0.25, dims.h);
    if (this.trussTemplate) {
      const truss = this.trussTemplate.clone();
      const trussMat = this.material({ color: '#7d858b', metalness: 0.7, gloss: 0.58 });
      truss.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { mesh.material = trussMat; }));
      const scale = dims.w / 204;
      truss.setLocalScale(scale, scale, scale);
      truss.setLocalEulerAngles(0, 90, 0);
      truss.setLocalPosition(0, h / 2, 0);
      root.addChild(truss);
      const mark = (node: pc.Entity): void => {
        (node as AnyEntity).__rid = object.id;
        node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
        node.children.forEach((child) => mark(child as pc.Entity));
      };
      mark(root);
      this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation + h / 2, object.position.z), size: new pc.Vec3(dims.w, h, dims.d) });
      return;
    }
    this.box(root, 'truss-chord', [dims.w, 0.06, 0.06], [0, h * 0.9, -dims.d / 2], mat, 0, true);
    this.box(root, 'truss-chord', [dims.w, 0.06, 0.06], [0, h * 0.9, dims.d / 2], mat, 0, true);
    const count = Math.max(2, Math.round(dims.w / 0.65));
    for (let i = 0; i <= count; i++) {
      const x = -dims.w / 2 + (dims.w * i) / count;
      this.box(root, 'truss-brace', [0.035, h * 0.9, 0.035], [x, h * 0.45, -dims.d / 2], mat, 0, true);
      this.box(root, 'truss-brace', [0.035, h * 0.9, 0.035], [x, h * 0.45, dims.d / 2], mat, 0, true);
    }
    (root as AnyEntity).__rid = object.id;
    this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation + h / 2, object.position.z), size: new pc.Vec3(dims.w, h, dims.d) });
  }

  private fitBarPosition(object: SceneObject, dims: { w: number; d: number; h: number }): { x: number; z: number } {
    const b = this.roomBounds;
    if (!b) return { x: object.position.x, z: object.position.z };
    const alongX = object.rotation % 180 === 0;
    const halfX = (alongX ? dims.w : dims.d) / 2;
    const halfZ = (alongX ? dims.d : dims.w) / 2;
    return {
      x: clamp(object.position.x, b.minX + halfX + 0.08, b.maxX - halfX - 0.08),
      z: clamp(object.position.z, b.minZ + halfZ + 0.08, b.maxZ - halfZ - 0.08),
    };
  }

  private buildFixture(project: Project, world: pc.Entity, object: SceneObject, dims: { w: number; d: number; h: number }, kind: string, rotation: number): void {
    const light = object.light;
    const color = light?.color || '#ffffff';
    const on = !!light?.on && (light?.intensity || 0) > 0.01;
    const root = new pc.Entity(object.name);
    const y = fixtureMountY(object);
    root.setPosition(object.position.x, y, object.position.z);
    root.setEulerAngles(0, rotation, 0);
    world.addChild(root);
    this.objectRoots.set(object.id, root);
    if (kind === 'bar' || kind === 'pixel') {
      const fitted = this.fitBarPosition(object, dims);
      root.setPosition(fitted.x, y, fitted.z);
    }
    const bodyMat = this.material({ color: '#252d34', metalness: 0.45, gloss: 0.45 });
    const lensMat = this.material({ color, emissive: on && !this.noGlow ? color : '#000000', unlit: !on });
    if (kind === 'bar' || kind === 'pixel') {
      if (this.barTemplate) {
        const bar = this.barTemplate.clone();
        const barMat = this.material({ color: '#11161a', metalness: 0.55, gloss: 0.42 });
        bar.findComponents('render').forEach((render) => { render.castShadows = false; render.meshInstances.forEach((mesh) => { mesh.material = barMat; }); });
        bar.setLocalScale(dims.w / 1.026, dims.h / 0.070, dims.d / 0.087);
        bar.setLocalPosition(0, 0, 0);
        root.addChild(bar);
        const markBar = (node: pc.Entity): void => {
          (node as AnyEntity).__rid = object.id;
          node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
          node.children.forEach((child) => markBar(child as pc.Entity));
        };
        markBar(root);
      } else {
        this.box(root, 'bar-body', [dims.w, Math.max(0.07, dims.h), Math.max(0.07, dims.d)], [0, 0, 0], bodyMat, 0, true);
      }
      const lensCount = Math.max(2, Math.min(12, getDevice(object.deviceId)?.lensCount || 6));
      const span = dims.w * 0.9;
      const cell = span / lensCount;
      for (let index = 0; index < lensCount; index++) {
        const segment = light?.segments?.[index] ?? light?.segments?.[0];
        const segmentColor = segment?.color || color;
        const segmentOn = on && (!segment || segment.intensity > 0.01);
        const segmentMat = this.material({ color: segmentColor, emissive: segmentOn && !this.noGlow ? segmentColor : '#000000', unlit: !segmentOn });
        this.box(
          root,
          `bar-lens-${index}`,
          [Math.max(0.014, cell * 0.7), 0.012, Math.max(0.025, dims.d * 0.55)],
          [-span / 2 + cell * (index + 0.5), dims.h / 2 + 0.006, 0],
          segmentMat,
        );
      }
    } else if (kind === 'head' || kind === 'spot' || kind === 'beam') {
      if (this.headTemplate) {
        const head = this.headTemplate.clone();
        const scale = Math.max(1.2, dims.h / 0.6);
        head.setLocalScale(scale, scale, scale);
        head.setLocalPosition(0, -dims.h, 0);
        head.setLocalEulerAngles(0, 180, 0);
        root.addChild(head);
        const mark = (node: pc.Entity): void => {
          (node as AnyEntity).__rid = object.id;
          node.findComponents('render').forEach((render) => render.meshInstances.forEach((mesh) => { (mesh as unknown as { __rid?: string }).__rid = object.id; }));
          node.children.forEach((child) => mark(child as pc.Entity));
        };
        mark(root);
      } else {
        this.box(root, 'head-body', [dims.w, Math.max(0.06, dims.h), Math.max(0.06, dims.d)], [0, 0, 0], bodyMat, 0, true);
      }
      this.box(root, 'head-lens', [dims.w * 0.55, 0.012, dims.d * 0.55], [0, -dims.h - 0.008, 0], lensMat);
    } else if (kind === 'par' || kind === 'flood' || kind === 'effectlight') {
      this.box(root, 'par-body', [dims.w, dims.h, dims.d], [0, 0, 0], bodyMat, 0, true);
      this.box(root, 'par-lens', [dims.w * 0.55, dims.h * 0.55, 0.012], [0, 0, dims.d / 2 + 0.008], lensMat);
    } else if (kind === 'speaker' || kind === 'soundbooth') {
      root.setPosition(object.position.x, object.elevation, object.position.z);
      const cabinetMat = this.material({ color: '#737b7f', metalness: 0.18, gloss: 0.3, emissive: '#14191c' });
      const baffleMat = this.material({ color: '#242a2e', metalness: 0.1, gloss: 0.18, emissive: '#0b0f11' });
      const driverMat = this.material({ color: '#4a5257', metalness: 0.35, gloss: 0.38, emissive: '#0d1113' });
      this.box(root, 'sound-cabinet', [dims.w, dims.h, dims.d], [0, dims.h / 2, 0], cabinetMat, 0, true);
      this.box(root, 'sound-baffle', [dims.w * 0.9, dims.h * 0.94, 0.025], [0, dims.h / 2, dims.d / 2 + 0.014], baffleMat);
      for (const ratio of [0.25, 0.5, 0.75]) {
        const driver = new pc.Entity(`sound-driver-${ratio}`);
        driver.addComponent('render', { type: 'cylinder', material: driverMat });
        driver.setLocalScale(dims.w * 0.56, 0.035, dims.w * 0.56);
        driver.setLocalEulerAngles(90, 0, 0);
        driver.setLocalPosition(0, dims.h * ratio, dims.d / 2 + 0.032);
        root.addChild(driver);
      }
      const ledMat = this.material({ color: '#ff8a3d', emissive: '#ff8a3d', unlit: true });
      this.box(root, 'sound-status', [dims.w * 0.5, 0.028, 0.018], [0, dims.h * 0.9, dims.d / 2 + 0.04], ledMat);
      root.findComponents('render').forEach((render) => { render.castShadows = true; });
      (root as AnyEntity).__rid = object.id;
      this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, object.elevation + dims.h / 2, object.position.z), size: new pc.Vec3(dims.w, dims.h, dims.d) });
      return;
    } else if (kind === 'ledwall' || kind === 'tv' || kind === 'projector' || kind === 'processor') {
      const screenMat = this.material({ color: '#05080b', emissive: '#020507', gloss: 0.2 });
      const entity = this.box(root, 'screen', [dims.w, dims.h, Math.max(0.05, dims.d)], [0, 0, 0], screenMat, 0, true);
      this.registerPick(entity, object);
    } else {
      const entity = this.box(root, 'fixture-body', [dims.w, Math.max(0.06, dims.h), Math.max(0.06, dims.d)], [0, 0, 0], bodyMat, 0, true);
      this.registerPick(entity, object);
      return;
    }
    root.findComponents('render').forEach((render) => { render.castShadows = false; });
    (root as AnyEntity).__rid = object.id;
    this.pickTargets.push({ id: object.id, center: new pc.Vec3(object.position.x, y, object.position.z), size: new pc.Vec3(dims.w, dims.h, dims.d) });
  }

  private buildLights(project: Project, world: pc.Entity): void {
    const master = project.lighting.master ?? 0.9;
    let index = 0;
    for (const object of project.objects) {
      if (!object.visible || object.type !== 'device' || !object.light?.on || !(object.light.intensity > 0.001)) continue;
      const profile = opticalProfile(object);
      const light = object.light;
      const level = (light.intensity || 0) * master;
      const device = getDevice(object.deviceId);
      const kind = device?.kind || 'spot';
      const isBar = profile.family === 'bar';
      const targetPoint = isBar ? this.barTarget(object, project) : fixtureAimPoint(object, project);
      const barPos = isBar ? this.fitBarPosition(object, objectDims(object)) : null;
      const position = isBar && barPos
        ? new pc.Vec3(barPos.x, fixtureMountY(object) + Math.max(0.08, objectDims(object).h / 2) + 0.03, barPos.z)
        : new pc.Vec3(object.position.x, Math.max(0.08, fixtureMountY(object) - (object.mount === 'truss' || object.mount === 'ceiling' ? 0.1 : 0)), object.position.z);
      const aim = new pc.Vec3(targetPoint[0], targetPoint[1], targetPoint[2]);
      const direction = new pc.Vec3().sub2(aim, position);
      if (direction.lengthSq() < 0.0001) direction.set(0, -1, 0);
      direction.normalize();
      const spot = new pc.Entity(`light-${object.id}`);
      spot.setPosition(position);
      spot.setRotation(new pc.Quat().setFromDirections(DOWN, direction));
      if (isBar) {
        const dims = objectDims(object);
        spot.setLocalScale(dims.w, 1, Math.max(0.08, dims.d * 0.7));
      }
      spot.addComponent('light', {
        type: 'spot',
        layers: this.blockerLayer ? [pc.LAYERID_WORLD, this.blockerLayer.id] : [pc.LAYERID_WORLD],
        shape: isBar ? pc.LIGHTSHAPE_RECT : pc.LIGHTSHAPE_PUNCTUAL,
        color: colorFrom(light.color),
        ...(this.cookies && !isBar ? { cookie: this.cookies.spot, cookieIntensity: 0.45 } : {}),
        intensity: level * (isBar ? 9 : kind === 'par' ? 1.5 : kind === 'beam' ? 6 : 8),
        range: isBar ? 13 : 22,
        innerConeAngle: isBar ? 18 : clamp(profile.beamAngle / 2, 2, 80),
        outerConeAngle: isBar ? 70 : clamp(profile.fieldAngle / 2, 3, 89),
        castShadows: !this.softwareRenderer,
        shadowResolution: project.lighting.quality === 'ultra' || project.lighting.quality === 'photo' ? 2048 : 1024,
        shadowDistance: 30,
        normalOffsetBias: 0.1,
        falloffMode: pc.LIGHTFALLOFF_INVERSESQUARED,
        volumetricScattering: isBar ? 0.65 : 4.2,
      });
      world.addChild(spot);
      this.deviceLightNodes.set(object.id, spot);
      index++;
    }
    const fill = new pc.Entity('scene-fill');
    fill.addComponent('light', {
      type: 'directional',
      color: new pc.Color(0.55, 0.62, 0.75),
      intensity: project.lighting.workLight ? 1.2 : 0.65,
      affectSpecularity: false,
      castShadows: false,
    });
    fill.setEulerAngles(42, 28, 0);
    world.addChild(fill);
    if (!project.lighting.workLight) {
      const frontFill = new pc.Entity('front-fill');
      frontFill.addComponent('light', {
        type: 'directional',
        color: new pc.Color(0.55, 0.58, 0.63),
        intensity: 0.5,
        affectSpecularity: false,
        castShadows: false,
      });
      frontFill.setEulerAngles(58, 180, 0);
      world.addChild(frontFill);
    }
    if (project.lighting.workLight) {
      const worklight = new pc.Entity('worklight');
      worklight.addComponent('light', {
        type: 'directional',
        color: new pc.Color(0.85, 0.9, 1),
        intensity: 1.4,
        castShadows: true,
        shadowResolution: 1024,
        shadowDistance: 30,
      });
      worklight.setEulerAngles(45, 30, 0);
      world.addChild(worklight);
    }
  }

  private barTarget(object: SceneObject, project: Project): [number, number, number] {
    const dims = objectDims(object);
    const y = fixtureMountY(object) + dims.h / 2;
    const bounds = getRoomBounds(project);
    return [object.position.x, Math.min(bounds.height - 0.1, y + 6), object.position.z];
  }

  private clampTarget(): void {
    if (!this.roomBounds) return;
    this.target.x = clamp(this.target.x, this.roomBounds.minX + 0.4, this.roomBounds.maxX - 0.4);
    this.target.z = clamp(this.target.z, this.roomBounds.minZ + 0.4, this.roomBounds.maxZ - 0.4);
    this.target.y = clamp(this.target.y, 0.2, this.roomBounds.height - 0.2);
  }

  private updateCamera(): void {
    if (!this.camera) return;
    // CameraControls owns the camera pose when available.
    if (this.cameraControls) {
      this.cameraFrame?.update();
      if (this.project) this.collectMeshCapabilities(this.project);
      this.requestRender();
      return;
    }
    const horizontal = Math.cos(this.pitch) * this.distance;
    const position = new pc.Vec3(
      this.target.x + Math.sin(this.yaw) * horizontal,
      this.target.y + Math.sin(this.pitch) * this.distance,
      this.target.z + Math.cos(this.yaw) * horizontal,
    );
    this.camera.setPosition(position);
    this.camera.lookAt(this.target);
  }

  private setCamera(position: [number, number, number], target: [number, number, number]): void {
    this.resetTaaHistory('camera-teleport');
    this.target.set(target[0], target[1], target[2]);
    const dx = position[0] - target[0];
    const dy = position[1] - target[1];
    const dz = position[2] - target[2];
    this.distance = Math.max(0.1, Math.sqrt(dx * dx + dy * dy + dz * dz));
    this.yaw = Math.atan2(dx, dz);
    this.pitch = Math.asin(clamp(dy / this.distance, -1, 1));
    if (this.cameraControls) {
      this.cameraControls.reset(this.target, new pc.Vec3(position[0], position[1], position[2]));
    } else {
      this.updateCamera();
    }
  }

  setView(view: ViewPreset): void {
    if (!this.project) return;
    const bounds = getRoomBounds(this.project);
    const stage = getStageCenter(this.project);
    if (view === 'top') this.setCamera([bounds.centerX, Math.max(16, bounds.height * 3), stage.z + 0.02], [bounds.centerX, stage.y, stage.z]);
    else if (view === 'front') this.setCamera([stage.x, Math.max(2.4, bounds.height * 0.52), bounds.maxZ + Math.max(2.5, (bounds.maxZ - bounds.minZ) * 0.18)], [stage.x, Math.max(1.0, stage.y + 0.9), stage.z]);
    else if (view === 'side') this.setCamera([bounds.maxX - 1.2, Math.max(2.2, bounds.height * 0.55), bounds.centerZ], [stage.x, Math.max(0.9, stage.y + 0.5), stage.z]);
    else this.setCamera([stage.x + 2.2, Math.max(4.8, bounds.height * 0.92), stage.z + 12], [stage.x, Math.max(0.85, stage.y + 0.8), stage.z]);
  }

  private objectEffectExpansion(object: SceneObject, project: Project): number {
    let expansion = 0;
    const look = project.looks?.find((entry) => entry.id === object.lookId);
    for (const instance of [...(object.shaders || []), ...(look?.shaders || [])]) {
      if (!instance.enabled) continue;
      const shader = project.customShaders?.find((entry) => entry.id === instance.shaderId);
      expansion += Math.abs(Number(shader?.boundsExpansion ?? 0));
    }
    for (const modifier of effectiveModifiers(object, project)) {
      if (!modifier.enabled) continue;
      const params = modifier.params;
      const definition = modifierDefinition(modifier.type);
      if (definition.runtime !== 'shader') continue;
      expansion += Math.abs(Number(params.strength ?? 0));
      expansion += Math.abs(Number(params.amount ?? 0)) * 0.5;
      expansion += Math.abs(Number(params.noise ?? 0)) * 0.1;
      expansion += Math.abs(Number(params.distortion ?? 0)) * 0.2;
      expansion += Math.abs(Number(params.radius ?? 0)) * 0.25;
      expansion += Math.abs(Number(params.spacing ?? 0)) * Math.min(64, Number(params.count ?? 0)) * 0.05;
    }
    return Math.min(500, expansion);
  }

  private recomputeSceneBounds(project: Project): void {
    let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (const object of project.objects) {
      if (!object.visible) continue;
      const dims = objectDims(object);
      const expansion = this.objectEffectExpansion(object, project);
      const x = object.position.x; const y = object.elevation + dims.h * 0.5; const z = object.position.z;
      minX = Math.min(minX, x - dims.w * 0.5 - expansion); maxX = Math.max(maxX, x + dims.w * 0.5 + expansion);
      minY = Math.min(minY, y - dims.h * 0.5 - expansion); maxY = Math.max(maxY, y + dims.h * 0.5 + expansion);
      minZ = Math.min(minZ, z - dims.d * 0.5 - expansion); maxZ = Math.max(maxZ, z + dims.d * 0.5 + expansion);
    }
    if (!Number.isFinite(minX)) { minX = -5; minY = 0; minZ = -5; maxX = 5; maxY = 5; maxZ = 5; }
    this.sceneBounds = new pc.BoundingBox(
      new pc.Vec3((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2),
      new pc.Vec3(Math.max(1, maxX - minX), Math.max(1, maxY - minY), Math.max(1, maxZ - minZ)),
    );
    this.sceneRadius = Math.max(1, this.sceneBounds.halfExtents.length());
  }

  private updateCameraRange(): void {
    if (!this.camera?.camera || !this.project) return;
    if (this.sceneBounds.halfExtents.lengthSq() === 0) this.recomputeSceneBounds(this.project);
    const position = this.camera.getPosition();
    const distance = Math.max(0.01, position.distance(this.sceneBounds.center));
    const radius = Math.max(1, this.sceneRadius);
    const near = Math.max(0.01, Math.min(1, distance * 0.0008));
    const far = Math.max(500, (distance + radius) * 6 + 250);
    this.camera.camera.nearClip = near;
    this.camera.camera.farClip = far;
    if (this.cameraFrame) {
      this.cameraFrame.volumetricFog.maxDistance = Math.min(Math.max(100, far * 0.5), Math.max(50, radius * 6 + 50));
      if (this.ditherEffect && (this.project.lighting.dithering ?? 'temporal') === 'temporal') this.ditherEffect.setUniform('uDitherTime', (performance.now() * 0.001) % 64);
    }
  }

  private frameBounds(bounds: pc.BoundingBox, label = 'selection'): void {
    if (!this.camera?.camera || !this.cameraControls) return;
    const center = bounds.center.clone();
    const rawRadius = bounds.halfExtents.length();
    if (!Number.isFinite(center.x) || !Number.isFinite(center.y) || !Number.isFinite(center.z) || !Number.isFinite(rawRadius) || rawRadius <= 0.01) {
      this.lastCameraAction = `rejected-invalid-${label}`;
      this.focusBoundsRadius = Number.isFinite(rawRadius) ? rawRadius : 0;
      this.focusTarget = 'invalid';
      this.recordInput('camera-frame-rejected', `${label} non-finite or zero bounds`);
      return;
    }
    const maxRadius = Math.max(20, this.sceneRadius * 8);
    if (rawRadius > maxRadius) {
      this.lastCameraAction = `rejected-absurd-${label}`;
      this.focusBoundsRadius = rawRadius;
      this.focusTarget = 'absurd';
      this.recordInput('camera-frame-rejected', `${label} radius=${rawRadius.toFixed(2)} max=${maxRadius.toFixed(2)}`);
      return;
    }
    const radius = Math.max(0.5, rawRadius);
    const fov = Math.max(10, this.camera.camera.fov) * Math.PI / 180;
    const distance = Math.max(1.5, radius / Math.tan(fov * 0.5) * 1.35);
    const direction = this.camera.forward.clone();
    if (direction.lengthSq() < 0.0001) direction.set(0, 0, -1);
    const before = this.camera.getPosition().distance(this.cameraControls.focusPoint || center);
    const position = center.clone().sub(direction.mulScalar(distance));
    this.focusTarget = `${center.x.toFixed(2)},${center.y.toFixed(2)},${center.z.toFixed(2)}`;
    this.focusBoundsRadius = radius;
    this.lastCameraAction = `frame-${label}`;
    this.cameraDistanceBefore = before;
    this.cameraControls.reset(center, position);
    this.camera.setPosition(position);
    this.cameraDistanceAfter = position.distance(center);
    this.updateCameraRange();
  }

  frameScene(): void {
    this.resetTaaHistory('camera-teleport');
    if (!this.project) return;
    this.recomputeSceneBounds(this.project);
    this.frameBounds(this.sceneBounds, 'scene');
  }

  frameSelection(ids: string[]): void {
    this.resetTaaHistory('camera-teleport');
    if (!this.project) return;
    const objects = this.project.objects.filter((object) => ids.includes(object.id) && object.visible);
    if (!objects.length) { this.frameScene(); return; }
    let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (const object of objects) {
      const dims = objectDims(object);
      const expansion = this.objectEffectExpansion(object, this.project);
      const x = object.position.x; const y = object.elevation + dims.h * 0.5; const z = object.position.z;
      const values = [x, y, z, dims.w, dims.h, dims.d, expansion];
      if (values.some((value) => !Number.isFinite(value))) continue;
      minX = Math.min(minX, x - dims.w * 0.5 - expansion); maxX = Math.max(maxX, x + dims.w * 0.5 + expansion);
      minY = Math.min(minY, y - dims.h * 0.5 - expansion); maxY = Math.max(maxY, y + dims.h * 0.5 + expansion);
      minZ = Math.min(minZ, z - dims.d * 0.5 - expansion); maxZ = Math.max(maxZ, z + dims.d * 0.5 + expansion);
    }
    if (!Number.isFinite(minX) || !Number.isFinite(maxX) || !Number.isFinite(minY) || !Number.isFinite(maxY) || !Number.isFinite(minZ) || !Number.isFinite(maxZ)) {
      this.lastCameraAction = 'rejected-invalid-selection';
      this.focusBoundsRadius = 0;
      this.focusTarget = 'invalid';
      this.recordInput('camera-frame-rejected', 'selection bounds non-finite');
      return;
    }
    this.frameBounds(new pc.BoundingBox(new pc.Vec3((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2), new pc.Vec3(Math.max(0.5, maxX - minX), Math.max(0.5, maxY - minY), Math.max(0.5, maxZ - minZ))), 'selection');
  }

  focusObject(id: string): void {
    this.frameSelection([id]);
    this.setSelected([id]);
  }

  setPerformanceProfiling(enabled: boolean): void {
    if (this.device?.gpuProfiler) this.device.gpuProfiler.enabled = enabled;
  }

  getPerformanceStats(): Record<string, number | string | null> {
    if (!this.app) return {};
    const stats = this.app.stats;
    const project = this.project;
    const lights = project?.objects.filter((object) => object.light?.on && (object.light.intensity || 0) > 0.001) || [];
    const shadowLights = project?.objects.filter((object) => object.light?.on && object.castShadows === true) || [];
    const visibleMeshes = this.world
      ? this.world.findComponents('render').reduce((sum, render) => sum + render.meshInstances.length, 0)
      : 0;
    return {
      fps: Math.round(stats.fps),
      frameMs: Number(stats.frameTime.toFixed(2)),
      cpuUpdateMs: Number(stats.cpuUpdateTime.toFixed(2)),
      cpuRenderMs: Number(stats.cpuRenderTime.toFixed(2)),
      gpuMs: stats.gpuFrameTime === undefined ? null : Number(stats.gpuFrameTime.toFixed(2)),
      drawCalls: stats.drawCallCount,
      primitives: stats.primitiveCount ?? null,
      materials: stats.frame.materials,
      activeLights: lights.length,
      shadowLights: shadowLights.length,
      visibleMeshes,
      renderWidth: this.canvas.width,
      renderHeight: this.canvas.height,
      cssWidth: this.canvas.clientWidth,
      cssHeight: this.canvas.clientHeight,
      vramMb: Number((stats.vramTotalBytes / (1024 * 1024)).toFixed(1)),
      quality: project?.lighting.quality || 'low',
      renderScale: Number((this.cameraFrame?.rendering.renderTargetScale ?? 1).toFixed(2)),
      fogSteps: this.cameraFrame?.volumetricFog.steps ?? 0,
      fogLocalSteps: this.cameraFrame?.volumetricFog.localSteps ?? 0,
      maxPixelRatio: Number((this.device?.maxPixelRatio ?? 1).toFixed(2)),
      taa: this.cameraFrame?.taa.enabled ? 1 : 0,
      shadows: this.app.scene.lighting.shadowsEnabled ? 1 : 0,
    };
  }

  async screenshot(scale = 1): Promise<Blob | null> {
    if (!this.app || !this.device) return null;
    const requested = Math.max(1, Math.min(3, scale));
    const cssWidth = Math.max(1, this.canvas.clientWidth);
    const cssHeight = Math.max(1, this.canvas.clientHeight);
    try {
      if (requested !== 1) {
        this.app.setCanvasResolution(pc.RESOLUTION_FIXED, Math.round(cssWidth * requested), Math.round(cssHeight * requested));
        this.app.resizeCanvas();
      }
      await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
      const blob = await new Promise<Blob | null>((resolve) => this.canvas.toBlob((value) => resolve(value), 'image/png'));
      return blob;
    } finally {
      if (requested !== 1) {
        this.app.setCanvasResolution(pc.RESOLUTION_AUTO);
        this.app.resizeCanvas();
      }
    }
  }

  destroy(): void {
    this.destroyed = true;
    this.resetPointerInteraction('unmount');
    this.marqueeElement?.remove();
    this.marqueeElement = null;
    this.disposePhysicsWorld();
    this.cancelGizmoInteraction();
    window.removeEventListener('blur', this.clearCameraInput);
    window.removeEventListener('pointerup', this.onWindowPointerEnd);
    window.removeEventListener('pointercancel', this.onWindowPointerEnd);
    window.removeEventListener('blur', this.onWindowBlur);
    document.removeEventListener('focusin', this.onFocusIn);
    document.removeEventListener('focusout', this.onFocusOut);
    this.translateGizmo?.destroy();
    this.rotateGizmo?.destroy();
    this.scaleGizmo?.destroy();
    this.cameraControls?.destroy?.();
    this.resizeObserver?.disconnect();
    window.removeEventListener('resize', this.resize);
    const canvas = this.canvas;
    canvas.removeEventListener('pointerdown', this.onPointerDown);
    canvas.removeEventListener('mousedown', this.onMouseDown);
    canvas.removeEventListener('mouseup', this.onMouseUp);
    canvas.removeEventListener('click', this.onClick);
    document.removeEventListener('pointerlockchange', this.onPointerLockDebug);
    document.removeEventListener('visibilitychange', this.onVisibilityChange);
    window.removeEventListener('keydown', this.onDebugEscape);
    window.removeEventListener('keydown', this.onFlyKeyDown);
    window.removeEventListener('keyup', this.onFlyKeyUp);
    window.removeEventListener('blur', this.onFlyBlur);
    canvas.removeEventListener('pointermove', this.onPointerMove);
    canvas.removeEventListener('pointerup', this.onPointerUp);
    canvas.removeEventListener('pointercancel', this.onPointerUp);
    canvas.removeEventListener('lostpointercapture', this.onLostPointerCapture);
    canvas.removeEventListener('wheel', this.onWheel);
    canvas.removeEventListener('contextmenu', this.onContextMenu);
    canvas.removeEventListener('dblclick', this.onDoubleClick);
    canvas.removeEventListener('keydown', this.onKeyDown);
    this.picker?.destroy();
    this.picker = null;
    this.ownedMaterials.forEach((material) => material.destroy());
    this.ownedMaterials = [];
    this.textureCache.forEach((texture) => texture.destroy());
    this.textureCache.clear();
    this.textureLoading.clear();
    this.selection = null;
    this.cameraFrame?.destroy();
    this.cameraFrame = null;
    this.app?.destroy();
    this.app = null;
    this.device = null;
  }
}
