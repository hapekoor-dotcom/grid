import { useEffect, useRef, useState } from 'react';
import '../../styles/viewport.css';

const LUMA_URL = (import.meta.env.VITE_LUMAVIEW_URL as string | undefined) || 'http://127.0.0.1:8765/?kiosk=1';

/** lumaview is a complete Art-Net stage visualiser; the app only embeds it. */
export function LumaViewport() {
  const frame = useRef<HTMLIFrameElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (!loaded) setFailed(true);
    }, 9000);
    return () => window.clearTimeout(timer);
  }, [loaded]);

  return (
    <div className="viewport3d beam-viewport">
      {!loaded && <div className="viewport-loading"><span className="spinner" />Loading Lumaview</div>}
      {failed && (
        <div className="beam-unavailable">
          <strong>Lumaview is not responding</strong>
          <span>Start Lumaview on port 8765 and refresh the page.</span>
          <a href={LUMA_URL.replace('?kiosk=1', '')} target="_blank" rel="noreferrer">Open Lumaview separately</a>
        </div>
      )}
      <iframe
        ref={frame}
        className="beam-frame"
        src={LUMA_URL}
        title="lumaview stage visualiser"
        allow="fullscreen"
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
}
