import { useEffect, useState } from 'react';
import type { Project } from '../../types/project';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { mutateProject, mutationRecord, serializeProject, type MutationScope } from '../../lib/mutationEngine';

interface PendingMutation {
  before: Project;
  projectId: string;
  after: Project;
  seed: number;
  diff: string[];
  scope: MutationScope;
  depth: number;
}

const clone = <T,>(value: T): T => structuredClone(value);

export function MutationBar() {
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const mutateTransient = useWorkspaceStore((state) => state.mutateTransient);
  const beginTransaction = useWorkspaceStore((state) => state.beginTransaction);
  const endTransaction = useWorkspaceStore((state) => state.endTransaction);
  const cancelTransaction = useWorkspaceStore((state) => state.cancelTransaction);
  const selectedIds = useUiStore((state) => state.selectedIds);
  const [depth, setDepth] = useState(0.55);
  const [scope, setScope] = useState<MutationScope>('object');
  const [pending, setPending] = useState<PendingMutation | null>(null);
  const [dev, setDev] = useState(false);

  useEffect(() => {
    if (!pending) return;
    if (pending.projectId === project?.id) return;
    cancelTransaction();
    setPending(null);
  }, [project?.id, pending, cancelTransaction]);

  const selectedObject = project?.objects.find((entry) => selectedIds.includes(entry.id)) || null;
  const effectiveScope: MutationScope = scope === 'look' && !selectedObject?.lookId ? 'object' : scope;

  const apply = (base: Project, nextScope: MutationScope, nextDepth: number) => {
    const result = mutateProject({ project: base, objectIds: selectedIds, lookId: selectedObject?.lookId, scope: nextScope, depth: nextDepth });
    beginTransaction();
    mutateTransient((draft) => Object.assign(draft, clone(result.project)));
    setPending({ before: clone(base), projectId: base.id, after: clone(result.project), seed: result.seed, diff: result.diff, scope: nextScope, depth: nextDepth });
  };

  const mutate = () => {
    if (!project || pending) return;
    apply(clone(project), effectiveScope, depth);
  };
  const revert = () => {
    if (!pending) return;
    cancelTransaction();
    mutateTransient((draft) => Object.assign(draft, clone(pending.before)));
    setPending(null);
  };
  const again = () => {
    if (!pending) return;
    const base = clone(pending.before);
    cancelTransaction();
    setPending(null);
    apply(base, pending.scope, pending.depth);
  };
  const keep = (branch = false) => {
    if (!pending || !project) return;
    const after = clone(project);
    const record = mutationRecord(after, serializeProject(pending.before), { project: after, seed: pending.seed, id: `mut_${pending.seed.toString(16)}_${Date.now().toString(36)}`, diff: pending.diff }, pending.scope, pending.depth, after.mutation?.accepted.at(-1)?.id || null);
    mutateTransient((draft) => {
      if (!draft.mutation) draft.mutation = { accepted: [], branchId: `branch_${crypto.randomUUID()}` };
      draft.mutation.accepted = [...draft.mutation.accepted.slice(-63), record];
      if (branch) draft.mutation.branchId = `branch_${crypto.randomUUID()}`;
    });
    endTransaction();
    setPending(null);
  };
  if (!project) return null;
  return (
    <div className={`mutation-bar${pending ? ' has-pending' : ''}`} aria-label="Mutation engine">
      {!pending ? (
        <>
          <button type="button" className="mutation-primary" onClick={mutate}>MUTATE</button>
          <select className="select mutation-scope" aria-label="Mutation scope" value={scope} onChange={(event) => setScope(event.target.value as MutationScope)}>
            <option value="object">Object</option>
            <option value="look" disabled={!selectedObject?.lookId}>Look</option>
            <option value="scene">Scene</option>
          </select>
          <label className="mutation-depth" title="Mutation depth">
            <span>Depth</span>
            <input type="range" min={0} max={1} step={0.01} value={depth} aria-label="Mutation depth" onChange={(event) => setDepth(Number(event.target.value))} />
          </label>
        </>
      ) : (
        <>
          <span className="mutation-id">MUTATION #{pending.seed.toString(16).toUpperCase()}</span>
          <button type="button" className="mutation-action is-primary" onClick={() => keep(false)}>Keep</button>
          <button type="button" className="mutation-action" onClick={again}>Again</button>
          <button type="button" className="mutation-action" onClick={() => keep(true)}>Branch</button>
          <button type="button" className="mutation-action" onClick={revert}>Revert</button>
          <button type="button" className="mutation-dev" onClick={() => setDev((value) => !value)} title="Developer reveal">···</button>
          {dev && <div className="mutation-debug">{pending.diff.map((entry, index) => <span key={`${entry}-${index}`}>{entry}</span>)}</div>}
        </>
      )}
    </div>
  );
}
