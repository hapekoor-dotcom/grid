import { useEffect, useMemo, useRef, useState } from 'react';
import { Aperture, Box, Camera, ChevronDown, Expand, Eye, EyeOff, Gauge, Image, Layers, MousePointer2, Move3D, RotateCcw, RotateCw, Sparkles, Sun } from 'lucide-react';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { downloadBlob } from '../../lib/exports';
import { assetObjectUrl } from '../../lib/assetStore';
import type { Project } from '../../types/project';
import { Button } from '../ui/Button';
import { PlayCanvasRuntime } from './playcanvasRuntime';
import { FeedbackOverlay } from './FeedbackOverlay';
import { ShaderLabDialog } from '../inspector/ShaderLabDialog';
import { PostFxDialog } from './PostFxDialog';
import { InputDebugOverlay } from './InputDebugOverlay';
import { MutationBar } from './MutationBar';
import { KeyframeButton } from '../inspector/KeyframeButton';
import { NumberInput } from '../ui/Field';

type CameraPreset = 'perspective' | 'top' | 'front' | 'side';

const PRESETS: { id: CameraPreset; label: string; icon: typeof Camera }[] = [
  { id: 'perspective', label: 'Perspective', icon: Camera },
  { id: 'top', label: 'Top', icon: Layers },
  { id: 'front', label: 'Front', icon: Box },
  { id: 'side', label: 'Side', icon: Move3D },
];

export function PlayCanvasViewport() {
  const project = useActiveProject();
  const selectedIds = useUiStore((state) => state.selectedIds);
  const select = useUiStore((state) => state.select);
  const selectMany = useUiStore((state) => state.selectMany);
  const clearSelection = useUiStore((state) => state.clearSelection);
  const focusCamera = useUiStore((state) => state.focusCamera);
  const mode = useUiStore((state) => state.mode);
  const rightOpen = useUiStore((state) => state.rightOpen);
  const setSettingsOpen = useUiStore((state) => state.setSettingsOpen);
  const updateLighting = useWorkspaceStore((state) => state.updateLighting);
  const updateView = useWorkspaceStore((state) => state.updateView);
  const mutateTransient = useWorkspaceStore((state) => state.mutateTransient);
  const beginTransaction = useWorkspaceStore((state) => state.beginTransaction);
  const endTransaction = useWorkspaceStore((state) => state.endTransaction);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const assetUrls = useRef<Map<string, string>>(new Map());
  const gizmoTransaction = useRef(false);
  const runtimeRef = useRef<PlayCanvasRuntime | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cameraPreset = (project?.view.cameraPreset || 'front') as CameraPreset;
  const wallsVisible = project?.lighting.showWalls !== false;
  const floorVisible = project?.lighting.showFloor !== false;
  const transformMode = useUiStore((state) => state.transformMode);
  const setTransformMode = useUiStore((state) => state.setTransformMode);
  const [perfOpen, setPerfOpen] = useState(false);
  const [perfStats, setPerfStats] = useState<Record<string, number | string | null>>({});
  const navigationMode = useUiStore((state) => state.navigationMode);
  const setNavigationMode = useUiStore((state) => state.setNavigationMode);
  const selectedObjects = project?.objects.filter((object) => selectedIds.includes(object.id)) || [];
  const selectedObject = selectedObjects[0] || null;
  const scaleAvailable = selectedObjects.some((object) => object.type === 'model');
  const quality = project?.lighting.quality || 'high';
  const setQuality = (value: Project['lighting']['quality']) => updateLighting({ quality: value });
  const imageValue = (patch: Partial<Project['lighting']>) => mutateTransient((draft) => { draft.lighting = { ...draft.lighting, ...patch }; });
  const runtimeProject = project;
  const [viewOpen, setViewOpen] = useState(false);
  const [postLabOpen, setPostLabOpen] = useState(false);
  const [postFxOpen, setPostFxOpen] = useState(false);
  const [rdPaintMode, setRdPaintMode] = useState(false);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [photoScale, setPhotoScale] = useState(2);
  const [photoProgress, setPhotoProgress] = useState<number | null>(null);
  const photoCancel = useRef(false);
  const viewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    const runtime = new PlayCanvasRuntime(canvas, {
      onSelect: (id, additive = false) => {
        if (!id) { clearSelection(); return; }
        select(id, additive);
        if (useUiStore.getState().mode === '3d' || useUiStore.getState().mode === 'light') useUiStore.getState().setRightOpen(true);
      },
      onSelectMany: (ids, additive, subtractive) => {
        const current = useUiStore.getState().selectedIds;
        const next = subtractive
          ? current.filter((id) => !ids.includes(id))
          : additive
            ? [...new Set([...current, ...ids])]
            : ids;
        selectMany(next);
        if (next.length) useUiStore.getState().setRightOpen(true);
      },
      onFocus: (id) => {
        focusCamera(id);
        runtime.focusObject(id);
      },
      onGizmoTransform: (id, patch, commit) => {
        if (!commit && !gizmoTransaction.current) {
          beginTransaction();
          gizmoTransaction.current = true;
        }
        mutateTransient((draft) => {
          const object = draft.objects.find((entry) => entry.id === id);
          if (object) Object.assign(object, patch);
        });
        if (commit && gizmoTransaction.current) {
          endTransaction();
          gizmoTransaction.current = false;
        }
      },
      onGizmoMultiTransform: (patches, commit) => {
        if (!commit && !gizmoTransaction.current) {
          beginTransaction();
          gizmoTransaction.current = true;
        }
        mutateTransient((draft) => {
          for (const entry of patches) {
            const object = draft.objects.find((candidate) => candidate.id === entry.id);
            if (object) Object.assign(object, entry.patch);
          }
        });
        if (commit && gizmoTransaction.current) {
          endTransaction();
          gizmoTransaction.current = false;
        }
      },
      onError: (nextError) => {
        if (!cancelled) setError(nextError.message);
      },
      onAssetError: (message) => useUiStore.getState().pushToast(message, 'error'),
      onAssetMaterials: (assetId, names) => {
        const state = useWorkspaceStore.getState();
        const project = state.projects.find((entry) => entry.id === state.activeId);
        if (!project) return;
        for (const object of project.objects) {
          if (object.assetId === assetId && object.materialSlots?.join('|') !== names.join('|')) {
            state.updateObject(object.id, { materialSlots: names }, false);
          }
        }
      },
      onAssetMaterialMaps: (assetId, slots) => useUiStore.getState().setAssetMaterialMaps(assetId, slots),
      onMeshCapabilities: (capabilities) => {
        (window as unknown as { __reMeshCapabilityReports?: number }).__reMeshCapabilityReports = ((window as unknown as { __reMeshCapabilityReports?: number }).__reMeshCapabilityReports || 0) + 1;
        useUiStore.getState().setMeshCapabilities(capabilities);
      },
      onReady: () => {
        if (!cancelled) setReady(true);
      },
    });
    runtimeRef.current = runtime;
    (window as unknown as { __RE_RUNTIME__: PlayCanvasRuntime }).__RE_RUNTIME__ = runtime;
    void runtime.init();
    return () => {
      cancelled = true;
      runtime.destroy();
      runtimeRef.current = null;
    };
  }, [beginTransaction, clearSelection, endTransaction, focusCamera, select, mutateTransient]);

  useEffect(() => {
    if (!ready || !runtimeProject) return;
    runtimeRef.current?.setProject(runtimeProject, selectedIds);
  }, [runtimeProject, ready]);

  const modelAssetKey = useMemo(() => project?.objects.filter((object) => object.type === 'model' && object.assetId).map((object) => object.assetId).sort().join('|') || '', [project]);

  useEffect(() => {
    if (!ready || !project) return;
    let cancelled = false;
    const ids = [...new Set(project.objects.filter((object) => object.type === 'model' && object.assetId).map((object) => object.assetId!))];
    for (const id of ids) {
      if (assetUrls.current.has(id)) continue;
      void assetObjectUrl(id).then((url) => {
        if (cancelled || !url) return;
        assetUrls.current.set(id, url);
        runtimeRef.current?.registerModelAsset(id, url);
      }).catch(() => useUiStore.getState().pushToast('The imported model could not be read from browser storage.', 'error'));
    }
    return () => { cancelled = true; };
  }, [modelAssetKey, ready, project]);

  useEffect(() => () => {
    for (const url of assetUrls.current.values()) URL.revokeObjectURL(url);
    assetUrls.current.clear();
  }, []);

  useEffect(() => {
    if (!ready) return;
    runtimeRef.current?.setSelected(selectedIds);
  }, [selectedIds, ready]);

  useEffect(() => {
    if (!ready) return;
    runtimeRef.current?.setFloorVisible(floorVisible);
  }, [floorVisible, ready]);

  useEffect(() => {
    if (transformMode === 'scale' && !scaleAvailable) {
      setTransformMode('move');
      return;
    }
    if (!ready) return;
    runtimeRef.current?.setTransformMode(transformMode);
  }, [transformMode, ready, scaleAvailable]);

  useEffect(() => {
    if (!ready || !perfOpen) return;
    runtimeRef.current?.setPerformanceProfiling(true);
    const update = () => setPerfStats(runtimeRef.current?.getPerformanceStats() || {});
    update();
    const timer = window.setInterval(update, 500);
    return () => {
      window.clearInterval(timer);
      runtimeRef.current?.setPerformanceProfiling(false);
    };
  }, [perfOpen, ready]);

  useEffect(() => {
    if (mode !== '3d' || !ready) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() !== 'f') return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable)) return;
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      event.preventDefault();
      if (event.shiftKey) runtimeRef.current?.frameScene();
      else runtimeRef.current?.frameSelection(selectedIds);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mode, ready, selectedIds]);

  useEffect(() => {
    if (!viewOpen) return;
    const onPointer = (event: MouseEvent) => {
      if (!viewRef.current?.contains(event.target as Node)) setViewOpen(false);
    };
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setViewOpen(false); };
    window.addEventListener('mousedown', onPointer);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('mousedown', onPointer);
      window.removeEventListener('keydown', onKey);
    };
  }, [viewOpen]);

  if (!project) return null;

  const setPreset = (next: CameraPreset) => {
    updateView({ cameraPreset: next });
    runtimeRef.current?.setView(next);
  };

  const takeScreenshot = async () => {
    const blob = await runtimeRef.current?.screenshot();
    if (blob) downloadBlob(blob, `${project.name.replace(/[^\p{L}\p{N}]+/gu, '-')}-3d.png`);
  };

  const runPhotoRender = async () => {
    if (photoProgress !== null) return;
    photoCancel.current = false;
    setPhotoProgress(12);
    await new Promise((resolve) => setTimeout(resolve, 80));
    setPhotoProgress(52);
    const blob = await runtimeRef.current?.screenshot(photoScale);
    if (photoCancel.current || !blob) {
      setPhotoProgress(null);
      return;
    }
    setPhotoProgress(86);
    downloadBlob(blob, `${project.name.replace(/[^\p{L}\p{N}]+/gu, '-')}-photo-${photoScale}x.png`);
    setPhotoProgress(100);
    await new Promise((resolve) => setTimeout(resolve, 180));
    setPhotoProgress(null);
    setPhotoOpen(false);
  };

  const cancelPhotoRender = () => {
    photoCancel.current = true;
  };

  return (
    <div className="viewport3d" data-mode={mode}>
      <canvas ref={canvasRef} aria-label="3D scene" />
      <FeedbackOverlay sourceRef={canvasRef} effects={project?.effects || []} project={project} />
      {mode === '3d' && <MutationBar />}
      {ready && mode === '3d' && <div className="viewport-fly-hint">{navigationMode === 'fly' ? 'WASD fly · Space/C up/down · Shift fast · RMB/MMB orbit · Shift+MMB pan · Wheel zoom' : 'RMB / MMB orbit · Shift+MMB pan · Wheel zoom · F frame selected · Shift+F frame scene'}</div>}
      {postLabOpen && <ShaderLabDialog initialContext="post" onClose={() => setPostLabOpen(false)} />}
      {postFxOpen && <PostFxDialog onClose={() => setPostFxOpen(false)} />}
      {new URLSearchParams(window.location.search).get('inputDebug') === '1' && <InputDebugOverlay getState={() => runtimeRef.current?.getInputDebug() || null} />}
      {!ready && !error && <div className="viewport-loading"><span className="spinner" />Preparing 3D scene</div>}
      {error && (
        <div className="viewport-fallback">
          <div className="empty">
            <Box />
            <strong>3D context unavailable</strong>
            <span>{error}. Plan remains available.</span>
          </div>
        </div>
      )}

      <div className="viewport-controls" ref={viewRef}>
        <Button size="sm" icon={<Camera />} onClick={() => setViewOpen((value) => !value)} aria-expanded={viewOpen}>View <ChevronDown /></Button>
        {viewOpen && (
          <div className="viewport-view-menu">
            <div className="viewport-view-label">Camera</div>
            <div className="viewport-view-presets">
              {PRESETS.map((entry) => {
                const Icon = entry.icon;
                return (
                  <button key={entry.id} type="button" className={cameraPreset === entry.id ? 'is-active' : ''} onClick={() => setPreset(entry.id)}>
                    <Icon /> {entry.label}
                  </button>
                );
              })}
            </div>
            <div className="viewport-view-sep" />
            <div className="viewport-view-label">Navigation</div>
            <div className="viewport-nav-modes">
              <button type="button" className={navigationMode === 'orbit' ? 'is-active' : ''} onClick={() => setNavigationMode('orbit')}>Orbit</button>
              <button type="button" className={navigationMode === 'fly' ? 'is-active' : ''} onClick={() => setNavigationMode('fly')}>Fly</button>
            </div>
            <div className="viewport-view-sep" />
            <div className="row wrap">
              <button type="button" className="viewport-view-action" onClick={() => runtimeRef.current?.frameSelection(selectedIds)}>Frame selected · F</button>
              <button type="button" className="viewport-view-action" onClick={() => runtimeRef.current?.frameScene()}>Frame scene · Shift+F</button>
            </div>
            <div className="viewport-view-sep" />
            <label className="viewport-view-field">
              <span>Quality</span>
              <select className="select" value={quality} onChange={(event) => setQuality(event.target.value as 'low' | 'medium' | 'high' | 'ultra' | 'photo')}>
                <option value="photo">Photo</option>
                <option value="ultra">Ultra</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </label>
            <button type="button" className="viewport-view-action" onClick={() => setPerfOpen((value) => !value)}>
              <Gauge /> {perfOpen ? 'Hide performance stats' : 'Performance stats'}
            </button>
            <div className="viewport-view-label">Image settings</div>
            <label className="viewport-image-row">
              <span className="field-label-row"><span>Exposure</span><KeyframeButton objectId={null} propertyPath="scene.exposure" value={project.lighting.exposure} label="Exposure" /></span>
              <input type="range" min={0.4} max={3.5} step={0.05} value={project.lighting.exposure} aria-label="Exposure" onPointerDown={beginTransaction} onPointerUp={endTransaction} onPointerCancel={endTransaction} onKeyDown={beginTransaction} onKeyUp={endTransaction} onChange={(event) => imageValue({ exposure: Number(event.target.value) })} />
              <span className="num">{project.lighting.exposure.toFixed(2)}</span>
            </label>
            <label className="viewport-image-row">
              <span className="field-label-row"><span>Haze</span><KeyframeButton objectId={null} propertyPath="scene.haze" value={project.lighting.haze} label="Haze" /></span>
              <input type="range" min={0} max={2} step={0.01} value={project.lighting.haze} aria-label="Haze density" onPointerDown={beginTransaction} onPointerUp={endTransaction} onPointerCancel={endTransaction} onKeyDown={beginTransaction} onKeyUp={endTransaction} onChange={(event) => imageValue({ haze: Number(event.target.value) })} />
              <span className="num">{Math.round(project.lighting.haze * 100)}%</span>
            </label>
            <label className="viewport-image-check">
              <input type="checkbox" checked={project.lighting.volumetric} onChange={(event) => updateLighting({ volumetric: event.target.checked })} />
              <span>Volumetric lighting</span>
            </label>
            <details className="viewport-image-advanced">
              <summary>Advanced</summary>
              <label className="viewport-image-row">
                <span className="field-label-row"><span>Anisotropy</span><KeyframeButton objectId={null} propertyPath="scene.anisotropy" value={project.lighting.anisotropy} label="Anisotropy" /></span>
                <input type="range" min={-0.15} max={0.9} step={0.01} value={project.lighting.anisotropy} aria-label="Anisotropy" onPointerDown={beginTransaction} onPointerUp={endTransaction} onPointerCancel={endTransaction} onKeyDown={beginTransaction} onKeyUp={endTransaction} onChange={(event) => imageValue({ anisotropy: Number(event.target.value) })} />
                <span className="num">{project.lighting.anisotropy.toFixed(2)}</span>
              </label>
            </details>
            {project?.reactionDiffusion?.enabled && <button type="button" className={`viewport-view-action${rdPaintMode ? ' is-active' : ''}`} onClick={() => { const next = !rdPaintMode; setRdPaintMode(next); runtimeRef.current?.setReactionPaintMode(next); }}><Sparkles /> {rdPaintMode ? 'Stop RD painting' : 'Paint Reaction Diffusion'}</button>}
            <button type="button" className="viewport-view-action" onClick={() => { setViewOpen(false); setPostFxOpen(true); }}><Sparkles /> Post FX stack…</button>
            <button type="button" className="viewport-view-action" onClick={() => { setViewOpen(false); setSettingsOpen(true); }}><Sparkles /> Scene modifier stack…</button>
            <button type="button" className="viewport-view-action" onClick={() => { setViewOpen(false); setPostLabOpen(true); }}><Sparkles /> Post Shader Lab…</button>
            <div className="viewport-view-sep" />
            <button type="button" className="viewport-view-action" onClick={() => updateLighting({ workLight: !project.lighting.workLight })}>
              <Sun /> {project.lighting.workLight ? 'Stage light' : 'Work light'}
            </button>
            <button type="button" className="viewport-view-action" onClick={() => updateLighting({ showWalls: !wallsVisible })}>
              {wallsVisible ? <EyeOff /> : <Eye />} {wallsVisible ? 'Hide walls' : 'Show walls'}
            </button>
            <button type="button" className="viewport-view-action" onClick={() => updateLighting({ showFloor: !floorVisible })}>
              {floorVisible ? <EyeOff /> : <Eye />} {floorVisible ? 'Hide floor' : 'Show floor'}
            </button>
            <button type="button" className="viewport-view-action" onClick={() => setPreset('front')}><RotateCcw /> Reset camera</button>
            <div className="viewport-view-sep" />
            <button type="button" className="viewport-view-action" onClick={takeScreenshot}><Image /> Save PNG</button>
            <button type="button" className="viewport-view-action" onClick={() => setPhotoOpen(true)}><Aperture /> Photo render</button>
            <div className="viewport-view-note">No output to hardware</div>
          </div>
        )}
      </div>

      <div className={`viewport-transform-tools ${rightOpen ? 'is-shifted' : ''}`} role="group" aria-label="Object transform">
        <button type="button" className={transformMode === 'select' ? 'is-active' : ''} title="Select · Q" aria-label="Select object mode" onClick={() => setTransformMode('select')}><MousePointer2 /></button>
        <button type="button" className={transformMode === 'move' ? 'is-active' : ''} title="Move gizmo · 1" aria-label="Move object" onClick={() => setTransformMode('move')}><Move3D /></button>
        <button type="button" className={transformMode === 'rotate' ? 'is-active' : ''} title="Rotate gizmo · 2" aria-label="Rotate object" onClick={() => setTransformMode('rotate')}><RotateCw /></button>
        <button type="button" className={transformMode === 'scale' ? 'is-active' : ''} title={scaleAvailable ? 'Scale gizmo · 3' : 'Scale is available for models'} aria-label="Scale object" disabled={!scaleAvailable} onClick={() => setTransformMode('scale')}><Expand /></button>
      </div>


      {perfOpen && (
        <div className="viewport-perf" role="status" aria-label="Performance statistics">
          {Object.entries(perfStats).map(([key, value]) => (
            <span key={key} data-stat={key}>{key}: <b>{value === null ? 'n/a' : value}</b></span>
          ))}
        </div>
      )}

      {photoOpen && (
        <div className="photo-render-panel" role="dialog" aria-label="Photo render">
          <div className="photo-render-head">
            <span className="field-label">Photo render</span>
            <button type="button" className="icon-btn icon-btn--sm" aria-label="Close photo render" onClick={() => { if (photoProgress === null) setPhotoOpen(false); }}>×</button>
          </div>
          <p className="field-hint">Current frame capture. Higher scales render at a larger pixel size.</p>
          <div className="photo-render-controls">
            <label className="field-label" htmlFor="photo-scale">Scale</label>
            <select id="photo-scale" className="select" value={photoScale} disabled={photoProgress !== null} onChange={(event) => setPhotoScale(Number(event.target.value))}>
              <option value={1}>1× · canvas</option>
              <option value={2}>2× · large</option>
              <option value={3}>3× · maximum</option>
            </select>
          </div>
          {photoProgress !== null ? (
            <div className="photo-render-progress">
              <div className="photo-render-bar" role="progressbar" aria-label="Photo render progress" aria-valuemin={0} aria-valuemax={100} aria-valuenow={photoProgress}><span style={{ width: `${photoProgress}%` }} /></div>
              <div className="row-between"><span className="field-hint">Rendering {photoProgress}%</span><Button size="sm" onClick={cancelPhotoRender}>Cancel</Button></div>
            </div>
          ) : (
            <Button variant="primary" block icon={<Aperture />} onClick={runPhotoRender}>Render PNG</Button>
          )}
        </div>
      )}

    </div>
  );
}
