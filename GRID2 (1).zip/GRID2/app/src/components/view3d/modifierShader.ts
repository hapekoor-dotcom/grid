/**
 * GLSL chunks for the object modifier stack. They keep the standard lit pipeline
 * (shadows, fog, tone mapping, textures) and only deform local positions or add
 * surface emission/opacity. Uniforms are set per mesh instance by the runtime.
 */
export const EFFECT_VERTEX_CHUNK = /* glsl */ `
attribute vec4 vertex_position;

uniform mat4 matrix_viewProjection;
uniform mat4 matrix_model;

uniform float uEffectTime;
uniform float uTwistAmount;
uniform float uTwistAxis;
uniform float uTwistFalloff;
uniform vec3 uTwistPivot;
uniform float uNoiseStrength;
uniform float uNoiseScale;
uniform float uNoiseSpeed;
uniform float uNoiseSeed;
uniform vec3 uNoiseMask;
uniform float uFbmStrength;
uniform float uFbmScale;
uniform float uFbmSpeed;
uniform float uFbmOctaves;
uniform float uFbmSeed;
uniform vec3 uFbmMask;
uniform float uMultiWaveStrength;
uniform float uMultiWaveFrequency;
uniform float uMultiWaveSpeed;
uniform float uTextureStrength;
uniform float uTextureInvert;
uniform vec2 uTextureOffset;
uniform vec2 uTextureTiling;
uniform float uTexturePlanar;
uniform float uTextureUv1;
uniform float uTextureFallback;
uniform float uHasDisplaceMap;
uniform sampler2D uDisplaceMap;
uniform float uTextureMode;
uniform sampler2D uReaction;
uniform float uReactionEnabled;
uniform float uReactionDisplace;
uniform float uReactionMapping;
uniform float uReactionHasUv;
uniform float uReactionContrast;
uniform float uReactionThreshold;
uniform float uReactionInvert;
uniform float uReactionOutput;
uniform float uFieldAdapter;
uniform float uFieldA;
uniform float uFieldB;
uniform float uOrderActive;
uniform float uOrderTwistFirst;
uniform float uOrderDomainStrength;
uniform float uOrderTwistAmount;
uniform float uPinchAmount;
uniform float uPinchRadius;
uniform vec3 uPinchCenter;
uniform float uGeoOpCount;
uniform float uGeoOp0;
uniform float uGeoOp1;
uniform float uGeoOp2;
uniform float uGeoOp3;
uniform float uGeoOp4;
uniform float uGeoOp5;
uniform float uGeoOp6;
uniform float uGeoOp7;
uniform float uGeoOp8;
uniform float uGeoOp9;
uniform float uGeoOp10;
uniform float uGeoOp11;
uniform float uGeoOp12;
uniform float uGeoOp13;
uniform float uGeoOp14;
uniform float uGeoOp15;
uniform float uTextureChannel;
varying vec2 vReactionUv;
uniform float uTextureMidpoint;
uniform float uDomainStrength;
uniform float uDomainScale;
uniform float uDomainSpeed;
uniform float uDomainOctaves;
uniform float uDomainLacunarity;
uniform float uDomainPersistence;
uniform float uDomainSeed;
uniform float uDomainAxis;
uniform float uVortexStrength;
uniform float uVortexRadius;
uniform float uVortexAxis;
uniform float uVortexFalloff;
uniform vec3 uVortexCenter;
uniform float uVortexAnimate;
uniform float uVortexSpeed;
uniform float uAttractStrength;
uniform float uAttractRadius;
uniform float uAttractFalloff;
uniform vec3 uAttractPoint;
uniform float uAttractRepel;
uniform float uBendAmount;
uniform float uBendAxis;
uniform float uBendStart;
uniform float uBendEnd;
uniform float uBendFalloff;
uniform vec3 uBendPivot;
uniform float uBendAnimate;
uniform float uBendSpeed;
uniform float uTaperAmount;
uniform float uTaperAxis;
uniform float uTaperCenter;
uniform float uTaperFalloff;
uniform float uTaperBulge;
uniform float uShearX;
uniform float uShearZ;
uniform float uQuantize;
uniform float uShearAxis;
uniform float uTwistStart;
uniform float uTwistEnd;
uniform float uMeltAmount;
uniform float uMeltViscosity;
uniform float uMeltNoise;
uniform float uMeltThreshold;
uniform float uMeltAxis;
uniform float uSpherizeAmount;
uniform float uSpherizeRadius;
uniform float uRippleStrength;
uniform float uRippleFrequency;
uniform float uRippleSpeed;
uniform vec3 uRippleCenter;
uniform float uRippleRadius;
uniform float uWaveStrength;
uniform float uWaveFrequency;
uniform float uWaveSpeed;
uniform float uWaveTravel;
uniform float uWaveAxis;
uniform float uFoldAmount;
uniform float uFoldAxis;
uniform float uFoldPosition;
uniform float uFoldSharpness;
uniform float uExplodeAmount;
uniform float uExplodeSeed;
uniform float uExplodeThreshold;
uniform float uExplodeAxis;
uniform float uQuantizeGrid;
uniform float uQuantizeRadial;
uniform float uQuantizeAngular;
uniform float uInflateAmount;
uniform float uInflateFalloff;
uniform float uInflateCenter;
uniform float uSliceBands;
uniform float uSliceGap;
uniform float uSliceAxis;
uniform float uMirrorAmount;
uniform float uMirrorAxis;
uniform float uMirrorPosition;
uniform float uSpiralAmount;
uniform float uSpiralRadius;
uniform float uSpiralTwist;
uniform float uSpiralAxis;
uniform float uCylindrifyAmount;
uniform float uCylindrifyRadius;
uniform float uCylindrifyAxis;

float effectHash(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float effectNoise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(effectHash(i + vec3(0,0,0)), effectHash(i + vec3(1,0,0)), f.x),
                   mix(effectHash(i + vec3(0,1,0)), effectHash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(effectHash(i + vec3(0,0,1)), effectHash(i + vec3(1,0,1)), f.x),
                   mix(effectHash(i + vec3(0,1,1)), effectHash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

float effectFbm(vec3 p, float octaves, float lacunarity, float persistence) {
    float total = 0.0;
    float amp = 1.0;
    float norm = 0.0;
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        if (fi >= octaves) break;
        total += effectNoise(p) * amp;
        norm += amp;
        p = p * lacunarity + vec3(1.7, 9.2, 3.4);
        amp *= persistence;
    }
    return norm > 0.0 ? total / norm : 0.0;
}

float effectAxisValue(vec3 p, float axis) {
    return axis < 0.5 ? p.x : (axis < 1.5 ? p.y : p.z);
}

vec3 effectAxisMask(float axis) {
    return axis < 0.5 ? vec3(1.0, 0.0, 0.0) : (axis < 1.5 ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0));
}

vec3 effectRotateAxis(vec3 p, vec3 pivot, float angle, float axis) {
    vec3 local = p - pivot;
    float c = cos(angle);
    float s = sin(angle);
    if (axis < 0.5) return pivot + vec3(local.x, c * local.y - s * local.z, s * local.y + c * local.z);
    if (axis < 1.5) return pivot + vec3(c * local.x + s * local.z, local.y, -s * local.x + c * local.z);
    return pivot + vec3(c * local.x - s * local.y, s * local.x + c * local.y, local.z);
}

void effectCustomVertex(inout vec3 p, vec3 normal, vec2 uv) {
}

float reactionAdapter(float value) { if (uFieldAdapter > 7.5) return floor(value / max(0.0001, uFieldA)) * uFieldA;
    if (uFieldAdapter > 6.5) return pow(max(0.0, value), max(0.01, uFieldA));
    if (uFieldAdapter > 5.5) return value + uFieldA;
    if (uFieldAdapter > 4.5) return value * uFieldA;
    if (uFieldAdapter > 3.5) return smoothstep(uFieldA, uFieldB, value); if (uFieldAdapter > 2.5) return 1.0 - value; if (uFieldAdapter > 1.5) return clamp((value - uFieldA) / max(0.0001, uFieldB - uFieldA), 0.0, 1.0); if (uFieldAdapter > 0.5) return step(uFieldA, value); return value; }
float reactionShade(float raw) { float value = (raw - uReactionThreshold) * uReactionContrast + 0.5; value = uReactionInvert > 0.5 ? 1.0 - value : value; return clamp(value, 0.0, 1.0); }
vec2 reactionGradient(vec2 uv) { vec2 t = vec2(0.003); float l = reactionShade(texture2D(uReaction, uv - vec2(t.x, 0.0)).r); float r = reactionShade(texture2D(uReaction, uv + vec2(t.x, 0.0)).r); float d = reactionShade(texture2D(uReaction, uv - vec2(0.0, t.y)).r); float u = reactionShade(texture2D(uReaction, uv + vec2(0.0, t.y)).r); return vec2(r - l, u - d); }
float reactionFieldValue(vec2 uv) { float scalar = reactionAdapter(reactionShade(texture2D(uReaction, uv).r)); if (uReactionOutput > 3.5) return clamp(length(reactionGradient(uv)) * 6.0, 0.0, 1.0);
    if (uReactionOutput > 2.5) { vec2 g = reactionGradient(uv); return clamp(0.5 + g.x * 4.0, 0.0, 1.0); } if (uReactionOutput > 1.5) return clamp(length(reactionGradient(uv)) * 6.0, 0.0, 1.0); if (uReactionOutput > 0.5) return step(uReactionThreshold, scalar); return scalar; }

vec3 effectOrderedDomain(vec3 p) {
    vec3 samplePos = p * max(0.001, uDomainScale) + vec3(uDomainSeed, uDomainSeed * 1.7, uDomainSeed * 2.3) + uEffectTime * uDomainSpeed;
    float n1 = effectFbm(samplePos, uDomainOctaves, uDomainLacunarity, uDomainPersistence);
    float n2 = effectFbm(samplePos + vec3(11.3, 7.1, 3.7), uDomainOctaves, uDomainLacunarity, uDomainPersistence);
    float n3 = effectFbm(samplePos + vec3(3.2, 19.1, 8.4), uDomainOctaves, uDomainLacunarity, uDomainPersistence);
    vec3 warp = (vec3(n1, n2, n3) * 2.0 - 1.0) * uOrderDomainStrength;
    warp *= uDomainAxis < 0.5 ? vec3(1.0, 0.0, 0.0) : (uDomainAxis < 1.5 ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0));
    return p + warp;
}
vec3 effectOrderedTwist(vec3 p) {
    float coordinate = uTwistAxis < 0.5 ? p.x : (uTwistAxis < 1.5 ? p.y : p.z);
    float pivotCoordinate = uTwistAxis < 0.5 ? uTwistPivot.x : (uTwistAxis < 1.5 ? uTwistPivot.y : uTwistPivot.z);
    float region = smoothstep(uTwistStart, uTwistEnd, coordinate);
    float angle = radians(uOrderTwistAmount) * (coordinate - pivotCoordinate) / max(0.001, uTwistFalloff) * region;
    return effectRotateAxis(p, uTwistPivot, angle, uTwistAxis);
}
vec3 effectOrderedOp(vec3 p, int op) {
    if (op == 1) return effectOrderedDomain(p);
    if (op == 2) return effectOrderedTwist(p);
    if (op == 3) {
        float len = max(0.0001, length(p));
        vec3 sphere = normalize(p + vec3(0.0001)) * uSpherizeRadius;
        return mix(p, sphere, clamp(uSpherizeAmount * 0.5, 0.0, 1.0));
    }
    if (op == 4) {
        vec3 samplePos = p * max(0.001, uNoiseScale) + vec3(uNoiseSeed, uNoiseSeed * 1.7, uNoiseSeed * 2.3) + uEffectTime * uNoiseSpeed;
        vec3 n = vec3(effectNoise(samplePos), effectNoise(samplePos + 19.1), effectNoise(samplePos + 37.7)) * 2.0 - 1.0;
        return p + n * uNoiseMask * uNoiseStrength;
    }
    if (op == 5) {
        float falloff = 1.0 - clamp((length(p) - uInflateCenter) / max(0.001, uInflateFalloff), 0.0, 1.0);
        return p + normalize(p + vec3(0.0001)) * uInflateAmount * falloff;
    }
    if (op == 6) {
        vec3 relative = p - uRippleCenter;
        float distanceToCenter = length(relative);
        float wave = sin(distanceToCenter * uRippleFrequency - uEffectTime * uRippleSpeed * 6.2831853);
        float falloff = 1.0 - clamp(distanceToCenter / max(0.001, uRippleRadius), 0.0, 1.0);
        return p + normalize(relative + vec3(0.0001)) * wave * uRippleStrength * falloff;
    }
    if (op == 7) {
        vec3 relative = p - uVortexCenter;
        float radial = length(relative);
        float falloff = clamp(1.0 - radial / max(0.001, uVortexRadius), 0.0, 1.0);
        float angle = uVortexStrength * falloff * (uVortexAnimate > 0.5 ? sin(uEffectTime * 6.2831853 * uVortexSpeed) : 1.0);
        return effectRotateAxis(p, uVortexCenter, angle, uVortexAxis);
    }
    if (op == 8) {
        float coordinate = effectAxisValue(p, uTaperAxis);
        float factor = 1.0 + (coordinate - uTaperCenter) / max(0.001, uTaperFalloff) * uTaperAmount;
        vec3 delta = p - effectAxisMask(uTaperAxis) * coordinate;
        vec3 result = effectAxisMask(uTaperAxis) * coordinate + delta * max(0.01, factor);
        return result + delta * (uTaperBulge * (1.0 - clamp(length(delta), 0.0, 1.0)));
    }
    if (op == 9) {
        float coordinate = effectAxisValue(p, uShearAxis);
        return p + vec3(uShearX * coordinate, 0.0, uShearZ * coordinate);
    }
    if (op == 10) return uQuantize > 0.0001 ? floor(p / uQuantize) * uQuantize : p;
    if (op == 11) {
        vec3 samplePos = p * max(0.001, uMeltNoise) + vec3(uEffectTime * 0.1);
        float meltNoise = effectNoise(samplePos) * 0.55 + effectNoise(samplePos * 2.1) * 0.3 + effectNoise(samplePos * 4.3) * 0.15;
        float melted = smoothstep(uMeltThreshold, uMeltThreshold + max(0.01, 1.0 - uMeltViscosity), meltNoise);
        vec3 result = p;
        result.y -= uMeltAmount * melted * (1.0 - smoothstep(0.0, 4.0, result.y));
        return result;
    }
    if (op == 12) {
        vec3 relative = p - uAttractPoint;
        float distanceToPoint = length(relative);
        float influence = pow(clamp(1.0 - distanceToPoint / max(0.001, uAttractRadius), 0.0, 1.0), max(0.05, uAttractFalloff));
        return p - normalize(relative + vec3(0.0001)) * uAttractStrength * influence * (uAttractRepel > 0.5 ? -1.0 : 1.0);
    }
    if (op == 13) {
        float coordinate = effectAxisValue(p, uBendAxis);
        float t = smoothstep(uBendStart, uBendEnd, coordinate);
        float angle = radians(uBendAmount) * t * (uBendAnimate > 0.5 ? sin(uEffectTime * 6.2831853 * uBendSpeed) : 1.0) / max(0.001, uBendFalloff);
        return effectRotateAxis(p, uBendPivot, angle, uBendAxis);
    }
    if (op == 14) {
        vec3 flatVec = vec3(p.x, 0.0, p.z);
        vec3 cylinder = normalize(flatVec + vec3(0.0001)) * uCylindrifyRadius;
        cylinder.y = effectAxisValue(p, uCylindrifyAxis);
        return mix(p, cylinder, clamp(abs(uCylindrifyAmount) * 0.5, 0.0, 1.0));
    }
    if (op == 15) {
        float coordinate = effectAxisValue(p, uSpiralAxis);
        float angle = coordinate * uSpiralTwist + uEffectTime * 0.2;
        vec3 rotated = effectRotateAxis(p, vec3(0.0), angle * uSpiralAmount, uSpiralAxis);
        return mix(p, rotated, clamp(1.0 / max(0.1, uSpiralRadius), 0.0, 1.0));
    }
    if (op == 16) {
        float coordinate = effectAxisValue(p, uFoldAxis);
        float folded = max(coordinate, 2.0 * uFoldPosition - coordinate);
        return p + effectAxisMask(uFoldAxis) * (folded - coordinate) * clamp(uFoldAmount, 0.0, 1.0) * max(0.1, uFoldSharpness);
    }
    if (op == 17) {
        vec3 samplePos = p * 3.1 + vec3(uExplodeSeed);
        float n = effectNoise(samplePos);
        float burst = step(uExplodeThreshold, n);
        return p + normalize(p + effectAxisMask(uExplodeAxis) * 0.001) * burst * uExplodeAmount * (0.4 + n);
    }
    if (op == 18) {
        float coordinate = effectAxisValue(p, uMirrorAxis);
        float side = sign(coordinate - uMirrorPosition);
        return mix(p, effectAxisMask(uMirrorAxis) * (2.0 * uMirrorPosition - coordinate) + (p - effectAxisMask(uMirrorAxis) * coordinate), clamp(uMirrorAmount, 0.0, 1.0) * step(0.0, -side));
    }
    if (op == 19) {
        float coordinate = effectAxisValue(p, uSliceAxis);
        float band = floor(coordinate * uSliceBands * 0.25);
        float shifted = coordinate + mod(band, 2.0) * uSliceGap * step(0.5, fract(band * 0.5));
        return p + effectAxisMask(uSliceAxis) * (shifted - coordinate);
    }
    if (op == 20) {
        vec3 relative = p - uPinchCenter;
        float falloff = exp(-dot(relative, relative) / max(0.0001, uPinchRadius * uPinchRadius));
        return uPinchCenter + relative * (1.0 + uPinchAmount * falloff);
    }
    if (op == 21) {
        vec3 samplePos = p * max(0.001, uFbmScale) + vec3(uFbmSeed) + uEffectTime * uFbmSpeed;
        vec3 n = vec3(effectFbm(samplePos, uFbmOctaves, 2.0, 0.5), effectFbm(samplePos + 13.7, uFbmOctaves, 2.0, 0.5), effectFbm(samplePos + 29.1, uFbmOctaves, 2.0, 0.5)) * 2.0 - 1.0;
        return p + n * uFbmMask * uFbmStrength;
    }
    if (op == 22) {
        float x = sin(dot(p, vec3(1.0, 0.3, 0.2)) * uMultiWaveFrequency - uEffectTime * uMultiWaveSpeed * 6.2831853);
        float y = sin(dot(p, vec3(0.2, 1.0, 0.4)) * uMultiWaveFrequency * 1.37 + uEffectTime * uMultiWaveSpeed * 4.7);
        float z = sin(dot(p, vec3(0.4, 0.2, 1.0)) * uMultiWaveFrequency * 0.83 - uEffectTime * uMultiWaveSpeed * 3.1);
        return p + vec3(x, y, z) * uMultiWaveStrength;
    }
    return p;
}
vec3 effectOrdered(vec3 p) {
    if (uOrderActive < 0.5) return p;
    vec3 result = p;
    if (uGeoOpCount > 0.5) result = effectOrderedOp(result, int(uGeoOp0));
    if (uGeoOpCount > 1.5) result = effectOrderedOp(result, int(uGeoOp1));
    if (uGeoOpCount > 2.5) result = effectOrderedOp(result, int(uGeoOp2));
    if (uGeoOpCount > 3.5) result = effectOrderedOp(result, int(uGeoOp3));
    if (uGeoOpCount > 4.5) result = effectOrderedOp(result, int(uGeoOp4));
    if (uGeoOpCount > 5.5) result = effectOrderedOp(result, int(uGeoOp5));
    if (uGeoOpCount > 6.5) result = effectOrderedOp(result, int(uGeoOp6));
    if (uGeoOpCount > 7.5) result = effectOrderedOp(result, int(uGeoOp7));
    if (uGeoOpCount > 8.5) result = effectOrderedOp(result, int(uGeoOp8));
    if (uGeoOpCount > 9.5) result = effectOrderedOp(result, int(uGeoOp9));
    if (uGeoOpCount > 10.5) result = effectOrderedOp(result, int(uGeoOp10));
    if (uGeoOpCount > 11.5) result = effectOrderedOp(result, int(uGeoOp11));
    if (uGeoOpCount > 12.5) result = effectOrderedOp(result, int(uGeoOp12));
    if (uGeoOpCount > 13.5) result = effectOrderedOp(result, int(uGeoOp13));
    if (uGeoOpCount > 14.5) result = effectOrderedOp(result, int(uGeoOp14));
    if (uGeoOpCount > 15.5) result = effectOrderedOp(result, int(uGeoOp15));
    return result;
}

vec3 effectApply(vec3 p) {
    vec3 result = p;
    if (uOrderActive < 0.5 && uDomainStrength > 0.0001) {
        vec3 samplePos = result * max(0.001, uDomainScale) + vec3(uDomainSeed, uDomainSeed * 1.7, uDomainSeed * 2.3) + uEffectTime * uDomainSpeed;
        float n1 = effectFbm(samplePos, uDomainOctaves, uDomainLacunarity, uDomainPersistence);
        float n2 = effectFbm(samplePos + vec3(11.3, 7.1, 3.7), uDomainOctaves, uDomainLacunarity, uDomainPersistence);
        float n3 = effectFbm(samplePos + vec3(3.2, 19.1, 8.4), uDomainOctaves, uDomainLacunarity, uDomainPersistence);
        vec3 warp = (vec3(n1, n2, n3) * 2.0 - 1.0) * uDomainStrength;
        warp *= uDomainAxis < 0.5 ? vec3(1.0, 0.0, 0.0) : (uDomainAxis < 1.5 ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0));
        result += warp;
    }
    if (uOrderActive < 0.5 && uVortexStrength != 0.0) {
        vec3 relative = result - uVortexCenter;
        float radial = length(relative);
        float falloff = clamp(1.0 - radial / max(0.001, uVortexRadius), 0.0, 1.0);
        float angle = uVortexStrength * falloff * (uVortexAnimate > 0.5 ? sin(uEffectTime * 6.2831853 * uVortexSpeed) : 1.0);
        result = effectRotateAxis(result, uVortexCenter, angle, uVortexAxis);
    }
    if (uOrderActive < 0.5 && uAttractStrength != 0.0) {
        vec3 relative = result - uAttractPoint;
        float distanceToPoint = length(relative);
        float influence = pow(clamp(1.0 - distanceToPoint / max(0.001, uAttractRadius), 0.0, 1.0), max(0.05, uAttractFalloff));
        result -= normalize(relative + vec3(0.0001)) * uAttractStrength * influence * (uAttractRepel > 0.5 ? -1.0 : 1.0);
    }
    if (uOrderActive < 0.5 && abs(uBendAmount) > 0.0001) {
        float coordinate = effectAxisValue(result, uBendAxis);
        float t = smoothstep(uBendStart, uBendEnd, coordinate);
        float angle = radians(uBendAmount) * t * (uBendAnimate > 0.5 ? sin(uEffectTime * 6.2831853 * uBendSpeed) : 1.0) / max(0.001, uBendFalloff);
        result = effectRotateAxis(result, uBendPivot, angle, uBendAxis);
    }
    if (uOrderActive < 0.5 && abs(uTaperAmount) > 0.0001 || abs(uTaperBulge) > 0.0001) {
        float coordinate = effectAxisValue(result, uTaperAxis);
        float factor = 1.0 + (coordinate - uTaperCenter) / max(0.001, uTaperFalloff) * uTaperAmount;
        vec3 delta = result - effectAxisMask(uTaperAxis) * coordinate;
        result = effectAxisMask(uTaperAxis) * coordinate + delta * max(0.01, factor);
        result += delta * (uTaperBulge * (1.0 - clamp(length(delta), 0.0, 1.0)));
    }
    if (uOrderActive < 0.5 && abs(uShearX) > 0.0001 || abs(uShearZ) > 0.0001) {
        float coordinate = effectAxisValue(result, uShearAxis);
        result.x += uShearX * coordinate;
        result.z += uShearZ * coordinate;
    }
    if (uOrderActive < 0.5 && uQuantize > 0.0001) result = floor(result / uQuantize) * uQuantize;
    if (uOrderActive < 0.5 && uMeltAmount > 0.0001) {
        vec3 samplePos = result * max(0.001, uMeltNoise) + vec3(uEffectTime * 0.1);
        float meltNoise = effectNoise(samplePos) * 0.55 + effectNoise(samplePos * 2.1) * 0.3 + effectNoise(samplePos * 4.3) * 0.15;
        float melted = smoothstep(uMeltThreshold, uMeltThreshold + max(0.01, 1.0 - uMeltViscosity), meltNoise);
        result.y -= uMeltAmount * melted * (1.0 - smoothstep(0.0, 4.0, result.y));
    }
    if (uOrderActive < 0.5 && abs(uSpherizeAmount) > 0.0001) {
        float len = max(0.0001, length(result));
        vec3 sphere = normalize(result + vec3(0.0001)) * uSpherizeRadius;
        result = mix(result, sphere, clamp(uSpherizeAmount * 0.5, 0.0, 1.0));
    }
    if (uOrderActive < 0.5 && uRippleStrength > 0.0001) {
        vec3 relative = result - uRippleCenter;
        float distanceToCenter = length(relative);
        float wave = sin(distanceToCenter * uRippleFrequency - uEffectTime * uRippleSpeed * 6.2831853);
        float falloff = 1.0 - clamp(distanceToCenter / max(0.001, uRippleRadius), 0.0, 1.0);
        result += normalize(relative + vec3(0.0001)) * wave * uRippleStrength * falloff;
    }
    if (uWaveStrength > 0.0001) {
        vec3 direction = effectAxisMask(uWaveTravel);
        float wave = sin(dot(result, direction) * uWaveFrequency - uEffectTime * uWaveSpeed * 6.2831853);
        result += effectAxisMask(uWaveAxis) * wave * uWaveStrength;
    }
    if (uOrderActive < 0.5 && uFoldAmount > 0.0001) {
        float coordinate = effectAxisValue(result, uFoldAxis);
        float folded = max(coordinate, 2.0 * uFoldPosition - coordinate);
        result = mix(result, result + effectAxisMask(uFoldAxis) * (folded - coordinate), clamp(uFoldAmount, 0.0, 1.0) * max(0.1, uFoldSharpness));
    }
    if (uOrderActive < 0.5 && uExplodeAmount > 0.0001) {
        vec3 samplePos = result * 3.1 + vec3(uExplodeSeed);
        float n = effectNoise(samplePos);
        float burst = step(uExplodeThreshold, n);
        result += normalize(result + effectAxisMask(uExplodeAxis) * 0.001) * burst * uExplodeAmount * (0.4 + n);
    }
    if (uQuantizeGrid > 0.0001) result = floor(result / uQuantizeGrid + 0.5) * uQuantizeGrid;
    if (uQuantizeRadial > 0.5) {
        vec3 flatVec = vec3(result.x, 0.0, result.z);
        float radius = length(flatVec);
        float stepRadius = 6.2831853 / uQuantizeRadial;
        float angle = atan(result.z, result.x);
        angle = floor(angle / stepRadius + 0.5) * stepRadius;
        result.xz = vec2(cos(angle), sin(angle)) * radius;
    }
    if (uOrderActive < 0.5 && abs(uInflateAmount) > 0.0001) {
        float falloff = 1.0 - clamp((length(result) - uInflateCenter) / max(0.001, uInflateFalloff), 0.0, 1.0);
        result += normalize(result + vec3(0.0001)) * uInflateAmount * falloff;
    }
    if (uOrderActive < 0.5 && uSliceBands > 1.5) {
        float coordinate = effectAxisValue(result, uSliceAxis);
        float band = floor(coordinate * uSliceBands * 0.25);
        vec3 tangent = uSliceAxis < 0.5 ? vec3(0.0, 0.0, 1.0) : (uSliceAxis < 1.5 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0));
        result += tangent * (mod(band, 2.0) * 2.0 - 1.0) * uSliceGap * 0.1;
    }
    if (uOrderActive < 0.5 && uMirrorAmount > 0.0001) {
        float coordinate = effectAxisValue(result, uMirrorAxis);
        float mirrored = coordinate > uMirrorPosition ? uMirrorPosition - (coordinate - uMirrorPosition) : coordinate;
        result += effectAxisMask(uMirrorAxis) * (mirrored - coordinate) * uMirrorAmount;
    }
    if (uOrderActive < 0.5 && uSpiralAmount > 0.0001) {
        float coordinate = effectAxisValue(result, uSpiralAxis);
        float angle = coordinate * uSpiralTwist + uEffectTime * 0.2;
        vec3 rotated = effectRotateAxis(result, vec3(0.0), angle * uSpiralAmount, uSpiralAxis);
        result = mix(result, rotated, clamp(1.0 / max(0.1, uSpiralRadius), 0.0, 1.0));
    }
    if (uOrderActive < 0.5 && abs(uCylindrifyAmount) > 0.0001) {
        vec3 flatVec = vec3(result.x, 0.0, result.z);
        vec3 cylinder = normalize(flatVec + vec3(0.0001)) * uCylindrifyRadius;
        cylinder.y = effectAxisValue(result, uCylindrifyAxis);
        result = mix(result, cylinder, clamp(abs(uCylindrifyAmount) * 0.5, 0.0, 1.0));
    }
    if (uOrderActive < 0.5 && abs(uTwistAmount) > 0.0001) {
        float coordinate = uTwistAxis < 0.5 ? p.x : (uTwistAxis < 1.5 ? p.y : p.z);
        float pivotCoordinate = uTwistAxis < 0.5 ? uTwistPivot.x : (uTwistAxis < 1.5 ? uTwistPivot.y : uTwistPivot.z);
        float region = smoothstep(uTwistStart, uTwistEnd, coordinate);
        float angle = radians(uTwistAmount) * (coordinate - pivotCoordinate) / max(0.001, uTwistFalloff) * region;
        result = effectRotateAxis(result, uTwistPivot, angle, uTwistAxis);
    }
    if (uOrderActive < 0.5 && uNoiseStrength > 0.0001) {
        vec3 samplePos = result * max(0.001, uNoiseScale) + vec3(uNoiseSeed, uNoiseSeed * 1.7, uNoiseSeed * 2.3) + uEffectTime * uNoiseSpeed;
        vec3 n = vec3(effectNoise(samplePos), effectNoise(samplePos + 19.1), effectNoise(samplePos + 37.7)) * 2.0 - 1.0;
        result += n * uNoiseMask * uNoiseStrength;
    }
    vec3 reactionWorld = (matrix_model * vec4(result, 1.0)).xyz;
    vec2 reactionUv;
    if (uReactionMapping > 3.5) {
        vec3 direction = normalize(reactionWorld + vec3(0.0001));
        reactionUv = vec2(atan(direction.z, direction.x) / 6.2831853 + 0.5, direction.y * 0.5 + 0.5);
    } else if (uReactionMapping > 2.5) {
        reactionUv = reactionWorld.xz * 0.25 + 0.5;
    } else if (uReactionMapping > 1.5) {
        reactionUv = result.xz * 0.25 + 0.5;
    } else if (uReactionMapping > 0.5 || uReactionHasUv > 0.5) {
        #ifdef UV0
            reactionUv = vertex_texCoord0;
        #else
            reactionUv = result.xz * 0.25 + 0.5;
        #endif
    } else {
        reactionUv = result.xz * 0.25 + 0.5;
    }
    vReactionUv = reactionUv;
    if (uReactionEnabled > 0.5 && abs(uReactionDisplace) > 0.0001) {
        float reactionField = reactionFieldValue(reactionUv);
        if (uReactionOutput > 3.5) {
            result.xz += reactionGradient(reactionUv) * uReactionDisplace;
        } else {
            vec3 reactionNormal = normalize(result + vec3(0.0001));
            result += reactionNormal * (reactionField - 0.5) * uReactionDisplace;
        }
    }
    if (uTextureStrength > 0.0001) {
        vec2 uv;
        #ifdef UV0
            uv = vertex_texCoord0;
        #else
            uv = result.xz * 0.25;
        #endif
        #ifdef UV1
            if (uTextureUv1 > 0.5) uv = vertex_texCoord1;
        #endif
        if (uTexturePlanar > 0.5) uv = result.xz * 0.25;
        uv = uv * uTextureTiling + uTextureOffset + vec2(uEffectTime * 0.04, 0.0);
        vec4 sampleColor = uHasDisplaceMap > 0.5 ? texture2D(uDisplaceMap, uv) : vec4(effectNoise(result * max(0.001, uNoiseScale) + uNoiseSeed) * uTextureFallback);
        float height = uTextureChannel < 0.5 ? sampleColor.r : (uTextureChannel < 1.5 ? sampleColor.g : (uTextureChannel < 2.5 ? sampleColor.b : sampleColor.a));
        height = uTextureInvert > 0.5 ? 1.0 - height : height;
        height = height - uTextureMidpoint;
        if (uTextureMode > 0.5 && uTextureMode < 1.5) {
            result += (sampleColor.rgb * 2.0 - 1.0) * uTextureStrength;
        } else if (uTextureMode > 1.5) {
            float depth = height;
            vec3 axis = uTextureMode > 2.5 ? normalize(result + vec3(0.0001)) : vec3(0.0, 1.0, 0.0);
            result += axis * depth * uTextureStrength;
        } else {
            vec3 radial = normalize(result - uTwistPivot + vec3(0.0001, 0.0001, 0.0001));
            result += radial * height * uTextureStrength;
        }
    }
    effectCustomVertex(result, normalize(result + vec3(0.0001)), vec2(result.x, result.z));
    result = effectOrdered(result);
    return result;
}

#ifdef MORPHING
    uniform vec2 morph_tex_params;
    attribute uint morph_vertex_id;
    ivec2 getTextureMorphCoords() {
        ivec2 textureSize = ivec2(morph_tex_params);
        int morphGridV = int(morph_vertex_id) / textureSize.x;
        int morphGridU = int(morph_vertex_id) - (morphGridV * textureSize.x);
        #ifdef WEBGPU
            morphGridV = textureSize.y - morphGridV - 1;
        #endif
        return ivec2(morphGridU, morphGridV);
    }
    #ifdef MORPHING_POSITION
        #ifdef MORPHING_INT
            uniform vec3 aabbSize;
            uniform vec3 aabbMin;
            uniform usampler2D morphPositionTex;
        #else
            uniform highp sampler2D morphPositionTex;
        #endif
    #endif
#endif

#ifdef defined(BATCH)
    #include "skinBatchVS"
    mat4 getModelMatrix() { return getBoneMatrix(vertex_boneIndices); }
#elif defined(SKIN)
    #include "skinVS"
    mat4 getModelMatrix() { return matrix_model * getSkinMatrix(vertex_boneIndices, vertex_boneWeights); }
#elif defined(INSTANCING)
    #include "transformInstancingVS"
#else
    mat4 getModelMatrix() { return matrix_model; }
#endif

vec3 getLocalPosition(vec3 vertexPosition) {
    vec3 localPos = vertexPosition;
    #ifdef MORPHING_POSITION
        ivec2 morphUV = getTextureMorphCoords();
        #ifdef MORPHING_INT
            vec3 morphPos = vec3(texelFetch(morphPositionTex, ivec2(morphUV), 0).xyz) / 65535.0 * aabbSize + aabbMin;
        #else
            vec3 morphPos = texelFetch(morphPositionTex, ivec2(morphUV), 0).xyz;
        #endif
        localPos += morphPos;
    #endif
    return effectApply(localPos);
}
`;

const FRAG_UNIFORMS = /* glsl */ `
#ifndef RE_REACTION_FRAG
#define RE_REACTION_FRAG
uniform float uEffectTime;
uniform sampler2D uReaction;
uniform float uReactionEnabled;
uniform float uReactionEmission;
uniform float uReactionContrast;
uniform float uReactionThreshold;
uniform float uReactionInvert;
uniform float uReactionOutput;
uniform float uFieldAdapter;
uniform float uFieldA;
uniform float uFieldB;
uniform float uReactionOpacity;
uniform float uReactionBaseColor;
uniform vec3 uReactionColor;
uniform vec3 uReactionColorB;
#ifndef RE_REACTION_UV
#define RE_REACTION_UV
varying vec2 vReactionUv;
#endif
float reactionAdapter(float value) { if (uFieldAdapter > 7.5) return floor(value / max(0.0001, uFieldA)) * uFieldA;
    if (uFieldAdapter > 6.5) return pow(max(0.0, value), max(0.01, uFieldA));
    if (uFieldAdapter > 5.5) return value + uFieldA;
    if (uFieldAdapter > 4.5) return value * uFieldA;
    if (uFieldAdapter > 3.5) return smoothstep(uFieldA, uFieldB, value); if (uFieldAdapter > 2.5) return 1.0 - value; if (uFieldAdapter > 1.5) return clamp((value - uFieldA) / max(0.0001, uFieldB - uFieldA), 0.0, 1.0); if (uFieldAdapter > 0.5) return step(uFieldA, value); return value; }
float reactionShade(float raw) { float value = (raw - uReactionThreshold) * uReactionContrast + 0.5; value = uReactionInvert > 0.5 ? 1.0 - value : value; return clamp(value, 0.0, 1.0); }
vec2 reactionGradient(vec2 uv) { vec2 t = vec2(0.003); float l = reactionShade(texture2D(uReaction, uv - vec2(t.x, 0.0)).r); float r = reactionShade(texture2D(uReaction, uv + vec2(t.x, 0.0)).r); float d = reactionShade(texture2D(uReaction, uv - vec2(0.0, t.y)).r); float u = reactionShade(texture2D(uReaction, uv + vec2(0.0, t.y)).r); return vec2(r - l, u - d); }
float reactionFieldValue(vec2 uv) { float scalar = reactionAdapter(reactionShade(texture2D(uReaction, uv).r)); if (uReactionOutput > 3.5) return clamp(length(reactionGradient(uv)) * 6.0, 0.0, 1.0);
    if (uReactionOutput > 2.5) { vec2 g = reactionGradient(uv); return clamp(0.5 + g.x * 4.0, 0.0, 1.0); } if (uReactionOutput > 1.5) return clamp(length(reactionGradient(uv)) * 6.0, 0.0, 1.0); if (uReactionOutput > 0.5) return step(uReactionThreshold, scalar); return scalar; }
uniform float uFresnelIntensity;
uniform float uFresnelBias;
uniform float uFresnelPower;
uniform float uFresnelMode;
uniform vec3 uFresnelColor;
uniform float uFresnelIridescence;
uniform float uFresnelBlend;
uniform float uDissolveAmount;
uniform float uDissolveEdgeWidth;
uniform vec3 uDissolveEdgeColor;
uniform float uDissolveEdgeGlow;
uniform float uDissolveNoiseScale;
uniform float uDissolveSeed;
uniform float uLiquidAmount;
uniform vec3 uLiquidTint;
uniform vec3 uLiquidAccent;
uniform float uLiquidFresnel;
uniform float uLiquidEmission;
uniform float uLiquidDistortion;
uniform float uLiquidFlow;
uniform float uLiquidScale;
uniform float uMagmaAmount;
uniform vec3 uMagmaCrust;
uniform vec3 uMagmaLava;
uniform vec3 uMagmaHot;
uniform float uMagmaScale;
uniform float uMagmaCrackWidth;
uniform float uMagmaTemperature;
uniform float uMagmaEmission;
uniform float uMagmaFlow;
uniform float uMagmaDistortion;
uniform float uPlasmaAmount;
uniform vec3 uPlasmaA;
uniform vec3 uPlasmaB;
uniform vec3 uPlasmaC;
uniform float uPlasmaScale;
uniform float uPlasmaSpeed;
uniform float uPlasmaTurbulence;
uniform float uPlasmaEmission;
uniform float uPlasmaEdge;
uniform float uHoloAmount;
uniform vec3 uHoloA;
uniform vec3 uHoloB;
uniform float uHoloScanDensity;
uniform float uHoloScanSpeed;
uniform float uHoloFlicker;
uniform float uHoloGlitch;
uniform float uHoloBreakup;
uniform float uHoloNoise;
uniform float uHoloChromatic;
uniform float uHoloOpacity;
uniform float uHoloEmission;
uniform float uIridAmount;
uniform float uIridThickness;
uniform float uIridIOR;
uniform float uIridHue;
uniform float uIridFresnel;
uniform float uIridScale;
uniform vec3 uIridTint;
uniform float uTriAmount;
uniform vec3 uTriA;
uniform vec3 uTriB;
uniform float uTriScale;
uniform float uTriSpeed;
uniform float uTriBlend;
uniform float uTriEmission;
uniform float uXrayAmount;
uniform vec3 uXrayColor;
uniform float uXrayPower;
uniform float uGhostAmount;
uniform vec3 uGhostColor;
uniform float uGhostPower;
uniform float uGlassAmount;
uniform vec3 uGlassColor;
uniform float uNeonAmount;
uniform vec3 uNeonColor;
uniform float uNeonPower;
uniform float uNeonWidth;
uniform float uScanSurfAmount;
uniform vec3 uScanSurfColor;
uniform float uScanDensity;
uniform float uScanSpeed;
uniform float uChromaticAmount;
uniform vec3 uChromaticA;
uniform vec3 uChromaticB;
uniform float uChromaticScale;
uniform float uChromaticSpeed;
uniform float uNoiseSurfAmount;
uniform vec3 uNoiseSurfA;
uniform vec3 uNoiseSurfB;
uniform float uNoiseSurfScale;
uniform float uNoiseSurfSpeed;
uniform float uDigitalSurfAmount;
uniform vec3 uDigitalColor;
uniform float uDigitalBlocks;
uniform float uDigitalSpeed;
uniform float uCheckerAmount;
uniform vec3 uCheckerA;
uniform vec3 uCheckerB;
uniform float uCheckerScale;
uniform float uWavesSurfAmount;
uniform vec3 uWavesColor;
uniform float uWavesScale;
uniform float uWavesSpeed;
uniform float uRingsSurfAmount;
uniform vec3 uRingsColor;
uniform float uRingsFreq;
uniform float uRingsSpeed;
uniform float uWireAmount;
uniform vec3 uWireColor;
uniform float uVoronoiAmount;
uniform float uVoronoiScale;
uniform float uVoronoiBorder;
uniform vec3 uVoronoiA;
uniform vec3 uVoronoiB;
uniform float uVoronoiEmission;
uniform float uGradientAmount;
uniform vec3 uGradientA;
uniform vec3 uGradientB;
uniform vec3 uGradientC;
uniform float uGradientScale;
uniform float uGradientSpeed;
uniform float uGradientAngle;
uniform float uGradientEmission;
uniform float uGlitchSurfaceAmount;
uniform float uGlitchSurfaceBlocks;
uniform float uGlitchSurfaceShift;
uniform float uGlitchSurfaceEmission;
uniform vec3 uGlitchSurfaceColor;

#endif`;

const EMISSIVE_FUNCTIONS = /* glsl */ `
float effectNoiseFrag(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3)) * 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float effectNoiseSurface(vec3 x) {
    vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(effectNoiseFrag(i), effectNoiseFrag(i + vec3(1,0,0)), f.x),
                   mix(effectNoiseFrag(i + vec3(0,1,0)), effectNoiseFrag(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(effectNoiseFrag(i + vec3(0,0,1)), effectNoiseFrag(i + vec3(1,0,1)), f.x),
                   mix(effectNoiseFrag(i + vec3(0,1,1)), effectNoiseFrag(i + vec3(1,1,1)), f.x), f.y), f.z);
}
vec3 effectRainbow(float h) {
    vec3 p = abs(fract(vec3(0.0, 0.33, 0.67) + h) * 6.0 - 3.0);
    return clamp(p - 1.0, 0.0, 1.0);
}
float effectFbmFrag(vec3 p) {
    float total = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 5; i++) {
        total += effectNoiseSurface(p) * amp;
        p = p * 2.03 + vec3(1.7, 9.2, 3.4);
        amp *= 0.5;
    }
    return total;
}
float effectFresnelFrag(vec3 n, vec3 v, float power, float bias) {
    return pow(clamp(1.0 - abs(dot(n, v)) + bias, 0.0, 1.0), max(0.05, power));
}
`;
export const EFFECT_EMISSIVE_CHUNK = /* glsl */ `
#ifndef MESH_COLOR
    uniform vec3 material_emissive;
#endif
uniform float material_emissiveIntensity;
${FRAG_UNIFORMS}
${EMISSIVE_FUNCTIONS}

void effectCustomSurface(inout vec3 emission, vec3 worldPos, vec3 normal, vec3 viewDir) {
}

void getEmission() {
    #ifdef MESH_COLOR
        dEmission = mesh_color.rgb * material_emissiveIntensity;
    #else
        dEmission = material_emissive * material_emissiveIntensity;
    #endif
    #ifdef STD_EMISSIVE_TEXTURE
    dEmission *= {STD_EMISSIVE_TEXTURE_DECODE}(texture2DBias({STD_EMISSIVE_TEXTURE_NAME}, {STD_EMISSIVE_TEXTURE_UV}, {STD_TEXTURE_BIAS})).{STD_EMISSIVE_TEXTURE_CHANNEL};
    #endif
    #ifdef STD_EMISSIVE_VERTEX
        dEmission *= saturate(vVertexColor.{STD_EMISSIVE_VERTEX_CHANNEL});
    #endif

    if (uFresnelIntensity > 0.0001) {
        vec3 n = normalize(vNormalW);
        vec3 v = normalize(view_position - vPositionW);
        float fres = pow(clamp(1.0 - abs(dot(n, v)) + uFresnelBias, 0.0, 1.0), max(0.05, uFresnelPower));
        vec3 fresnelColor = uFresnelMode < 0.5
            ? effectRainbow(n.y * 0.5 + v.y * 0.5 + uEffectTime * 0.03) * uFresnelIridescence + uFresnelColor * (1.0 - uFresnelIridescence)
            : uFresnelColor;
        dEmission += fresnelColor * fres * uFresnelIntensity * uFresnelBlend;
    }

    if (uDissolveAmount > 0.0001) {
        float n = effectNoiseSurface(vPositionW * max(0.01, uDissolveNoiseScale) + uDissolveSeed);
        float threshold = 1.0 - clamp(uDissolveAmount, 0.0, 1.0);
        float edge = smoothstep(threshold, threshold + max(0.001, uDissolveEdgeWidth), n);
        float rim = 1.0 - edge;
        dEmission += uDissolveEdgeColor * rim * uDissolveEdgeGlow * step(threshold, n) * step(n, threshold + uDissolveEdgeWidth * 2.0);
    }

    vec3 surfaceNormal = normalize(vNormalW);
    vec3 surfaceView = normalize(view_position - vPositionW);
    float surfaceFresnel = effectFresnelFrag(surfaceNormal, surfaceView, 2.0, 0.0);
    float flow = uEffectTime;

    if (uLiquidAmount > 0.0001) {
        vec3 p = vPositionW * max(0.01, uLiquidScale) + vec3(flow * uLiquidFlow);
        float n = effectFbmFrag(p + effectNoiseSurface(p * 0.7) * uLiquidDistortion);
        float spec = pow(clamp(n + surfaceFresnel * uLiquidFresnel, 0.0, 2.0), 3.0);
        dEmission += (uLiquidTint * spec + uLiquidAccent * surfaceFresnel * 0.6) * uLiquidAmount * uLiquidEmission;
    }

    if (uMagmaAmount > 0.0001) {
        vec3 p = vPositionW * max(0.01, uMagmaScale) + vec3(flow * uMagmaFlow);
        float n = effectFbmFrag(p + effectNoiseSurface(p * 0.6) * uMagmaDistortion);
        float crack = smoothstep(0.42 - uMagmaCrackWidth, 0.42 + uMagmaCrackWidth, n);
        vec3 lava = mix(uMagmaLava, uMagmaHot, clamp(crack * uMagmaTemperature, 0.0, 1.0));
        dEmission += lava * crack * uMagmaEmission * uMagmaAmount;
    }

    if (uPlasmaAmount > 0.0001) {
        vec3 p = vPositionW * max(0.01, uPlasmaScale) + vec3(flow * uPlasmaSpeed);
        float plasma = sin(p.x * 1.7 + flow) * sin(p.y * 1.3 - flow * 1.4) * sin(p.z * 2.1 + flow * 0.7);
        float turbulence = effectFbmFrag(p * 1.7 + plasma * uPlasmaTurbulence);
        float bands = 0.5 + 0.5 * sin((plasma + turbulence) * 6.2831853);
        vec3 color = mix(mix(uPlasmaA, uPlasmaB, turbulence), uPlasmaC, bands);
        dEmission += color * (0.35 + bands * 0.65) * uPlasmaEmission * uPlasmaAmount;
        if (uPlasmaEdge > 0.0001) dEmission += uPlasmaB * surfaceFresnel * uPlasmaEdge * uPlasmaAmount;
    }

    if (uReactionEnabled > 0.5 && uReactionOpacity > 0.0001) { dAlpha *= mix(1.0, clamp(reactionFieldValue(vReactionUv), 0.0, 1.0), uReactionOpacity); }
    if (uHoloAmount > 0.0001) {
        float scan = 0.5 + 0.5 * sin(vPositionW.y * uHoloScanDensity + flow * uHoloScanSpeed * 6.2831853);
        float flicker = 1.0 - uHoloFlicker * (0.5 + 0.5 * sin(flow * 8.0 + vPositionW.y * 3.0));
        float glitch = step(0.86, fract(sin(floor(flow * 9.0) * 91.7 + vPositionW.y * 3.1) * 43758.5453)) * uHoloGlitch;
        float breakup = 1.0 - uHoloBreakup * step(0.8, fract(vPositionW.y * 7.0 + flow * 3.0));
        vec3 holo = mix(uHoloA, uHoloB, clamp(vPositionW.y * 0.5 + surfaceFresnel, 0.0, 1.0));
        dEmission += holo * (0.4 + scan * 0.6) * flicker * breakup * (1.0 - glitch * 0.65) * uHoloEmission * uHoloAmount;
    }

    if (uIridAmount > 0.0001) {
        float thickness = uIridThickness / max(1.0, uIridIOR * uIridIOR);
        float hue = fract(thickness * 0.0008 + surfaceFresnel * 0.55 + uIridHue + uEffectTime * 0.02 * uIridScale);
        vec3 film = effectRainbow(hue) * uIridTint;
        dEmission += film * (0.4 + surfaceFresnel * uIridFresnel) * uIridAmount;
    }

    if (uTriAmount > 0.0001) {
        vec3 blend = pow(abs(surfaceNormal), vec3(4.0));
        blend /= max(0.001, blend.x + blend.y + blend.z);
        float nx = effectNoiseSurface(vec3(vPositionW.yz * uTriScale, flow * uTriSpeed));
        float ny = effectNoiseSurface(vec3(vPositionW.xz * uTriScale, flow * uTriSpeed));
        float nz = effectNoiseSurface(vec3(vPositionW.xy * uTriScale, flow * uTriSpeed));
        float tri = nx * blend.x + ny * blend.y + nz * blend.z;
        vec3 triColor = mix(uTriA, uTriB, clamp(tri + uTriBlend * 0.5, 0.0, 1.0));
        dEmission += triColor * tri * uTriEmission * uTriAmount;
    }

    if (uVoronoiAmount > 0.0001) {
        vec3 p = vPositionW * max(0.01, uVoronoiScale);
        vec3 cell = floor(p);
        vec3 local = fract(p);
        float minimum = 8.0;
        for (int z = -1; z <= 1; z++) for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
            vec3 neighbor = vec3(float(x), float(y), float(z));
            vec3 point = neighbor + vec3(effectNoiseSurface(cell + neighbor), effectNoiseSurface(cell + neighbor + 3.1), effectNoiseSurface(cell + neighbor + 7.7));
            minimum = min(minimum, length(point - local));
        }
        float border = 1.0 - smoothstep(0.0, max(0.001, uVoronoiBorder), minimum);
        dEmission += mix(uVoronoiA, uVoronoiB, border) * border * uVoronoiEmission * uVoronoiAmount;
    }

    if (uGradientAmount > 0.0001) {
        float angle = uGradientAngle * 0.0174532925;
        float coordinate = (vPositionW.x * cos(angle) + vPositionW.z * sin(angle)) * uGradientScale + flow * uGradientSpeed;
        float t = fract(coordinate * 0.1);
        vec3 gradient = t < 0.5 ? mix(uGradientA, uGradientB, t * 2.0) : mix(uGradientB, uGradientC, (t - 0.5) * 2.0);
        dEmission += gradient * uGradientEmission * uGradientAmount;
    }

    if (uGlitchSurfaceAmount > 0.0001) {
        float block = floor(vPositionW.y * uGlitchSurfaceBlocks + floor(flow * 7.0));
        float random = fract(sin(block * 12.9898 + floor(flow * 9.0)) * 43758.5453);
        float glitchActive = step(1.0 - uGlitchSurfaceAmount, random);
        dEmission += uGlitchSurfaceColor * glitchActive * uGlitchSurfaceShift * uGlitchSurfaceEmission;
    }

    if (uXrayAmount > 0.0001) dEmission += uXrayColor * pow(surfaceFresnel, max(0.1, uXrayPower)) * uXrayAmount;
    if (uGhostAmount > 0.0001) dEmission += uGhostColor * pow(surfaceFresnel, max(0.1, uGhostPower)) * uGhostAmount;
    if (uGlassAmount > 0.0001) dEmission += uGlassColor * (0.08 + surfaceFresnel * 0.35) * uGlassAmount;

    if (uNeonAmount > 0.0001) {
        float edge = smoothstep(1.0 - uNeonWidth, 1.0, pow(surfaceFresnel, max(0.1, uNeonPower)));
        dEmission += uNeonColor * edge * uNeonAmount;
    }

    if (uScanSurfAmount > 0.0001) {
        float scan = 0.5 + 0.5 * sin(vPositionW.y * uScanDensity + flow * uScanSpeed * 6.2831853);
        dEmission += uScanSurfColor * (0.25 + scan * 0.75) * uScanSurfAmount;
    }

    if (uChromaticAmount > 0.0001) {
        float phase = dot(surfaceNormal, surfaceView) * uChromaticScale + flow * uChromaticSpeed;
        float split = 0.5 + 0.5 * sin(phase * 6.2831853);
        dEmission += mix(uChromaticA, uChromaticB, split) * uChromaticAmount;
    }

    if (uNoiseSurfAmount > 0.0001) {
        float n = effectFbmFrag(vPositionW * max(0.01, uNoiseSurfScale) + vec3(flow * uNoiseSurfSpeed));
        dEmission += mix(uNoiseSurfA, uNoiseSurfB, n) * n * uNoiseSurfAmount;
    }

    if (uDigitalSurfAmount > 0.0001) {
        vec3 cell = floor(vPositionW * max(1.0, uDigitalBlocks));
        float blockNoise = fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719)) + floor(flow * uDigitalSpeed)) * 43758.5453);
        dEmission += uDigitalColor * step(0.55, blockNoise) * uDigitalSurfAmount;
    }

    if (uCheckerAmount > 0.0001) {
        vec3 checkerPos = floor(vPositionW * max(0.01, uCheckerScale));
        float checker = mod(checkerPos.x + checkerPos.y + checkerPos.z, 2.0);
        dEmission += mix(uCheckerA, uCheckerB, checker) * uCheckerAmount;
    }

    if (uWavesSurfAmount > 0.0001) {
        float wave = 0.5 + 0.5 * sin((vPositionW.x + vPositionW.y * 0.7 + vPositionW.z * 0.4) * uWavesScale - flow * uWavesSpeed * 6.2831853);
        dEmission += uWavesColor * wave * uWavesSurfAmount;
    }

    if (uRingsSurfAmount > 0.0001) {
        float radial = length(vPositionW.xz) * uRingsFreq - flow * uRingsSpeed;
        dEmission += uRingsColor * (0.5 + 0.5 * sin(radial * 6.2831853)) * uRingsSurfAmount;
    }
    if (uWireAmount > 0.0001) dEmission += uWireColor * uWireAmount;
    effectCustomSurface(dEmission, vPositionW, surfaceNormal, surfaceView);
    if (uReactionEnabled > 0.5 && uReactionEmission > 0.0001) {
        float reactionValue = reactionFieldValue(vReactionUv);
        vec3 reactionTint = mix(uReactionColor, uReactionColorB, clamp(reactionValue, 0.0, 1.0));
        dEmission += reactionTint * reactionValue * uReactionEmission;
        if (uReactionBaseColor > 0.0001) dAlbedo = mix(dAlbedo, reactionTint, clamp(uReactionBaseColor, 0.0, 1.0) * clamp(reactionValue, 0.0, 1.0));
    }
}
`;

export const EFFECT_OPACITY_CHUNK = /* glsl */ `
#ifndef MESH_COLOR
    uniform float material_opacity;
#endif
uniform float material_alphaDitherScale;
${FRAG_UNIFORMS}
float effectOpacityHash(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3)) * 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float effectOpacityNoise(vec3 x) {
    vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(effectOpacityHash(i), effectOpacityHash(i + vec3(1,0,0)), f.x),
                   mix(effectOpacityHash(i + vec3(0,1,0)), effectOpacityHash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(effectOpacityHash(i + vec3(0,0,1)), effectOpacityHash(i + vec3(1,0,1)), f.x),
                   mix(effectOpacityHash(i + vec3(0,1,1)), effectOpacityHash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

void getOpacity() {
    #ifdef MESH_COLOR
        dAlpha = mesh_color.a;
    #else
        dAlpha = material_opacity;
    #endif
    #ifdef STD_OPACITY_TEXTURE
        dAlpha *= texture2DBias({STD_OPACITY_TEXTURE_NAME}, {STD_OPACITY_TEXTURE_UV}, {STD_TEXTURE_BIAS}).{STD_OPACITY_TEXTURE_CHANNEL};
    #endif
    #ifdef STD_OPACITY_VERTEX
        dAlpha *= clamp(vVertexColor.{STD_OPACITY_VERTEX_CHANNEL}, 0.0, 1.0);
    #endif
    if (uDissolveAmount > 0.0001) {
        float n = effectOpacityNoise(vPositionW * max(0.01, uDissolveNoiseScale) + uDissolveSeed);
        float threshold = 1.0 - clamp(uDissolveAmount, 0.0, 1.0);
        dAlpha *= 1.0 - smoothstep(threshold, threshold + max(0.001, uDissolveEdgeWidth), n);
    }
    if (uReactionEnabled > 0.5 && uReactionOpacity > 0.0001) { dAlpha *= mix(1.0, clamp(reactionFieldValue(vReactionUv), 0.0, 1.0), uReactionOpacity); }
    if (uHoloAmount > 0.0001) {
        float scan = 0.5 + 0.5 * sin(vPositionW.y * uHoloScanDensity + uEffectTime * uHoloScanSpeed * 6.2831853);
        float breakup = step(uHoloBreakup * 0.9, fract(vPositionW.y * 5.0 + uEffectTime * 2.0));
        dAlpha *= uHoloOpacity * (0.35 + scan * 0.65) * mix(1.0, breakup, 0.35);
    }
}
`;

export const EFFECT_GLOSS_CHUNK = /* glsl */ `
uniform sampler2D uReaction;
uniform float uReactionEnabled;
uniform float uReactionRoughness;
#ifndef RE_REACTION_UV
#define RE_REACTION_UV
varying vec2 vReactionUv;
#endif

#ifdef STD_GLOSS_CONSTANT
uniform float material_gloss;
#endif
void getGlossiness() {
    dGlossiness = 1.0;
    #ifdef STD_GLOSS_CONSTANT
    dGlossiness *= material_gloss;
    #endif
    #ifdef STD_GLOSS_TEXTURE
    dGlossiness *= texture2DBias({STD_GLOSS_TEXTURE_NAME}, {STD_GLOSS_TEXTURE_UV}, {STD_TEXTURE_BIAS}).{STD_GLOSS_TEXTURE_CHANNEL};
    #endif
    #ifdef STD_GLOSS_VERTEX
    dGlossiness *= saturate(vVertexColor.{STD_GLOSS_VERTEX_CHANNEL});
    #endif
    #ifdef STD_GLOSS_INVERT
    dGlossiness = 1.0 - dGlossiness;
    #endif
    if (uReactionEnabled > 0.5 && uReactionRoughness > 0.0001) {
        float rd = texture2D(uReaction, vReactionUv).r;
        dGlossiness *= mix(1.0, 1.0 - clamp(rd, 0.0, 1.0), clamp(uReactionRoughness, 0.0, 1.0));
    }
    dGlossiness += 0.0000001;
}`;

export const EFFECT_METALNESS_CHUNK = /* glsl */ `
uniform sampler2D uReaction;
uniform float uReactionEnabled;
uniform float uReactionMetallic;
#ifndef RE_REACTION_UV
#define RE_REACTION_UV
varying vec2 vReactionUv;
#endif

#ifdef STD_METALNESS_CONSTANT
uniform float material_metalness;
#endif
void getMetalness() {
    float metalness = 1.0;
    #ifdef STD_METALNESS_CONSTANT
    metalness *= material_metalness;
    #endif
    #ifdef STD_METALNESS_TEXTURE
    metalness *= texture2DBias({STD_METALNESS_TEXTURE_NAME}, {STD_METALNESS_TEXTURE_UV}, {STD_TEXTURE_BIAS}).{STD_METALNESS_TEXTURE_CHANNEL};
    #endif
    #ifdef STD_METALNESS_VERTEX
    metalness *= saturate(vVertexColor.{STD_METALNESS_VERTEX_CHANNEL});
    #endif
    if (uReactionEnabled > 0.5 && uReactionMetallic > 0.0001) {
        float rd = texture2D(uReaction, vReactionUv).r;
        metalness = mix(metalness, clamp(rd, 0.0, 1.0), clamp(uReactionMetallic, 0.0, 1.0));
    }
    dMetalness = metalness;
}`;
