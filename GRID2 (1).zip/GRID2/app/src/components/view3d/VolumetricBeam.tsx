import { useMemo, useRef } from 'react';
import { AdditiveBlending, Color, DoubleSide, Quaternion, ShaderMaterial, Vector3 } from 'three';
import { useFrame } from '@react-three/fiber';

interface VolumetricBeamProps {
  from: [number, number, number];
  to: [number, number, number];
  color: string;
  intensity: number;
  haze: number;
  fieldAngle: number;
  beamAngle: number;
  alpha: number;
  coreAlpha: number;
  softness?: number;
  axialPower?: number;
  strobe?: number;
  visible: boolean;
  core?: boolean;
}

const vertexShader = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vViewDir;
  void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vViewDir = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv;
  }
`;

const fragmentShader = /* glsl */ `
  uniform vec3 uColor;
  uniform float uIntensity;
  uniform float uAlpha;
  uniform float uSoftness;
  uniform float uAxial;
  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vViewDir;
  void main() {
    float axial = pow(clamp(vUv.y, 0.0, 1.0), uAxial);
    float facing = abs(dot(normalize(vNormal), normalize(vViewDir)));
    float soft = smoothstep(0.015, uSoftness, facing);
    float alpha = uAlpha * axial * soft * uIntensity;
    if (alpha < 0.002) discard;
    gl_FragColor = vec4(uColor, alpha);
  }
`;

function useBeamMaterial(alpha: number, softness: number, axial: number) {
  return useMemo(() => new ShaderMaterial({
    uniforms: {
      uColor: { value: new Color('#ffffff') },
      uIntensity: { value: 1 },
      uAlpha: { value: alpha },
      uSoftness: { value: softness },
      uAxial: { value: axial },
    },
    vertexShader,
    fragmentShader,
    transparent: true,
    depthWrite: false,
    side: DoubleSide,
    blending: AdditiveBlending,
    toneMapped: false,
  }), [alpha, softness, axial]);
}

function Cone({ from, to, angle, material, renderOrder }: { from: [number, number, number]; to: [number, number, number]; angle: number; material: ShaderMaterial; renderOrder: number }) {
  const geometry = useMemo(() => {
    const start = new Vector3(...from);
    const end = new Vector3(...to);
    const direction = new Vector3().subVectors(end, start);
    const length = direction.length();
    if (length < 0.04) return null;
    const radius = Math.tan((Math.max(1.5, Math.min(95, angle)) * Math.PI) / 360) * length;
    const mid = new Vector3().addVectors(start, end).multiplyScalar(0.5);
    const quaternion = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), direction.clone().normalize().negate());
    return { length, radius: Math.max(0.015, radius), mid, quaternion };
  }, [from[0], from[1], from[2], to[0], to[1], to[2], angle]);
  if (!geometry) return null;
  return (
    <mesh position={geometry.mid} quaternion={geometry.quaternion} renderOrder={renderOrder}>
      <cylinderGeometry args={[0.0015, geometry.radius, geometry.length, 28, 1, true]} />
      <primitive object={material} attach="material" />
    </mesh>
  );
}

export function VolumetricBeam({
  from, to, color, intensity, haze, fieldAngle, beamAngle, alpha, coreAlpha,
  softness = 0.72, axialPower = 2.0, strobe = 0, visible, core = true,
}: VolumetricBeamProps) {
  const outer = useBeamMaterial(alpha, softness, axialPower);
  const inner = useBeamMaterial(coreAlpha, Math.max(0.08, softness * 0.62), axialPower + 0.5);
  const hazeFactor = 0.62 + Math.max(0, Math.min(1, haze)) * 0.85;

  useFrame(() => {
    const active = strobe > 0 ? (performance.now() / 1000 * strobe) % 1 < 0.55 : true;
    const level = Math.min(2, Math.max(0, intensity)) * (active ? 1 : 0.02);
    for (const material of [outer, inner]) {
      material.uniforms.uColor.value.set(color);
      material.uniforms.uIntensity.value = level * hazeFactor;
    }
  });

  if (!visible) return null;

  return (
    <group>
      <Cone from={from} to={to} angle={fieldAngle} material={outer} renderOrder={6} />
      {core && Math.abs(beamAngle - fieldAngle) > 0.1 && (
        <Cone from={from} to={to} angle={beamAngle} material={inner} renderOrder={7} />
      )}
    </group>
  );
}
