import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { wrapEffect } from '@react-three/postprocessing';
import { Matrix4, Vector2 } from 'three';
import type { Project } from '../../types/project';
import { collectVolumetrics } from '../../lib/volumetrics';
import { getQualityProfile } from '../../lib/renderQuality';
import { VolumetricScatteringEffect } from './VolumetricScatteringEffect';

const VolumetricPrimitive = wrapEffect(VolumetricScatteringEffect);

export function VolumetricScattering({ project, beamVisible }: { project: Project; beamVisible: boolean }) {
  const { camera, gl } = useThree();
  const effect = useRef<VolumetricScatteringEffect>(null);
  const invProjection = useMemo(() => new Matrix4(), []);
  const cameraWorld = useMemo(() => new Matrix4(), []);
  const size = useMemo(() => new Vector2(), []);
  const volumes = useMemo(() => collectVolumetrics(project), [project]);
  const profile = getQualityProfile(project.lighting.quality);
  const enabled = beamVisible && project.lighting.volumetric && project.lighting.haze > 0.002 && profile.raymarch;

  useEffect(() => {
    effect.current?.setVolumes(volumes);
  }, [volumes]);

  useEffect(() => {
    if (!effect.current) return;
    effect.current.setAtmosphere(
      project.lighting.haze * 0.72,
      project.lighting.anisotropy,
      52.0,
      profile.volumetricSamples,
    );
  }, [project.lighting.haze, project.lighting.anisotropy, profile.volumetricSamples]);

  useFrame(({ clock }) => {
    const current = effect.current;
    if (!current || !enabled) return;
    camera.updateMatrixWorld();
    invProjection.copy(camera.projectionMatrixInverse);
    cameraWorld.copy(camera.matrixWorld);
    gl.getDrawingBufferSize(size);
    current.setCamera(invProjection, cameraWorld, size.x, size.y, clock.elapsedTime);
  });

  if (!enabled) return null;
  return <VolumetricPrimitive ref={effect} />;
}
