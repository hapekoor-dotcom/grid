import { useState } from 'react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { defaultModulator } from '../../lib/signals';
import { Button } from '../ui/Button';
import { Dialog } from '../ui/Dialog';
import { ShaderLabDialog } from '../inspector/ShaderLabDialog';

export function PostFxDialog({ onClose }: { onClose: () => void }) {
  const project = useWorkspaceStore((state) => state.projects.find((entry) => entry.id === state.activeId) || null);
  const movePostShader = useWorkspaceStore((state) => state.movePostShader);
  const reorderPostShader = useWorkspaceStore((state) => state.reorderPostShader);
  const removePostShader = useWorkspaceStore((state) => state.removePostShader);
  const duplicatePostShader = useWorkspaceStore((state) => state.duplicatePostShader);
  const togglePostShader = useWorkspaceStore((state) => state.togglePostShader);
  const updatePostShaderValues = useWorkspaceStore((state) => state.updatePostShaderValues);
  const setPostShaderModulator = useWorkspaceStore((state) => state.setPostShaderModulator);
  const resetPostHistory = useWorkspaceStore((state) => state.resetPostHistory);
  const [lab, setLab] = useState<{ add: boolean; passId?: string; shaderId?: string } | null>(null);
  const [dragged, setDragged] = useState<string | null>(null);
  if (!project) return null;
  const passes = project.postShaders || [];
  const temporal = (pass: any) => {
    const shader = project.customShaders?.find((entry) => entry.id === pass.shaderId);
    return !!shader && /uPrevious/.test(shader.lastWorking?.fragment || shader.fragment);
  };
  return (
    <>
      <Dialog title="Scene Post FX" description="Ordered fullscreen shader stack. Passes run top to bottom on the renderer-owned HDR scene color." onClose={onClose} wide footer={<Button size="sm" onClick={onClose}>Done</Button>}>
        <div className="post-fx">
          <div className="post-fx-toolbar">
            <div><strong>POST STACK</strong><span>{passes.length} pass{passes.length === 1 ? '' : 'es'}</span></div>
            <div className="row"><Button size="sm" variant="ghost" onClick={() => resetPostHistory()}>Reset All History</Button><Button size="sm" onClick={() => setLab({ add: true })}>+ Add Post Shader</Button></div>
          </div>
          {!passes.length && <div className="post-fx-empty"><p>No post passes. Add Feedback, RGB Split, Kaleidoscope or a custom fullscreen shader.</p><div className="row"><Button size="sm" variant="ghost" onClick={() => resetPostHistory()}>Reset All History</Button><Button size="sm" onClick={() => setLab({ add: true })}>+ Add Post Shader</Button></div></div>}
          <div className="post-fx-list">
            {passes.map((pass, index) => {
              const passId = pass.id || pass.shaderId;
              const shader = project.customShaders?.find((entry) => entry.id === pass.shaderId);
              if (!shader) return null;
              return (
                <div
                  key={passId}
                  className={`post-fx-row${pass.enabled ? '' : ' is-bypassed'}${dragged === passId ? ' is-dragging' : ''}`}
                  draggable
                  onDragStart={() => setDragged(passId)}
                  onDragEnd={() => setDragged(null)}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={() => { if (dragged && dragged !== passId) reorderPostShader(dragged, passId); setDragged(null); }}
                >
                  <div className="post-fx-row-head">
                    <span className="post-fx-index">{index + 1}</span>
                    <span className="post-fx-grip" title="Drag to reorder">⋮⋮</span>
                    <strong>{shader.name}</strong>
                    <span className="post-fx-kind">{pass.enabled ? 'enabled' : 'bypassed'}</span>
                    <span className="post-fx-actions">
                      <button type="button" className="post-fx-btn" onClick={() => togglePostShader(passId, !pass.enabled)}>{pass.enabled ? 'Bypass' : 'Enable'}</button>
                      <button type="button" className="post-fx-btn" onClick={() => setLab({ add: false, passId, shaderId: pass.shaderId })}>Edit</button>{temporal(pass) && <button type="button" className="post-fx-btn" onClick={() => resetPostHistory(passId)}>Reset History</button>}
                      <button type="button" className="post-fx-btn" onClick={() => duplicatePostShader(passId)}>Duplicate</button>
                      <button type="button" className="post-fx-btn" onClick={() => movePostShader(passId, -1)} aria-label="Move up">↑</button>
                      <button type="button" className="post-fx-btn" onClick={() => movePostShader(passId, 1)} aria-label="Move down">↓</button>
                      <button type="button" className="post-fx-btn is-danger" onClick={() => removePostShader(passId)}>Delete</button>
                    </span>
                  </div>
                  <div className="post-fx-params">
                    {shader.params.filter((param) => param.type === 'float' || param.type === 'int').map((param) => <div className="post-fx-param" key={param.id}>
                      <label><span>{param.label}</span><input type="range" min={param.recommendedMin ?? 0} max={Math.max((param.recommendedMax ?? 2) * 5, 1)} step={0.01} value={Number(pass.values[param.id] ?? param.default ?? 0)} onChange={(event) => updatePostShaderValues(passId, { [param.id]: Number(event.target.value) })} /><span className="num">{Number(pass.values[param.id] ?? param.default ?? 0).toFixed(2)}</span></label>
                      <select className="select shader-mod-source" value={pass.modulators?.[param.id]?.sourceId || ''} aria-label={`${shader.name} ${param.label} modulation source`} onChange={(event) => setPostShaderModulator(passId, param.id, event.target.value ? { ...defaultModulator(event.target.value), amount: 1 } : null)}><option value="">~ No modulator</option>{(project.signals || []).map((signal) => <option key={signal.id} value={signal.id}>~ {signal.name} · {signal.kind}</option>)}</select>
                      {pass.modulators?.[param.id] && <input className="input" type="number" step={0.01} aria-label={`${shader.name} ${param.label} modulation amount`} value={pass.modulators[param.id].amount} onChange={(event) => setPostShaderModulator(passId, param.id, { ...pass.modulators![param.id], amount: Number(event.target.value) })} />}
                    </div>)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Dialog>
      {lab && <ShaderLabDialog initialContext="post" initialShaderId={lab.shaderId} replacePostShaderId={lab.passId} onClose={() => setLab(null)} />}
    </>
  );
}
