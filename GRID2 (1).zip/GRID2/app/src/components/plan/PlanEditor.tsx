import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Cable, Crosshair, Maximize2, Grid2X2, Layers, Lock, Minus, MousePointer2, Check,
  Plus, Redo2, RotateCw, Square, Trash2, Undo2, Unlock, Eye, EyeOff, Columns3, Armchair, Box, CircleDot,
  RectangleHorizontal, Layers3, Copy, Scissors, ClipboardPaste, Settings2, MousePointerClick, Users, Search, Lightbulb,
} from 'lucide-react';
import type { CableType, CatalogDevice } from '../../types/catalog';
import type { Connection, Point, Project, SceneObject } from '../../types/project';
import { CABLE_META, getDevice } from '../../lib/catalog';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore, type PlanTool } from '../../store/uiStore';
import { useAnalysis } from '../../lib/analysis';
import { objectDims, objectRect, placePorts, getObjectPorts, isStructure } from '../../lib/objects';
import { routeAll } from '../../lib/routing';
import { clamp, formatMeters, uid } from '../../lib/id';
import { snapPoint } from '../../lib/geometry';
import { cx } from '../../lib/cx';
import { IconButton } from '../ui/Button';
import { ContextMenu, type MenuItem } from '../ui/ContextMenu';
import { PlanObjectShape } from './PlanGlyphs';
import { DeviceIcon } from '../catalog/CatalogPanel';


const FIXTURE_TYPE_LABELS: Record<string, string> = {
  head: 'WASH', beam: 'BEAM', spot: 'SPOT', par: 'PAR', bar: 'LED BAR', pixel: 'PIXEL',
  strobe: 'STROBE', blinder: 'BLINDER', laser: 'LASER', effectlight: 'EFFECT', flood: 'FLOOD',
  panel: 'PANEL', decor: 'DECOR', mirrorball: 'MIRROR', speaker: 'SPEAKER', soundbooth: 'SOUND',
  distro: 'DISTRO', dimmer: 'DIMMER', node: 'NODE', splitter: 'SPLIT', switch: 'SWITCH',
  console: 'CONSOLE', controller: 'CONTROL', mixer: 'MIXER', laptop: 'LAPTOP', computer: 'PC',
  player: 'PLAYER', outlet: 'OUTLET', battery: 'BATTERY', generator: 'GENERATOR', ledwall: 'LED',
  tv: 'DISPLAY', projector: 'PROJECTOR', processor: 'PROCESSOR', camera: 'CAMERA', interface: 'IFACE',
  receiver: 'RECEIVER', transmitter: 'TX', power: 'POWER', fan: 'FAN', table: 'TABLE', chair: 'CHAIR',
  barricade: 'BARRIER', truss: 'TRUSS', stage: 'STAGE', riser: 'RISER', curtain: 'CURTAIN',
};

const RULER = 20;
const MIN_ZOOM = 8;
const MAX_ZOOM = 300;

interface ViewState {
  x: number;
  z: number;
  zoom: number;
}

type Gesture =
  | { kind: 'pan'; startClientX: number; startClientY: number; startView: ViewState }
  | { kind: 'marquee'; startWorld: Point; additive: boolean; startClientX: number; startClientY: number }
  | { kind: 'move'; startWorld: Point; ids: string[]; initial: { id: string; x: number; z: number }[]; moved: boolean }
  | { kind: 'draw'; tool: 'room' | 'wall' | 'stage' | 'zone' | 'truss' | 'seating' | 'crowd'; startWorld: Point }
  | { kind: 'resize'; id: string; corner: 'nw' | 'ne' | 'sw' | 'se'; initial: { x: number; z: number; w: number; d: number }; startWorld: Point };

interface MarqueeRect {
  x: number;
  z: number;
  w: number;
  d: number;
}

interface GuideDrag {
  axis: 'x' | 'z';
  position: number;
  existingId?: string;
}

interface SnapLines {
  x: number[];
  z: number[];
}

const TOOLS: { id: PlanTool; label: string; shortcut: string; icon: typeof MousePointer2 }[] = [
  { id: 'select', label: 'Select and move', shortcut: 'V', icon: MousePointer2 },
  { id: 'room', label: 'Room', shortcut: 'B', icon: Square },
  { id: 'wall', label: 'Wall', shortcut: 'W', icon: Minus },
  { id: 'stage', label: 'Stage', shortcut: 'T', icon: RectangleHorizontal },
  { id: 'zone', label: 'Zone', shortcut: 'Z', icon: Layers3 },
  { id: 'truss', label: 'Truss', shortcut: 'G', icon: Columns3 },
  { id: 'seating', label: 'Seating', shortcut: 'S', icon: Armchair },
];

interface ScreenPoint { x: number; y: number }

function screenPoint(view: ViewState, size: { w: number; h: number }, point: Point): ScreenPoint {
  return {
    x: size.w / 2 + (point.x - view.x) * view.zoom,
    y: size.h / 2 + (point.z - view.z) * view.zoom,
  };
}

function worldPoint(view: ViewState, size: { w: number; h: number }, point: ScreenPoint): Point {
  return {
    x: view.x + (point.x - size.w / 2) / view.zoom,
    z: view.z + (point.y - size.h / 2) / view.zoom,
  };
}

function normalizeRect(a: Point, b: Point): MarqueeRect {
  return { x: Math.min(a.x, b.x), z: Math.min(a.z, b.z), w: Math.abs(a.x - b.x), d: Math.abs(a.z - b.z) };
}

function intersects(a: MarqueeRect, b: { x: number; z: number; w: number; d: number }): boolean {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.z < b.z + b.d && a.z + a.d > b.z;
}

function unionRects(objects: SceneObject[]): MarqueeRect | null {
  if (!objects.length) return null;
  const rects = objects.map(objectRect);
  const x = Math.min(...rects.map((rect) => rect.x));
  const z = Math.min(...rects.map((rect) => rect.z));
  const maxX = Math.max(...rects.map((rect) => rect.x + rect.w));
  const maxZ = Math.max(...rects.map((rect) => rect.z + rect.d));
  return { x, z, w: maxX - x, d: maxZ - z };
}

function objectDimensionLabel(object: SceneObject): string {
  const dims = objectDims(object);
  return `${dims.w.toFixed(2)} × ${dims.d.toFixed(2)} m`;
}

function toolHint(tool: PlanTool, cableActive: boolean): string {
  if (cableActive) return 'Choose an output, then an input. Esc to cancel';
  switch (tool) {
    case 'room': return 'Drag the room. Dimensions are in the inspector';
    case 'wall': return 'Drag a horizontal or vertical wall';
    case 'stage': return 'Drag the stage. Height is in the inspector';
    case 'zone': return 'Drag a zone: dance floor, FOH or another area';
    case 'truss': return 'Drag a horizontal or vertical truss';
    case 'seating': return 'Drag seating: rows and seats are generated automatically';
    case 'crowd': return 'Drag a Crowd zone';
    case 'cable': return 'Choose a port: output first, then input';
    default: return '';
  }
}

export function PlanEditor() {
  const project = useActiveProject();
  const tool = useUiStore((state) => state.tool);
  const cableFilter = useUiStore((state) => state.cableFilter);
  const hiddenLayers = useUiStore((state) => state.hiddenLayers);
  const toggleLayer = useUiStore((state) => state.toggleLayer);
  const setCableFilter = useUiStore((state) => state.setCableFilter);
  const setTool = useUiStore((state) => state.setTool);
  const selectedIds = useUiStore((state) => state.selectedIds);
  const selectedConnectionId = useUiStore((state) => state.selectedConnectionId);
  const select = useUiStore((state) => state.select);
  const selectMany = useUiStore((state) => state.selectMany);
  const selectConnection = useUiStore((state) => state.selectConnection);
  const clearSelection = useUiStore((state) => state.clearSelection);
  const hoveredObjectId = useUiStore((state) => state.hoveredObjectId);
  const setHoveredObject = useUiStore((state) => state.setHoveredObject);
  const cableStart = useUiStore((state) => state.cableStart);
  const setCableStart = useUiStore((state) => state.setCableStart);
  const openCommand = useUiStore((state) => state.openCommand);
  const setPendingAdd = useUiStore((state) => state.setPendingAdd);
  const cancelCable = useUiStore((state) => state.cancelCable);
  const pushToast = useUiStore((state) => state.pushToast);
  const fitRequest = useUiStore((state) => state.fitRequest);
  const zoomInRequest = useUiStore((state) => state.zoomInRequest);
  const zoomOutRequest = useUiStore((state) => state.zoomOutRequest);
  const setCursor = useUiStore((state) => state.setCursor);
  const setPlanCamera = useUiStore((state) => state.setPlanCamera);
  const setDiagnosticsOpen = useUiStore((state) => state.setDiagnosticsOpen);
  const setDragging = useUiStore((state) => state.setDragging);
  const askConfirm = useUiStore((state) => state.askConfirm);
  const analysis = useAnalysis();

  const addConnection = useWorkspaceStore((state) => state.addConnection);
  const deleteConnection = useWorkspaceStore((state) => state.deleteConnection);
  const deleteSelection = useWorkspaceStore((state) => state.deleteSelection);
  const duplicateSelection = useWorkspaceStore((state) => state.duplicateSelection);
  const copySelection = useWorkspaceStore((state) => state.copySelection);
  const pasteClipboard = useWorkspaceStore((state) => state.pasteClipboard);
  const rotateSelection = useWorkspaceStore((state) => state.rotateSelection);
  const lockSelection = useWorkspaceStore((state) => state.lockSelection);
  const hideSelection = useWorkspaceStore((state) => state.hideSelection);
  const groupSelection = useWorkspaceStore((state) => state.groupSelection);
  const ungroupSelection = useWorkspaceStore((state) => state.ungroupSelection);
  const addRoom = useWorkspaceStore((state) => state.addRoom);
  const addStage = useWorkspaceStore((state) => state.addStage);
  const addTruss = useWorkspaceStore((state) => state.addTruss);
  const addSeating = useWorkspaceStore((state) => state.addSeating);
  const addCrowd = useWorkspaceStore((state) => state.addCrowd);
  const addAreaBar = useWorkspaceStore((state) => state.addAreaBar);
  const addLight = useWorkspaceStore((state) => state.addLight);
  const addWall = useWorkspaceStore((state) => state.addWall);
  const updateConnection = useWorkspaceStore((state) => state.updateConnection);
  const addDevice = useWorkspaceStore((state) => state.addDevice);
  const updateObject = useWorkspaceStore((state) => state.updateObject);
  const mutateTransient = useWorkspaceStore((state) => state.mutateTransient);
  const beginTransaction = useWorkspaceStore((state) => state.beginTransaction);
  const endTransaction = useWorkspaceStore((state) => state.endTransaction);
  const updateView = useWorkspaceStore((state) => state.updateView);
  const updateSettings = useWorkspaceStore((state) => state.updateSettings);
  const addGuide = useWorkspaceStore((state) => state.addGuide);
  const deleteGuide = useWorkspaceStore((state) => state.deleteGuide);
  const clearGuides = useWorkspaceStore((state) => state.clearGuides);
  const clipboard = useWorkspaceStore((state) => state.clipboard);
  const updateGuide = useWorkspaceStore((state) => state.updateGuide);

  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [view, setView] = useState<ViewState>({ x: 0, z: 0, zoom: 60 });
  const viewRef = useRef(view);
  viewRef.current = view;
  const [gesture, setGesture] = useState<Gesture | null>(null);
  const [marquee, setMarquee] = useState<MarqueeRect | null>(null);
  const [draft, setDraft] = useState<{ rect: MarqueeRect; tool: 'room' | 'wall' | 'stage' | 'zone' | 'truss' | 'seating' | 'crowd' } | null>(null);
  const [snapLines, setSnapLines] = useState<SnapLines>({ x: [], z: [] });
  const snapLockRef = useRef<{ x: number | null; z: number | null }>({ x: null, z: null });
  const [spaceDown, setSpaceDown] = useState(false);
  const leftDownRef = useRef(false);
  const suppressContextMenuRef = useRef(false);
  const rightPanRef = useRef<{ startClientX: number; startClientY: number; startView: ViewState; moved: boolean } | null>(null);
  const rightContextRef = useRef<{ target: Element } | null>(null);
  const [guideDrag, setGuideDrag] = useState<GuideDrag | null>(null);
  const [menu, setMenu] = useState<{ x: number; y: number; items: MenuItem[] } | null>(null);
  const [layersOpen, setLayersOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [showIntro, setShowIntro] = useState(() => { try { return localStorage.getItem('regrid.plan-intro') !== '1'; } catch { return true; } });
  const dismissIntro = () => { setShowIntro(false); try { localStorage.setItem('regrid.plan-intro', '1'); } catch { /* ignore storage */ } };
  const [showPorts] = useState(false);
  const [waypointDrag, setWaypointDrag] = useState<{ connectionId: string; index: number; initial: Point[] } | null>(null);
  const [hoveredPort, setHoveredPort] = useState<{ objectId: string; portId: string } | null>(null);
  const [cursorWorld, setCursorWorld] = useState<Point | null>(null);
  const initialFit = useRef(false);
  const projectIdRef = useRef(project?.id);

  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const moving = !!gesture && (gesture.kind === 'move' || gesture.kind === 'resize');
  const routes = useMemo<Map<string, Point[]>>(() => (project ? routeAll(project, moving) : new Map<string, Point[]>()), [project, moving]);
  const dmxMap = useMemo(() => new Map(analysis.dmx.rows.map((row) => [row.objectId, row])), [analysis.dmx]);
  const objectIssues = useMemo(() => {
    const map = new Map<string, { errors: number; warnings: number }>();
    for (const diagnostic of analysis.diagnostics) {
      if (diagnostic.severity === 'info' || ['dmx', 'power', 'connection'].includes(diagnostic.area)) continue;
      for (const id of diagnostic.objectIds) {
        const entry = map.get(id) || { errors: 0, warnings: 0 };
        if (diagnostic.severity === 'error') entry.errors += 1;
        else entry.warnings += 1;
        map.set(id, entry);
      }
    }
    return map;
  }, [analysis.diagnostics]);
  const connectionIssues = useMemo(() => {
    const map = new Map<string, { errors: number; warnings: number }>();
    for (const diagnostic of analysis.diagnostics) {
      if (diagnostic.severity === 'info' || !diagnostic.connectionId) continue;
      const entry = map.get(diagnostic.connectionId) || { errors: 0, warnings: 0 };
      if (diagnostic.severity === 'error') entry.errors += 1;
      else entry.warnings += 1;
      map.set(diagnostic.connectionId, entry);
    }
    return map;
  }, [analysis.diagnostics]);

  /* --------------------------------------------------------------- sizing */
  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setSize({ w: rect.width, h: rect.height });
    });
    observer.observe(element);
    setSize({ w: element.clientWidth, h: element.clientHeight });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const resetGesture = () => {
      rightPanRef.current = null;
      rightContextRef.current = null;
      leftDownRef.current = false;
      setGesture(null);
      setMarquee(null);
      setDraft(null);
      setDragging(false);
      endTransaction();
    };
    const onVisibility = () => { if (document.visibilityState === 'hidden') resetGesture(); };
    window.addEventListener('blur', resetGesture);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('blur', resetGesture);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [endTransaction, setDragging]);

  /* ---------------------------------------------------------------- view fit */
  const fitView = useCallback(() => {
    if (!project || !size.w || !size.h) return;
    const visibleObjects = project.objects.filter((object) => object.visible);
    if (!visibleObjects.length) {
      setView({ x: 0, z: 0, zoom: 60 });
      return;
    }
    const bounds = unionRects(visibleObjects)!;
    const availableW = Math.max(120, size.w - 150);
    const availableH = Math.max(100, size.h - 150);
    const zoom = clamp(Math.min(availableW / bounds.w, availableH / bounds.d), MIN_ZOOM, 180);
    setView({ x: bounds.x + bounds.w / 2, z: bounds.z + bounds.d / 2, zoom });
  }, [project, size]);

  useEffect(() => {
    if (!project) return;
    if (projectIdRef.current !== project.id) {
      projectIdRef.current = project.id;
      const saved = project.view.plan;
      if (saved.zoom > 0) setView({ x: saved.panX, z: saved.panY, zoom: saved.zoom });
      else initialFit.current = false;
    }
  }, [project]);

  useEffect(() => {
    if (!initialFit.current && size.w && size.h && project) {
      initialFit.current = true;
      const saved = project.view.plan;
      if (saved.zoom > 0) setView({ x: saved.panX, z: saved.panY, zoom: saved.zoom });
      else requestAnimationFrame(fitView);
    }
  }, [size, project, fitView]);

  useEffect(() => {
    if (!fitRequest || !initialFit.current) return;
    fitView();
  }, [fitRequest, fitView]);

  useEffect(() => {
    if (!zoomInRequest) return;
    setView((current) => ({ ...current, zoom: clamp(current.zoom * 1.25, MIN_ZOOM, MAX_ZOOM) }));
  }, [zoomInRequest]);

  useEffect(() => {
    if (!zoomOutRequest) return;
    setView((current) => ({ ...current, zoom: clamp(current.zoom / 1.25, MIN_ZOOM, MAX_ZOOM) }));
  }, [zoomOutRequest]);

  /* -------------------------------------------------------------- persistence */
  useEffect(() => {
    if (!project || !size.w) return;
    const timeout = window.setTimeout(() => {
      if (useWorkspaceStore.getState().activeId !== project.id) return;
      const saved = project.view.plan;
      if (Math.abs(saved.zoom - view.zoom) < 0.01 && Math.abs(saved.panX - view.x) < 0.001 && Math.abs(saved.panY - view.z) < 0.001) return;
      updateView({ panX: view.x, panY: view.z, zoom: view.zoom });
    }, 500);
    return () => window.clearTimeout(timeout);
  }, [view.x, view.z, view.zoom, project, size.w, updateView]);

  useEffect(() => {
    setPlanCamera(size.w ? { x: view.x, z: view.z, zoom: view.zoom, width: size.w, height: size.h } : null);
  }, [view, size, setPlanCamera]);

  /* ------------------------------------------------------------------ wheel */
  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const rect = element.getBoundingClientRect();
      const current = viewRef.current;
      const pointer = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      const before = worldPoint(current, { w: rect.width, h: rect.height }, { x: pointer.x, y: pointer.y });
      const factor = Math.exp(-event.deltaY * 0.0014);
      const zoom = clamp(current.zoom * factor, MIN_ZOOM, MAX_ZOOM);
      const x = before.x - (pointer.x - rect.width / 2) / zoom;
      const z = before.z - (pointer.y - rect.height / 2) / zoom;
      setView({ x, z, zoom });
      setCursor(before);
    };
    element.addEventListener('wheel', onWheel, { passive: false });
    return () => element.removeEventListener('wheel', onWheel);
  }, [setCursor]);

  /* ------------------------------------------------------------------ space */
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'Space' && !event.repeat) {
        const target = event.target as HTMLElement;
        if (/^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName) || target.isContentEditable) return;
        event.preventDefault();
        setSpaceDown(true);
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.code === 'Space') setSpaceDown(false);
    };
    const onBlur = () => setSpaceDown(false);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  if (!project) return null;

  const selectedObjects = project.objects.filter((object) => selectedSet.has(object.id));
  const hiddenObjectCount = project.objects.filter((object) => !object.visible).length;
  const selectionRect = unionRects(selectedObjects);
  const cursorScreen = cursorWorld ? screenPoint(view, size, cursorWorld) : null;
  const activeTool = TOOLS.find((entry) => entry.id === tool);

  const toWorld = (clientX: number, clientY: number): Point => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, z: 0 };
    return worldPoint(viewRef.current, { w: rect.width, h: rect.height }, { x: clientX - rect.left, y: clientY - rect.top });
  };

  const toScreen = (point: Point): ScreenPoint => screenPoint(view, size, point);

  const selectGroupFor = (object: SceneObject, additive: boolean) => {
    const members = object.groupId ? project.objects.filter((entry) => entry.groupId === object.groupId).map((entry) => entry.id) : [object.id];
    if (additive) {
      const current = new Set(selectedIds);
      const allSelected = members.every((id) => current.has(id));
      if (allSelected) members.forEach((id) => current.delete(id));
      else members.forEach((id) => current.add(id));
      selectMany([...current]);
    } else {
      selectMany(members);
    }
  };

  const showAllObjects = () => {
    beginTransaction();
    mutateTransient((draftProject) => {
      for (const object of draftProject.objects) object.visible = true;
    });
    endTransaction();
    setLayersOpen(false);
    pushToast('Hidden objects restored', 'success');
  };

  const snapMove = (ids: string[], initial: { id: string; x: number; z: number }[], rawDx: number, rawDz: number) => {
    const grid = project.settings.gridSize;
    if (!project.settings.snap) {
      snapLockRef.current = { x: null, z: null };
      setSnapLines({ x: [], z: [] });
      return { dx: rawDx, dz: rawDz };
    }
    let dx = rawDx;
    let dz = rawDz;
    const idSet = new Set(ids);
    const threshold = 8 / view.zoom;
    const release = threshold * 3.6;
    const rawRects = initial.map((entry) => {
      const object = project.objects.find((candidate) => candidate.id === entry.id);
      if (!object) return null;
      const rect = objectRect(object);
      // Use the gesture's starting centre. The project object already holds
      // the previous snapped position; adding rawDx to that created a feedback
      // loop and made the guides fight the pointer.
      return { x: entry.x - rect.w / 2 + rawDx, z: entry.z - rect.d / 2 + rawDz, w: rect.w, d: rect.d };
    }).filter(Boolean) as MarqueeRect[];
    const staticObjects = project.objects.filter((object) => object.visible && !idSet.has(object.id));
    const staticRects = staticObjects.map((object) => objectRect(object));
    const xTargets = [
      ...staticRects.flatMap((rect) => [rect.x, rect.x + rect.w / 2, rect.x + rect.w]),
      ...project.guides.filter((guide) => guide.axis === 'x').map((guide) => guide.position),
    ];
    const zTargets = [
      ...staticRects.flatMap((rect) => [rect.z, rect.z + rect.d / 2, rect.z + rect.d]),
      ...project.guides.filter((guide) => guide.axis === 'z').map((guide) => guide.position),
    ];
    const closestDelta = (rects: MarqueeRect[], axis: 'x' | 'z', target: number, limit: number) => {
      let best: number | null = null;
      for (const rect of rects) {
        const start = axis === 'x' ? rect.x : rect.z;
        const size = axis === 'x' ? rect.w : rect.d;
        for (const edge of [start, start + size / 2, start + size]) {
          const delta = target - edge;
          if (Math.abs(delta) <= limit && (best === null || Math.abs(delta) < Math.abs(best))) best = delta;
        }
      }
      return best;
    };
    const locked = snapLockRef.current;
    let bestX: { delta: number; target: number } | null = null;
    let bestZ: { delta: number; target: number } | null = null;
    // Keep the active guide until the pointer moves beyond a wider release
    // radius. Without hysteresis the object flickers between snap and free
    // movement exactly at the 8px threshold.
    if (locked.x !== null) {
      const delta = closestDelta(rawRects, 'x', locked.x, release);
      if (delta !== null) bestX = { delta, target: locked.x };
      else locked.x = null;
    }
    if (locked.z !== null) {
      const delta = closestDelta(rawRects, 'z', locked.z, release);
      if (delta !== null) bestZ = { delta, target: locked.z };
      else locked.z = null;
    }
    if (!bestX) {
      for (const rect of rawRects) {
        for (const target of xTargets) {
          for (const edge of [rect.x, rect.x + rect.w / 2, rect.x + rect.w]) {
            const delta = target - edge;
            if (Math.abs(delta) <= threshold && (!bestX || Math.abs(delta) < Math.abs(bestX.delta))) bestX = { delta, target };
          }
        }
      }
      locked.x = bestX ? bestX.target : null;
    }
    if (!bestZ) {
      for (const rect of rawRects) {
        for (const target of zTargets) {
          for (const edge of [rect.z, rect.z + rect.d / 2, rect.z + rect.d]) {
            const delta = target - edge;
            if (Math.abs(delta) <= threshold && (!bestZ || Math.abs(delta) < Math.abs(bestZ.delta))) bestZ = { delta, target };
          }
        }
      }
      locked.z = bestZ ? bestZ.target : null;
    }
    const snapX = new Set<number>();
    const snapZ = new Set<number>();
    if (bestX) {
      dx = rawDx + bestX.delta;
      snapX.add(Math.round(bestX.target * 1000) / 1000);
    }
    if (bestZ) {
      dz = rawDz + bestZ.delta;
      snapZ.add(Math.round(bestZ.target * 1000) / 1000);
    }
    // Objects live on whole cells. Quantize the selection's top-left edge after
    // smart-guide snapping so a guide can never leave an object between grid lines.
    const primaryObject = initial[0] ? project.objects.find((object) => object.id === initial[0].id) : null;
    if (primaryObject) {
      const rect = objectRect(primaryObject);
      const edgeX = initial[0].x - rect.w / 2 + dx;
      const edgeZ = initial[0].z - rect.d / 2 + dz;
      const snappedX = Math.round(edgeX / grid) * grid;
      const snappedZ = Math.round(edgeZ / grid) * grid;
      dx += snappedX - edgeX;
      dz += snappedZ - edgeZ;
      if (snapX.size) { snapX.clear(); snapX.add(Math.round(snappedX * 1000) / 1000); }
      if (snapZ.size) { snapZ.clear(); snapZ.add(Math.round(snappedZ * 1000) / 1000); }
    }
    setSnapLines({ x: [...snapX], z: [...snapZ] });
    return { dx, dz };
  };

  const beginMove = (event: React.PointerEvent, object: SceneObject) => {
    snapLockRef.current = { x: null, z: null };
    if (object.locked) {
      selectGroupFor(object, event.shiftKey || event.metaKey || event.ctrlKey);
      return;
    }
    const additive = event.shiftKey || event.metaKey || event.ctrlKey;
    if (additive) {
      selectGroupFor(object, true);
      return;
    }
    if (!selectedSet.has(object.id)) selectGroupFor(object, false);
    const currentSelection = new Set(useUiStore.getState().selectedIds);
    if (!currentSelection.has(object.id)) currentSelection.add(object.id);
    const ids = [...currentSelection].filter((id) => {
      const candidate = project.objects.find((entry) => entry.id === id);
      return candidate && !candidate.locked;
    });
    if (!ids.length) return;
    const initial = ids.map((id) => {
      const candidate = project.objects.find((entry) => entry.id === id)!;
      return { id, x: candidate.position.x, z: candidate.position.z };
    });
    beginTransaction();
    setGesture({ kind: 'move', startWorld: toWorld(event.clientX, event.clientY), ids, initial, moved: false });
  };

  const beginResize = (event: React.PointerEvent, object: SceneObject, corner: 'nw' | 'ne' | 'sw' | 'se') => {
    if (object.locked) return;
    const rect = objectRect(object);
    beginTransaction();
    setGesture({
      kind: 'resize',
      id: object.id,
      corner,
      initial: { x: rect.x, z: rect.z, w: rect.w, d: rect.d },
      startWorld: toWorld(event.clientX, event.clientY),
    });
  };

  const handlePointerDown = (event: React.PointerEvent<SVGSVGElement>) => {
    const bothButtons = (event.buttons & 3) === 3;
    if (event.button === 2) {
      // Right click opens a menu; right drag pans. The 5px threshold prevents
      // a context menu after a small hand movement.
      if (!leftDownRef.current && !bothButtons) {
        suppressContextMenuRef.current = false;
        rightPanRef.current = { startClientX: event.clientX, startClientY: event.clientY, startView: { ...view }, moved: false };
        rightContextRef.current = { target: event.target as Element };
        setMenu(null);
        (event.currentTarget as SVGSVGElement).setPointerCapture(event.pointerId);
        return;
      }
      suppressContextMenuRef.current = true;
      setGesture({ kind: 'pan', startClientX: event.clientX, startClientY: event.clientY, startView: { ...view } });
      setMarquee(null);
      setDraft(null);
      setDragging(false);
      (event.currentTarget as SVGSVGElement).setPointerCapture(event.pointerId);
      event.preventDefault();
      return;
    }
    if (menu) setMenu(null);
    const world = toWorld(event.clientX, event.clientY);
    (event.currentTarget as SVGSVGElement).setPointerCapture(event.pointerId);
    if (event.button === 1 || spaceDown || bothButtons) {
      setGesture({ kind: 'pan', startClientX: event.clientX, startClientY: event.clientY, startView: { ...view } });
      return;
    }
    if (event.button === 0) leftDownRef.current = true;
    if (event.button !== 0) return;
    if (tool === 'select') {
      if (cableStart) {
        cancelCable();
        return;
      }
      const additive = event.shiftKey || event.metaKey || event.ctrlKey;
      setGesture({ kind: 'marquee', startWorld: world, additive, startClientX: event.clientX, startClientY: event.clientY });
      setMarquee({ x: world.x, z: world.z, w: 0, d: 0 });
      return;
    }
    if (tool === 'cable') {
      cancelCable();
      selectConnection(null);
      return;
    }
    setGesture({ kind: 'draw', tool, startWorld: world });
    setDraft({ rect: { x: world.x, z: world.z, w: 0, d: 0 }, tool });
  };

  const handlePointerMove = (event: React.PointerEvent<SVGSVGElement>) => {
    // Some browsers swallow the second pointerdown while the first button is
    // held. Detect the LMB+RMB combination from the buttons bitmask instead.
    if ((event.buttons & 3) === 3 && gesture?.kind === 'marquee') {
      setGesture({ kind: 'pan', startClientX: event.clientX, startClientY: event.clientY, startView: { ...view } });
      setMarquee(null);
      suppressContextMenuRef.current = true;
      return;
    }
    const rightPan = rightPanRef.current;
    if (rightPan && (event.buttons & 2)) {
      const dx = event.clientX - rightPan.startClientX;
      const dy = event.clientY - rightPan.startClientY;
      if (!rightPan.moved && Math.hypot(dx, dy) > 5) {
        rightPan.moved = true;
        suppressContextMenuRef.current = true;
      }
      if (rightPan.moved) {
        setView({ ...rightPan.startView, x: rightPan.startView.x - dx / view.zoom, z: rightPan.startView.z - dy / view.zoom });
      }
      return;
    }
    const world = toWorld(event.clientX, event.clientY);
    setCursorWorld(world);
    setCursor(world);
    if (waypointDrag) {
      const snapped = project.settings.snap ? snapPoint(world, project.settings.gridSize) : world;
      mutateTransient((draftProject) => {
        const connection = draftProject.connections.find((entry) => entry.id === waypointDrag.connectionId);
        if (connection) connection.waypoints[waypointDrag.index] = { x: Math.round(snapped.x * 1000) / 1000, z: Math.round(snapped.z * 1000) / 1000 };
      });
      return;
    }
    if (!gesture) return;
    if (gesture.kind === 'pan') {
      const dx = (event.clientX - gesture.startClientX) / view.zoom;
      const dz = (event.clientY - gesture.startClientY) / view.zoom;
      setView({ ...gesture.startView, x: gesture.startView.x - dx, z: gesture.startView.z - dz });
      return;
    }
    if (gesture.kind === 'marquee') {
      setMarquee(normalizeRect(gesture.startWorld, world));
      return;
    }
    if (gesture.kind === 'draw') {
      setDraft({ rect: normalizeRect(gesture.startWorld, world), tool: gesture.tool });
      return;
    }
    if (gesture.kind === 'move') {
      const rawDx = world.x - gesture.startWorld.x;
      const rawDz = world.z - gesture.startWorld.z;
      const { dx, dz } = snapMove(gesture.ids, gesture.initial, rawDx, rawDz);
      if (!gesture.moved && Math.abs(dx) < 0.001 && Math.abs(dz) < 0.001) return;
      setGesture({ ...gesture, moved: true });
      setDragging(true);
      mutateTransient((draftProject) => {
        for (const entry of gesture.initial) {
          const object = draftProject.objects.find((candidate) => candidate.id === entry.id);
          if (object) {
            object.position.x = Math.round((entry.x + dx) * 1000) / 1000;
            object.position.z = Math.round((entry.z + dz) * 1000) / 1000;
          }
        }
      });
      return;
    }
    if (gesture.kind === 'resize') {
      const object = project.objects.find((entry) => entry.id === gesture.id);
      if (!object) return;
      const grid = project.settings.gridSize;
      let left = gesture.initial.x;
      let top = gesture.initial.z;
      let right = gesture.initial.x + gesture.initial.w;
      let bottom = gesture.initial.z + gesture.initial.d;
      if (gesture.corner.includes('w')) left = Math.min(right - 0.2, world.x);
      if (gesture.corner.includes('e')) right = Math.max(left + 0.2, world.x);
      if (gesture.corner.includes('n')) top = Math.min(bottom - 0.2, world.z);
      if (gesture.corner.includes('s')) bottom = Math.max(top + 0.2, world.z);
      if (project.settings.snap) {
        left = Math.round(left / grid) * grid;
        top = Math.round(top / grid) * grid;
        right = Math.round(right / grid) * grid;
        bottom = Math.round(bottom / grid) * grid;
      }
      const width = Math.max(0.2, right - left);
      const depth = Math.max(0.2, bottom - top);
      mutateTransient((draftProject) => {
        const target = draftProject.objects.find((entry) => entry.id === gesture.id);
        if (!target) return;
        target.size = { w: Math.round(width * 1000) / 1000, d: Math.round(depth * 1000) / 1000, h: target.size?.h ?? 1 };
        target.position = { x: Math.round((left + width / 2) * 1000) / 1000, z: Math.round((top + depth / 2) * 1000) / 1000 };
        if (target.room) target.room.wallHeight = target.size.h;
        if (target.type === 'stage') target.elevation = target.size.h;
      });
    }
  };

  const handlePointerUp = (event: React.PointerEvent<SVGSVGElement>) => {
    if (event.button === 0) leftDownRef.current = false;
    if (event.button === 2 && rightPanRef.current) {
      const moved = rightPanRef.current.moved;
      const target = rightContextRef.current?.target;
      rightPanRef.current = null;
      rightContextRef.current = null;
      if (moved) {
        suppressContextMenuRef.current = true;
        return;
      }
      if (target?.isConnected) {
        // Pointer capture retargets the native contextmenu event to the SVG.
        // Re-dispatch it on the element under the original pointer.
        suppressContextMenuRef.current = false;
        target.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, button: 2, clientX: event.clientX, clientY: event.clientY }));
        suppressContextMenuRef.current = true;
      }
      return;
    }

    if (waypointDrag) {
      endTransaction();
      setWaypointDrag(null);
      return;
    }
    if (!gesture) return;
    if (gesture.kind === 'pan') {
      setGesture(null);
      return;
    }
    if (gesture.kind === 'marquee') {
      const rect = marquee;
      if (rect && (rect.w > 0.05 || rect.d > 0.05)) {
        const hits = project.objects.filter((object) => object.visible && intersects(rect, objectRect(object)));
        const ids = hits.map((object) => object.id);
        if (gesture.additive) {
          const current = new Set(selectedIds);
          ids.forEach((id) => current.add(id));
          selectMany([...current]);
        } else {
          selectMany(ids);
        }
      } else {
        clearSelection();
      }
      setGesture(null);
      setMarquee(null);
      return;
    }
    if (gesture.kind === 'draw') {
      const rect = draft?.rect;
      const linear = gesture.tool === 'wall' || gesture.tool === 'truss';
      const validSize = rect ? (linear ? Math.max(rect.w, rect.d) >= 0.4 : rect.w >= 0.4 && rect.d >= 0.4) : false;
      if (rect && validSize) {
        if (gesture.tool === 'room') addRoom(rect);
        else if (gesture.tool === 'wall') addWall(rect);
        else if (gesture.tool === 'stage') addStage(rect, 'Stage');
        else if (gesture.tool === 'zone') addStage(rect, 'Zone');
        else if (gesture.tool === 'seating') addSeating(rect);
        else if (gesture.tool === 'crowd') addCrowd(rect);
        else addTruss(rect);
        setTool('select');
        pushToast(
          gesture.tool === 'room' ? 'Room added' :
          gesture.tool === 'wall' ? 'Wall added' :
          gesture.tool === 'stage' ? 'Stage added' :
          gesture.tool === 'zone' ? 'Zone added' : gesture.tool === 'seating' ? 'Seating added' : gesture.tool === 'crowd' ? 'Crowd added' : 'Truss added',
          'success',
        );
      }
      setGesture(null);
      setDraft(null);
      return;
    }
    if (gesture.kind === 'move' || gesture.kind === 'resize') {
      snapLockRef.current = { x: null, z: null };
      endTransaction();
      setGesture(null);
      setSnapLines({ x: [], z: [] });
      setDragging(false);
    }
  };

  const handleObjectPointerDown = (event: React.PointerEvent, object: SceneObject) => {
    if (event.button === 2) return;
    if (tool !== 'select' && tool !== 'cable') return;
    event.stopPropagation();
    if (event.button === 1) return;
    if (tool === 'cable') return;
    if (selectedSet.has(object.id) && (event.shiftKey || event.metaKey || event.ctrlKey)) {
      selectGroupFor(object, true);
      return;
    }
    beginMove(event, object);
  };

  const handlePortPick = (event: React.SyntheticEvent, object: SceneObject, portId: string) => {
    if ((event.nativeEvent as PointerEvent).button === 2) return;
    event.stopPropagation();
    if (tool !== 'select') return;
    const port = getObjectPorts(object).find((entry) => entry.id === portId);
    if (!port) return;
    if (!cableStart) {
      setCableStart({ objectId: object.id, portId });
      pushToast(`${object.name}: choose an input`, 'default');
      return;
    }
    if (cableStart.objectId === object.id && cableStart.portId === portId) {
      cancelCable();
      return;
    }
    const startObject = project.objects.find((entry) => entry.id === cableStart.objectId);
    const startPort = startObject ? getObjectPorts(startObject).find((entry) => entry.id === cableStart.portId) : null;
    if (startObject && startPort) {
      const success = addConnection(startObject.id, startPort.id, object.id, port.id);
      if (success) {
        pushToast(`${CABLE_META[startPort.type].label}: connected`, 'success');
      } else {
        pushToast('Ports are incompatible, occupied or would create a loop', 'error');
      }
    }
    cancelCable();
    setTool('select');
  };

  const handleContextMenu = (event: React.MouseEvent, object?: SceneObject, connection?: Connection) => {
    event.preventDefault();
    event.stopPropagation();
    // A right-button gesture owns the menu until pointerup decides click vs pan.
    if (rightPanRef.current) return;
    if (suppressContextMenuRef.current) {
      suppressContextMenuRef.current = false;
      return;
    }
    const items: MenuItem[] = [];
    if (connection) {
      selectConnection(connection.id);
      items.push(
        { id: 'inspect-cable', label: 'Cable properties', icon: <Settings2 />, onSelect: () => selectConnection(connection.id) },
        { id: 'delete-cable', label: 'Delete cable', icon: <Trash2 />, danger: true, onSelect: () => deleteConnection(connection.id) },
      );
    } else if (object) {
      if (!selectedSet.has(object.id)) selectGroupFor(object, false);
      items.push(
        { id: 'inspect', label: 'Properties', icon: <Settings2 />, onSelect: () => { if (!selectedSet.has(object.id) || selectedIds.length === 1) select(object.id); } },
        { id: 'duplicate', label: 'Duplicate', icon: <Copy />, shortcut: 'Ctrl D', onSelect: () => duplicateSelection() },
      );
      if (selectedIds.length > 1 || selectedObjects.some((entry) => entry.groupId)) {
        items.push(
          { id: 'group', label: 'Group', icon: <Layers />, disabled: selectedIds.length < 2, onSelect: () => groupSelection() },
          { id: 'ungroup', label: 'Ungroup', icon: <Layers />, disabled: !selectedObjects.some((entry) => entry.groupId), onSelect: () => ungroupSelection() },
        );
      }
      items.push(
        { id: 'sep-1', separator: true },
        { id: 'delete', label: 'Delete', icon: <Trash2 />, shortcut: 'Del', danger: true, onSelect: () => deleteSelection() },
      );
    } else {
      const world = toWorld(event.clientX, event.clientY);
      items.push(
        { id: 'add-here', label: 'Add here…', icon: <Plus />, onSelect: () => { setPendingAdd({ x: world.x, z: world.z }); openCommand(true); } },
      );
      if (clipboard) items.push({ id: 'paste', label: 'Paste', icon: <ClipboardPaste />, shortcut: 'Ctrl V', onSelect: () => pasteClipboard() });
    }
    setMenu({ x: event.clientX, y: event.clientY, items });
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    const deviceId = event.dataTransfer.getData('application/x-regrid-device');
    if (!deviceId) return;
    const world = toWorld(event.clientX, event.clientY);
    addDevice(deviceId, { x: Math.round(world.x * 20) / 20, z: Math.round(world.z * 20) / 20 });
    const device = getDevice(deviceId);
    pushToast(`${device?.shortName || 'Object'} added`, 'success');
    setTool('select');
  };

  const resetGuides = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    clearGuides();
    pushToast('All guides cleared', 'success');
  };

  const beginGuide = (event: React.PointerEvent, axis: 'x' | 'z') => {
    if (event.button !== 0) return;
    event.preventDefault();
    const world = toWorld(event.clientX, event.clientY);
    setGuideDrag({ axis, position: axis === 'x' ? world.x : world.z });
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
  };

  const moveGuide = (event: React.PointerEvent) => {
    if (!guideDrag) return;
    const world = toWorld(event.clientX, event.clientY);
    setGuideDrag({ ...guideDrag, position: guideDrag.axis === 'x' ? world.x : world.z });
  };

  const endGuide = () => {
    if (!guideDrag) return;
    if (guideDrag.existingId) updateGuide(guideDrag.existingId, guideDrag.position);
    else addGuide(guideDrag.axis, Math.round(guideDrag.position * 100) / 100);
    setGuideDrag(null);
  };

  /* --------------------------------------------------------------- rendering */
  const gridStep = project.settings.gridSize * view.zoom;
  const majorStep = Math.max(project.settings.gridSize * 4, 1) * view.zoom;
  const gridOffsetX = ((size.w / 2 - view.x * view.zoom) % gridStep + gridStep) % gridStep;
  const gridOffsetY = ((size.h / 2 - view.z * view.zoom) % gridStep + gridStep) % gridStep;
  const majorOffsetX = ((size.w / 2 - view.x * view.zoom) % majorStep + majorStep) % majorStep;
  const majorOffsetY = ((size.h / 2 - view.z * view.zoom) % majorStep + majorStep) % majorStep;
  const showMinorGrid = project.settings.showGrid && view.zoom * project.settings.gridSize >= 7;

  const tickStep = view.zoom >= 80 ? 1 : view.zoom >= 35 ? 2 : view.zoom >= 18 ? 5 : 10;
  const visibleWorldMin = worldPoint(view, size, { x: RULER, y: RULER });
  const visibleWorldMax = worldPoint(view, size, { x: size.w, y: size.h });
  const topTicks: number[] = [];
  const leftTicks: number[] = [];
  for (let x = Math.floor(visibleWorldMin.x / tickStep) * tickStep; x <= visibleWorldMax.x; x += tickStep) topTicks.push(Math.round(x * 100) / 100);
  for (let z = Math.floor(visibleWorldMin.z / tickStep) * tickStep; z <= visibleWorldMax.z; z += tickStep) leftTicks.push(Math.round(z * 100) / 100);

  const renderableObjects = project.objects.filter((object) => {
    if (!object.visible || hiddenLayers.includes(object.type)) return false;
    if (object.type === 'device' && !object.light) {
      const kind = getDevice(object.deviceId)?.kind || '';
      if (!['bar', 'head', 'speaker', 'soundbooth', 'spot', 'beam'].includes(kind)) return false;
    }
    return true;
  });
  // Stagger dense equipment labels at fit zoom so neighbouring fixtures stay readable.
  const labelObjects = [
    ...renderableObjects.filter((object) => object.type === 'furniture' && (selectedIds.includes(object.id) || hoveredObjectId === object.id)),
  ];
  const cardObjects = [
    ...renderableObjects.filter((object) => object.type === 'device' && getDevice(object.deviceId)),
  ].sort((a, b) => {
    const aActive = selectedSet.has(a.id) || hoveredObjectId === a.id;
    const bActive = selectedSet.has(b.id) || hoveredObjectId === b.id;
    const aBar = ['bar', 'pixel'].includes(getDevice(a.deviceId)?.kind || '');
    const bBar = ['bar', 'pixel'].includes(getDevice(b.deviceId)?.kind || '');
    return Number(bActive) - Number(aActive) || Number(aBar) - Number(bBar) || a.position.x - b.position.x;
  });
  const fixtureNumbers = new Map<string, string>();
  const suffixCounts = new Map<string, number>();
  const deviceObjects = project.objects.filter((object) => object.type === 'device' && object.visible && getDevice(object.deviceId));
  for (const object of deviceObjects) {
    const device = getDevice(object.deviceId)!;
    const suffix = object.name.match(/(\d+)\s*$/)?.[1];
    if (suffix) suffixCounts.set(`${device.kind}:${suffix}`, (suffixCounts.get(`${device.kind}:${suffix}`) || 0) + 1);
  }
  const fixtureCounts = new Map<string, number>();
  for (const object of deviceObjects) {
    const device = getDevice(object.deviceId)!;
    const suffix = object.name.match(/(\d+)\s*$/)?.[1];
    if (suffix && suffixCounts.get(`${device.kind}:${suffix}`) === 1) {
      fixtureNumbers.set(object.id, suffix.padStart(2, '0').slice(-2));
      continue;
    }
    const next = (fixtureCounts.get(device.kind) || 0) + 1;
    fixtureCounts.set(device.kind, next);
    fixtureNumbers.set(object.id, String(next).padStart(2, '0'));
  }
  const placedCards: { x: number; y: number; w: number; h: number }[] = [];
  const guideLines = project.guides;
  const activeCableType: CableType | null = cableStart
    ? (() => {
        const object = project.objects.find((entry) => entry.id === cableStart.objectId);
        return object ? getObjectPorts(object).find((port) => port.id === cableStart.portId)?.type || null : null;
      })()
    : null;

  const renderObject = (object: SceneObject) => {

            const dims = objectDims(object);
            const footprint = object.rotation % 180 === 0 ? { w: dims.w, d: dims.d } : { w: dims.d, d: dims.w };
            const center = toScreen(object.position);
            const device = getDevice(object.deviceId);
            const isSelected = selectedSet.has(object.id);
            const isHovered = hoveredObjectId === object.id;
            const canResize = object.type !== 'device' && object.rotation % 180 === 0 && isSelected && !object.locked;
            return (
              <g
                key={object.id}
                className={cx('plan-object', isSelected && 'is-selected', isHovered && 'is-hovered', object.locked && 'is-locked')}
                data-object-id={object.id}
                transform={`translate(${center.x} ${center.y}) scale(${view.zoom}) rotate(${object.rotation})`}
                onPointerDown={(event) => handleObjectPointerDown(event, object)}
                onPointerEnter={() => setHoveredObject(object.id)}
                onPointerLeave={() => setHoveredObject(null)}
                onContextMenu={(event) => handleContextMenu(event, object)}
                tabIndex={0}
                role="group"
                aria-label={object.name}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') selectGroupFor(object, event.shiftKey);
                }}
              >
                <PlanObjectShape object={object} device={device} dims={dims} />
                {object.type === 'device' && (
                  <rect
                    data-testid="object-hit"
                    x={-Math.max(dims.w, 24 / view.zoom) / 2}
                    y={-Math.max(dims.d, 24 / view.zoom) / 2}
                    width={Math.max(dims.w, 24 / view.zoom)}
                    height={Math.max(dims.d, 24 / view.zoom)}
                    fill="transparent"
                    stroke="none"
                    pointerEvents="all"
                  />
                )}
                {(isSelected || isHovered) && (
                  <rect
                    x={-dims.w / 2 - 0.05}
                    y={-dims.d / 2 - 0.05}
                    width={dims.w + 0.1}
                    height={dims.d + 0.1}
                    fill="none"
                    stroke={isSelected ? 'var(--accent)' : 'rgba(207,203,195,0.35)'}
                    strokeWidth={isSelected ? 1.5 : 1}
                    strokeDasharray={isSelected ? undefined : '3 3'}
                    vectorEffect="non-scaling-stroke"
                    pointerEvents="none"
                  />
                )}
                {(isSelected || isHovered) && objectIssues.get(object.id) && (() => {
                  const issue = objectIssues.get(object.id)!;
                  const color = issue.errors ? 'var(--danger)' : 'var(--warning)';
                  return (
                    <g transform={`translate(${dims.w / 2 + 8 / view.zoom} ${-dims.d / 2 - 8 / view.zoom}) scale(${1 / view.zoom})`} data-ui="issue" style={{ cursor: 'pointer' }} onPointerDown={(event) => { event.stopPropagation(); select(object.id); setDiagnosticsOpen(true); }}>
                      <circle r={6} fill={color} stroke="var(--bg-0)" strokeWidth={1.5} />
                      <text x={0} y={3.2} textAnchor="middle" fontSize={12} fontWeight={700} fill="#0d0e10">!</text>
                      <title>{issue.errors ? `${issue.errors} errors` : `${issue.warnings} warnings`}</title>
                    </g>
                  );
                })()}
                {objectIssues.get(object.id)?.errors ? (
                  <rect x={-dims.w / 2 - 0.06} y={-dims.d / 2 - 0.06} width={dims.w + 0.12} height={dims.d + 0.12} fill="none" stroke="var(--danger)" strokeWidth={1.4} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" pointerEvents="none" />
                ) : null}
                {object.locked && (
                  <g transform={`translate(${dims.w / 2 - 0.1} ${-dims.d / 2 + 0.1}) scale(${0.7 / view.zoom})`} pointerEvents="none">
                    <rect x={-5} y={-5} width={10} height={10} rx={1} fill="var(--bg-0)" stroke="var(--line-3)" />
                    <path d="M-2 -1v-2a2 2 0 0 1 4 0v2M-3 -1h6v4h-6z" fill="none" stroke="var(--text-3)" strokeWidth={1} />
                  </g>
                )}
                {canResize && (['nw', 'ne', 'sw', 'se'] as const).map((corner) => {
                  const screenX = (corner.includes('e') ? footprint.w / 2 : -footprint.w / 2) * view.zoom;
                  const screenY = (corner.includes('s') ? footprint.d / 2 : -footprint.d / 2) * view.zoom;
                  return (
                    <g key={corner} transform={`translate(${screenX / view.zoom} ${screenY / view.zoom}) scale(${1 / view.zoom})`} data-ui="handle">
                      <rect
                        x={-5}
                        y={-5}
                        width={10}
                        height={10}
                        fill="var(--bg-0)"
                        stroke="var(--accent)"
                        strokeWidth={1}
                        style={{ cursor: `${corner}-resize` }}
                        onPointerDown={(event) => { event.stopPropagation(); beginResize(event, object, corner); }}
                      />
                    </g>
                  );
                })}
              </g>
            );
  };

  return (
    <div
      ref={containerRef}
      className={cx('plan-canvas', spaceDown && 'is-panning-ready', gesture?.kind === 'pan' && 'is-panning')}
      data-tool={tool}
      onDragOver={(event) => { event.preventDefault(); event.dataTransfer.dropEffect = 'copy'; }}
      onDrop={handleDrop}
    >
      <svg
        ref={svgRef}
        className="plan-svg"
        width={size.w}
        height={size.h}
        viewBox={`0 0 ${size.w} ${size.h}`}
        role="region"
        aria-label="Scene plan"
        data-plan-svg
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onPointerLeave={() => { setCursorWorld(null); setCursor(null); }}
        onContextMenu={(event) => handleContextMenu(event)}
      >
        <defs>
          <pattern id="plan-grid" width={gridStep} height={gridStep} patternUnits="userSpaceOnUse" patternTransform={`translate(${gridOffsetX} ${gridOffsetY})`}>
            <path d={`M ${gridStep} 0 L 0 0 0 ${gridStep}`} fill="none" stroke="rgba(207,203,195,0.05)" strokeWidth="1" />
          </pattern>
          <pattern id="plan-grid-major" width={majorStep} height={majorStep} patternUnits="userSpaceOnUse" patternTransform={`translate(${majorOffsetX} ${majorOffsetY})`}>
            <path d={`M ${majorStep} 0 L 0 0 0 ${majorStep}`} fill="none" stroke="rgba(207,203,195,0.085)" strokeWidth="1" />
          </pattern>
          <filter id="plan-glow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="5" />
          </filter>
        </defs>

        <rect data-ui="background" x="0" y="0" width={size.w} height={size.h} fill="transparent" />
        {showMinorGrid && <rect data-ui="grid" x="0" y="0" width={size.w} height={size.h} fill="url(#plan-grid)" />}
        {project.settings.showGrid && <rect data-ui="grid" x="0" y="0" width={size.w} height={size.h} fill="url(#plan-grid-major)" />}

        {/* world origin */}
        <g data-ui="axes" opacity="0.45">
          <line x1={toScreen({ x: 0, z: visibleWorldMin.z }).x} y1={0} x2={toScreen({ x: 0, z: visibleWorldMax.z }).x} y2={size.h} stroke="rgba(207,203,195,0.13)" strokeDasharray="2 5" />
          <line x1={0} y1={toScreen({ x: visibleWorldMin.x, z: 0 }).y} x2={size.w} y2={toScreen({ x: visibleWorldMax.x, z: 0 }).y} stroke="rgba(207,203,195,0.13)" strokeDasharray="2 5" />
        </g>

        {/* manual guides */}
        <g data-ui="guides">
          {guideLines.map((guide) => {
            const point = guide.axis === 'x' ? { x: guide.position, z: visibleWorldMin.z } : { x: visibleWorldMin.x, z: guide.position };
            const screen = toScreen(point);
            return (
              <g key={guide.id}>
                <line
                  x1={guide.axis === 'x' ? screen.x : 0}
                  y1={guide.axis === 'x' ? 0 : screen.y}
                  x2={guide.axis === 'x' ? screen.x : size.w}
                  y2={guide.axis === 'x' ? size.h : screen.y}
                  stroke="rgba(139,180,255,0.31)"
                  strokeDasharray="4 4"
                  data-ui="guide"
                  style={{ cursor: 'pointer' }}
                  onDoubleClick={() => deleteGuide(guide.id)}
                  onContextMenu={(event) => { event.preventDefault(); event.stopPropagation(); deleteGuide(guide.id); }}
                >
                  <title>Guide. Double-click or right-click to remove</title>
                </line>
                <line
                  x1={guide.axis === 'x' ? screen.x : 0}
                  y1={guide.axis === 'x' ? 0 : screen.y}
                  x2={guide.axis === 'x' ? screen.x : size.w}
                  y2={guide.axis === 'x' ? size.h : screen.y}
                  stroke="transparent"
                  strokeWidth={12}
                  pointerEvents="stroke"
                  style={{ cursor: 'pointer' }}
                  onDoubleClick={() => deleteGuide(guide.id)}
                  onContextMenu={(event) => { event.preventDefault(); event.stopPropagation(); deleteGuide(guide.id); }}
                />
              </g>
            );
          })}
          {guideDrag && (
            <line
              x1={guideDrag.axis === 'x' ? toScreen({ x: guideDrag.position, z: 0 }).x : 0}
              y1={guideDrag.axis === 'x' ? 0 : toScreen({ x: 0, z: guideDrag.position }).y}
              x2={guideDrag.axis === 'x' ? toScreen({ x: guideDrag.position, z: 0 }).x : size.w}
              y2={guideDrag.axis === 'x' ? size.h : toScreen({ x: 0, z: guideDrag.position }).y}
              stroke="rgba(232,180,10,0.6)"
              strokeDasharray="4 4"
              data-ui="guide"
            />
          )}
        </g>

        {/* beams under objects and cables */}
        {project.settings.showBeams && (
          <g data-ui="beams">
            {renderableObjects.filter((object) => object.light && object.light.on && object.light.intensity > 0.02).map((object) => {
              const dims = objectDims(object);
              const center = toScreen(object.position);
              const angle = ((object.light?.pan || 0) * Math.PI) / 180;
              const length = 3.1 * view.zoom;
              const width = Math.min(1.1, Math.tan(((object.light?.zoom || 20) * Math.PI) / 360) * 3.1) * view.zoom;
              const dx = Math.sin(angle);
              const dz = Math.cos(angle);
              const nx = Math.cos(angle);
              const nz = -Math.sin(angle);
              const startOffset = Math.max(dims.w, dims.d) * view.zoom * 0.2;
              const p1 = { x: center.x + dx * startOffset, y: center.y + dz * startOffset };
              const p2 = { x: p1.x + dx * length + nx * width, y: p1.y + dz * length + nz * width };
              const p3 = { x: p1.x + dx * length - nx * width, y: p1.y + dz * length - nz * width };
              return (
                <g key={`beam-${object.id}`}>
                  <polygon
                    points={`${p1.x},${p1.y} ${p2.x},${p2.y} ${p3.x},${p3.y}`}
                    fill={object.light?.color || '#fff'}
                    opacity={Math.min(0.045, (object.light?.intensity || 0) * 0.045)}
                  />
                  <polygon
                    points={`${p1.x},${p1.y} ${p2.x},${p2.y} ${p3.x},${p3.y}`}
                    fill="none"
                    stroke={object.light?.color || '#fff'}
                    strokeWidth={1}
                    opacity={0.16}
                  />
                </g>
              );
            })}
          </g>
        )}

        {/* room, stage, truss and furniture sit below cables; devices sit above */}
        <g data-ui="structure">
          {renderableObjects.filter((object) => object.type !== 'device').map(renderObject)}
        </g>

        {/* cables */}
        <g data-ui="cables" style={{ display: 'none' }}>
          {project.connections.filter((connection) => cableFilter === 'all' || (cableFilter !== 'none' && connection.type === cableFilter)).map((connection) => {
            const points = routes.get(connection.id) || [];
            if (points.length < 2) return null;
            const screen = points.map((point) => toScreen(point));
            let d = `M${screen[0].x},${screen[0].y}`;
            for (let i = 1; i < screen.length; i++) d += ` L${screen[i].x},${screen[i].y}`;
            const color = CABLE_META[connection.type].color;
            const active = selectedConnectionId === connection.id;
            const relatedToSelection = selectedIds.includes(connection.from) || selectedIds.includes(connection.to);
            const faded = (!!selectedConnectionId || selectedIds.length > 0) && !active && !relatedToSelection;
            const from = project.objects.find((object) => object.id === connection.from);
            const to = project.objects.find((object) => object.id === connection.to);
            const mid = screen[Math.floor(screen.length / 2)];
            return (
              <g key={connection.id} className={cx('plan-cable', active && 'is-selected')} opacity={faded ? 0.18 : 1}>
                <path d={d} fill="none" stroke="rgba(0,0,0,0.55)" strokeWidth={active ? 5.5 : 4.5} strokeLinecap="round" strokeLinejoin="round" data-ui="cable-underlay" pointerEvents="none" />
                <path d={d} fill="none" stroke={color} strokeWidth={active ? 2.2 : 1.35} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={connection.type === 'wireless' ? '5 4' : undefined} opacity={active ? 1 : 0.8} data-ui="cable" pointerEvents="none" />
                <path
                  d={d}
                  fill="none"
                  stroke="transparent"
                  strokeWidth={12}
                  pointerEvents="stroke"
                  style={{ cursor: 'pointer' }}
                  data-connection-id={connection.id}
                  onClick={(event) => { event.stopPropagation(); selectConnection(connection.id); }}
                  onDoubleClick={(event) => {
                    event.stopPropagation();
                    const world = project.settings.snap ? snapPoint(toWorld(event.clientX, event.clientY), project.settings.gridSize) : toWorld(event.clientX, event.clientY);
                    updateConnection(connection.id, { waypoints: [...connection.waypoints, { x: Math.round(world.x * 1000) / 1000, z: Math.round(world.z * 1000) / 1000 }] });
                    selectConnection(connection.id);
                  }}
                  onContextMenu={(event) => handleContextMenu(event, undefined, connection)}
                >
                  <title>{`${from?.name || connection.from} → ${to?.name || connection.to} · ${CABLE_META[connection.type].label}`}</title>
                </path>
                {active && connectionIssues.get(connection.id) && (() => {
                  const issue = connectionIssues.get(connection.id)!;
                  return (
                    <g transform={`translate(${mid.x} ${mid.y - 10})`} data-ui="cable-issue" style={{ cursor: 'pointer' }} onPointerDown={(event) => { event.stopPropagation(); selectConnection(connection.id); setDiagnosticsOpen(true); }}>
                      <circle r={5.5} fill={issue.errors ? 'var(--danger)' : 'var(--warning)'} stroke="var(--bg-0)" strokeWidth={1.4} />
                      <text x={0} y={3} textAnchor="middle" fontSize={12} fontWeight={700} fill="#0d0e10">!</text>
                    </g>
                  );
                })()}
                {active && (
                  <g data-ui="cable-actions">
                    {connection.waypoints.map((point, index) => {
                      const screenPoint = toScreen(point);
                      return (
                        <circle
                          key={index}
                          cx={screenPoint.x}
                          cy={screenPoint.y}
                          r={4}
                          fill="var(--bg-0)"
                          stroke={color}
                          strokeWidth={1.5}
                          pointerEvents="all"
                          style={{ cursor: 'move' }}
                          onPointerDown={(event) => {
                            event.stopPropagation();
                            beginTransaction();
                            setWaypointDrag({ connectionId: connection.id, index, initial: connection.waypoints.map((entry) => ({ ...entry })) });
                          }}
                          onDoubleClick={(event) => {
                            event.stopPropagation();
                            updateConnection(connection.id, { waypoints: connection.waypoints.filter((_, waypointIndex) => waypointIndex !== index) });
                          }}
                        >
                          <title>Drag the bend. Double-click to remove</title>
                        </circle>
                      );
                    })}
                    <g transform={`translate(${mid.x + 8} ${mid.y - 18})`}>
                      <rect x={0} y={0} width={Math.max(120, (from?.name.length || 4) * 7 + 34)} height={20} rx={3} fill="rgba(14,17,19,0.94)" stroke="rgba(207,203,195,0.14)" />
                      <text x={6} y={13} fill={color} fontSize={12} fontFamily="IBM Plex Mono, monospace">{CABLE_META[connection.type].short} · {from?.name} → {to?.name}</text>
                    </g>
                  </g>
                )}
              </g>
            );
          })}
          {cableStart && activeCableType && cursorScreen && (() => {
            const startObject = project.objects.find((object) => object.id === cableStart.objectId);
            const startPort = startObject ? placePorts(startObject).find((port) => port.id === cableStart.portId) : null;
            if (!startPort) return null;
            const a = toScreen({ x: startPort.x, z: startPort.z });
            return (
              <path
                d={`M${a.x},${a.y} L${cursorScreen.x},${cursorScreen.y}`}
                stroke={CABLE_META[activeCableType].color}
                strokeWidth={1.5}
                strokeDasharray="4 4"
                fill="none"
                data-ui="cable-preview"
              />
            );
          })()}
        </g>

        {/* devices sit above cables so ports and addresses always read */}
        <g data-ui="objects">
          {renderableObjects.filter((object) => object.type === 'device').map(renderObject)}
        </g>

        {/* object labels are drawn in screen space so they never rotate upside down */}
        <g data-ui="labels">
          {labelObjects.map((object, index) => {
            const device = getDevice(object.deviceId);
            const isActive = selectedSet.has(object.id) || hoveredObjectId === object.id;
            const isVideoObject = device?.category === 'video';
            // Interaction shows the full name; at close zoom a short label is enough.
            const show = project.settings.showLabels && isActive && !isVideoObject;
            if (!show) return null;
            const dims = objectDims(object);
            const fp = object.rotation % 180 === 0 ? { w: dims.w, d: dims.d } : { w: dims.d, d: dims.w };
            const center = toScreen(object.position);
            const isSelected = selectedSet.has(object.id);
            const label = object.name;
            const stagger = 0;
            return (
              <g key={`label-${object.id}`} transform={`translate(${center.x} ${center.y + (fp.d / 2) * view.zoom + 12 + stagger})`} pointerEvents="none" data-ui="label">
                <text textAnchor="middle" fill={isSelected ? 'var(--accent)' : 'var(--text-2)'} fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif" fontWeight={isSelected ? 500 : 400} style={{ paintOrder: 'stroke', stroke: '#0d0e10', strokeWidth: 3 }}>{label}</text>
              </g>
            );
          })}
        </g>

        {/* room and stage labels outside shape */}
        <g data-ui="annotations">
          {renderableObjects.filter((object) => object.type === 'room' && (selectedSet.has(object.id) || hoveredObjectId === object.id)).map((object) => {
            const rect = objectRect(object);
            const bottomLeft = toScreen({ x: rect.x, z: rect.z + rect.d });
            return (
              <g key={`label-${object.id}`} transform={`translate(${bottomLeft.x + 8} ${bottomLeft.y - 12})`} pointerEvents="none">
                <text fill="var(--text-2)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{object.name}</text>
              </g>
            );
          })}
          {renderableObjects.filter((object) => object.type === 'stage' && (selectedSet.has(object.id) || hoveredObjectId === object.id)).map((object) => {
            const device = getDevice(object.deviceId);
            if (device?.kind === 'curtain') return null;
            const rect = objectRect(object);
            const bottomLeft = toScreen({ x: rect.x, z: rect.z + rect.d });
            return (
              <g key={`label-${object.id}`} transform={`translate(${bottomLeft.x + 8} ${bottomLeft.y - 8})`} pointerEvents="none">
                <text fill="var(--text-2)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{object.name}</text>
              </g>
            );
          })}
          {renderableObjects.filter((object) => object.type === 'seating' && (selectedSet.has(object.id) || hoveredObjectId === object.id)).map((object) => {
            const rect = objectRect(object);
            const topLeft = toScreen({ x: rect.x, z: rect.z });
            const count = (object.seating?.rows || 0) * (object.seating?.columns || 0);
            return (
              <g key={`seat-label-${object.id}`} transform={`translate(${topLeft.x + 8} ${topLeft.y + 15})`} pointerEvents="none">
                <text fill="var(--text-2)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{view.zoom < 30 ? object.name.replace('Seating ', '') : object.name}</text>
                {view.zoom >= 30 && <text y={13} fill="var(--text-4)" fontSize={12} fontFamily="IBM Plex Mono, monospace">{count ? `${count} seats · ${object.seating?.columns} × ${object.seating?.rows}` : 'seating'}</text>}
              </g>
            );
          })}
          {renderableObjects.filter((object) => object.type === 'areabar' && (selectedSet.has(object.id) || hoveredObjectId === object.id)).map((object) => {
            const rect = objectRect(object);
            const topLeft = toScreen({ x: rect.x, z: rect.z });
            return (
              <g key={`areabar-label-${object.id}`} transform={`translate(${topLeft.x + 6} ${topLeft.y - 6})`} pointerEvents="none">
                <text fill="var(--text-2)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{object.name}</text>
              </g>
            );
          })}
          {renderableObjects.filter((object) => object.type === 'crowd' && (selectedSet.has(object.id) || hoveredObjectId === object.id)).map((object) => {
            const rect = objectRect(object);
            const topLeft = toScreen({ x: rect.x, z: rect.z });
            return (
              <g key={`crowd-label-${object.id}`} transform={`translate(${topLeft.x + 8} ${topLeft.y + 15})`} pointerEvents="none">
                <text fill="var(--text-2)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{object.name}</text>
              </g>
            );
          })}
          {renderableObjects.filter((object) => object.type === 'truss').map((object) => {
            const isSelected = selectedSet.has(object.id);
            if (!isSelected && hoveredObjectId !== object.id) return null;
            const rect = objectRect(object);
            const topLeft = toScreen({ x: rect.x, z: rect.z });
            return (
              <g key={`label-${object.id}`} transform={`translate(${topLeft.x + 2} ${topLeft.y - 6})`} pointerEvents="none">
                <text fill="var(--accent)" fontSize={12} fontFamily="IBM Plex Sans Variable, sans-serif">{object.name}</text>
              </g>
            );
          })}
        </g>

        {/* ports */}


        {/* marquee */}
        {marquee && (marquee.w > 0.01 || marquee.d > 0.01) && (() => {
          const topLeft = toScreen({ x: marquee.x, z: marquee.z });
          return (
            <rect
              data-ui="marquee"
              x={topLeft.x}
              y={topLeft.y}
              width={marquee.w * view.zoom}
              height={marquee.d * view.zoom}
              fill="rgba(232,180,10,0.06)"
              stroke="var(--accent)"
              strokeDasharray="4 3"
              strokeWidth={1}
            />
          );
        })()}

        {/* draft shape */}
        {draft && (draft.rect.w > 0.01 || draft.rect.d > 0.01) && (() => {
          const topLeft = toScreen({ x: draft.rect.x, z: draft.rect.z });
          return (
            <g data-ui="draft">
              <rect x={topLeft.x} y={topLeft.y} width={draft.rect.w * view.zoom} height={draft.rect.d * view.zoom} fill="rgba(232,180,10,0.06)" stroke="var(--accent)" strokeWidth={1} />
              <text x={topLeft.x + 6} y={topLeft.y - 6} fill="var(--accent)" fontSize={12} fontFamily="IBM Plex Mono, monospace">
                {draft.rect.w.toFixed(2)} × {draft.rect.d.toFixed(2)} m
              </text>
            </g>
          );
        })()}

        {/* smart guides */}
        <g data-ui="snap">
          {snapLines.x.map((x) => (
            <line key={`sx-${x}`} x1={toScreen({ x, z: 0 }).x} y1={0} x2={toScreen({ x, z: 0 }).x} y2={size.h} stroke="rgba(232,180,10,0.55)" strokeDasharray="2 3" />
          ))}
          {snapLines.z.map((z) => (
            <line key={`sz-${z}`} x1={0} y1={toScreen({ x: 0, z }).y} x2={size.w} y2={toScreen({ x: 0, z }).y} stroke="rgba(232,180,10,0.55)" strokeDasharray="2 3" />
          ))}
        </g>

        {/* selection bounds */}
        {selectionRect && selectedIds.length > 0 && (() => {
          const topLeft = toScreen({ x: selectionRect.x, z: selectionRect.z });
          return (
            <g key={selectedObjects.map((object) => `${object.id}:${object.rotation}:${object.position.x}:${object.position.z}`).join('|')} data-ui="selection">
              <rect x={topLeft.x - 2} y={topLeft.y - 2} width={selectionRect.w * view.zoom + 4} height={selectionRect.d * view.zoom + 4} fill="none" stroke="rgba(232,180,10,0.32)" strokeWidth={1} strokeDasharray="3 3" />
              {selectedIds.length > 1 && (
                <text x={topLeft.x} y={topLeft.y - 8} fill="var(--accent)" fontSize={12} fontFamily="IBM Plex Mono, monospace">{selectedIds.length} objects</text>
              )}
            </g>
          );
        })()}
      </svg>

      {/* rulers */}
      {project.settings.showRulers && (
        <>
          <div className="plan-ruler plan-ruler--top" onPointerDown={(event) => beginGuide(event, 'x')} onPointerMove={moveGuide} onPointerUp={endGuide} onPointerCancel={endGuide} onLostPointerCapture={endGuide} onContextMenu={resetGuides}>
            <svg width={size.w} height={RULER} aria-hidden="true">
              {topTicks.map((tick) => {
                const x = toScreen({ x: tick, z: 0 }).x;
                return (
                  <g key={tick}>
                    <line x1={x} y1={RULER - 5} x2={x} y2={RULER} stroke="rgba(207,203,195,0.25)" />
                    <text x={x + 3} y={10} fill="rgba(207,203,195,0.62)" fontSize={12} fontFamily="IBM Plex Mono, monospace">{tick.toFixed(0)}</text>
                  </g>
                );
              })}
            </svg>
            <span className="plan-ruler-corner" />
          </div>
          <div className="plan-ruler plan-ruler--left" onPointerDown={(event) => beginGuide(event, 'z')} onPointerMove={moveGuide} onPointerUp={endGuide} onPointerCancel={endGuide} onLostPointerCapture={endGuide} onContextMenu={resetGuides}>
            <svg width={RULER} height={size.h} aria-hidden="true">
              {leftTicks.map((tick) => {
                const y = toScreen({ x: 0, z: tick }).y;
                return (
                  <g key={tick}>
                    <line x1={RULER - 5} y1={y} x2={RULER} y2={y} stroke="rgba(207,203,195,0.25)" />
                    <text x={4} y={y + 2} fill="rgba(207,203,195,0.62)" fontSize={12} fontFamily="IBM Plex Mono, monospace">{tick.toFixed(0)}</text>
                  </g>
                );
              })}
            </svg>
          </div>
        </>
      )}

      {/* toolbar */}
      <div className="plan-toolbar" role="toolbar" aria-label="Plan tools">
        {TOOLS.slice(0, 1).map((entry) => {
          const Icon = entry.icon;
          return (
            <button
              key={entry.id}
              type="button"
              className={cx('plan-tool', tool === entry.id && 'is-active')}
              data-tool={entry.id}
              aria-pressed={tool === entry.id}
              aria-label={entry.label}
              data-tooltip={`${entry.label} · ${entry.shortcut}`}
              onClick={() => { setTool(entry.id); if (entry.id !== 'cable') cancelCable(); }}
            >
              <Icon />
              <span className="plan-tool-key">{entry.shortcut}</span>
            </button>
          );
        })}
        <div className="plan-add-wrap">
          <button type="button" className={cx('plan-tool', addOpen && 'is-active-soft')} onClick={() => setAddOpen((value) => !value)} aria-label="Add object" aria-expanded={addOpen} data-tooltip="Add object">
            <Plus />
          </button>
          {addOpen && (
            <div className="plan-add-menu" role="menu" aria-label="Add to plan">
              {(['room', 'stage', 'zone', 'wall', 'truss'] as const).map((id) => {
                const item = TOOLS.find((entry) => entry.id === id);
                if (!item) return null;
                const Icon = item.icon;
                return <button key={id} type="button" role="menuitem" onClick={() => { setTool(id); setAddOpen(false); }}><Icon /> {item.label}<span className="kbd">{item.shortcut}</span></button>;
              })}
              <span className="plan-add-sep" />
              <button type="button" role="menuitem" onClick={() => { setAddOpen(false); addLight('spot', { x: view.x, z: view.z + 3 }); }}><Lightbulb /> Spot Light</button>
              <button type="button" role="menuitem" onClick={() => { setAddOpen(false); addLight('point', { x: view.x, z: view.z + 3 }); }}><CircleDot /> Point Light</button>
              <button type="button" role="menuitem" onClick={() => { setAddOpen(false); addLight('area', { x: view.x, z: view.z + 3 }); }}><RectangleHorizontal /> Area Light</button>
              <button type="button" role="menuitem" onClick={() => { setPendingAdd(null); setAddOpen(false); openCommand(true); }}><Plus /> Equipment…<span className="kbd">Ctrl K</span></button>
            </div>
          )}
        </div>
        <div className="plan-toolbar-sep" />
        <button type="button" className="plan-tool" aria-label="Fit plan" data-tooltip="Fit plan · F" onClick={() => useUiStore.getState().requestFit()}>
          <Maximize2 />
        </button>
        <button type="button" className={cx('plan-tool', project.settings.showGrid && 'is-active-soft')} aria-label="Grid" data-tooltip={project.settings.showGrid ? 'Hide grid' : 'Show grid'} onClick={() => updateSettings({ showGrid: !project.settings.showGrid })}>
          <Grid2X2 />
        </button>
        <button type="button" className={cx('plan-tool', project.settings.snap && 'is-active-soft')} aria-label="Snap" data-tooltip={project.settings.snap ? 'Disable snapping' : 'Enable snapping'} onClick={() => updateSettings({ snap: !project.settings.snap })}>
          <Crosshair />
        </button>
        <button type="button" className={cx('plan-tool', project.settings.showBeams && 'is-active-soft')} aria-label="Beams" data-tooltip={project.settings.showBeams ? 'Hide beams' : 'Show beams'} onClick={() => updateSettings({ showBeams: !project.settings.showBeams })}>
          <MousePointerClick />
        </button>
        <div className="plan-toolbar-sep" />
        <button type="button" className={cx('plan-tool', (layersOpen || cableFilter !== 'all') && 'is-active-soft')} aria-label="Layers" data-tooltip="Layers and visibility" onClick={() => setLayersOpen((value) => !value)}>
          <Layers />
        </button>
      </div>

      {/* layers popover */}
      {layersOpen && (
        <div className="plan-layers-panel" role="dialog" aria-label="Layers">
          <div className="plan-layers-head"><span>Layers</span><button type="button" className="plan-layers-close" onClick={() => setLayersOpen(false)}>×</button></div>
          {[['model', 'Models'], ['light', 'Lights'], ['room', 'Rooms'], ['stage', 'Stages and zones'], ['truss', 'Trusses'], ['device', 'Fixtures'], ['furniture', 'Furniture and walls']].map(([layer, label]) => (
            <button key={layer} type="button" className="plan-layer-row" aria-pressed={!hiddenLayers.includes(layer)} onClick={() => toggleLayer(layer)}>
              <span className={`plan-layer-check ${!hiddenLayers.includes(layer) ? 'is-on' : ''}`}>{!hiddenLayers.includes(layer) && <Check />}</span>
              {label}
            </button>
          ))}
          {hiddenObjectCount > 0 && (
            <button type="button" className="plan-layer-row plan-layer-row--restore" onClick={showAllObjects}>
              <span className="plan-layer-check is-on"><Eye /></span>
              Show hidden ({hiddenObjectCount})
            </button>
          )}
        </div>
      )}

      {/* hint + scale */}
      {toolHint(tool, !!cableStart) && (
        <div className="plan-hint">
          <span className="plan-hint-tool">{activeTool?.label || 'Select'}</span>
          <span>{toolHint(tool, !!cableStart)}</span>
          {cableStart && <button type="button" className="plan-hint-cancel" onClick={cancelCable}>Cancel</button>}
        </div>
      )}


      {showIntro && (
        <div className="plan-intro-card" role="note">
          <button type="button" className="plan-intro-close" aria-label="Dismiss plan introduction" onClick={dismissIntro}>×</button>
          <strong>Scene plan</strong>
          <span>Import models, arrange objects and add lights. Preview everything in 3D.</span>
        </div>
      )}

      {/* one contextual next step, never a guided tour */}
      {(() => {
        const hasScene = project.objects.some((object) => ['model', 'light', 'device', 'stage', 'room'].includes(object.type));
        if (hasScene) return null;
        return (
          <div className="plan-empty">
            <div className="plan-empty-card">
              <Search />
              <strong>Start your scene</strong>
              <span>Import a 3D model or add a light from the Add menu.</span>
            </div>
          </div>
        );
      })()}

      {menu && <ContextMenu x={menu.x} y={menu.y} items={menu.items} onClose={() => setMenu(null)} />}
    </div>
  );
}
