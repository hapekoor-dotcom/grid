import { useId } from 'react';
import type { CatalogDevice } from '../../types/catalog';
import type { SceneObject } from '../../types/project';
import { objectDims } from '../../lib/objects';

interface ShapeProps {
  object: SceneObject;
  device: CatalogDevice | null;
  dims: { w: number; d: number; h: number };
}

const CARD = '#151a1e';
const CARD_DARK = '#11161a';
const EDGE = 'rgba(207,203,195,0.26)';
const EDGE_SOFT = 'rgba(207,203,195,0.14)';

function lightColor(object: SceneObject, fallback = '#2c3439'): string {
  if (!object.light || !object.light.on || object.light.intensity <= 0.01) return fallback;
  return object.light.color;
}

function DeviceShape({ object, device, dims }: ShapeProps) {
  const { w, d } = dims;
  const kind = device?.kind || 'other';
  const color = lightColor(object);
  const opacity = object.light ? Math.max(0.28, object.light.intensity) : 1;
  const cellCount = Math.min(16, Math.max(3, device?.lensCount || (kind === 'bar' ? 6 : kind === 'pixel' ? 8 : 1)));

  if (['head', 'beam', 'spot'].includes(kind)) {
    const radius = Math.min(w, d) * 0.36;
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.035} fill={CARD} stroke={EDGE} />
        <path d={`M${-w * 0.32} ${d * 0.24} L${-w * 0.2} ${-d * 0.1}`} fill="none" stroke={EDGE} strokeWidth={1.2} vectorEffect="non-scaling-stroke" />
        <path d={`M${w * 0.32} ${d * 0.24} L${w * 0.2} ${-d * 0.1}`} fill="none" stroke={EDGE} strokeWidth={1.2} vectorEffect="non-scaling-stroke" />
        <circle cx={0} cy={-d * 0.04} r={radius} fill="#0c1012" stroke={EDGE} />
        <circle cx={0} cy={-d * 0.04} r={radius * 0.62} fill={color} opacity={opacity} />
        <circle cx={0} cy={-d * 0.04} r={radius * 0.28} fill="#fff" opacity={opacity * 0.7} />
        <line x1={0} y1={d * 0.08} x2={0} y2={d * 0.52} stroke={color} strokeWidth={1.6} opacity={0.5} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (['bar', 'pixel', 'panel'].includes(kind)) {
    const innerW = w - 0.06;
    const cellW = innerW / cellCount;
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill={CARD} stroke={object.light?.on ? color : EDGE} strokeOpacity={object.light?.on ? 0.8 : 1} />
        {/* An asymmetric nose makes the bar's rotation readable even when all cells are the same colour. */}
        <path d={`M0 ${-d / 2 - 0.055} l-0.07 0.075 h0.14 z`} fill={object.light?.on ? color : EDGE} opacity={0.9} />
        {Array.from({ length: cellCount }, (_, index) => (
          <rect
            key={index}
            x={-w / 2 + 0.03 + index * cellW}
            y={-d / 2 + d * 0.3}
            width={Math.max(0.008, cellW - 0.008)}
            height={d * 0.4}
            rx={0.008}
            fill={color}
            opacity={opacity * (kind === 'pixel' ? 1 : 0.9)}
          />
        ))}
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill="none" stroke={EDGE} />
      </g>
    );
  }

  if (kind === 'speaker' || kind === 'soundbooth') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.035} fill={CARD} stroke={EDGE} />
        {[0.25, 0.5, 0.75].map((ratio) => (
          <circle key={ratio} cx={0} cy={-d / 2 + d * ratio} r={Math.min(w, d) * 0.17} fill="#0c1012" stroke={EDGE_SOFT} />
        ))}
        <path d={`M${-w * 0.32} ${-d / 2 + d * 0.08}V${d / 2 - d * 0.08}`} stroke={EDGE_SOFT} strokeWidth={0.8} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (['par', 'strobe', 'blinder', 'flood', 'effectlight'].includes(kind)) {
    const radius = Math.min(w, d) * 0.36;
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={kind === 'blinder' ? 0.02 : 0.035} fill={CARD} stroke={EDGE} />
        <circle cx={0} cy={0} r={radius} fill="#0c1012" stroke={EDGE} />
        <circle cx={0} cy={0} r={radius * 0.58} fill={color} opacity={opacity} />
        <line x1={0} y1={d * 0.1} x2={0} y2={d * 0.48} stroke={color} strokeWidth={1.5} opacity={0.45} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (kind === 'mirrorball') {
    return (
      <g>
        <circle cx={0} cy={0} r={Math.min(w, d) / 2} fill="#1a2126" stroke={EDGE} />
        <circle cx={0} cy={0} r={Math.min(w, d) * 0.34} fill="rgba(207,203,195,0.14)" stroke={EDGE_SOFT} />
        <circle cx={-Math.min(w, d) * 0.1} cy={-Math.min(w, d) * 0.12} r={Math.min(w, d) * 0.08} fill="rgba(255,255,255,0.35)" />
      </g>
    );
  }

  if (kind === 'console' || kind === 'controller' || kind === 'mixer') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill={CARD} stroke={EDGE} />
        <rect x={-w / 2 + 0.04} y={-d / 2 + 0.04} width={w - 0.08} height={d - 0.08} rx={0.02} fill={CARD_DARK} stroke={EDGE_SOFT} />
        {Array.from({ length: 7 }, (_, index) => {
          const x = -w / 2 + 0.1 + (index * (w - 0.2)) / 6;
          return (
            <g key={index}>
              <line x1={x} y1={-d / 2 + 0.1} x2={x} y2={d / 2 - 0.1} stroke={EDGE_SOFT} strokeWidth={0.5} vectorEffect="non-scaling-stroke" />
              <rect x={x - 0.022} y={-d / 2 + 0.1 + (index % 3) * 0.07} width={0.044} height={0.035} rx={0.008} fill={index === 3 ? color : '#2a3238'} />
            </g>
          );
        })}
        <circle cx={w / 2 - 0.1} cy={0} r={0.035} fill="#2a3238" stroke={EDGE_SOFT} />
        <circle cx={w / 2 - 0.1} cy={0} r={0.015} fill={color} opacity={0.8} />
      </g>
    );
  }

  if (kind === 'outlet') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.02} fill={CARD} stroke={EDGE} />
        {Array.from({ length: Math.max(1, Math.min(4, Math.round(w / 0.14))) }, (_, index) => {
          const x = -w / 2 + 0.08 + index * 0.14;
          return (
            <g key={index}>
              <circle cx={x} cy={0} r={0.035} fill="#0c1012" stroke={EDGE_SOFT} />
              <circle cx={x - 0.011} cy={-0.005} r={0.006} fill="#E8B40A" opacity={0.5} />
              <circle cx={x + 0.011} cy={-0.005} r={0.006} fill="#E8B40A" opacity={0.5} />
            </g>
          );
        })}
      </g>
    );
  }

  if (kind === 'distro' || kind === 'dimmer') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill={CARD} stroke={EDGE} />
        <rect x={-w / 2 + 0.05} y={-d / 2 + 0.06} width={w - 0.1} height={d - 0.12} rx={0.02} fill={CARD_DARK} stroke={EDGE_SOFT} />
        {Array.from({ length: 4 }, (_, index) => (
          <rect key={index} x={-w / 2 + 0.1 + index * (w - 0.2) / 3 - 0.03} y={-d / 2 + 0.12} width={0.06} height={0.05} rx={0.01} fill={index === 0 ? '#E8B40A' : '#242b30'} />
        ))}
        <rect x={-w / 2 + 0.1} y={d / 2 - 0.13} width={w - 0.2} height={0.03} rx={0.01} fill="#36d77c" opacity={0.6} />
      </g>
    );
  }

  if (kind === 'node' || kind === 'splitter' || kind === 'switch' || kind === 'interface' || kind === 'receiver' || kind === 'transmitter') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.025} fill={CARD} stroke={EDGE} />
        <rect x={-w / 2 + 0.04} y={-d / 2 + 0.05} width={w - 0.08} height={d - 0.1} rx={0.02} fill={CARD_DARK} stroke={EDGE_SOFT} />
        <circle cx={-w / 2 + 0.08} cy={-d / 2 + 0.1} r={0.012} fill={kind === 'node' ? '#35fc72' : '#355cfc'} />
        <rect x={-w / 2 + 0.05} y={d / 2 - 0.13} width={Math.max(0.08, w * 0.28)} height={0.025} rx={0.01} fill="#2a3238" />
      </g>
    );
  }

  if (kind === 'battery' || kind === 'powerbank' || kind === 'generator' || kind === 'solar') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill={CARD} stroke={EDGE} />
        <rect x={-w / 2 + 0.06} y={-d / 2 + 0.07} width={w - 0.12} height={d - 0.14} rx={0.02} fill={CARD_DARK} stroke={EDGE_SOFT} />
        <rect x={0} y={0} width={w * 0.22} height={d * 0.3} rx={0.02} fill="#E8B40A" opacity={0.55} />
        <path d={`M${-w * 0.12} 0 h${w * 0.1} l${-w * 0.04} ${-d * 0.1} h${w * 0.08} l${w * 0.08} ${d * 0.16} h${-w * 0.1}`} fill="none" stroke="#E8B40A" strokeWidth={1} opacity={0.7} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (kind === 'ledwall' || kind === 'tv' || kind === 'projector' || kind === 'processor') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.015} fill={kind === 'ledwall' ? '#10161b' : CARD} stroke={EDGE} />
        <rect x={-w / 2 + 0.02} y={-d / 2 + 0.02} width={w - 0.04} height={d - 0.04} rx={0.01} fill="none" stroke="rgba(252,53,191,0.22)" strokeWidth={0.8} vectorEffect="non-scaling-stroke" />
        {Array.from({ length: 4 }, (_, index) => (
          <line key={index} x1={-w / 2 + (w / 4) * index} y1={-d / 2} x2={-w / 2 + (w / 4) * index} y2={d / 2} stroke="rgba(252,53,191,0.12)" strokeWidth={0.5} vectorEffect="non-scaling-stroke" />
        ))}
      </g>
    );
  }

  if (kind === 'haze' || kind === 'fog' || kind === 'snow' || kind === 'bubble' || kind === 'co2' || kind === 'confetti' || kind === 'flame' || kind === 'fan') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.04} fill={CARD} stroke={EDGE} />
        <circle cx={-w * 0.08} cy={0} r={Math.min(w, d) * 0.2} fill="none" stroke="rgba(207,203,195,0.3)" />
        <circle cx={w * 0.1} cy={-d * 0.08} r={Math.min(w, d) * 0.1} fill="none" stroke="rgba(207,203,195,0.18)" />
        <path d={`M${w * 0.3} 0 h${w * 0.2}`} stroke="rgba(207,203,195,0.3)" strokeWidth={1} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  return (
    <g>
      <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill={CARD} stroke={EDGE} />
      <circle cx={0} cy={0} r={Math.min(w, d) * 0.12} fill={EDGE} />
    </g>
  );
}

function StructureShape({ object, dims }: ShapeProps) {
  const { w, d } = dims;
  if (object.type === 'room') {
    const wall = 4.5;
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} fill="rgba(20,26,30,0.55)" stroke="none" />
        <rect x={-w / 2} y={-d / 2} width={w} height={d} fill="none" stroke="rgba(207,203,195,0.32)" strokeWidth={wall} vectorEffect="non-scaling-stroke" />
        <rect x={-w / 2 + 0.14} y={-d / 2 + 0.14} width={w - 0.28} height={d - 0.28} fill="none" stroke="rgba(207,203,195,0.07)" strokeWidth={1.6} vectorEffect="non-scaling-stroke" />
        {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => (
          <path
            key={`${sx}${sz}`}
            d={`M${sx * w / 2 - sx * 0.3} ${sz * d / 2} h${sx * 0.3} v${-sz * 0.3}`}
            fill="none"
            stroke="rgba(207,203,195,0.42)"
            strokeWidth={1}
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </g>
    );
  }

  if (object.type === 'stage') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.02} fill={object.stage?.color || '#22282e'} stroke="rgba(207,203,195,0.22)" />
        <rect x={-w / 2 + 0.06} y={-d / 2 + 0.06} width={Math.max(0.01, w - 0.12)} height={Math.max(0.01, d - 0.12)} fill="none" stroke="rgba(232,180,10,0.12)" strokeWidth={0.8} vectorEffect="non-scaling-stroke" />
        <line x1={-w / 2} y1={-d / 2} x2={w / 2} y2={-d / 2} stroke="rgba(207,203,195,0.3)" strokeWidth={2.5} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (object.type === 'crowd') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill="rgba(232,180,10,0.035)" stroke="rgba(232,180,10,0.32)" strokeWidth={1} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />
        {[0.25, 0.5, 0.75].map((ratio) => (
          <line key={ratio} x1={-w / 2 + w * ratio} y1={-d / 2} x2={-w / 2 + w * ratio} y2={d / 2} stroke="rgba(207,203,195,0.08)" strokeWidth={0.7} vectorEffect="non-scaling-stroke" />
        ))}
      </g>
    );
  }

  if (object.type === 'seating') {
    const rows = Math.max(1, object.seating?.rows || 1);
    const columns = Math.max(1, object.seating?.columns || 1);
    const stepX = w / columns;
    const stepZ = d / rows;
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.03} fill="rgba(207,203,195,0.035)" stroke="rgba(207,203,195,0.28)" strokeWidth={1} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />
        {Array.from({ length: rows }, (_, row) => Array.from({ length: columns }, (_, column) => {
          const x = -w / 2 + stepX * (column + 0.5);
          const z = -d / 2 + stepZ * (row + 0.5);
          return (
            <g key={`${row}-${column}`} transform={`translate(${x} ${z})`}>
              <rect x={-0.18} y={-0.11} width={0.36} height={0.22} rx={0.04} fill="#20252a" stroke="rgba(207,203,195,0.2)" strokeWidth={0.7} vectorEffect="non-scaling-stroke" />
              <line x1={-0.18} y1={-0.16} x2={0.18} y2={-0.16} stroke="rgba(207,203,195,0.3)" strokeWidth={0.8} vectorEffect="non-scaling-stroke" />
            </g>
          );
        }))}
        <line x1={0} y1={-d / 2} x2={0} y2={d / 2} stroke="rgba(232,180,10,0.16)" strokeWidth={1} strokeDasharray="2 3" vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (object.type === 'model') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.04} fill="rgba(82,112,145,0.16)" stroke="rgba(154,186,220,0.72)" strokeWidth={1.2} vectorEffect="non-scaling-stroke" />
        <path d={`M${-w / 2} ${-d / 2} L${w / 2} ${d / 2} M${w / 2} ${-d / 2} L${-w / 2} ${d / 2}`} stroke="rgba(154,186,220,0.35)" strokeWidth={1} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (object.type === 'light') {
    return (
      <g>
        <circle cx={0} cy={0} r={Math.max(0.16, Math.min(w, d) / 2)} fill="rgba(255,190,84,0.18)" stroke="rgba(255,205,120,0.9)" strokeWidth={1.2} vectorEffect="non-scaling-stroke" />
        {[0, 90, 180, 270].map((angle) => (
          <line key={angle} x1={0} y1={0} x2={Math.cos((angle * Math.PI) / 180) * Math.max(0.3, Math.min(w, d) * 0.85)} y2={Math.sin((angle * Math.PI) / 180) * Math.max(0.3, Math.min(w, d) * 0.85)} stroke="rgba(255,205,120,0.45)" strokeWidth={1} vectorEffect="non-scaling-stroke" />
        ))}
      </g>
    );
  }

  if (object.type === 'areabar') {
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={Math.max(0.08, d)} rx={0.02} fill="#050608" stroke="rgba(255,255,255,0.72)" strokeWidth={1} vectorEffect="non-scaling-stroke" />
        <line x1={-w * 0.45} y1={0} x2={w * 0.45} y2={0} stroke="#ffffff" strokeWidth={2} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (object.type === 'truss') {
    const segments = Math.max(1, Math.round(w / 0.5));
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.02} fill="#161b1f" stroke="rgba(207,203,195,0.34)" />
        {Array.from({ length: segments }, (_, index) => {
          const x = -w / 2 + (w / segments) * index;
          return (
            <g key={index}>
              <line x1={x} y1={-d / 2} x2={x + w / segments} y2={d / 2} stroke="rgba(207,203,195,0.22)" strokeWidth={0.7} vectorEffect="non-scaling-stroke" />
              <line x1={x} y1={d / 2} x2={x + w / segments} y2={-d / 2} stroke="rgba(207,203,195,0.22)" strokeWidth={0.7} vectorEffect="non-scaling-stroke" />
            </g>
          );
        })}
        <line x1={-w / 2} y1={0} x2={w / 2} y2={0} stroke="rgba(207,203,195,0.14)" strokeWidth={0.6} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  if (object.type === 'furniture') {
    if (/^(Wall|Стена)/i.test(object.name)) {
      const segments = Math.max(2, Math.round(w / 0.35));
      return (
        <g>
          <rect x={-w / 2} y={-d / 2} width={w} height={d} fill="#20262b" stroke="rgba(207,203,195,0.38)" strokeWidth={1.2} />
          {Array.from({ length: segments }, (_, index) => {
            const x = -w / 2 + (w / segments) * index;
            return <line key={index} x1={x} y1={-d / 2} x2={x + w / segments} y2={d / 2} stroke="rgba(207,203,195,0.18)" strokeWidth={0.7} vectorEffect="non-scaling-stroke" />;
          })}
        </g>
      );
    }
    const kind = object.deviceId || '';
    if (kind.includes('chair')) {
      return <circle cx={0} cy={0} r={Math.min(w, d) / 2} fill="#181d21" stroke="rgba(207,203,195,0.28)" />;
    }
    if (kind.includes('barricade')) {
      return (
        <g>
          <rect x={-w / 2} y={-d / 2} width={w} height={d} fill="rgba(207,203,195,0.09)" stroke="rgba(207,203,195,0.35)" />
          {Array.from({ length: Math.max(2, Math.round(w / 0.5)) }, (_, index) => (
            <line key={index} x1={-w / 2 + (w / Math.max(2, Math.round(w / 0.5))) * index} y1={-d / 2} x2={-w / 2 + (w / Math.max(2, Math.round(w / 0.5))) * index} y2={d / 2} stroke="rgba(207,203,195,0.22)" strokeWidth={1.6} vectorEffect="non-scaling-stroke" />
          ))}
        </g>
      );
    }
    return (
      <g>
        <rect x={-w / 2} y={-d / 2} width={w} height={d} rx={0.04} fill="#181d21" stroke="rgba(207,203,195,0.28)" />
        <rect x={-w / 2 + 0.05} y={-d / 2 + 0.05} width={w - 0.1} height={d - 0.1} rx={0.02} fill="none" stroke="rgba(207,203,195,0.08)" vectorEffect="non-scaling-stroke" />
      </g>
    );
  }

  return null;
}

export function PlanObjectShape(props: ShapeProps) {
  if (props.object.type === 'device') return <DeviceShape {...props} />;
  return <StructureShape {...props} />;
}

export function RotateHandleMark({ rotation }: { rotation: number }) {
  return <circle cx={0} cy={0} r={0.01} fill="none" stroke="rgba(232,180,10,0.4)" data-rotation={rotation} />;
}
