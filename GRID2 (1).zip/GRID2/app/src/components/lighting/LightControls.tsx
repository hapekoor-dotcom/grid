import type { Project, SceneObject } from '../../types/project';
import { getDevice } from '../../lib/catalog';
import { COLOR_SWATCHES } from '../../lib/lighting';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { Field, NumberInput, Slider, Toggle } from '../ui/Field';
import { OverdriveControl } from '../ui/OverdriveControl';
import { KeyframeButton } from '../inspector/KeyframeButton';

interface LightControlsProps {
  project: Project;
  objects: SceneObject[];
  compact?: boolean;
}

export function LightControls({ project, objects, compact }: LightControlsProps) {
  const beginTransaction = useWorkspaceStore((state) => state.beginTransaction);
  const endTransaction = useWorkspaceStore((state) => state.endTransaction);
  const mutateTransient = useWorkspaceStore((state) => state.mutateTransient);
  const updateLight = useWorkspaceStore((state) => state.updateLight);
  const fixtures = objects.filter((object) => object.light && object.visible);
  if (!fixtures.length) {
    return <div className="notice">Select a fixture with lighting. Controls are virtual and are not sent to hardware.</div>;
  }
  const ids = fixtures.map((object) => object.id);
  const first = fixtures[0];
  const light = first.light!;
  const keyObject = fixtures.length === 1 ? first : null;
  const devices = fixtures.map((object) => getDevice(object.deviceId)).filter(Boolean);
  const supports = (key: 'color' | 'pan' | 'tilt' | 'zoom' | 'strobe' | 'focus') => devices.some((device) => device?.capabilities?.[key]);
  const anyOn = fixtures.some((object) => object.light?.on);
  const barDevice = devices.find((device) => device?.kind === 'bar' || device?.kind === 'pixel');
  const segmentCount = Math.min(16, Math.max(3, barDevice?.lensCount || 12));
  const segmentValues = Array.from({ length: segmentCount }, (_, index) => first.light?.segments?.[index]?.intensity ?? 1);
  const avgIntensity = fixtures.reduce((sum, object) => sum + (object.light?.intensity || 0), 0) / fixtures.length;
  const distinct = (getter: (object: SceneObject) => unknown) => new Set(fixtures.map(getter)).size > 1;
  const mixedIntensity = distinct((object) => object.light?.intensity);
  const mixedColor = distinct((object) => object.light?.color);
  const mixedZoom = distinct((object) => object.light?.zoom);
  const mixedPan = distinct((object) => object.light?.pan);
  const mixedTilt = distinct((object) => object.light?.tilt);
  const mixedStrobe = distinct((object) => object.light?.strobe);
  const mixedFocus = distinct((object) => object.light?.focus);
  const mixedOn = fixtures.some((object) => object.light?.on) && fixtures.some((object) => !object.light?.on);

  const transient = (patch: Partial<NonNullable<SceneObject['light']>>) => {
    mutateTransient((draft) => {
      for (const object of draft.objects) {
        if (ids.includes(object.id) && object.light) object.light = { ...object.light, ...patch };
      }
      draft.lighting.activePresetId = null;
    });
  };

  const slider = (value: number, min: number, max: number, step: number, patch: (value: number) => Partial<NonNullable<SceneObject['light']>>, ariaLabel: string, format: (value: number) => string, mixed = false) => (
    <div className="light-control">
      <div className="light-control-head">
        <span className="field-label-row"><span className="field-label">{ariaLabel}</span>{keyObject && ({ Zoom: 'light.zoom', Strobe: 'light.strobe', Focus: 'light.focus' } as Record<string,string>)[ariaLabel] ? <KeyframeButton objectId={keyObject.id} propertyPath={({ Zoom: 'light.zoom', Strobe: 'light.strobe', Focus: 'light.focus' } as Record<string,string>)[ariaLabel]} value={ariaLabel === 'Zoom' ? light.zoom : ariaLabel === 'Strobe' ? light.strobe : light.focus} label={ariaLabel} /> : null}</span>
        <span className={`light-readout num ${mixed ? 'is-mixed' : ''}`}>{mixed ? 'Mixed' : format(value)}</span>
      </div>
      <div
        onPointerDown={beginTransaction}
        onPointerUp={endTransaction}
        onPointerCancel={endTransaction}
        onKeyDown={beginTransaction}
        onKeyUp={endTransaction}
      >
        <Slider
          value={value}
          min={min}
          max={max}
          step={step}
          ariaLabel={ariaLabel}
          onChange={(next) => transient(patch(next))}
        />
      </div>
    </div>
  );

  return (
    <div className={`light-controls ${compact ? 'light-controls--compact' : ''}`}>
      <div className="row-between">
        <span className="field-label">Output</span>
        <Toggle
          checked={anyOn}
          ariaLabel="Toggle light output"
          onChange={(checked) => updateLight(ids, { on: checked })}
        />
      </div>

      <div className="light-control">
        <div className="light-control-head">
          <span className="field-label-row"><span className="field-label">Dimmer</span>{keyObject && <KeyframeButton objectId={keyObject.id} propertyPath="light.intensity" value={keyObject.light?.intensity ?? 1} label="Dimmer" />}</span>
          <span className={`light-readout num ${mixedIntensity ? 'is-mixed' : ''}`}>{mixedIntensity ? 'Mixed' : `${Math.round(avgIntensity * 100)}%`}</span>
        </div>
        <OverdriveControl
          value={avgIntensity}
          ariaLabel="Dimmer"
          onChange={(value) => transient({ intensity: value })}
          onInteractionStart={beginTransaction}
          onInteractionEnd={endTransaction}
        />
      </div>

      {barDevice && (
        <div className="light-control">
          <div className="light-control-head">
            <span className="field-label">Sections · {segmentCount}</span>
            <button type="button" className="section-link" onClick={() => updateLight(ids, { segments: null })}>All</button>
          </div>
          <div className="segment-strip" style={{ gridTemplateColumns: `repeat(${segmentCount}, minmax(0, 1fr))` }} role="group" aria-label="Fixture sections">
            {segmentValues.map((value, index) => (
              <button
                key={index}
                type="button"
                className={`segment-cell ${value > 0.01 ? 'is-on' : ''}`}
                aria-label={`Section ${index + 1}`}
                aria-pressed={value > 0.01}
                title={`Section ${index + 1}`}
                onClick={() => {
                  const next = segmentValues.map((segment, segmentIndex) => ({ intensity: segmentIndex === index ? (segment > 0.01 ? 0 : 1) : segment }));
                  updateLight(ids, { segments: next });
                }}
              />
            ))}
          </div>
        </div>
      )}

      {supports('color') && (
        <div className="light-control">
          <div className="light-control-head">
            <span className="field-label-row"><span className="field-label">Color</span>{keyObject && <KeyframeButton objectId={keyObject.id} propertyPath="light.color" value={keyObject.light?.color ?? '#ffffff'} label="Color" />}</span>
            <span className={`light-readout num ${mixedColor ? 'is-mixed' : ''}`}>{mixedColor ? 'Mixed' : light.color.toUpperCase()}</span>
          </div>
          <div className="color-row">
            <input
              type="color"
              className="color-input"
              value={light.color}
              aria-label="Fixture color"
              onPointerDown={beginTransaction}
              onPointerUp={endTransaction}
              onBlur={endTransaction}
              onChange={(event) => transient({ color: event.target.value })}
            />
            <div className="swatch-row">
              {COLOR_SWATCHES.slice(0, compact ? 6 : 12).map((swatch) => (
                <button
                  key={swatch.color}
                  type="button"
                  className="swatch"
                  style={{ background: swatch.color }}
                  aria-label={swatch.name}
                  title={swatch.name}
                  onClick={() => updateLight(ids, { color: swatch.color })}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {supports('zoom') && slider(light.zoom, 2, 80, 0.5, (value) => ({ zoom: value }), 'Zoom', (value) => `${value.toFixed(1)}°`, mixedZoom)}

      {(supports('pan') || supports('tilt')) && (
        <div className="light-control">
          <div className="light-control-head">
            <span className="field-label-row"><span className="field-label">Pan / Tilt</span>{keyObject && <><KeyframeButton objectId={keyObject.id} propertyPath="light.pan" value={keyObject.light?.pan ?? 0} label="Pan" /><KeyframeButton objectId={keyObject.id} propertyPath="light.tilt" value={keyObject.light?.tilt ?? 0} label="Tilt" /></>}</span>
            <span className={`light-readout num ${mixedPan || mixedTilt ? 'is-mixed' : ''}`}>{mixedPan || mixedTilt ? 'Mixed' : `${light.pan}° / ${light.tilt}°`}</span>
          </div>
          <div className="form-grid form-grid--2">
            <Field label="Pan" hint="Horizontal aiming angle in degrees."><NumberInput value={light.pan} min={-180} max={180} step={1} suffix="°" ariaLabel="Pan" onChange={(value) => transient({ pan: Math.max(-180, Math.min(180, value ?? 0)) })} /></Field>
            <Field label="Tilt" hint="Vertical aiming angle in degrees."><NumberInput value={light.tilt} min={-90} max={90} step={1} suffix="°" ariaLabel="Tilt" onChange={(value) => transient({ tilt: Math.max(-90, Math.min(90, value ?? 0)) })} /></Field>
          </div>
        </div>
      )}

      {(supports('strobe') || supports('focus')) && (
        <details className="light-advanced">
          <summary>Advanced</summary>
          <div className="form-grid">
            {supports('strobe') && slider(light.strobe, 0, 30, 1, (value) => ({ strobe: value }), 'Strobe', (value) => `${value.toFixed(0)} Hz`, mixedStrobe)}
            {supports('focus') && slider(light.focus * 100, 0, 100, 1, (value) => ({ focus: value / 100 }), 'Focus', (value) => `${Math.round(value)}%`, mixedFocus)}
          </div>
        </details>
      )}

      <div className="light-control-meta">
        <span>Master {Math.round(project.lighting.master * 100)}%</span>
        <span className="dim">Virtual preview</span>
        {mixedOn && <span className="dim">Mixed output</span>}
      </div>
    </div>
  );
}
