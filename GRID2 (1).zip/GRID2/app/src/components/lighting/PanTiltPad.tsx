import { useRef } from 'react';

interface PanTiltPadProps {
  pan: number;
  tilt: number;
  disabled?: boolean;
  onStart: () => void;
  onChange: (pan: number, tilt: number) => void;
  onEnd: () => void;
}

export function PanTiltPad({ pan, tilt, disabled, onStart, onChange, onEnd }: PanTiltPadProps) {
  const ref = useRef<HTMLDivElement>(null);
  const active = useRef(false);

  const update = (clientX: number, clientY: number) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((clientX - rect.left) / rect.width) * 2 - 1;
    const y = ((clientY - rect.top) / rect.height) * 2 - 1;
    const radius = Math.hypot(x, y);
    const scale = radius > 1 ? 1 / radius : 1;
    const nextPan = Math.round(x * scale * 180);
    const nextTilt = Math.round(-y * scale * 90);
    onChange(nextPan, nextTilt);
  };

  return (
    <div
      ref={ref}
      className="pan-tilt-pad"
      role="application"
      aria-label="Pan and tilt"
      aria-disabled={disabled}
      onPointerDown={(event) => {
        if (disabled) return;
        active.current = true;
        (event.currentTarget as HTMLDivElement).setPointerCapture(event.pointerId);
        onStart();
        update(event.clientX, event.clientY);
      }}
      onPointerMove={(event) => {
        if (!active.current || disabled) return;
        update(event.clientX, event.clientY);
      }}
      onPointerUp={() => {
        if (!active.current) return;
        active.current = false;
        onEnd();
      }}
      onPointerCancel={() => {
        if (!active.current) return;
        active.current = false;
        onEnd();
      }}
    >
      <span className="pan-tilt-cross pan-tilt-cross--x" />
      <span className="pan-tilt-cross pan-tilt-cross--y" />
      <span className="pan-tilt-center" />
      <span
        className="pan-tilt-dot"
        style={{ left: `${50 + (pan / 180) * 50}%`, top: `${50 - (tilt / 90) * 50}%` }}
      />
      <span className="pan-tilt-readout num">P {pan}° / T {tilt}°</span>
    </div>
  );
}
