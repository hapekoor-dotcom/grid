import { useMemo, useState } from 'react';
import { ChevronDown, Lightbulb, Plus, Save, Search, Sparkles, Trash2, Users, Wand2 } from 'lucide-react';
import type { Project, SceneObject } from '../../types/project';
import { getDevice } from '../../lib/catalog';
import { useUiStore } from '../../store/uiStore';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { Button, IconButton } from '../ui/Button';
import { TextInput } from '../ui/Field';
import { LightControls } from './LightControls';

export function LightingPanel({ project }: { project: Project }) {
  const selectedIds = useUiStore((state) => state.selectedIds);
  const selectMany = useUiStore((state) => state.selectMany);
  const select = useUiStore((state) => state.select);
  const setMode = useUiStore((state) => state.setMode);
  const applyPreset = useWorkspaceStore((state) => state.applyPreset);
  const savePreset = useWorkspaceStore((state) => state.savePreset);
  const deletePreset = useWorkspaceStore((state) => state.deletePreset);
  const createGroup = useWorkspaceStore((state) => state.createGroup);
  const deleteGroup = useWorkspaceStore((state) => state.deleteGroup);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [presetName, setPresetName] = useState('');
  const [groupName, setGroupName] = useState('');

  const fixtures = project.objects.filter((object) => object.light);
  const selectedFixtures = fixtures.filter((object) => selectedIds.includes(object.id));
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return fixtures;
    return fixtures.filter((object) => {
      const device = getDevice(object.deviceId);
      return `${object.name} ${device?.name || ''} ${device?.brand || ''}`.toLowerCase().includes(normalized);
    });
  }, [fixtures, query]);
  const groups = project.lighting.groups.filter((group) => group.memberIds.length > 0);
  const activeGroup = project.lighting.groups.find((group) => group.memberIds.length > 0 && group.memberIds.every((id) => selectedIds.includes(id)));
  const allSelected = fixtures.length > 0 && fixtures.every((object) => selectedIds.includes(object.id));
  const summary = selectedFixtures.length === 0
    ? 'Select fixtures…'
    : activeGroup
      ? `${activeGroup.name} · ${selectedFixtures.length} fixtures`
      : selectedFixtures.length === 1
        ? selectedFixtures[0].name
        : `${selectedFixtures.length} fixtures selected`;

  const toggleFixture = (object: SceneObject) => {
    const selected = new Set(selectedFixtures.map((entry) => entry.id));
    if (selected.has(object.id)) selected.delete(object.id);
    else selected.add(object.id);
    selectMany([...selected]);
  };

  return (
    <>
      <div className="panel-head">
        <span className="panel-title">Lighting</span>
        <span className="badge badge--accent">Virtual</span>
      </div>
      <div className="panel-body">
        <section className="inspector-section">
          <button type="button" className={`light-select-target ${open ? 'is-open' : ''}`} aria-expanded={open} onClick={() => setOpen((value) => !value)}>
            <Lightbulb />
            <span className="light-select-copy">
              <span className="light-select-label">Select fixtures</span>
              <strong>{summary}</strong>
            </span>
            <ChevronDown className={open ? 'is-open' : ''} />
          </button>

          {open && (
            <div className="light-selector">
              <div className="catalog-search lighting-search">
                <Search aria-hidden="true" />
                <input className="input" value={query} placeholder="Search fixtures" aria-label="Search fixtures" onChange={(event) => setQuery(event.target.value)} />
              </div>
              <div className="light-select-actions">
                <button type="button" onClick={() => selectMany(fixtures.map((object) => object.id))} className={allSelected ? 'is-active' : ''}>All fixtures</button>
                <button type="button" onClick={() => selectMany([])} disabled={!selectedFixtures.length}>Clear</button>
                <button type="button" onClick={() => setMode('plan')}><Wand2 /> Plan</button>
              </div>
              {groups.length > 0 && (
                <div className="light-group-list">
                  {groups.map((group) => (
                    <div className="light-group-row" key={group.id}>
                      <button type="button" className={activeGroup?.id === group.id ? 'is-active' : ''} onClick={() => selectMany(group.memberIds)}>
                        <Users /> <span>{group.name}</span> <span className="num">{group.memberIds.length}</span>
                      </button>
                      <IconButton label={`Delete ${group.name}`} size="sm" onClick={() => deleteGroup(group.id)}><Trash2 /></IconButton>
                    </div>
                  ))}
                </div>
              )}
              <div className="fixture-list light-fixture-list">
                {filtered.map((object) => {
                  const active = selectedIds.includes(object.id);
                  const device = getDevice(object.deviceId);
                  return (
                    <button type="button" key={object.id} className={`fixture-row ${active ? 'is-active' : ''}`} onClick={() => toggleFixture(object)}>
                      <span className="fixture-color" style={{ background: object.light?.color || '#fff', opacity: object.light?.on ? 1 : 0.25 }} />
                      <span className="fixture-row-copy">
                        <span className="fixture-row-name">{object.name}</span>
                        <span className="fixture-row-meta">{device?.shortName || object.deviceId}</span>
                      </span>
                      <span className="fixture-row-value num">{Math.round((object.light?.intensity || 0) * 100)}%</span>
                    </button>
                  );
                })}
                {!filtered.length && <div className="empty"><Lightbulb /><span>No fixtures found.</span></div>}
              </div>
              <div className="light-group-create">
                <TextInput value={groupName} onChange={setGroupName} placeholder="New group" ariaLabel="Group name" />
                <Button size="sm" icon={<Plus />} disabled={!selectedFixtures.length} onClick={() => { createGroup(groupName); setGroupName(''); }}>Group</Button>
              </div>
            </div>
          )}
        </section>

        {selectedFixtures.length > 0 ? (
          <section className="inspector-section">
            <div className="section-label"><span>Parameters</span><span className="count">{selectedFixtures.length}</span></div>
            <LightControls project={project} objects={selectedFixtures} />
          </section>
        ) : (
          <div className="light-empty-state"><Lightbulb /><span>Select a fixture to edit its lighting.</span></div>
        )}

        <section className="inspector-section">
          <div className="section-label"><span>Presets</span><span className="count">{project.lighting.presets.length}</span></div>
          <div className="preset-list">
            {project.lighting.presets.map((preset) => {
              const targets = project.objects.filter((object) => preset.values[object.id]).map((object) => object.name);
              return (
              <div className={`preset-row ${project.lighting.activePresetId === preset.id ? 'is-active' : ''}`} key={preset.id}>
                <button type="button" className="preset-row-main" title={targets.join(', ')} onClick={() => applyPreset(preset.id)}>
                  <Sparkles />
                  <span className="truncate">{preset.name}</span>
                  <span className="num dim">{targets.length} fixtures</span>
                </button>
                <IconButton label={`Delete ${preset.name}`} size="sm" onClick={() => deletePreset(preset.id)}><Trash2 /></IconButton>
              </div>
              );
            })}
            {!project.lighting.presets.length && <div className="empty" style={{ padding: '12px 0' }}><Sparkles /><span>No presets saved.</span></div>}
          </div>
          <div className="inline-form">
            <TextInput value={presetName} onChange={setPresetName} placeholder="Preset name" ariaLabel="Preset name" />
            <Button size="sm" icon={<Save />} disabled={!selectedFixtures.length} onClick={() => { savePreset(presetName); setPresetName(''); }}>Save</Button>
          </div>
          {selectedFixtures.length > 0 && <p className="field-hint">Saved for {selectedFixtures.length === 1 ? selectedFixtures[0].name : `${selectedFixtures.length} selected fixtures`}.</p>}
        </section>
      </div>
    </>
  );
}
