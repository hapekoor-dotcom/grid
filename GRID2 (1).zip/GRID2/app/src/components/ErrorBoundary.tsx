import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props { children: ReactNode }
interface State { error: Error | null }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('RE:GRID render failure', error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="fatal-screen">
          <div className="fatal-card">
            <span className="brand-mark">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                <path d="M3 3h18v18H3zM9 3v18M15 3v18M3 9h18M3 15h18" />
              </svg>
            </span>
            <h1>RE:GRID stopped</h1>
            <p>A UI error occurred. The project is saved in localStorage if the browser allows writes.</p>
            <pre>{this.state.error.message}</pre>
            <div className="fatal-actions">
              <button type="button" className="btn btn--primary" onClick={() => window.location.reload()}>Reload</button>
              <button type="button" className="btn" onClick={() => { void navigator.clipboard?.writeText(this.state.error?.stack || this.state.error?.message || ''); }}>Copy error</button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
