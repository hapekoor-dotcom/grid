import { useRef, useState } from 'react';
import { Loader2, Upload } from 'lucide-react';
import { newAssetId, putAsset } from '../../lib/assetStore';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { normalizeModelFiles } from '../../lib/gltfImport';

const MAX_BYTES = 200 * 1024 * 1024;

export function ImportModelButton() {
  const inputRef = useRef<HTMLInputElement>(null);
  const addModel = useWorkspaceStore((state) => state.addModel);
  const pushToast = useUiStore((state) => state.pushToast);
  const [busy, setBusy] = useState(false);

  const importFiles = async (files: File[]) => {
    if (!files.length) return;
    if (files.reduce((sum, file) => sum + file.size, 0) > MAX_BYTES) {
      pushToast('Model files are larger than 200 MB.', 'error');
      return;
    }
    setBusy(true);
    try {
      const id = newAssetId();
      const model = await normalizeModelFiles(files);
      await putAsset({ id, name: model.name, mime: model.mime, data: model.data, createdAt: Date.now() });
      addModel(id, model.name);
      const ui = useUiStore.getState();
      if (ui.mode === '3d' || ui.mode === 'light') ui.setRightOpen(true);
      pushToast(`${model.name} imported`, 'success');
    } catch (error) {
      pushToast(error instanceof Error ? error.message : 'The model could not be imported.', 'error');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept=".glb,.gltf,model/gltf-binary,model/gltf+json"
        style={{ display: 'none' }}
        multiple
        aria-label="Choose 3D model files"
        onChange={(event) => void importFiles(Array.from(event.target.files || []))}
      />
      <button type="button" className="sidebar-row sidebar-row--import" disabled={busy} onClick={() => inputRef.current?.click()}>
        {busy ? <Loader2 className="spin" /> : <Upload />}
        <span>{busy ? 'Importing…' : 'Import 3D Model'}</span>
      </button>
    </>
  );
}
