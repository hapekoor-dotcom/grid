import type { CatalogDevice } from '../../types/catalog';
import {
  Armchair, BatteryCharging, BookOpen, Box, ChevronRight, CircleDot, CloudFog, Columns3, Focus,
  Fan, FolderOpen, Gauge, Layers3, Lightbulb, MonitorPlay, Network, Plug, Radio,
  RectangleHorizontal, Search, Settings2, ShieldAlert, SlidersHorizontal, Sparkles, Split, Triangle, Volume2, Wind,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { categories, CATEGORY_LABELS, kindLabel, visibleDevices } from '../../lib/catalog';
import { useUiStore } from '../../store/uiStore';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { ImportModelButton } from './ImportModelButton';
import { PRIMITIVES } from '../../lib/primitives';

export function DeviceIcon({ device }: { device: CatalogDevice }) {
  const kind = device.kind;
  const props = { size: 14, strokeWidth: 1.6 } as const;
  if (['head', 'beam', 'spot', 'par', 'laser'].includes(kind)) return <Lightbulb {...props} />;
  if (['bar', 'pixel', 'panel'].includes(kind)) return <RectangleHorizontal {...props} />;
  if (['strobe', 'blinder'].includes(kind)) return <Lightbulb {...props} />;
  if (kind === 'effectlight' || kind === 'decor' || kind === 'flood') return <Sparkles {...props} />;
  if (kind === 'mirrorball') return <CircleDot {...props} />;
  if (kind === 'fog' || kind === 'haze') return <CloudFog {...props} />;
  if (kind === 'snow' || kind === 'bubble' || kind === 'confetti' || kind === 'co2') return <Wind {...props} />;
  if (kind === 'fan') return <Fan {...props} />;
  if (kind === 'node' || kind === 'interface' || kind === 'switch') return <Network {...props} />;
  if (kind === 'splitter') return <Split {...props} />;
  if (kind === 'receiver' || kind === 'transmitter') return <Radio {...props} />;
  if (kind === 'console' || kind === 'controller' || kind === 'mixer') return <SlidersHorizontal {...props} />;
  if (kind === 'laptop' || kind === 'computer' || kind === 'player') return <MonitorPlay {...props} />;
  if (kind === 'outlet' || kind === 'power' || kind === 'dimmer') return <Plug {...props} />;
  if (kind === 'battery' || kind === 'powerbank' || kind === 'generator' || kind === 'solar') return <BatteryCharging {...props} />;
  if (kind === 'distro') return <Gauge {...props} />;
  if (kind === 'truss' || kind === 'trussTower' || kind === 'curtain') return <Columns3 {...props} />;
  if (kind === 'stage' || kind === 'riser') return <Layers3 {...props} />;
  if (kind === 'table' || kind === 'chair' || kind === 'barricade') return <Armchair {...props} />;
  if (kind === 'speaker' || kind === 'soundbooth') return <Volume2 {...props} />;
  if (device.category === 'video') return <MonitorPlay {...props} />;
  if (device.category === 'light') return <Lightbulb {...props} />;
  return <Triangle {...props} />;
}

function CategoryIcon({ id }: { id: string }) {
  if (id === 'light') return <Lightbulb />;
  if (id === 'effects') return <Sparkles />;
  if (id === 'rigging') return <Columns3 />;
  if (id === 'stage') return <Layers3 />;
  if (id === 'power') return <Plug />;
  if (id === 'network') return <Network />;
  if (id === 'control') return <SlidersHorizontal />;
  if (id === 'video') return <MonitorPlay />;
  return <Volume2 />;
}

export function CatalogPanel() {
  const project = useActiveProject();
  const addDevice = useWorkspaceStore((state) => state.addDevice);
  const addLight = useWorkspaceStore((state) => state.addLight);
  const addPrimitive = useWorkspaceStore((state) => state.addPrimitive);
  const setMode = useUiStore((state) => state.setMode);
  const setTool = useUiStore((state) => state.setTool);
  const openCommand = useUiStore((state) => state.openCommand);
  const setPendingAdd = useUiStore((state) => state.setPendingAdd);
  const setHelpOpen = useUiStore((state) => state.setHelpOpen);
  const setDiagnosticsOpen = useUiStore((state) => state.setDiagnosticsOpen);
  const setProjectsOpen = useUiStore((state) => state.setProjectsOpen);
  const setSettingsOpen = useUiStore((state) => state.setSettingsOpen);
  const camera = useUiStore((state) => state.planCamera);
  const pushToast = useUiStore((state) => state.pushToast);
  const [openCategory, setOpenCategory] = useState<string | null>(() => { try { return localStorage.getItem('regrid.catalog.category'); } catch { return null; } });
  const [catalogOpen, setCatalogOpen] = useState(() => { try { return localStorage.getItem('regrid.catalog.open') === '1'; } catch { return false; } });
  const toggleCatalog = () => { setCatalogOpen((value) => { const next = !value; try { localStorage.setItem('regrid.catalog.open', next ? '1' : '0'); } catch { /* ignore storage */ } return next; }); };
  const toggleCategory = (id: string | null) => { setOpenCategory(id); try { if (id) localStorage.setItem('regrid.catalog.category', id); else localStorage.removeItem('regrid.catalog.category'); } catch { /* ignore storage */ } };

  const byCategory = useMemo(() => {
    const map = new Map<string, CatalogDevice[]>();
    for (const device of visibleDevices) {
      const list = map.get(device.category) || [];
      list.push(device);
      map.set(device.category, list);
    }
    return map;
  }, []);

  const creationMode = () => useUiStore.getState().mode;
  const finishCreation = () => {
    setPendingAdd(null);
    if (creationMode() === '3d' || creationMode() === 'light') useUiStore.getState().setRightOpen(true);
  };
  const add = (device: CatalogDevice) => {
    if (!project) return;
    const mode = creationMode();
    if (mode === 'plan') setTool('select');
    setPendingAdd(null);
    addDevice(device.id, camera ? { x: camera.x, z: camera.z } : { x: 0, z: 0 });
    if (mode === '3d' || mode === 'light') useUiStore.getState().setRightOpen(true);
    pushToast(`${device.shortName} added`, 'success');
  };

  return (
    <aside className="panel left-panel sidebar" aria-label="Navigation and catalog">
      <div className="sidebar-head sidebar-head--create">
        <span className="sidebar-head-title">Create</span>
      </div>

      <div className="sidebar-actions">
        <button type="button" className="sidebar-row" onClick={() => setProjectsOpen(true)}>
          <FolderOpen />
          <span>Projects</span>
        </button>
        <button type="button" className="sidebar-row" onClick={() => setHelpOpen(true)}>
          <BookOpen />
          <span>Documentation</span>
        </button>
      </div>

      <div className="sidebar-catalog">
        <div className="sidebar-create-group">
          <div className="sidebar-label"><span>Models</span></div>
          <ImportModelButton />
          <p className="sidebar-create-note">GLB or GLTF with external files</p>
          <div className="primitive-grid">
            {PRIMITIVES.map((primitive) => (
              <button key={primitive.kind} type="button" className="sidebar-device primitive-button" onClick={() => { if (!project) return; addPrimitive(primitive.kind, camera ? { x: camera.x, z: camera.z } : { x: 0, z: 0 }); finishCreation(); }}>
                <Box />
                <span>{primitive.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="sidebar-create-group">
          <div className="sidebar-label"><span>Lights</span></div>
          {(['point', 'spot', 'area', 'directional'] as const).map((kind) => (
            <button
              key={kind}
              type="button"
              className="sidebar-device sidebar-create-action"
              onClick={() => {
                if (!project) return;
                addLight(kind, camera ? { x: camera.x, z: camera.z } : { x: 0, z: 0 });
                finishCreation();
                pushToast(`${kind === 'area' ? 'Area' : kind[0].toUpperCase() + kind.slice(1)} Light added`, 'success');
              }}
            >
              <Lightbulb />
              <span>{kind === 'area' ? 'Area / Rect Light' : kind[0].toUpperCase() + kind.slice(1) + ' Light'}</span>
            </button>
          ))}
        </div>

        <div className="sidebar-create-group">
          <div className="sidebar-label"><span>Advanced Fixtures</span></div>
          <button
            type="button"
            className="sidebar-device sidebar-create-action"
            onClick={() => {
              if (!project) return;
              addDevice('focusflex', camera ? { x: camera.x, z: camera.z } : { x: 0, z: 0 });
              finishCreation();
              pushToast('Focus Flex added', 'success');
            }}
          >
            <Focus />
            <span>Focus Flex</span>
          </button>
        </div>

        <details className="sidebar-legacy">
          <summary>Legacy fixtures</summary>
          <div className="sidebar-tree">
            {categories.filter((category) => ['light', 'effects', 'rigging', 'stage', 'video', 'audio'].includes(category.id)).map((category) => {
              const list = byCategory.get(category.id) || [];
              const open = openCategory === category.id;
              return (
                <div className="sidebar-group" key={category.id}>
                  <button type="button" className="sidebar-cat" aria-expanded={open} onClick={() => toggleCategory(open ? null : category.id)}>
                    <span className="sidebar-cat-icon"><CategoryIcon id={category.id} /></span>
                    <span>{CATEGORY_LABELS[category.id] || category.label}</span>
                    <ChevronRight className={open ? 'is-open' : ''} />
                  </button>
                  {open && (
                    <div className="sidebar-devices">
                      {list.map((device) => (
                        <button type="button" className="sidebar-device" key={device.id} onClick={() => add(device)} title={`${device.name} · ${kindLabel(device)}`}>
                          <DeviceIcon device={device} />
                          <span>{device.shortName}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </details>
      </div>

      <div className="sidebar-footer">
          <button type="button" className="sidebar-row sidebar-settings" onClick={() => setSettingsOpen(true)}>
          <Settings2 />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
}
