import { PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen } from 'lucide-react';

export function PanelToggle({ side, open, onToggle }: { side: 'left' | 'right'; open: boolean; onToggle: () => void }) {
  const Icon = side === 'left'
    ? (open ? PanelLeftClose : PanelLeftOpen)
    : (open ? PanelRightClose : PanelRightOpen);
  const label = side === 'left'
    ? (open ? 'Collapse sidebar' : 'Expand sidebar')
    : (open ? 'Collapse inspector' : 'Expand inspector');
  return (
    <button
      type="button"
      className={`panel-toggle panel-toggle--${side} ${open ? 'is-open' : 'is-closed'}`}
      onClick={onToggle}
      aria-label={label}
      title={label}
    >
      <Icon />
    </button>
  );
}
