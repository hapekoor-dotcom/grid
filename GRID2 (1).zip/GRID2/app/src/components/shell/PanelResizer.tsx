import { useCallback } from 'react';
import { useUiStore } from '../../store/uiStore';

export function PanelResizer({ side }: { side: 'left' | 'right' }) {
  const setLeftWidth = useUiStore((state) => state.setLeftWidth);
  const setRightWidth = useUiStore((state) => state.setRightWidth);
  const leftWidth = useUiStore((state) => state.leftWidth);
  const rightWidth = useUiStore((state) => state.rightWidth);

  const onPointerDown = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    const startX = event.clientX;
    const initial = side === 'left' ? leftWidth : rightWidth;
    const target = event.currentTarget;
    target.dataset.active = 'true';
    target.setPointerCapture(event.pointerId);
    const onMove = (moveEvent: PointerEvent) => {
      const delta = moveEvent.clientX - startX;
      if (side === 'left') setLeftWidth(initial + delta);
      else setRightWidth(initial - delta);
    };
    const onUp = () => {
      target.dataset.active = 'false';
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      window.removeEventListener('blur', onUp);
      try { if (target.hasPointerCapture(event.pointerId)) target.releasePointerCapture(event.pointerId); } catch { /* already released */ }
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    window.addEventListener('blur', onUp);
  }, [leftWidth, rightWidth, side, setLeftWidth, setRightWidth]);

  return (
    <div
      className="panel-resizer"
      role="separator"
      aria-orientation="vertical"
      aria-label={side === 'left' ? 'Resize catalog panel' : 'Resize inspector panel'}
      onPointerDown={onPointerDown}
    />
  );
}
