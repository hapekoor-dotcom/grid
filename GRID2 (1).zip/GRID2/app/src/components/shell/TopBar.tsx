import {
  Box, Map, Redo2, Undo2,
} from 'lucide-react';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore, type AppMode } from '../../store/uiStore';
import { formatDate } from '../../lib/id';
import { IconButton } from '../ui/Button';

const MODES: { id: AppMode; label: string; icon: typeof Map; key: string }[] = [
  { id: 'plan', label: 'Plan', icon: Map, key: '1' },
  { id: '3d', label: '3D', icon: Box, key: '2' },
];

export function TopBar() {
  const project = useActiveProject();
  const mode = useUiStore((state) => state.mode);
  const setMode = useUiStore((state) => state.setMode);
  const pushToast = useUiStore((state) => state.pushToast);
  const dirty = useWorkspaceStore((state) => state.dirty);
  const savedAt = useWorkspaceStore((state) => state.savedAt);
  const persistNow = useWorkspaceStore((state) => state.persistNow);
  const past = useWorkspaceStore((state) => state.past);
  const future = useWorkspaceStore((state) => state.future);
  const undo = useWorkspaceStore((state) => state.undo);
  const redo = useWorkspaceStore((state) => state.redo);
  const storageError = useWorkspaceStore((state) => state.storageError);



  if (!project) return null;

  const save = () => {
    persistNow();
    const error = useWorkspaceStore.getState().storageError;
    pushToast(error || 'Project saved in this browser', error ? 'error' : 'success');
  };
  const saveLabel = storageError ? 'Save failed' : dirty ? 'Saving…' : 'Saved';
  const saveTone = storageError ? 'danger' : dirty ? 'warn' : 'ok';
  const activeMode = mode === 'light' ? '3d' : mode;

  return (
    <header className="topbar">
      <div className="topbar-left">
        <button type="button" className="brand" onClick={() => useUiStore.getState().setProjectsOpen(true)} aria-label="RE:GRID projects">
          <span className="brand-mark">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
              <path d="M3 3h18v18H3zM9 3v18M15 3v18M3 9h18M3 15h18" />
            </svg>
          </span>
          <span className="brand-word">RE<span>:</span>GRID</span>
        </button>
        <button type="button" className={`save-state ${dirty ? 'save-state--dirty' : ''}`} onClick={save} aria-label={storageError ? 'Save failed. Retry saving' : dirty ? 'Saving changes' : 'Project saved'} title={storageError || (savedAt ? `Saved ${formatDate(savedAt)}` : 'Saved')}>
          <span className={`status-dot status-dot--${saveTone}`} />
          {saveLabel}
        </button>
      </div>

      <div className="topbar-center">
      <nav className="mode-tabs" aria-label="Workspace mode">
        {MODES.map(({ id, label, icon: Icon, key }) => (
          <button
            key={id}
            type="button"
            className="mode-tab"
            data-mode={id}
            role="tab"
            aria-selected={activeMode === id}
            onClick={() => setMode(id)}
            title={`${label} · ${key}`}
          >
            <Icon />
            <span>{label}</span>
          </button>
        ))}
      </nav>
      </div>

      <div className="topbar-right">
        <IconButton label="Undo · Ctrl Z" onClick={undo} disabled={!past.length}><Undo2 /></IconButton>
        <IconButton label="Redo · Ctrl Shift Z" onClick={redo} disabled={!future.length}><Redo2 /></IconButton>
      </div>
    </header>
  );
}
