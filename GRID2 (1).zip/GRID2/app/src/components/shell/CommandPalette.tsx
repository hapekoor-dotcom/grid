import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Archive, ArrowLeft, Check, Pin, Search } from 'lucide-react';
import type { CatalogDevice } from '../../types/catalog';
import { categories, CATEGORY_LABELS, getDevice, kindLabel, searchDevices } from '../../lib/catalog';
import { useActiveProject, useWorkspaceStore } from '../../store/workspaceStore';
import { useUiStore } from '../../store/uiStore';
import { DeviceIcon } from '../catalog/CatalogPanel';

const RECENT_KEY = 'regrid-recent-devices';

function readRecent(): string[] {
  try {
    const value = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]');
    return Array.isArray(value) ? value.filter((id): id is string => typeof id === 'string').slice(0, 6) : [];
  } catch {
    return [];
  }
}

export function CommandPalette() {
  const open = useUiStore((state) => state.commandOpen);
  const openCommand = useUiStore((state) => state.openCommand);
  const setMode = useUiStore((state) => state.setMode);
  const setTool = useUiStore((state) => state.setTool);
  const pushToast = useUiStore((state) => state.pushToast);
  const camera = useUiStore((state) => state.planCamera);
  const pendingAdd = useUiStore((state) => state.pendingAdd);
  const setPendingAdd = useUiStore((state) => state.setPendingAdd);
  const project = useActiveProject();
  const addDevice = useWorkspaceStore((state) => state.addDevice);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [archive, setArchive] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [active, setActive] = useState(0);
  const [recent, setRecent] = useState<string[]>(readRecent);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const results = useMemo(() => {
    const normalized = query.trim();
    const pool = searchDevices(query, archive).filter((device) => ['light', 'effects', 'rigging', 'stage', 'video', 'audio'].includes(device.category));
    if (normalized) return category === 'all' ? pool.slice(0, 40) : pool.filter((device) => device.category === category).slice(0, 40);
    if (category !== 'all') return pool.filter((device) => device.category === category);
    return recent.map((id) => getDevice(id)).filter((device): device is CatalogDevice => !!device);
  }, [archive, category, query, recent]);

  const showCategories = !query.trim() && category === 'all';
  const activeCategory = categories.find((entry) => entry.id === category);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    setCategory('all');
    setActive(0);
    const timer = window.setTimeout(() => inputRef.current?.focus(), 20);
    return () => window.clearTimeout(timer);
  }, [open]);

  useEffect(() => { setActive(0); }, [query, category, archive]);

  useEffect(() => {
    const element = listRef.current?.querySelector<HTMLElement>(`[data-index="${active}"]`);
    element?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const remember = (id: string) => {
    setRecent((current) => {
      const next = [id, ...current.filter((entry) => entry !== id)].slice(0, 6);
      try { localStorage.setItem(RECENT_KEY, JSON.stringify(next)); } catch { /* storage is optional */ }
      return next;
    });
  };

  const add = (device: CatalogDevice) => {
    if (!project) return;
    const mode = useUiStore.getState().mode;
    if (mode === 'plan') setTool('select');
    addDevice(device.id, pendingAdd || (camera ? { x: camera.x, z: camera.z } : { x: 0, z: 0 }));
    if (mode === '3d' || mode === 'light') useUiStore.getState().setRightOpen(true);
    remember(device.id);
    pushToast(`${device.shortName} added`, 'success');
    if (!pinned) { setPendingAdd(null); openCommand(false); }
  };

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.isComposing) return;
      if (event.key === 'Escape') { event.preventDefault(); openCommand(false); return; }
      if (event.key === 'ArrowDown') { event.preventDefault(); setActive((value) => Math.max(0, Math.min(results.length - 1, value + 1))); return; }
      if (event.key === 'ArrowUp') { event.preventDefault(); setActive((value) => Math.max(0, value - 1)); return; }
      if (event.key === 'Enter') { event.preventDefault(); const device = results[active]; if (device) add(device); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, results, active, pinned, project, camera, pendingAdd]);

  if (!open) return null;

  return createPortal(
    <div className="overlay command-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) openCommand(false); }}>
      <div className="command-palette add-palette" role="dialog" aria-modal="true" aria-label="Add equipment">
        <div className="command-input-row">
          <Search />
          <input
            ref={inputRef}
            className="command-input"
            value={query}
            placeholder="Fixture, light or category"
            aria-label="Search fixtures"
            onChange={(event) => { setQuery(event.target.value); setCategory('all'); }}
          />
          <button type="button" className={`palette-tool ${archive ? 'is-active' : ''}`} aria-pressed={archive} aria-label={archive ? 'Hide archive' : 'Show archive'} onClick={() => { setArchive((value) => !value); inputRef.current?.focus(); }} title="Show archived items">
            <Archive />
          </button>
          <button type="button" className={`palette-tool ${pinned ? 'is-active' : ''}`} aria-pressed={pinned} aria-label={pinned ? 'Unpin window' : 'Pin window'} onClick={() => { setPinned((value) => !value); inputRef.current?.focus(); }} title={pinned ? 'Window pinned' : 'Pin for quick repeated additions'}>
            <Pin />
          </button>
          <span className="kbd">Esc</span>
        </div>

        {showCategories && (
          <div className="add-categories">
            {categories.filter((entry) => ['light', 'effects', 'rigging', 'stage', 'video', 'audio'].includes(entry.id)).map((entry) => (
              <button key={entry.id} type="button" className="add-category" onClick={() => { setCategory(entry.id); setActive(0); inputRef.current?.focus(); }}>
                <span>{entry.label}</span>
              </button>
            ))}
          </div>
        )}

        {showCategories && results.length > 0 && (
          <div className="add-list-head"><span className="add-list-caption">Recent</span></div>
        )}

        {!showCategories && (
          <div className="add-list-head">
            <button type="button" className="add-back" onClick={() => { setCategory('all'); setQuery(''); inputRef.current?.focus(); }}>
              <ArrowLeft /> {activeCategory ? activeCategory.label : query.trim() ? 'Results' : 'All categories'}
            </button>
            <span className="dim">{results.length}</span>
          </div>
        )}

        <div className="command-list" ref={listRef} role="listbox">
          {results.length === 0 && (
            <div className="empty">
              <Search />
              <span>{query.trim() ? 'Nothing found' : 'Start typing or choose a category'}</span>
            </div>
          )}
          {results.map((device, index) => (
            <button
              key={device.id}
              type="button"
              role="option"
              aria-selected={index === active}
              data-index={index}
              className={`add-device-row ${index === active ? 'is-active' : ''}`}
              onMouseEnter={() => setActive(index)}
              onClick={() => add(device)}
            >
              <span className="add-device-icon"><DeviceIcon device={device} /></span>
              <span className="add-device-copy">
                <span className="add-device-name">{device.shortName}</span>
                <span className="add-device-meta">{device.brand || kindLabel(device)} · {CATEGORY_LABELS[device.category] || device.category}</span>
              </span>
              {recent.includes(device.id) && <Check className="add-device-check" />}
            </button>
          ))}
        </div>

        <div className="command-foot">
          <span><span className="kbd">↑</span><span className="kbd">↓</span> select</span>
          <span><span className="kbd">Enter</span> add</span>
          <span className="add-foot-pin">{pinned ? 'pinned' : 'Esc to close'}</span>
        </div>
      </div>
    </div>,
    document.body,
  );
}
