import { lazy, Suspense, useEffect, useRef } from 'react';
import { TopBar } from './TopBar';
import { PanelToggle } from './PanelToggle';
import { CatalogPanel } from '../catalog/CatalogPanel';
import { RightPanel } from '../inspector/RightPanel';
import { PlanEditor } from '../plan/PlanEditor';
const Viewport3D = lazy(() => import('../view3d/PlayCanvasViewport').then((module) => ({ default: module.PlayCanvasViewport })));
import { useUiStore } from '../../store/uiStore';
import { useActiveProject } from '../../store/workspaceStore';
import { CommandPalette } from './CommandPalette';
import { ProjectLibraryDialog } from '../projects/ProjectLibraryDialog';
import { NewProjectDialog } from '../projects/NewProjectDialog';
import { SettingsDialog } from '../projects/SettingsDialog';
import { HelpDialog } from '../projects/HelpDialog';
import { ExportDialog } from '../projects/ExportDialog';
import { ConfirmDialog, ImportReportDialog } from '../projects/ImportDialogs';
import { Toasts } from '../ui/Toasts';
import { TimelinePanel } from '../timeline/TimelinePanel';

function CenterWorkspace() {
  const mode = useUiStore((state) => state.mode);
  const project = useActiveProject();
  if (!project) return null;
  const title = mode === 'plan' ? 'Scene plan' : '3D scene';
  return (
    <>
      <h1 className="visually-hidden">{title} — {project.name}</h1>
      {mode === 'plan' ? <PlanEditor /> : (
        <Suspense fallback={<div className="viewport-loading"><span className="spinner" />Preparing 3D scene</div>}>
          <Viewport3D />
        </Suspense>
      )}
    </>
  );
}

export function AppShell() {
  const leftOpen = useUiStore((state) => state.leftOpen);
  const rightOpen = useUiStore((state) => state.rightOpen);
  const mode = useUiStore((state) => state.mode);
  const selectedKey = useUiStore((state) => state.selectedIds.join(','));
  const rightWidth = useUiStore((state) => state.rightWidth);
  const toggleLeft = useUiStore((state) => state.toggleLeft);
  const toggleRight = useUiStore((state) => state.toggleRight);
  const lastSelectedKey = useRef(selectedKey);

  useEffect(() => {
    // A new selection in 3D opens the inspector. Entering 3D with an existing
    // selection does not force panels open.
    if (mode === '3d') {
      if (selectedKey && selectedKey !== lastSelectedKey.current) useUiStore.getState().setRightOpen(true);
      lastSelectedKey.current = selectedKey;
      return;
    }
    lastSelectedKey.current = selectedKey;
    const state = useUiStore.getState();
    const shouldOpen = mode === 'light' || (mode === 'plan' && !!selectedKey);
    if (shouldOpen && !state.rightOpen) state.setRightOpen(true);
    if (!shouldOpen && state.rightOpen) state.setRightOpen(false);
  }, [mode, selectedKey]);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 760px)');
    const collapseForPhone = () => {
      if (!query.matches) return;
      if (useUiStore.getState().leftOpen) toggleLeft();
      if (useUiStore.getState().rightOpen) toggleRight();
    };
    collapseForPhone();
    query.addEventListener('change', collapseForPhone);
    return () => query.removeEventListener('change', collapseForPhone);
  }, [toggleLeft, toggleRight]);

  return (
    <div className="app-shell">
      <a className="skip-link" href="#center-region">Skip to workspace</a>
      <TopBar />
      <div
        className="workspace"
        data-left={leftOpen ? 'true' : 'false'}
        data-right={rightOpen ? 'true' : 'false'}
        style={{ ['--right-width' as string]: `${rightWidth}px` } as React.CSSProperties}
      >
        {leftOpen && <CatalogPanel />}
        <main id="center-region" className="center-region" aria-label="Workspace">
          <div className="center-stage"><CenterWorkspace /></div>
          <TimelinePanel />
        </main>
        {rightOpen && <RightPanel />}
        <PanelToggle side="left" open={leftOpen} onToggle={toggleLeft} />
        <PanelToggle side="right" open={rightOpen} onToggle={toggleRight} />
      </div>
      <CommandPalette />
      <ProjectLibraryDialog />
      <NewProjectDialog />
      <SettingsDialog />
      <HelpDialog />
      <ExportDialog />
      <ConfirmDialog />
      <ImportReportDialog />
      <Toasts />
    </div>
  );
}
