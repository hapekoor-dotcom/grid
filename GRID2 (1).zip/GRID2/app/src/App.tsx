import { useEffect } from 'react';
import { useActiveProject, useWorkspaceStore } from './store/workspaceStore';
import { useUiStore } from './store/uiStore';
import { AppShell } from './components/shell/AppShell';
import { Welcome } from './components/projects/Welcome';
import { Toasts } from './components/ui/Toasts';
import { ConfirmDialog, ImportReportDialog } from './components/projects/ImportDialogs';
import { NewProjectDialog } from './components/projects/NewProjectDialog';
import { CommandPalette } from './components/shell/CommandPalette';

function isTypingTarget(target: EventTarget | null): boolean {
  const element = target as HTMLElement | null;
  if (!element) return false;
  return /^(INPUT|TEXTAREA|SELECT)$/.test(element.tagName) || element.isContentEditable;
}

export function App() {
  const initialized = useWorkspaceStore((state) => state.initialized);
  const activeProject = useActiveProject();
  const init = useWorkspaceStore((state) => state.init);
  const projects = useWorkspaceStore((state) => state.projects);
  const activeId = useWorkspaceStore((state) => state.activeId);
  const persistNow = useWorkspaceStore((state) => state.persistNow);
  const storageError = useWorkspaceStore((state) => state.storageError);

  useEffect(() => {
    init();
  }, [init]);

  // Debounced local autosave.
  useEffect(() => {
    if (!initialized) return;
    const timeout = window.setTimeout(() => persistNow(), 700);
    return () => window.clearTimeout(timeout);
  }, [projects, activeId, initialized, persistNow]);

  useEffect(() => {
    if (!storageError) return;
    useUiStore.getState().pushToast(storageError, 'error');
  }, [storageError]);

  useEffect(() => {
    const save = () => { if (useWorkspaceStore.getState().initialized) useWorkspaceStore.getState().persistNow(); };
    const onVisibility = () => { if (document.visibilityState === 'hidden') save(); };
    window.addEventListener('beforeunload', save);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('beforeunload', save);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  // Global shortcuts. Panels and the plan editor own the interaction-level keys.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const ui = useUiStore.getState();
      const overlaysOpen = ui.commandOpen || ui.projectsOpen || ui.newProjectOpen || ui.helpOpen || ui.settingsOpen || ui.exportOpen || ui.diagnosticsOpen || !!ui.confirm || !!ui.importReport;
      if (overlaysOpen || isTypingTarget(event.target)) return;
      const workspace = useWorkspaceStore.getState();
      const project = workspace.projects.find((entry) => entry.id === workspace.activeId);
      if (!project) return;
      const mod = event.metaKey || event.ctrlKey;
      const key = event.key.toLowerCase();

      if (mod) {
        if (key === 'z') {
          event.preventDefault();
          if (event.shiftKey) workspace.redo(); else workspace.undo();
          return;
        }
        if (key === 'y') { event.preventDefault(); workspace.redo(); return; }
        if (key === 's') { event.preventDefault(); workspace.persistNow(); ui.pushToast('Project saved in this browser', 'success'); return; }
        if (key === 'e') { event.preventDefault(); ui.setExportOpen(true); return; }
        if (key === 'k') { event.preventDefault(); ui.setPendingAdd(null); ui.openCommand(true); return; }
        if (key === 'c') { event.preventDefault(); workspace.copySelection(); return; }
        if (key === 'v') { event.preventDefault(); workspace.pasteClipboard(); return; }
        if (key === 'd') { event.preventDefault(); workspace.duplicateSelection(); return; }
        if (key === 'g') {
          event.preventDefault();
          if (event.shiftKey) workspace.ungroupSelection(); else workspace.groupSelection();
          return;
        }
        return;
      }

      if (event.key === 'Escape') {
        if (ui.cableStart) { ui.cancelCable(); ui.setTool('select'); return; }
        if (ui.tool !== 'select') { ui.setTool('select'); return; }
        if (ui.mode === '3d') {
          if (ui.transformMode !== 'select') { ui.setTransformMode('select'); return; }
          // In 3D, Escape exits navigation/transform; it does not discard the
          // current object selection. Clicking empty space remains the clear action.
          return;
        }
        ui.clearSelection();
        return;
      }

      if (key === 'delete' || key === 'backspace') {
        event.preventDefault();
        if (ui.selectedConnectionId) workspace.deleteConnection(ui.selectedConnectionId);
        else workspace.deleteSelection();
        return;
      }

      if (ui.mode === '3d') {
        if (key === 'q') { ui.setTransformMode('select'); return; }
        if (key === 'b') { ui.setTransformMode('select'); return; }
        if (key === '1') { ui.setTransformMode('move'); return; }
        if (key === '2') { ui.setTransformMode('rotate'); return; }
        if (key === '3') {
          if (project.objects.some((object) => ui.selectedIds.includes(object.id) && object.type === 'model')) ui.setTransformMode('scale');
          return;
        }
        return;
      }
      if (key === '1') { ui.setMode('plan'); return; }
      if (key === '2') { ui.setMode('3d'); return; }
      if (key === '3') { ui.setMode('light'); return; }

      if (key === '?' || (key === '/' && event.shiftKey)) { ui.setHelpOpen(true); return; }

      if (ui.mode !== 'plan') return;

      if (key === 'v') { ui.setTool('select'); return; }
      if (key === 'f') { ui.requestFit(); return; }
      if (key === 'r' && ui.selectedIds.length) { workspace.rotateSelection(90); return; }
      if (key === 'l' && ui.selectedIds.length) { workspace.lockSelection(!project.objects.find((object) => object.id === ui.selectedIds[0])?.locked); return; }
      if (key === 'h' && ui.selectedIds.length) { workspace.hideSelection(false); return; }

      if (event.key.startsWith('Arrow')) {
        event.preventDefault();
        const amount = event.shiftKey ? 0.5 : 0.05;
        if (event.key === 'ArrowLeft') workspace.nudgeSelection(-amount, 0);
        if (event.key === 'ArrowRight') workspace.nudgeSelection(amount, 0);
        if (event.key === 'ArrowUp') workspace.nudgeSelection(0, -amount);
        if (event.key === 'ArrowDown') workspace.nudgeSelection(0, amount);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  if (!initialized) {
    return (
      <div className="boot-screen">
        <div className="brand-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
            <path d="M3 3h18v18H3zM9 3v18M15 3v18M3 9h18M3 15h18" />
          </svg>
        </div>
        <span>RE:GRID</span>
        <span className="boot-sub">Preparing workspace</span>
      </div>
    );
  }

  if (!activeProject) {
    return (
      <>
        <Welcome />
        <NewProjectDialog />
        <ConfirmDialog />
        <ImportReportDialog />
        <CommandPalette />
        <Toasts />
      </>
    );
  }

  return <AppShell />;
}
