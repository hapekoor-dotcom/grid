import { create } from 'zustand';
import type { Project } from '../types/project';
import type { MaterialSourceSlotInfo } from '../lib/materialMaps';

export type AppMode = 'plan' | '3d' | 'light' | 'patch';
export type PlanTool = 'select' | 'room' | 'wall' | 'stage' | 'zone' | 'truss' | 'seating' | 'crowd' | 'cable';
export type PatchTab = 'dmx' | 'power' | 'equipment' | 'connections' | 'diagnostics';

export interface CableStart {
  objectId: string;
  portId: string;
}

export interface Toast {
  id: number;
  message: string;
  tone: 'default' | 'success' | 'warning' | 'error';
}

export interface ConfirmState {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
}

export interface ImportReport {
  title: string;
  warnings: string[];
  projectName: string;
  objects: number;
  connections: number;
  legacy: boolean;
}

interface UiState {
  mode: AppMode;
  tool: PlanTool;
  cableFilter: 'all' | 'none' | 'power' | 'dmx' | 'ethernet' | 'usb' | 'video' | 'wireless';
  hiddenLayers: string[];
  selectedIds: string[];
  selectedConnectionId: string | null;
  hoveredObjectId: string | null;
  hoveredPort: { objectId: string; portId: string } | null;
  cableStart: CableStart | null;
  cableTarget: CableStart | null;
  pendingAdd: { x: number; z: number } | null;

  leftOpen: boolean;
  rightOpen: boolean;
  timelineOpen: boolean;
  meshCapabilities: Record<string, { uv0: boolean; uv1: boolean; normals: boolean; tangents: boolean; colors: boolean }>;
  navigationMode: 'orbit' | 'fly';
  panelsByMode: Record<AppMode, { left: boolean; right: boolean }>;
  catalogAutoCollapsed: boolean;
  leftWidth: number;
  rightWidth: number;
  catalogQuery: string;
  catalogCategory: string;
  showHiddenDevices: boolean;
  patchTab: PatchTab;
  diagnosticsOpen: boolean;
  commandOpen: boolean;
  projectsOpen: boolean;
  newProjectOpen: boolean;
  helpOpen: boolean;
  settingsOpen: boolean;
  exportOpen: boolean;
  shortcutsOpen: boolean;
  confirm: ConfirmState | null;
  importReport: ImportReport | null;

  toasts: Toast[];
  fitRequest: number;
  zoomInRequest: number;
  zoomOutRequest: number;
  dragging: boolean;
  cameraFocusId: string | null;
  lightingGroupId: string | null;
  planCamera: { x: number; z: number; zoom: number; width: number; height: number } | null;
  cursor: { x: number; z: number } | null;
  transformMode: 'select' | 'move' | 'rotate' | 'scale';
  assetMaterialMaps: Record<string, MaterialSourceSlotInfo[]>;

  setMode: (mode: AppMode) => void;
  setTransformMode: (mode: 'select' | 'move' | 'rotate' | 'scale') => void;
  setAssetMaterialMaps: (assetId: string, slots: MaterialSourceSlotInfo[]) => void;
  setTool: (tool: PlanTool) => void;
  setCableFilter: (filter: UiState['cableFilter']) => void;
  toggleLayer: (layer: string) => void;
  select: (id: string, additive?: boolean) => void;
  selectMany: (ids: string[]) => void;
  selectConnection: (id: string | null) => void;
  clearSelection: () => void;
  pruneSelection: (project: Project) => void;
  setHoveredObject: (id: string | null) => void;
  setHoveredPort: (value: { objectId: string; portId: string } | null) => void;
  setCableStart: (value: CableStart | null) => void;
  setCableTarget: (value: CableStart | null) => void;
  setPendingAdd: (value: { x: number; z: number } | null) => void;
  cancelCable: () => void;

  toggleLeft: () => void;
  toggleRight: () => void;
  setRightOpen: (open: boolean) => void;
  setTimelineOpen: (open: boolean) => void;
  setMeshCapabilities: (capabilities: Record<string, { uv0: boolean; uv1: boolean; normals: boolean; tangents: boolean; colors: boolean }>) => void;
  setNavigationMode: (mode: 'orbit' | 'fly') => void;
  setLeftWidth: (width: number) => void;
  setRightWidth: (width: number) => void;
  setCatalogQuery: (query: string) => void;
  setCatalogCategory: (category: string) => void;
  toggleHiddenDevices: () => void;
  setPatchTab: (tab: PatchTab) => void;
  setDiagnosticsOpen: (open: boolean) => void;
  openCommand: (open?: boolean) => void;
  setProjectsOpen: (open: boolean) => void;
  setNewProjectOpen: (open: boolean) => void;
  setHelpOpen: (open: boolean) => void;
  setSettingsOpen: (open: boolean) => void;
  setExportOpen: (open: boolean) => void;
  setShortcutsOpen: (open: boolean) => void;
  askConfirm: (state: ConfirmState | null) => void;
  setImportReport: (report: ImportReport | null) => void;
  pushToast: (message: string, tone?: Toast['tone']) => void;
  dismissToast: (id: number) => void;
  requestFit: () => void;
  requestZoom: (direction: 1 | -1) => void;
  setDragging: (dragging: boolean) => void;
  focusCamera: (id: string) => void;
  clearCameraFocus: () => void;
  setLightingGroup: (id: string | null) => void;
  setPlanCamera: (camera: { x: number; z: number; zoom: number; width: number; height: number } | null) => void;
  setCursor: (cursor: { x: number; z: number } | null) => void;
}

let toastId = 0;

function readLeftOpen(): boolean {
  try { return localStorage.getItem('regrid:left-open') !== 'false'; } catch { return true; }
}

export const useUiStore = create<UiState>((set) => ({
  mode: 'plan',
  tool: 'select',
  cableFilter: 'all',
  hiddenLayers: [],
  selectedIds: [],
  selectedConnectionId: null,
  hoveredObjectId: null,
  hoveredPort: null,
  cableStart: null,
  cableTarget: null,
  pendingAdd: null,

  leftOpen: readLeftOpen(),
  rightOpen: false,
  timelineOpen: false,
  meshCapabilities: {},
  navigationMode: 'orbit',
  panelsByMode: {
    plan: { left: true, right: false },
    '3d': { left: false, right: false },
    light: { left: false, right: true },
    patch: { left: true, right: false },
  },
  catalogAutoCollapsed: false,
  leftWidth: 236,
  rightWidth: 342,
  catalogQuery: '',
  catalogCategory: 'all',
  showHiddenDevices: false,
  patchTab: 'dmx',
  diagnosticsOpen: false,
  commandOpen: false,
  projectsOpen: false,
  newProjectOpen: false,
  helpOpen: false,
  settingsOpen: false,
  exportOpen: false,
  shortcutsOpen: false,
  confirm: null,
  importReport: null,

  toasts: [],
  fitRequest: 0,
  zoomInRequest: 0,
  zoomOutRequest: 0,
  dragging: false,
  cameraFocusId: null,
  lightingGroupId: null,
  planCamera: null,
  cursor: null,
  transformMode: 'select',
  assetMaterialMaps: {},

  setMode: (mode) => set((state) => {
    if (mode === state.mode) return state;
    const panelsByMode = {
      ...state.panelsByMode,
      [state.mode]: { left: state.leftOpen, right: state.rightOpen },
    };
    const next = panelsByMode[mode];
    const entering3d = mode === '3d' && state.mode !== '3d';
    return {
      ...state,
      mode,
      tool: mode === 'plan' ? 'select' : state.tool,
      selectedConnectionId: null,
      cableStart: null,
      panelsByMode,
      leftOpen: entering3d ? false : next.left,
      rightOpen: entering3d ? false : next.right,
      ...(entering3d ? {
        commandOpen: false,
        diagnosticsOpen: false,
        projectsOpen: false,
        helpOpen: false,
        settingsOpen: false,
        exportOpen: false,
        shortcutsOpen: false,
      } : {}),
    };
  }),
  setTool: (tool) => set({ tool, cableStart: null, selectedConnectionId: null }),
  setCableFilter: (filter) => set({ cableFilter: filter }),
  toggleLayer: (layer) => set((state) => ({ hiddenLayers: state.hiddenLayers.includes(layer) ? state.hiddenLayers.filter((entry) => entry !== layer) : [...state.hiddenLayers, layer] })),
  select: (id, additive = false) => set((state) => {
    if (additive) {
      return state.selectedIds.includes(id)
        ? { selectedIds: state.selectedIds.filter((entry) => entry !== id), selectedConnectionId: null }
        : { selectedIds: [...state.selectedIds, id], selectedConnectionId: null };
    }
    return { selectedIds: [id], selectedConnectionId: null };
  }),
  selectMany: (ids) => set({ selectedIds: [...new Set(ids)], selectedConnectionId: null }),
  selectConnection: (id) => set({ selectedConnectionId: id, selectedIds: [] }),
  clearSelection: () => set({ selectedIds: [], selectedConnectionId: null, cableStart: null, cableTarget: null }),
  pruneSelection: (project) => set((state) => {
    const ids = new Set(project.objects.map((object) => object.id));
    const connections = new Set(project.connections.map((connection) => connection.id));
    return {
      selectedIds: state.selectedIds.filter((id) => ids.has(id)),
      selectedConnectionId: state.selectedConnectionId && connections.has(state.selectedConnectionId) ? state.selectedConnectionId : null,
    };
  }),
  setHoveredObject: (id) => set({ hoveredObjectId: id }),
  setHoveredPort: (value) => set({ hoveredPort: value }),
  setCableStart: (value) => set({ cableStart: value, cableTarget: null }),
  setCableTarget: (value) => set({ cableTarget: value }),
  setPendingAdd: (value) => set({ pendingAdd: value }),
  cancelCable: () => set({ cableStart: null, cableTarget: null }),

  toggleLeft: () => set((state) => {
    const leftOpen = !state.leftOpen;
    try { localStorage.setItem('regrid:left-open', String(leftOpen)); } catch { /* optional */ }
    return { leftOpen, catalogAutoCollapsed: false };
  }),
  toggleRight: () => set((state) => ({
    rightOpen: !state.rightOpen,
    panelsByMode: { ...state.panelsByMode, [state.mode]: { ...state.panelsByMode[state.mode], right: !state.rightOpen } },
  })),
  setTimelineOpen: (timelineOpen) => set({ timelineOpen }),
  setMeshCapabilities: (meshCapabilities) => set((state) => JSON.stringify(state.meshCapabilities) === JSON.stringify(meshCapabilities) ? state : { meshCapabilities }),
  setNavigationMode: (navigationMode) => set({ navigationMode }),
  setRightOpen: (open) => set((state) => ({
    rightOpen: open,
    panelsByMode: { ...state.panelsByMode, [state.mode]: { ...state.panelsByMode[state.mode], right: open } },
  })),
  setLeftWidth: (width) => set({ leftWidth: Math.min(380, Math.max(232, width)) }),
  setRightWidth: (width) => set({ rightWidth: Math.min(460, Math.max(290, width)) }),
  setCatalogQuery: (query) => set({ catalogQuery: query }),
  setCatalogCategory: (category) => set({ catalogCategory: category }),
  toggleHiddenDevices: () => set((state) => ({ showHiddenDevices: !state.showHiddenDevices })),
  setPatchTab: (tab) => set({ patchTab: tab }),
  setDiagnosticsOpen: (open) => set({ diagnosticsOpen: open }),
  openCommand: (open = true) => set({ commandOpen: open }),
  setProjectsOpen: (open) => set({ projectsOpen: open }),
  setNewProjectOpen: (open) => set({ newProjectOpen: open }),
  setHelpOpen: (open) => set({ helpOpen: open }),
  setSettingsOpen: (open) => set({ settingsOpen: open }),
  setExportOpen: (open) => set({ exportOpen: open }),
  setShortcutsOpen: (open) => set({ shortcutsOpen: open }),
  askConfirm: (state) => set({ confirm: state }),
  setImportReport: (report) => set({ importReport: report }),
  pushToast: (message, tone = 'default') => {
    toastId += 1;
    const id = toastId;
    set((state) => ({ toasts: [...state.toasts.slice(-3), { id, message, tone }] }));
    window.setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((toast) => toast.id !== id) }));
    }, 4200);
  },
  dismissToast: (id) => set((state) => ({ toasts: state.toasts.filter((toast) => toast.id !== id) })),
  requestFit: () => set((state) => ({ fitRequest: state.fitRequest + 1 })),
  requestZoom: (direction) => set((state) => ({
    zoomInRequest: direction === 1 ? state.zoomInRequest + 1 : state.zoomInRequest,
    zoomOutRequest: direction === -1 ? state.zoomOutRequest + 1 : state.zoomOutRequest,
  })),
  setDragging: (dragging) => set({ dragging }),
  setTransformMode: (mode) => set({ transformMode: mode }),
  setAssetMaterialMaps: (assetId, slots) => set((state) => ({ assetMaterialMaps: { ...state.assetMaterialMaps, [assetId]: slots } })),
  focusCamera: (id) => set({ cameraFocusId: id }),
  clearCameraFocus: () => set({ cameraFocusId: null }),
  setLightingGroup: (id) => set({ lightingGroupId: id }),
  setPlanCamera: (camera) => set({ planCamera: camera }),
  setCursor: (cursor) => set({ cursor }),
}));
