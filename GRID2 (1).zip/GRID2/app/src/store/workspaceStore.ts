import { create } from 'zustand';
import type { Connection, Guide, LightState, Project, SceneObject } from '../types/project';
import type { CableType } from '../types/catalog';
import { getDevice } from '../lib/catalog';
import { createAreaBar, createCrowd, createLightSource, createModel, createRoom, createSceneObject, createSeating, createStage, createTruss, createWall, getObjectPorts, objectRect, snapObjectToGrid } from '../lib/objects';
import { snapValue } from '../lib/geometry';
import { createBaseProject } from '../lib/baseProject';
import { createPrimitive } from '../lib/primitives';
import { createModifier } from '../lib/modifiers';
import { createProject } from '../lib/project';
import { defaultReactionDiffusion, normalizeReactionDiffusion } from '../lib/reactionDiffusion';
import { createDefaultTimeline } from '../types/timeline';
import { applyAutoPatch } from '../lib/dmx';
import { uid } from '../lib/id';
import { useUiStore } from './uiStore';
import { migrateLegacy, parseProjectFile, saveWorkspace, loadWorkspace } from '../lib/migration';

interface Clipboard {
  objects: SceneObject[];
  connections: Connection[];
}

interface WorkspaceState {
  projects: Project[];
  activeId: string | null;
  past: Project[];
  future: Project[];
  dirty: boolean;
  savedAt: string | null;
  storageError: string | null;
  clipboard: Clipboard | null;
  txSnapshot: Project | null;
  transformClipboard: { position: { x: number; z: number }; elevation: number; rotation: number; rotationX: number; rotationZ: number; scale: { x: number; y: number; z: number } } | null;
  initialized: boolean;

  init: () => void;
  createNewProject: (name: string, width?: number, depth?: number) => void;
  loadDemo: () => void;
  openProject: (id: string) => void;
  duplicateProject: (id: string) => void;
  deleteProject: (id: string) => void;
  renameProject: (name: string) => void;
  importProjectFile: (text: string, name?: string, preserveId?: boolean) => { warnings: string[]; project: Project };
  importLegacyRaw: (raw: unknown) => { warnings: string[]; project: Project };

  mutate: (recipe: (project: Project) => void, history?: boolean) => void;
  mutateTransient: (recipe: (project: Project) => void) => void;
  beginTransaction: () => void;
  endTransaction: () => void;
  cancelTransaction: () => void;
  undo: () => void;
  redo: () => void;
  persistNow: () => void;

  addDevice: (deviceId: string, position: { x: number; z: number }) => void;
  addRoom: (rect: { x: number; z: number; w: number; d: number }) => void;
  addStage: (rect: { x: number; z: number; w: number; d: number }, label?: string) => void;
  addTruss: (rect: { x: number; z: number; w: number; d: number }) => void;
  addSeating: (rect: { x: number; z: number; w: number; d: number }) => void;
  addCrowd: (rect: { x: number; z: number; w: number; d: number }) => void;
  addAreaBar: (position: { x: number; z: number }) => void;
  addModel: (assetId: string, assetName: string) => void;
  addPrimitive: (kind: 'box' | 'sphere' | 'cylinder' | 'plane' | 'cone' | 'torus', position?: { x: number; z: number }) => void;
  addLight: (kind: 'spot' | 'point' | 'area' | 'directional', position?: { x: number; z: number }) => void;
  addWall: (rect: { x: number; z: number; w: number; d: number }) => void;
  addConnection: (from: string, fromPort: string, to: string, toPort: string) => boolean;
  deleteConnection: (id: string) => void;
  updateConnection: (id: string, patch: Partial<Connection>) => void;

  deleteSelection: () => void;
  duplicateSelection: () => void;
  copySelection: () => void;
  pasteClipboard: () => void;
  rotateSelection: (delta?: number) => void;
  nudgeSelection: (dx: number, dz: number) => void;
  lockSelection: (locked?: boolean) => void;
  hideSelection: (visible?: boolean) => void;
  groupSelection: () => void;
  ungroupSelection: () => void;
  updateObject: (id: string, patch: Partial<SceneObject>, history?: boolean) => void;
  updateLight: (ids: string[], patch: Partial<LightState>) => void;
  updateLighting: (patch: Partial<Project['lighting']>) => void;
  updateSceneEffects: (modifiers: Project['effects']) => void;
  updateSignals: (signals: Project['signals']) => void;
  updatePhysics: (patch: Partial<NonNullable<Project['physics']>>) => void;
  updateFields: (fields: Project['fields']) => void;
  updateCustomShaders: (shaders: Project['customShaders']) => void;
  updateReactionDiffusion: (patch: Partial<NonNullable<Project['reactionDiffusion']>>) => void;
  resetReactionDiffusion: () => void;
  addFieldLink: (link: NonNullable<Project['fieldLinks']>[number]) => void;
  removeFieldLink: (id: string) => void;
  setReactionDiffusionModulator: (param: string, modulator: any | null) => void;
  updateShaderValues: (target: { objectId?: string; lookId?: string }, shaderId: string, values: Record<string, number | number[] | boolean>) => void;
  setShaderModulator: (target: { objectId?: string; lookId?: string }, shaderId: string, paramId: string, modulator: NonNullable<NonNullable<Project['looks']>[number]['shaders']>[number]['modulators'] extends Record<string, infer T> | undefined ? T | null : never) => void;
  assignPostShader: (instance: { id?: string; shaderId: string; enabled: boolean; values: Record<string, number | number[] | boolean> }) => void;
  updatePostShaderValues: (passId: string, values: Record<string, number | number[] | boolean>) => void;
  setPostShaderModulator: (passId: string, paramId: string, modulator: any | null) => void;
  movePostShader: (passId: string, delta: number) => void;
  reorderPostShader: (fromId: string, toId: string) => void;
  removePostShader: (passId: string) => void;
  duplicatePostShader: (passId: string) => void;
  togglePostShader: (passId: string, enabled: boolean) => void;
  resetPostHistory: (passId?: string) => void;
  replacePostShader: (passId: string, instance: { shaderId: string; enabled: boolean; values: Record<string, number | number[] | boolean> }) => void;
  assignShader: (target: { objectId?: string; lookId?: string }, instance: NonNullable<Project['customShaders']>[number] extends never ? never : { shaderId: string; enabled: boolean; values: Record<string, number | number[] | boolean> }) => void;
  applyLook: (look: NonNullable<Project['looks']>[number], ids: string[]) => void;
  applySavedLook: (lookId: string, ids: string[]) => void;
  updateLook: (lookId: string, patch: { name?: string; material?: NonNullable<Project['looks']>[number]['material']; modifiers?: NonNullable<Project['looks']>[number]['modifiers'] }) => void;
  makeLookUnique: (objectId: string) => void;
  duplicateLook: (lookId: string) => void;
  deleteLook: (lookId: string) => void;
  updateEffectGroups: (groups: Project['effectGroups']) => void;
  updateSettings: (patch: Partial<Project['settings']>) => void;
  updateView: (patch: Partial<Project['view']['plan']> & { cameraPreset?: Project['view']['cameraPreset'] }) => void;
  addGuide: (axis: 'x' | 'z', position: number) => void;
  updateGuide: (id: string, position: number) => void;
  deleteGuide: (id: string) => void;
  clearGuides: () => void;
  autoPatch: () => void;
  savePreset: (name: string) => void;
  applyPreset: (id: string) => void;
  deletePreset: (id: string) => void;
  createGroup: (name: string) => void;
  deleteGroup: (id: string) => void;
  renameGroup: (id: string, name: string) => void;
  alignSelection: (mode: 'left' | 'center-x' | 'right' | 'top' | 'center-z' | 'bottom') => void;
  distributeSelection: (axis: 'x' | 'z') => void;
  updateSelectionAxis: (kind: 'position' | 'rotation' | 'scale', axis: 'x' | 'y' | 'z', value: number) => void;
  updateSelectionScaleUniform: (value: number) => void;
  alignSelectionAxis: (axis: 'x' | 'y' | 'z') => void;
  distributeSelectionAxis: (axis: 'x' | 'y' | 'z') => void;
  copySelectionTransform: () => void;
  pasteSelectionTransform: () => void;
  resetSelectionRotation: () => void;
  resetSelectionScale: () => void;
  updateSelectionVisibility: (visible: boolean) => void;
  updateSelectionLight: (patch: Partial<NonNullable<SceneObject['light']>>) => void;
  updateSelectionLightCapability: (kind: 'pan' | 'tilt' | 'zoom' | 'focus' | 'strobe', patch: Partial<NonNullable<SceneObject['light']>>) => void;
  updateSelectionMaterial: (patch: NonNullable<SceneObject['material']>) => void;
  addModifierToSelection: (type: string) => void;
  replaceMode: (objectId: string, modeId: string) => void;
  setManualAddress: (objectId: string, address: number | null) => void;
  setPowerState: (objectId: string, on: boolean) => void;
}

function now(): string {
  return new Date().toISOString();
}

function activeProject(state: Pick<WorkspaceState, 'projects' | 'activeId'>): Project | null {
  return state.projects.find((project) => project.id === state.activeId) || null;
}

function replaceProject(projects: Project[], project: Project): Project[] {
  return projects.map((entry) => (entry.id === project.id ? project : entry));
}

function uniqueName(base: string, objects: SceneObject[]): string {
  const names = new Set(objects.map((object) => object.name));
  if (!names.has(base)) return base;
  let index = 2;
  while (names.has(`${base} ${index}`)) index += 1;
  return `${base} ${index}`;
}

function rectCenter(rect: { x: number; z: number; w: number; d: number }): { x: number; z: number } {
  return { x: rect.x + rect.w / 2, z: rect.z + rect.d / 2 };
}

function selectionObjects(project: Project): SceneObject[] {
  const ids = new Set(useUiStore.getState().selectedIds);
  return project.objects.filter((object) => ids.has(object.id));
}

function connectionExists(project: Project, from: string, fromPort: string, to: string, toPort: string): boolean {
  return project.connections.some((connection) => connection.from === from && connection.fromPort === fromPort && connection.to === to && connection.toPort === toPort);
}

function portUsed(project: Project, objectId: string, portId: string, direction: 'in' | 'out'): boolean {
  return project.connections.some((connection) => direction === 'out'
    ? connection.from === objectId && connection.fromPort === portId
    : connection.to === objectId && connection.toPort === portId);
}

function wouldCycle(project: Project, from: string, to: string, type: CableType): boolean {
  const visited = new Set<string>();
  const walk = (id: string): boolean => {
    if (id === from) return true;
    if (visited.has(id)) return false;
    visited.add(id);
    for (const connection of project.connections) {
      if (connection.type !== type) continue;
      if (connection.to === id && walk(connection.from)) return true;
    }
    return false;
  };
  return walk(to);
}

export const useWorkspaceStore = create<WorkspaceState>((set, get) => ({
  projects: [],
  activeId: null,
  past: [],
  future: [],
  dirty: false,
  savedAt: null,
  storageError: null,
  clipboard: null,
  txSnapshot: null,
  transformClipboard: null,
  initialized: false,

  init: () => {
    if (get().initialized) return;
    const { workspace } = loadWorkspace();
    if (workspace && workspace.projects.length) {
      const activeId = workspace.activeProjectId && workspace.projects.some((project) => project.id === workspace.activeProjectId)
        ? workspace.activeProjectId
        : workspace.projects[0].id;
      const projects = workspace.projects.map((project) => ({ ...project, effects: project.effects || [], signals: project.signals || [], effectGroups: project.effectGroups || [], physics: project.physics, fields: project.fields || [], looks: project.looks || [], customShaders: project.customShaders || [], postShaders: project.postShaders || [], timeline: project.timeline ? { ...project.timeline, groupEffects: project.timeline.groupEffects || [] } : createDefaultTimeline() }));
      set({ projects, activeId, initialized: true, dirty: false });
    } else {
      set({ projects: [], activeId: null, initialized: true });
    }
  },

  createNewProject: (name, width = 14, depth = 9) => {
    const project = createProject(name, width, depth, false);
    set((state) => ({
      projects: [project, ...state.projects],
      activeId: project.id,
      past: [],
      future: [],
      dirty: true,
    }));
    useUiStore.getState().clearSelection();
    useUiStore.getState().setMode('plan');
  },

  loadDemo: () => {
    const demo = createBaseProject();
    const existing = get().projects.find((project) => project.id === demo.id);
    if (existing) {
      get().openProject(existing.id);
      useUiStore.getState().setMode('3d');
      return;
    }
    // A fresh workspace seeds the club project itself. Replace an older demo
    // with the same name so the user's current layout is the visible base.
    set((state) => ({
      projects: [demo, ...state.projects.filter((project) => project.id !== demo.id)],
      activeId: demo.id,
      past: [],
      future: [],
      dirty: true,
    }));
    useUiStore.getState().clearSelection();
    useUiStore.getState().setMode('3d');
  },

  openProject: (id) => {
    if (!get().projects.some((project) => project.id === id)) return;
    set({ activeId: id, past: [], future: [], txSnapshot: null });
    useUiStore.getState().clearSelection();
    useUiStore.getState().setMode('plan');
  },

  duplicateProject: (id) => {
    const source = get().projects.find((project) => project.id === id);
    if (!source) return;
    const copy: Project = {
      ...structuredClone(source),
      id: uid('prj'),
      name: `${source.name} · copy`,
      createdAt: now(),
      updatedAt: now(),
    };
    set((state) => ({ projects: [copy, ...state.projects], activeId: copy.id, past: [], future: [], dirty: true }));
    useUiStore.getState().clearSelection();
  },

  deleteProject: (id) => {
    const state = get();
    const remaining = state.projects.filter((project) => project.id !== id);
    const activeId = state.activeId === id ? remaining[0]?.id || null : state.activeId;
    set({ projects: remaining, activeId, past: [], future: [], dirty: true });
    if (state.activeId === id) useUiStore.getState().clearSelection();
  },

  renameProject: (name) => {
    const project = activeProject(get());
    if (!project) return;
    const trimmed = name.trim().slice(0, 120);
    if (!trimmed || trimmed === project.name) return;
    const updated = { ...project, name: trimmed, updatedAt: now() };
    set((state) => ({ projects: replaceProject(state.projects, updated), dirty: true }));
  },

  importProjectFile: (text, name, preserveId = false) => {
    const result = parseProjectFile(text, name || 'Imported project');
    const project = result.project;
    project.id = preserveId && !get().projects.some((entry) => entry.id === project.id) ? project.id : uid('prj');
    project.updatedAt = now();
    set((state) => ({ projects: [project, ...state.projects], activeId: project.id, past: [], future: [], dirty: true }));
    useUiStore.getState().clearSelection();
    return { warnings: result.warnings, project };
  },

  importLegacyRaw: (raw) => {
    const result = migrateLegacy(raw, 'Rig Grid · legacy project');
    const project = result.project;
    project.id = uid('prj');
    project.updatedAt = now();
    set((state) => ({ projects: [project, ...state.projects], activeId: project.id, past: [], future: [], dirty: true }));
    useUiStore.getState().clearSelection();
    return { warnings: result.warnings, project };
  },

  mutate: (recipe, history = true) => {
    if (history && get().txSnapshot) {
      get().mutateTransient(recipe);
      return;
    }
    const state = get();
    const project = activeProject(state);
    if (!project) return;
    const clone = structuredClone(project);
    recipe(clone);
    clone.updatedAt = now();
    set({
      projects: replaceProject(state.projects, clone),
      past: history ? [...state.past.slice(-79), project] : state.past,
      future: history ? [] : state.future,
      dirty: true,
    });
  },

  mutateTransient: (recipe) => {
    const state = get();
    const project = activeProject(state);
    if (!project) return;
    const clone = structuredClone(project);
    recipe(clone);
    clone.updatedAt = now();
    set({ projects: replaceProject(state.projects, clone), dirty: true });
  },

  beginTransaction: () => {
    if (get().txSnapshot) return;
    const project = activeProject(get());
    if (project) set({ txSnapshot: project });
  },

  endTransaction: () => {
    const state = get();
    if (!state.txSnapshot) return;
    const current = activeProject(state);
    if (current && current !== state.txSnapshot) {
      set({ past: [...state.past.slice(-79), state.txSnapshot], future: [], txSnapshot: null });
    } else {
      set({ txSnapshot: null });
    }
  },

  cancelTransaction: () => {
    const state = get();
    if (!state.txSnapshot) return;
    set({ projects: replaceProject(state.projects, state.txSnapshot), txSnapshot: null, dirty: true });
  },

  undo: () => {
    const state = get();
    const project = activeProject(state);
    if (!project || !state.past.length) return;
    const previous = state.past[state.past.length - 1];
    set({
      projects: replaceProject(state.projects, previous),
      past: state.past.slice(0, -1),
      future: [project, ...state.future].slice(0, 80),
      dirty: true,
      txSnapshot: null,
    });
    useUiStore.getState().pruneSelection(previous);
  },

  redo: () => {
    const state = get();
    const project = activeProject(state);
    if (!project || !state.future.length) return;
    const next = state.future[0];
    set({
      projects: replaceProject(state.projects, next),
      past: [...state.past.slice(-79), project],
      future: state.future.slice(1),
      dirty: true,
      txSnapshot: null,
    });
    useUiStore.getState().pruneSelection(next);
  },

  persistNow: () => {
    const state = get();
    const ok = saveWorkspace({ schemaVersion: 1, activeProjectId: state.activeId, projects: state.projects });
    set({ dirty: !ok, savedAt: ok ? now() : state.savedAt, storageError: ok ? null : 'Could not save to localStorage: storage is full or unavailable.' });
  },

  addDevice: (deviceId, position) => {
    const device = getDevice(deviceId);
    if (!device) return;
    const state = get();
    const project = activeProject(state);
    if (!project) return;
    const name = uniqueName(device.shortName, project.objects);
    const object = createSceneObject(deviceId, position, { name });
    if (object.light) {
      object.light = { ...object.light, intensity: device.capabilities.dimmer ? 0.8 : 1 };
    }
    state.mutate((draft) => {
      draft.objects.push(object);
    });
    useUiStore.getState().select(object.id);
  },

  addRoom: (rect) => {
    const project = activeProject(get());
    if (!project) return;
    const room = createRoom(rectCenter(rect), { w: Math.max(1, rect.w), d: Math.max(1, rect.d) }, 4.8, uniqueName('Venue', project.objects));
    room.locked = false;
    get().mutate((draft) => {
      draft.objects.push(room);
    });
    useUiStore.getState().select(room.id);
  },

  addStage: (rect, label = 'Stage') => {
    const project = activeProject(get());
    if (!project) return;
    const stage = createStage(rectCenter(rect), { w: Math.max(1, rect.w), d: Math.max(1, rect.d), h: label === 'Zone' ? 0.04 : 0.45 }, uniqueName(label, project.objects));
    stage.stage = { color: label === 'Zone' ? '#1a2026' : '#242a30', label };
    get().mutate((draft) => {
      draft.objects.push(stage);
    });
    useUiStore.getState().select(stage.id);
  },

  addWall: (rect) => {
    const project = activeProject(get());
    if (!project) return;
    const horizontal = rect.w >= rect.d;
    const center = { x: rect.x + rect.w / 2, z: rect.z + rect.d / 2 };
    const wall = createWall(center, horizontal ? rect.w : rect.d, horizontal ? 0 : 90, uniqueName('Wall', project.objects));
    get().mutate((draft) => {
      draft.objects.push(wall);
    });
    useUiStore.getState().select(wall.id);
  },

  addTruss: (rect) => {
    const project = activeProject(get());
    if (!project) return;
    const horizontal = rect.w >= rect.d;
    const truss = createTruss(rectCenter(rect), Math.max(1, horizontal ? rect.w : rect.d), uniqueName('Truss', project.objects));
    truss.rotation = horizontal ? 0 : 90;
    truss.size = { w: Math.max(1, horizontal ? rect.w : rect.d), d: 0.29, h: 0.29 };
    truss.elevation = 4.5;
    get().mutate((draft) => {
      draft.objects.push(truss);
    });
    useUiStore.getState().select(truss.id);
  },

  addPrimitive: (kind, position = { x: 0, z: 0 }) => {
    const project = activeProject(get());
    if (!project) return;
    const object = createPrimitive(kind, position);
    get().mutate((draft) => { draft.objects.push(object); });
    useUiStore.getState().select(object.id);
    useUiStore.getState().setTool('select');
  },

  addModel: (assetId, assetName) => {
    const project = activeProject(get());
    if (!project) return;
    const model = createModel(assetId, assetName, { x: 0, z: 0 });
    get().mutate((draft) => { draft.objects.push(model); });
    useUiStore.getState().select(model.id);
    useUiStore.getState().setTool('select');
  },

  addLight: (kind, position = { x: 0, z: 0 }) => {
    const project = activeProject(get());
    if (!project) return;
    const light = createLightSource(kind, position);
    get().mutate((draft) => { draft.objects.push(light); });
    useUiStore.getState().select(light.id);
    useUiStore.getState().setTool('select');
  },

  addAreaBar: (position) => {
    const project = activeProject(get());
    if (!project) return;
    const bar = createAreaBar(position, uniqueName('Area Bar', project.objects));
    get().mutate((draft) => {
      draft.objects.push(bar);
    });
    useUiStore.getState().select(bar.id);
    useUiStore.getState().setTool('select');
  },

  addCrowd: (rect) => {
    const project = activeProject(get());
    if (!project) return;
    const crowd = createCrowd(rectCenter(rect), { w: Math.max(1, rect.w), d: Math.max(1, rect.d) }, uniqueName('Crowd', project.objects));
    get().mutate((draft) => {
      draft.objects.push(crowd);
    });
    useUiStore.getState().select(crowd.id);
  },

  addSeating: (rect) => {
    const project = activeProject(get());
    if (!project) return;
    const seating = createSeating(rectCenter(rect), { w: Math.max(1, rect.w), d: Math.max(1, rect.d) }, uniqueName('Seating', project.objects));
    get().mutate((draft) => {
      draft.objects.push(seating);
    });
    useUiStore.getState().select(seating.id);
  },

  addConnection: (from, fromPort, to, toPort) => {
    const project = activeProject(get());
    if (!project || from === to) return false;
    const fromObject = project.objects.find((object) => object.id === from);
    const toObject = project.objects.find((object) => object.id === to);
    if (!fromObject || !toObject) return false;
    let fromDef = getObjectPorts(fromObject).find((port) => port.id === fromPort);
    let toDef = getObjectPorts(toObject).find((port) => port.id === toPort);
    if (!fromDef || !toDef || fromDef.type !== toDef.type) return false;
    let fromId = from;
    let fromPortId = fromPort;
    let toId = to;
    let toPortId = toPort;
    if (fromDef.direction === 'in' && toDef.direction === 'out') {
      [fromId, toId] = [toId, fromId];
      [fromPortId, toPortId] = [toPortId, fromPortId];
      [fromDef, toDef] = [toDef, fromDef];
    }
    if (fromDef.direction === 'in' || toDef.direction === 'out') return false;
    if (portUsed(project, fromId, fromPortId, 'out') || portUsed(project, toId, toPortId, 'in')) return false;
    if (connectionExists(project, fromId, fromPortId, toId, toPortId)) return false;
    if (wouldCycle(project, fromId, toId, fromDef.type)) return false;
    const connection: Connection = { id: uid('cbl'), type: fromDef.type, from: fromId, fromPort: fromPortId, to: toId, toPort: toPortId, waypoints: [], note: '' };
    get().mutate((draft) => {
      draft.connections.push(connection);
    });
    useUiStore.getState().selectConnection(connection.id);
    return true;
  },

  deleteConnection: (id) => {
    get().mutate((draft) => {
      draft.connections = draft.connections.filter((connection) => connection.id !== id);
    });
    useUiStore.setState((state) => ({ selectedConnectionId: state.selectedConnectionId === id ? null : state.selectedConnectionId }));
  },

  updateConnection: (id, patch) => {
    get().mutate((draft) => {
      const connection = draft.connections.find((entry) => entry.id === id);
      if (connection) Object.assign(connection, patch);
    });
  },

  deleteSelection: () => {
    const ids = new Set(useUiStore.getState().selectedIds);
    if (!ids.size) return;
    get().mutate((draft) => {
      draft.objects = draft.objects.filter((object) => !ids.has(object.id));
      draft.connections = draft.connections.filter((connection) => !ids.has(connection.from) && !ids.has(connection.to));
    });
    useUiStore.getState().clearSelection();
  },

  copySelection: () => {
    const project = activeProject(get());
    if (!project) return;
    const selected = selectionObjects(project);
    if (!selected.length) return;
    const ids = new Set(selected.map((object) => object.id));
    const connections = project.connections.filter((connection) => ids.has(connection.from) && ids.has(connection.to));
    set({ clipboard: { objects: structuredClone(selected), connections: structuredClone(connections) } });
  },

  pasteClipboard: () => {
    const clipboard = get().clipboard;
    if (!clipboard) return;
    const idMap = new Map<string, string>();
    const groupMap = new Map<string, string>();
    const objects = clipboard.objects.map((object) => {
      const id = uid('obj');
      idMap.set(object.id, id);
      let groupId = object.groupId;
      if (groupId) {
        if (!groupMap.has(groupId)) groupMap.set(groupId, uid('grp'));
        groupId = groupMap.get(groupId)!;
      }
      return { ...structuredClone(object), id, groupId, position: { x: object.position.x + 0.5, z: object.position.z + 0.5 }, name: object.name };
    });
    const connections = clipboard.connections.map((connection) => ({
      ...structuredClone(connection),
      id: uid('cbl'),
      from: idMap.get(connection.from) || connection.from,
      to: idMap.get(connection.to) || connection.to,
    }));
    get().mutate((draft) => {
      draft.objects.push(...objects);
      draft.connections.push(...connections);
    });
    useUiStore.getState().selectMany(objects.map((object) => object.id));
  },

  duplicateSelection: () => {
    get().copySelection();
    get().pasteClipboard();
  },

  rotateSelection: (delta = 90) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        if (object.type === 'room') continue;
        object.rotation = ((object.rotation + delta + 360) % 360) as SceneObject['rotation'];
        snapObjectToGrid(object, draft.settings.gridSize);
      }
    });
  },

  nudgeSelection: (dx, dz) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        object.position.x = Math.round((object.position.x + dx) * 1000) / 1000;
        object.position.z = Math.round((object.position.z + dz) * 1000) / 1000;
      }
    });
  },

  lockSelection: (locked = true) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) if (ids.has(object.id)) object.locked = locked;
    });
  },

  hideSelection: (visible = false) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) if (ids.has(object.id)) object.visible = visible;
    });
  },

  groupSelection: () => {
    const ids = useUiStore.getState().selectedIds;
    if (ids.length < 2) return;
    const groupId = uid('grp');
    get().mutate((draft) => {
      for (const object of draft.objects) if (ids.includes(object.id)) object.groupId = groupId;
    });
  },

  ungroupSelection: () => {
    const ids = new Set(useUiStore.getState().selectedIds);
    const project = activeProject(get());
    if (!project) return;
    const groups = new Set(project.objects.filter((object) => ids.has(object.id)).map((object) => object.groupId).filter(Boolean));
    get().mutate((draft) => {
      for (const object of draft.objects) if (object.groupId && groups.has(object.groupId)) object.groupId = null;
    });
  },

  updateObject: (id, patch, history = true) => {
    get().mutate((draft) => {
      const object = draft.objects.find((entry) => entry.id === id);
      if (object) Object.assign(object, patch);
    }, history);
  },

  updateLight: (ids, patch) => {
    const setIds = new Set(ids);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!setIds.has(object.id) || !object.light) continue;
        object.light = { ...object.light, ...patch };
      }
      draft.lighting.activePresetId = null;
    });
  },

  updateLighting: (patch) => {
    get().mutate((draft) => {
      draft.lighting = { ...draft.lighting, ...patch };
    });
  },

  updateSceneEffects: (modifiers) => {
    get().mutate((draft) => {
      draft.effects = modifiers || [];
    });
  },

  updateSignals: (signals) => {
    get().mutate((draft) => {
      draft.signals = signals || [];
    });
  },

  updateFields: (fields) => {
    get().mutate((draft) => { draft.fields = fields || []; });
  },

  updateReactionDiffusion: (patch) => {
    get().mutate((draft) => {
      const current = draft.reactionDiffusion || defaultReactionDiffusion();
      draft.reactionDiffusion = normalizeReactionDiffusion({ ...current, ...patch });
    });
  },

  setReactionDiffusionModulator: (param, modulator) => {
    get().mutate((draft) => {
      const current = draft.reactionDiffusion || defaultReactionDiffusion();
      const modulators = { ...(current.modulators || {}) };
      if (modulator) modulators[param] = modulator; else delete modulators[param];
      draft.reactionDiffusion = { ...current, modulators };
    });
  },

  addFieldLink: (link) => {
    get().mutate((draft) => {
      draft.fieldLinks = [...(draft.fieldLinks || []).filter((entry) => !(entry.modifierId === link.modifierId && entry.slot === link.slot)), link];
      const modifier = [...draft.objects.flatMap((object) => object.modifiers || []), ...(draft.looks || []).flatMap((look) => look.modifiers || [])].find((entry) => entry.id === link.modifierId);
      if (modifier) { modifier.enabled = true; modifier.params = { ...modifier.params, output: link.output }; }
    });
  },

  removeFieldLink: (id) => {
    get().mutate((draft) => {
      const link = (draft.fieldLinks || []).find((entry) => entry.id === id);
      draft.fieldLinks = (draft.fieldLinks || []).filter((entry) => entry.id !== id);
      if (!link) return;
      const modifier = [...draft.objects.flatMap((object) => object.modifiers || []), ...(draft.looks || []).flatMap((look) => look.modifiers || [])].find((entry) => entry.id === link.modifierId);
      if (modifier) modifier.params = { ...modifier.params, output: 'scalar' };
    });
  },

  resetReactionDiffusion: () => {
    get().mutate((draft) => {
      const current = draft.reactionDiffusion || defaultReactionDiffusion();
      draft.reactionDiffusion = { ...current, resetToken: (current.resetToken || 0) + 1 };
    });
  },

  updateCustomShaders: (shaders) => {
    get().mutate((draft) => { draft.customShaders = shaders || []; });
  },

  setShaderModulator: (target, shaderId, paramId, modulator) => {
    get().mutate((draft) => {
      const list = target.lookId ? draft.looks?.find((entry) => entry.id === target.lookId)?.shaders : draft.objects.find((entry) => entry.id === target.objectId)?.shaders;
      const instance = list?.find((entry) => entry.shaderId === shaderId);
      if (!instance) return;
      const mods = { ...(instance.modulators || {}) };
      if (modulator) mods[paramId] = modulator; else delete mods[paramId];
      instance.modulators = mods;
    });
  },

  updateShaderValues: (target, shaderId, values) => {
    get().mutate((draft) => {
      const list = target.lookId ? draft.looks?.find((entry) => entry.id === target.lookId)?.shaders : draft.objects.find((entry) => entry.id === target.objectId)?.shaders;
      const instance = list?.find((entry) => entry.shaderId === shaderId);
      if (instance) instance.values = { ...instance.values, ...values };
    });
  },

  assignPostShader: (instance) => {
    get().mutate((draft) => {
      draft.postShaders = [...(draft.postShaders || []), { ...instance, id: instance.id || `pass_${crypto.randomUUID()}` }];
    });
  },

  updatePostShaderValues: (passId, values) => {
    get().mutate((draft) => {
      const instance = draft.postShaders?.find((entry) => (entry.id || entry.shaderId) === passId);
      if (instance) instance.values = { ...instance.values, ...values };
    });
  },

  setPostShaderModulator: (passId, paramId, modulator) => {
    get().mutate((draft) => {
      const instance = draft.postShaders?.find((entry) => (entry.id || entry.shaderId) === passId);
      if (!instance) return;
      const mods = { ...(instance.modulators || {}) };
      if (modulator) mods[paramId] = modulator; else delete mods[paramId];
      instance.modulators = mods;
    });
  },

  movePostShader: (passId, delta) => {
    get().mutate((draft) => {
      const list = draft.postShaders || [];
      const index = list.findIndex((entry) => (entry.id || entry.shaderId) === passId);
      const target = index + delta;
      if (index < 0 || target < 0 || target >= list.length) return;
      [list[index], list[target]] = [list[target], list[index]];
      draft.postShaders = list;
    });
  },

  reorderPostShader: (fromId, toId) => {
    get().mutate((draft) => {
      const list = draft.postShaders || [];
      const from = list.findIndex((entry) => (entry.id || entry.shaderId) === fromId);
      const to = list.findIndex((entry) => (entry.id || entry.shaderId) === toId);
      if (from < 0 || to < 0 || from === to) return;
      const [moved] = list.splice(from, 1);
      list.splice(to, 0, moved);
      draft.postShaders = list;
    });
  },

  removePostShader: (passId) => {
    get().mutate((draft) => { draft.postShaders = (draft.postShaders || []).filter((entry) => (entry.id || entry.shaderId) !== passId); });
  },

  duplicatePostShader: (passId) => {
    get().mutate((draft) => {
      const list = draft.postShaders || [];
      const index = list.findIndex((entry) => (entry.id || entry.shaderId) === passId);
      if (index < 0) return;
      const original = list[index];
      const asset = draft.customShaders?.find((entry) => entry.id === original.shaderId);
      if (!asset) return;
      const copy = structuredClone(asset);
      copy.id = `shader_${crypto.randomUUID()}`;
      copy.name = `${asset.name} Copy`;
      copy.createdAt = new Date().toISOString();
      copy.updatedAt = copy.createdAt;
      draft.customShaders = [...(draft.customShaders || []), copy];
      draft.postShaders = [...list.slice(0, index + 1), { ...structuredClone(original), id: `pass_${crypto.randomUUID()}`, shaderId: copy.id, values: { ...original.values } }, ...list.slice(index + 1)];
    });
  },

  togglePostShader: (passId, enabled) => {
    get().mutate((draft) => {
      const instance = draft.postShaders?.find((entry) => (entry.id || entry.shaderId) === passId);
      if (instance) instance.enabled = enabled;
    });
  },

  resetPostHistory: (passId) => {
    get().mutate((draft) => {
      for (const instance of draft.postShaders || []) {
        if (passId && (instance.id || instance.shaderId) !== passId) continue;
        instance.historyResetToken = (instance.historyResetToken || 0) + 1;
      }
    });
  },

  replacePostShader: (passId, instance) => {
    get().mutate((draft) => {
      const list = draft.postShaders || [];
      const index = list.findIndex((entry) => (entry.id || entry.shaderId) === passId);
      if (index < 0) return;
      list[index] = { ...instance, id: list[index].id || `pass_${crypto.randomUUID()}` };
      draft.postShaders = list;
    });
  },

  assignShader: (target, instance) => {
    get().mutate((draft) => {
      if (target.lookId) {
        const look = draft.looks?.find((entry) => entry.id === target.lookId);
        if (look) look.shaders = [...(look.shaders || []).filter((entry) => entry.shaderId !== instance.shaderId), instance];
      } else if (target.objectId) {
        const object = draft.objects.find((entry) => entry.id === target.objectId);
        if (object) object.shaders = [...(object.shaders || []).filter((entry) => entry.shaderId !== instance.shaderId), instance];
      }
    });
  },

  applyLook: (look, ids) => {
    get().mutate((draft) => {
      draft.looks = [...(draft.looks || []).filter((entry) => entry.id !== look.id), look];
      const set = new Set(ids);
      for (const object of draft.objects) if (set.has(object.id)) { object.lookId = look.id; object.material = null; object.materialOverrides = {}; }
    });
  },

  applySavedLook: (lookId, ids) => {
    get().mutate((draft) => {
      const look = draft.looks?.find((entry) => entry.id === lookId);
      if (!look) return;
      const set = new Set(ids);
      for (const object of draft.objects) if (set.has(object.id)) { object.lookId = look.id; object.material = null; object.materialOverrides = {}; }
    });
  },

  updateLook: (lookId, patch) => {
    get().mutate((draft) => {
      draft.looks = (draft.looks || []).map((look) => look.id === lookId ? { ...look, ...patch, material: patch.material || look.material, modifiers: patch.modifiers || look.modifiers } : look);
    });
  },

  makeLookUnique: (objectId) => {
    get().mutate((draft) => {
      const object = draft.objects.find((entry) => entry.id === objectId);
      const look = draft.looks?.find((entry) => entry.id === object?.lookId);
      if (!object || !look) return;
      const copy = { ...structuredClone(look), id: `look_${crypto.randomUUID()}`, name: `${look.name} Unique` };
      // A unique Look owns its shader graph. Cloning only the instance would
      // keep source and uniforms shared with every other Look user.
      for (const instance of copy.shaders || []) {
        const asset = draft.customShaders?.find((entry) => entry.id === instance.shaderId);
        if (!asset) continue;
        const shaderCopy = { ...structuredClone(asset), id: `shader_${crypto.randomUUID()}`, name: `${asset.name} Unique`, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        draft.customShaders = [...(draft.customShaders || []), shaderCopy];
        instance.shaderId = shaderCopy.id;
      }
      const modifierIds = new Map<string, string>();
      copy.modifiers = (copy.modifiers || []).map((modifier) => {
        const nextId = `mod_${crypto.randomUUID()}`;
        modifierIds.set(modifier.id, nextId);
        return { ...modifier, id: nextId };
      });
      for (const modifier of copy.modifiers || []) {
        if (!modifier.modulators) continue;
        modifier.modulators = Object.fromEntries(Object.entries(modifier.modulators).map(([key, modulator]) => [key, modulator.sourceType === 'modifier' && modifierIds.has(modulator.sourceId) ? { ...modulator, sourceId: modifierIds.get(modulator.sourceId)! } : modulator]));
      }
      const clonedLinks = (draft.fieldLinks || []).filter((link) => modifierIds.has(link.modifierId)).map((link) => ({ ...structuredClone(link), id: `field_${crypto.randomUUID()}`, modifierId: modifierIds.get(link.modifierId)! }));
      if (clonedLinks.length) draft.fieldLinks = [...(draft.fieldLinks || []), ...clonedLinks];
      draft.looks = [...(draft.looks || []), copy];
      object.lookId = copy.id;
    });
  },

  duplicateLook: (lookId) => {
    get().mutate((draft) => {
      const look = draft.looks?.find((entry) => entry.id === lookId);
      if (!look) return;
      draft.looks = [...(draft.looks || []), { ...structuredClone(look), id: `look_${crypto.randomUUID()}`, name: `${look.name} Copy` }];
    });
  },

  deleteLook: (lookId) => {
    get().mutate((draft) => {
      draft.looks = (draft.looks || []).filter((look) => look.id !== lookId);
      for (const object of draft.objects) if (object.lookId === lookId) object.lookId = undefined;
    });
  },

  updatePhysics: (patch) => {
    get().mutate((draft) => {
      draft.physics = { ...(draft.physics || { enabled: false, gravity: { x: 0, y: -9.81, z: 0 }, timeScale: 1, paused: false, debug: false, quality: 'medium', resetToken: 0, stepToken: 0 }), ...patch } as NonNullable<Project['physics']>;
    });
  },

  updateEffectGroups: (groups) => {
    get().mutate((draft) => {
      draft.effectGroups = groups || [];
    });
  },

  updateSettings: (patch) => {
    get().mutate((draft) => {
      draft.settings = { ...draft.settings, ...patch };
    });
  },

  updateView: (patch) => {
    get().mutateTransient((draft) => {
      const { cameraPreset, ...plan } = patch;
      draft.view.plan = { ...draft.view.plan, ...plan };
      if (cameraPreset) draft.view.cameraPreset = cameraPreset;
    });
    // View changes should not mark the project dirty in the same way as content.
    set({ dirty: get().dirty });
  },

  addGuide: (axis, position) => {
    const guide: Guide = { id: uid('gd'), axis, position };
    get().mutate((draft) => {
      draft.guides.push(guide);
    });
  },

  updateGuide: (id, position) => {
    get().mutateTransient((draft) => {
      const guide = draft.guides.find((entry) => entry.id === id);
      if (guide) guide.position = position;
    });
  },

  deleteGuide: (id) => {
    get().mutate((draft) => {
      draft.guides = draft.guides.filter((guide) => guide.id !== id);
    });
  },

  clearGuides: () => {
    get().mutate((draft) => {
      draft.guides = [];
    });
  },

  autoPatch: () => {
    const project = activeProject(get());
    if (!project) return;
    const objects = applyAutoPatch(project);
    get().mutate((draft) => {
      draft.objects = objects;
    });
  },

  savePreset: (name) => {
    const project = activeProject(get());
    if (!project) return;
    const values = Object.fromEntries(project.objects.filter((object) => object.light).map((object) => [object.id, { ...object.light }]));
    get().mutate((draft) => {
      draft.lighting.presets.push({
        id: uid('pst'),
        name: name.trim() || `Preset ${draft.lighting.presets.length + 1}`,
        createdAt: now(),
        values,
      });
      draft.lighting.activePresetId = null;
    });
  },

  applyPreset: (id) => {
    get().mutate((draft) => {
      const preset = draft.lighting.presets.find((entry) => entry.id === id);
      if (!preset) return;
      for (const object of draft.objects) {
        if (!object.light) continue;
        const values = preset.values[object.id];
        if (values) object.light = { ...object.light, ...values };
      }
      draft.lighting.activePresetId = id;
    });
  },

  deletePreset: (id) => {
    get().mutate((draft) => {
      draft.lighting.presets = draft.lighting.presets.filter((preset) => preset.id !== id);
      if (draft.lighting.activePresetId === id) draft.lighting.activePresetId = null;
    });
  },

  createGroup: (name) => {
    const ids = useUiStore.getState().selectedIds;
    if (!ids.length) return;
    get().mutate((draft) => {
      draft.lighting.groups.push({ id: uid('grp'), name: name.trim() || `Group ${draft.lighting.groups.length + 1}`, memberIds: [...ids] });
    });
  },

  deleteGroup: (id) => {
    get().mutate((draft) => {
      draft.lighting.groups = draft.lighting.groups.filter((group) => group.id !== id);
    });
  },

  renameGroup: (id, name) => {
    get().mutate((draft) => {
      const group = draft.lighting.groups.find((entry) => entry.id === id);
      if (group) group.name = name.trim() || group.name;
    });
  },

  updateSelectionAxis: (kind, axis, value) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        if (kind === 'position') {
          if (axis === 'y') object.elevation = value;
          else object.position[axis] = value;
        } else if (kind === 'rotation') {
          if (axis === 'x') object.rotationX = value;
          else if (axis === 'y') object.rotation = value;
          else object.rotationZ = value;
        } else if (object.type === 'model') {
          const scale = object.scale || { x: 1, y: 1, z: 1 };
          object.scale = { ...scale, [axis]: Math.max(0.001, value) };
        }
      }
    });
  },

  updateSelectionScaleUniform: (value) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.type !== 'model' || object.locked) continue;
        const next = Math.max(0.001, value);
        object.scale = { x: next, y: next, z: next };
      }
    });
  },

  alignSelectionAxis: (axis) => {
    const ids = useUiStore.getState().selectedIds;
    const project = activeProject(get());
    if (!project || ids.length < 2) return;
    const primary = project.objects.find((object) => object.id === ids[0]);
    if (!primary) return;
    const value = axis === 'x' ? primary.position.x : axis === 'y' ? primary.elevation : primary.position.z;
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.includes(object.id) || object.locked) continue;
        if (axis === 'y') object.elevation = value;
        else object.position[axis] = value;
      }
    });
  },

  distributeSelectionAxis: (axis) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    const project = activeProject(get());
    if (!project || ids.size < 3) return;
    const objects = project.objects.filter((object) => ids.has(object.id) && !object.locked);
    if (objects.length < 3) return;
    const valueOf = (object: SceneObject) => axis === 'x' ? object.position.x : axis === 'y' ? object.elevation : object.position.z;
    const sorted = [...objects].sort((a, b) => valueOf(a) - valueOf(b));
    const first = valueOf(sorted[0]);
    const last = valueOf(sorted[sorted.length - 1]);
    const step = (last - first) / (sorted.length - 1);
    const values = new Map(sorted.map((object, index) => [object.id, first + step * index]));
    get().mutate((draft) => {
      for (const object of draft.objects) {
        const next = values.get(object.id);
        if (next === undefined) continue;
        if (axis === 'y') object.elevation = next;
        else object.position[axis] = next;
      }
    });
  },

  copySelectionTransform: () => {
    const ids = useUiStore.getState().selectedIds;
    const project = activeProject(get());
    const object = project?.objects.find((entry) => entry.id === ids[0]);
    if (!object) return;
    set({ transformClipboard: { position: { ...object.position }, elevation: object.elevation, rotation: object.rotation, rotationX: object.rotationX || 0, rotationZ: object.rotationZ || 0, scale: { ...(object.scale || { x: 1, y: 1, z: 1 }) } } });
  },

  pasteSelectionTransform: () => {
    const clipboard = get().transformClipboard;
    if (!clipboard) return;
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        object.position = { ...clipboard.position };
        object.elevation = clipboard.elevation;
        object.rotation = clipboard.rotation;
        object.rotationX = clipboard.rotationX;
        object.rotationZ = clipboard.rotationZ;
        if (object.type === 'model') object.scale = { ...clipboard.scale };
      }
    });
  },

  resetSelectionRotation: () => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        object.rotation = 0;
        object.rotationX = 0;
        object.rotationZ = 0;
      }
    });
  },

  resetSelectionScale: () => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.type !== 'model' || object.locked) continue;
        object.scale = { x: 1, y: 1, z: 1 };
      }
    });
  },

  updateSelectionVisibility: (visible) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) if (ids.has(object.id) && !object.locked) object.modelVisible = visible;
    });
  },

  updateSelectionLight: (patch) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || !object.light || object.locked) continue;
        object.light = { ...object.light, ...patch };
      }
      draft.lighting.activePresetId = null;
    });
  },

  updateSelectionLightCapability: (kind, patch) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || !object.light || object.type !== 'device' || object.locked) continue;
        const device = getDevice(object.deviceId);
        if (!device?.capabilities?.[kind]) continue;
        object.light = { ...object.light, ...patch };
      }
      draft.lighting.activePresetId = null;
    });
  },

  updateSelectionMaterial: (patch) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.type !== 'model' || object.locked) continue;
        object.material = { ...(object.material || {}), ...patch };
      }
    });
  },

  addModifierToSelection: (type) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    get().mutate((draft) => {
      for (const object of draft.objects) {
        if (!ids.has(object.id) || object.locked) continue;
        const allowed = object.type === 'model' || object.type === 'light' || object.type === 'device';
        if (!allowed) continue;
        object.modifiers = [...(object.modifiers || []), createModifier(type)];
      }
    });
  },

  alignSelection: (mode) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    const project = activeProject(get());
    if (!project || ids.size < 2) return;
    const objects = project.objects.filter((object) => ids.has(object.id) && !object.locked);
    if (objects.length < 2) return;
    const rects = objects.map((object) => ({ object, rect: objectRect(object) }));
    const grid = project.settings.gridSize;
    const left = snapValue(Math.min(...rects.map((entry) => entry.rect.x)), grid);
    const right = snapValue(Math.max(...rects.map((entry) => entry.rect.x + entry.rect.w)), grid);
    const top = snapValue(Math.min(...rects.map((entry) => entry.rect.z)), grid);
    const bottom = snapValue(Math.max(...rects.map((entry) => entry.rect.z + entry.rect.d)), grid);
    const centerX = (left + right) / 2;
    const centerZ = (top + bottom) / 2;
    get().mutate((draft) => {
      for (const { object, rect } of rects) {
        const target = draft.objects.find((entry) => entry.id === object.id);
        if (!target) continue;
        if (mode === 'left') target.position.x = left + rect.w / 2;
        if (mode === 'right') target.position.x = right - rect.w / 2;
        if (mode === 'center-x') target.position.x = centerX;
        if (mode === 'top') target.position.z = top + rect.d / 2;
        if (mode === 'bottom') target.position.z = bottom - rect.d / 2;
        if (mode === 'center-z') target.position.z = centerZ;
      }
    });
  },

  distributeSelection: (axis) => {
    const ids = new Set(useUiStore.getState().selectedIds);
    const project = activeProject(get());
    if (!project || ids.size < 3) return;
    const objects = project.objects
      .filter((object) => ids.has(object.id) && !object.locked)
      .sort((a, b) => objectRect(a)[axis === 'x' ? 'x' : 'z'] - objectRect(b)[axis === 'x' ? 'x' : 'z']);
    if (objects.length < 3) return;
    const rects = objects.map(objectRect);
    const first = rects[0][axis === 'x' ? 'x' : 'z'];
    const last = rects[rects.length - 1][axis === 'x' ? 'x' : 'z'] + rects[rects.length - 1][axis === 'x' ? 'w' : 'd'];
    const total = rects.reduce((sum, rect) => sum + (axis === 'x' ? rect.w : rect.d), 0);
    const gap = (last - first - total) / (objects.length - 1);
    let cursor = first;
    get().mutate((draft) => {
      for (const [index, object] of objects.entries()) {
        const target = draft.objects.find((entry) => entry.id === object.id);
        const rect = rects[index];
        const size = axis === 'x' ? rect.w : rect.d;
        if (target) target.position[axis] = cursor + size / 2;
        cursor += size + gap;
      }
    });
  },

  replaceMode: (objectId, modeId) => {
    get().mutate((draft) => {
      const object = draft.objects.find((entry) => entry.id === objectId);
      if (!object?.fixture) return;
      object.fixture.modeId = modeId;
      object.fixture.manualAddress = false;
      object.fixture.address = null;
    });
  },

  setManualAddress: (objectId, address) => {
    get().mutate((draft) => {
      const object = draft.objects.find((entry) => entry.id === objectId);
      if (!object?.fixture) return;
      if (address === null) {
        object.fixture.manualAddress = false;
        object.fixture.address = null;
      } else {
        object.fixture.manualAddress = true;
        object.fixture.address = Math.max(1, Math.min(512, Math.round(address)));
      }
    });
  },

  setPowerState: (objectId, on) => {
    get().mutate((draft) => {
      const object = draft.objects.find((entry) => entry.id === objectId);
      if (object?.fixture) object.fixture.powerOn = on;
    });
  },
}));

export function useActiveProject(): Project | null {
  return useWorkspaceStore((state) => state.projects.find((project) => project.id === state.activeId) || null);
}

export function useProjectList(): Project[] {
  return useWorkspaceStore((state) => state.projects);
}
