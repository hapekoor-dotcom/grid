# Editor usability pass

## Pointer ownership

- CameraControls left button is `none`. LMB is reserved for editor selection and gizmo handles.
- RMB orbits, MMB pans.
- The runtime maintains one interaction owner: NONE / SELECT / GIZMO / CAMERA / UI.
- `resetPointerInteraction` clears owner, pointer id, buttons, capture, gizmo drag and camera input.
- Debug overlay is available at `?inputDebug=1` with camera distance/clip/radius readouts.

## Camera / world range

- Scene bounds are calculated from object positions, dimensions and effect expansion.
- Near/far clips adapt to camera distance and effective scene radius.
- Volumetric fog max distance follows far clip.
- `F` frames selection, `Shift+F` frames the effective scene.
- Camera zoom is not capped to venue dimensions.

## Culling

- Meshes with shader deformation disable frustum culling individually because CPU AABBs do not include vertex displacement.
- Effective scene bounds include effect expansion for camera framing.

## Inspector

- One `.panel-body` scroll container per Inspector.
- Verified at 768 px with Material, Modifiers, shader effects and Rendering expanded; final section reachable and canvas receives zero wheel events.

## GLB Look

- Material → Import Look parses a GLB material, factors and embedded texture bufferViews.
- Textures are stored in the local asset store.
- Looks are saved in `project.looks` and can be re-applied.
- Multi-selection can apply the same look in one Undo step.

## Remaining

- Custom shader import/Shader Lab is not implemented.
- GLB Look application copies material data per object; shared live-editable looks are not complete.

## Shared Look update

Objects now reference `lookId`. Material edits and shader-stack edits made while
a Look is active update `project.looks`, so every referencing object updates.
`Make Unique` clones the Look and switches only that object. The prior copied
material behavior is removed.
