# Optional physics layer

Physics is opt-in at `project.physics.enabled`. Nothing is imported or
simulated while it is disabled.

Runtime uses a lazily imported `cannon-es` world. Project JSON stores
configuration only; simulation transforms are runtime state, not Undo history.

## Global

- Enabled
- Gravity X/Y/Z
- Simulation speed
- Pause / Step one frame / Reset
- Debug colliders
- Quality

## Per object

`SceneObject.physics`:

- off / static / dynamic / kinematic
- mass, friction, restitution
- linear/angular damping
- gravity scale
- initial linear/angular velocity
- position/rotation lock flags

`SceneObject.collision`:

- off / on / trigger
- auto / box / sphere / capsule / cylinder / cone / convex / mesh
- layer and mask names

Imported GLBs stay Physics Off until the user enables them. Auto collision uses
a cheap box unless the object is a sphere primitive.

## Physics as signals

Runtime physics state feeds these signal kinds:

- velocity
- angular speed
- height
- impact
- distance to ground
- sleeping
- trigger overlap

They use the same modulation sockets and signal graph as sine/noise.

## Current boundaries

Implemented: optional rigid-body simulation for boxes/spheres/cylinders,
static colliders, triggers as non-blocking bodies, collision layer/mask,
collision impact signals, debug collider shapes, pause/step/reset.

Not yet implemented: joints/constraints, breakable welds, physics fields
(rigid-body force fields), full trigger enter/stay/exit event objects,
interaction rules/envelopes UI, collision-driven preset stacks, physics
timeline release, bake physics to animation, and physics diagnostics.
