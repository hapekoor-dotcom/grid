import { expect, test } from '@playwright/test';

test('camera motion does not rewrite mesh capabilities every frame', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible();
  await page.waitForTimeout(900);
  const before = await page.evaluate(() => (window as unknown as { __reMeshCapabilityReports?: number }).__reMeshCapabilityReports || 0);
  const box = await page.locator('canvas[aria-label^="3D scene"]').boundingBox();
  await page.mouse.move(box!.x + box!.width * 0.5, box!.y + box!.height * 0.5);
  await page.mouse.down({ button: 'right' });
  await page.mouse.move(box!.x + box!.width * 0.62, box!.y + box!.height * 0.55, { steps: 20 });
  await page.mouse.up({ button: 'right' });
  await page.waitForTimeout(700);
  const after = await page.evaluate(() => (window as unknown as { __reMeshCapabilityReports?: number }).__reMeshCapabilityReports || 0);
  expect(after - before).toBeLessThanOrEqual(2);
});
