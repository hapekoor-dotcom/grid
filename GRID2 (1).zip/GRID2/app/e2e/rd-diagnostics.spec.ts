import { expect, test } from '@playwright/test';

test('RD diagnostics list explicit consumers and zero state', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('RD Diagnostics');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(1800);
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    s.updateReactionDiffusion({ enabled: true, paused: false });
    (window as any).__RE_UI__.getState().setSettingsOpen(true);
  });
  await expect(page.getByText('RD is evolving, but currently does not affect the rendered scene.')).toBeVisible();
  await expect(page.getByText('Consumers', { exact: false })).toBeVisible();
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    s.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [{ id: 'surface', type: 'reactionSurface', enabled: true, params: { emission: 1, color: '#42e8ff', colorB: '#ff2bd6', opacity: 0.2, baseColor: 0, mapping: 'auto', output: 'scalar' } }];
      draft.looks = [{ id: 'look_chrome', name: 'Chrome', material: {}, createdAt: '', modifiers: [{ id: 'look_rd', type: 'reactionDisplace', enabled: true, params: { strength: 0.2, mapping: 'auto', output: 'scalar' } }] }];
      draft.objects.push({ ...object, id: 'look_object', name: 'Look Object', lookId: 'look_chrome', modifiers: [] });
    });
  });
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = (window as any).__RE_CUSTOM__.defaultPostPreset('reactionFeedback'); s.updateCustomShaders([shader]); s.assignPostShader({ id: 'rd_post', shaderId: shader.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues(shader) }); });
  await page.waitForTimeout(600);
  const counts = await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug());
  expect(counts.rdConsumers).toBeGreaterThanOrEqual(3);
  expect(counts.rdConsumerList).toContain('Sphere');
  expect(counts.rdConsumerList).toContain('Post');
  await expect(page.locator('.rd-consumers li')).toHaveCount(counts.rdConsumers);
  await page.getByRole('button', { name: 'Show in Graph' }).click();
  await expect(page.locator('.rd-graph-edge')).toHaveCount(counts.rdConsumers);
  await expect(page.locator('.rd-consumers li.is-highlighted')).toHaveCount(counts.rdConsumers);
});
