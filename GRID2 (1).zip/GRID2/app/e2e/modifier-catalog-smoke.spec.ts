import { expect, test } from '@playwright/test';

test('every model modifier installs without runtime or shader errors', async ({ page }) => {
  test.setTimeout(300_000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (message) => { if (message.type() === 'error' && !message.text().includes('requires uDisplaceMap texture')) errors.push(message.text()); });
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Catalog');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  const definitions = await page.evaluate(() => (window as any).__RE_MODIFIERS__.filter((entry: any) => entry.targets?.includes('model') && entry.runtime !== 'post'));
  for (const definition of definitions) {
    errors.length = 0;
    await page.evaluate(({ type, defaults }) => {
      const store = (window as any).__RE_STORE__.getState();
      store.mutate((draft: any) => {
        const object = draft.objects.find((entry: any) => entry.type === 'model');
        object.modifiers = [{ id: `smoke_${type}`, type, enabled: true, params: { ...defaults } }];
      });
    }, { type: definition.type, defaults: definition.defaults });
    await page.waitForTimeout(definition.runtime === 'shader' ? 220 : 80);
    expect(errors, `${definition.type} emitted errors: ${errors.join(' | ')}`).toEqual([]);
  }
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.type === 'model'); object.modifiers = []; });
  });
});
