import { expect, test } from '@playwright/test';

test('modifier graph writes runtime modulation and rejects cycles', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Graph');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [
        { id: 'a', type: 'attractorField', enabled: true, params: { strength: 1, radius: 4, falloff: 1, pointX: 3, pointY: 0, pointZ: 4, mode: 'attract' } },
        { id: 'b', type: 'ripple', enabled: true, params: { strength: 0.2, frequency: 4, speed: 0.6, centerX: 0, centerY: 0, centerZ: 0, radius: 8 } },
      ];
    });
  });
  await page.getByRole('button', { name: 'Graph', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Modifier Graph' })).toBeVisible();
  await page.getByLabel('Graph source').selectOption('modifier:a:distance');
  await page.getByLabel('Graph target effect').selectOption('b');
  await page.getByLabel('Graph target input').selectOption('strength');
  await page.getByLabel('Graph adapter').selectOption('remap');
  await page.getByRole('button', { name: 'Add connection' }).click();
  await expect.poll(() => page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].objects[0].modifiers.find((m: any) => m.id === 'b').modulators?.strength?.sourceId)).toBe('a');
  const before = await page.evaluate(() => JSON.stringify((window as any).__RE_STORE__.getState().projects[0].objects[0].modifiers.find((m: any) => m.id === 'a').modulators || {}));
  await page.getByLabel('Graph source').selectOption('modifier:b:amplitude');
  await page.getByLabel('Graph target effect').selectOption('a');
  await page.getByLabel('Graph target input').selectOption('strength');
  await page.getByRole('button', { name: 'Add connection' }).click();
  await expect(page.getByText('Connection would create a dependency cycle.')).toBeVisible();
  const after = await page.evaluate(() => JSON.stringify((window as any).__RE_STORE__.getState().projects[0].objects[0].modifiers.find((m: any) => m.id === 'a').modulators || {}));
  expect(after).toBe(before);
  await page.getByRole('button', { name: 'Done' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(800);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  const first = await canvas.screenshot();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const modifier = draft.objects[0].modifiers.find((entry: any) => entry.id === 'a');
      modifier.params.pointX = -6;
      modifier.params.pointZ = -5;
    });
  });
  await page.waitForTimeout(700);
  const second = await canvas.screenshot();
  expect(first.equals(second)).toBe(false);
});
