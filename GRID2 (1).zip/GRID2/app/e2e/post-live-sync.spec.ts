import { expect, test } from '@playwright/test';

async function luma(page: any) {
  const buffer = Buffer.from(await page.evaluate(async () => {
    const blob = await (window as any).__RE_RUNTIME__.screenshot();
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }), 'base64');
  return page.evaluate(async (base64) => {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = reject; i.src = `data:image/png;base64,${base64}`; });
    const canvas = document.createElement('canvas'); canvas.width = image.width; canvas.height = image.height;
    const context = canvas.getContext('2d')!; context.drawImage(image, 0, 0);
    const data = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let total = 0; for (let i = 0; i < data.length; i += 4) total += (data[i] + data[i + 1] + data[i + 2]) / 3;
    return total / (data.length / 4);
  }, buffer.toString('base64'));
}

test('post structural mutations render immediately without haze', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Post Live Sync');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); (window as any).__RE_UI__.getState().clearSelection(); });
  await page.waitForTimeout(3000);
  const baseline = await luma(page);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const sh = (window as any).__RE_CUSTOM__.defaultPostPreset('feedback'); s.updateCustomShaders([sh]); s.assignPostShader({ id: 'pass_feedback', shaderId: sh.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues(sh) }); });
  await page.waitForTimeout(1200);
  expect(await luma(page)).toBeGreaterThan(baseline * 0.3);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const sh = (window as any).__RE_CUSTOM__.defaultPostPreset('rgbSplit'); s.updateCustomShaders([...s.projects[0].customShaders, sh]); s.assignPostShader({ id: 'pass_rgb', shaderId: sh.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues(sh) }); });
  await page.waitForTimeout(1000);
  expect(await luma(page)).toBeGreaterThan(baseline * 0.3);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.reorderPostShader('pass_rgb', 'pass_feedback'); const pass = s.projects[0].postShaders.find((entry: any) => entry.id === 'pass_feedback'); s.togglePostShader('pass_feedback', !pass.enabled); });
  await page.waitForTimeout(1000);
  expect(await luma(page)).toBeGreaterThan(baseline * 0.3);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { draft.postShaders = []; }); });
  await page.waitForTimeout(1000);
  expect(await luma(page)).toBeGreaterThan(baseline * 0.3);
});
