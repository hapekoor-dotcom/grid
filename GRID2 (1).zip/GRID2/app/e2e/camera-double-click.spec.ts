import { expect, test } from '@playwright/test';

async function camera(page: any) {
  return page.evaluate(() => {
    const r = (window as any).__RE_RUNTIME__;
    const p = r.camera.getPosition();
    return { x: p.x, y: p.y, z: p.z, distance: r.getInputDebug().cameraDistance };
  });
}

test('double click never moves the camera and F remains explicit', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Camera Safety');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  await expect(canvas).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); });
  await page.waitForTimeout(2500);
  const before = await camera(page);
  const box = (await canvas.boundingBox())!;
  const x = box.x + box.width * 0.5;
  const y = box.y + box.height * 0.5;
  for (let index = 0; index < 50; index += 1) {
    if (index % 2) await page.mouse.dblclick(x, y, { delay: 0 });
    else await page.mouse.click(x, y);
  }
  await page.waitForTimeout(400);
  const after = await camera(page);
  expect(after.distance).toBeCloseTo(before.distance, 3);
  expect(after.x).toBeCloseTo(before.x, 3);
  expect(after.y).toBeCloseTo(before.y, 3);
  expect(after.z).toBeCloseTo(before.z, 3);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_UI__.getState().select(o.id); });
  await page.keyboard.press('f');
  await page.waitForTimeout(600);
  const debug = await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug());
  expect(debug.lastCameraAction).toContain('frame-selection');
  expect(debug.focusBoundsRadius).toBeGreaterThan(0);
  expect(Number.isFinite(debug.cameraDistanceAfter)).toBe(true);
});

test('extreme and invalid focus bounds are rejected safely', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Focus Safety');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(2000);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); });
  await page.waitForTimeout(800);
  const before = await camera(page);
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    s.mutate((draft: any) => { const o = draft.objects.find((entry: any) => entry.type === 'model'); o.position.x = Number.NaN; });
  });
  await page.waitForTimeout(500);
  const afterMutation = await camera(page);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); });
  const after = await camera(page);
  expect(after.distance).toBeCloseTo(afterMutation.distance, 3);
  expect(before.distance).toBeGreaterThan(0);
  const debug = await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug());
  expect(debug.lastCameraAction).toContain('rejected');
  expect(debug.focusBoundsRadius).toBeGreaterThanOrEqual(0);
});

test('F frames extreme effective bounds without teleporting', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Extreme Focus');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    const o = s.projects[0].objects.find((entry: any) => entry.type === 'model');
    s.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.id === o.id); object.modifiers = [{ id: 'sph', type: 'spherize', enabled: true, params: { amount: 5, radius: 5 } }]; });
    (window as any).__RE_RUNTIME__.frameSelection([o.id]);
  });
  await page.waitForTimeout(1500);
  const debug = await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug());
  expect(debug.lastCameraAction).toContain('frame-selection');
  expect(debug.focusBoundsRadius).toBeGreaterThan(0);
  expect(Number.isFinite(debug.cameraDistanceAfter)).toBe(true);
  expect(debug.cameraDistanceAfter).toBeLessThan(500);
  expect(await page.evaluate(() => { const p = (window as any).__RE_RUNTIME__.camera.getPosition(); return Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z); })).toBe(true);
});
