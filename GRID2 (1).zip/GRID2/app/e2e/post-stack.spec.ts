import { expect, test } from '@playwright/test';

async function setupStack(page: any) {
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Post Stack');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(700);
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post Shader Lab/ }).click();
  await page.getByRole('button', { name: /\+ Post \/ Fullscreen/ }).click();
  await page.getByRole('button', { name: 'Feedback', exact: true }).click();
  await page.getByRole('button', { name: 'Compile' }).click();
  await page.getByRole('button', { name: /Add to Post Stack/ }).click();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post FX stack/ }).click();
  await page.getByRole('button', { name: '+ Add Post Shader' }).click();
  await page.getByRole('button', { name: /\+ Post \/ Fullscreen/ }).click();
  await page.getByRole('button', { name: 'RGB Split', exact: true }).click();
  await page.getByRole('button', { name: 'Compile' }).click();
  await page.getByRole('button', { name: /Add to Post Stack/ }).click();
  await expect(page.locator('.post-fx-row')).toHaveCount(2);
}

test('broken post pass is bypassed without a black viewport', async ({ page }) => {
  test.setTimeout(180_000);
  await setupStack(page);
  await page.evaluate(async () => {
    const module = await import('/src/store/workspaceStore.ts');
    const store = (module as any).useWorkspaceStore.getState();
    store.mutate((draft: any) => {
      const source = draft.customShaders.find((shader: any) => shader.context === 'post');
      draft.customShaders.push({
        ...structuredClone(source),
        id: 'shader_broken',
        name: 'Broken Pass',
        fragment: 'void main() { this is not valid glsl; }',
        lastWorking: { vertex: source.vertex, fragment: 'void main() { this is not valid glsl; }' },
      });
      draft.postShaders.splice(1, 0, { id: 'pass_broken', shaderId: 'shader_broken', enabled: true, values: {} });
    });
  });
  await page.waitForTimeout(1200);
  await expect(page.locator('.input-debug-renderer')).toContainText('Bypassed failed pass: Broken Pass');
  await expect(page.locator('.input-debug-renderer')).toContainText('Post passes2');
  await expect(page.locator('.post-fx-row')).toHaveCount(3);
  const luma = await page.evaluate(() => {
    const source = document.querySelector('canvas[aria-label^="3D scene"]') as HTMLCanvasElement;
    const sample = document.createElement('canvas');
    sample.width = 64; sample.height = 64;
    const context = sample.getContext('2d')!;
    context.drawImage(source, 0, 0, 64, 64);
    const data = context.getImageData(0, 0, 64, 64).data;
    let total = 0;
    for (let index = 0; index < data.length; index += 4) total += (data[index] + data[index + 1] + data[index + 2]) / 3;
    return total / (64 * 64);
  });
  expect(luma).toBeGreaterThan(5);
  await page.getByRole('button', { name: 'Done' }).click();
  await page.waitForTimeout(500);
});

test('post pass order changes the rendered pixels', async ({ page }) => {
  test.setTimeout(180_000);
  await setupStack(page);
  await page.getByRole('button', { name: 'Done' }).click();
  await page.waitForTimeout(900);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  const feedbackFirst = await canvas.screenshot();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post FX stack/ }).click();
  const rows = page.locator('.post-fx-row');
  await page.locator('.post-fx-grip').nth(1).dragTo(rows.nth(0));
  await expect(rows.nth(0)).toContainText('RGB Split');
  await page.getByRole('button', { name: 'Done' }).click();
  await page.waitForTimeout(900);
  const rgbFirst = await canvas.screenshot();
  expect(feedbackFirst.equals(rgbFirst)).toBe(false);
});

test('post history reset is scoped and does not black the viewport', async ({ page }) => {
  test.setTimeout(180_000);
  page.on('console', (message) => { if (message.text().includes('[PH]')) console.log(message.text()); });
  await setupStack(page);
  const before = await page.locator('.input-debug-renderer').innerText();
  await page.getByRole('button', { name: 'Reset History' }).first().click();
  await page.waitForTimeout(500);
  const after = await page.locator('.input-debug-renderer').innerText();
  expect(after).toContain('Post history resets');
  expect(after).toContain('user-reset');
  expect(after).toContain('Post depth');
  const luma = await page.evaluate(() => {
    const source = document.querySelector('canvas[aria-label^="3D scene"]') as HTMLCanvasElement;
    const sample = document.createElement('canvas');
    sample.width = 32; sample.height = 32;
    const context = sample.getContext('2d')!;
    context.drawImage(source, 0, 0, 32, 32);
    const data = context.getImageData(0, 0, 32, 32).data;
    let total = 0;
    for (let index = 0; index < data.length; index += 4) total += (data[index] + data[index + 1] + data[index + 2]) / 3;
    return total / (32 * 32);
  });
  expect(luma).toBeGreaterThan(4);
  await page.getByRole('button', { name: 'Reset All History' }).click();
  await page.waitForTimeout(400);
  expect(await page.locator('.input-debug-renderer').innerText()).toContain('user-reset');
  expect(before).toContain('Post passes');
});
