import { expect, test, type Page } from '@playwright/test';

async function pixelDiff(page: Page, a: Buffer, b: Buffer): Promise<{ pct: number; max: number }> {
  return page.evaluate(async ([left, right]) => {
    const load = (base64: string) => new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = reject;
      image.src = `data:image/png;base64,${base64}`;
    });
    const [ia, ib] = await Promise.all([load(left), load(right)]);
    const canvas = document.createElement('canvas');
    canvas.width = ia.width; canvas.height = ia.height;
    const context = canvas.getContext('2d')!;
    context.drawImage(ia, 0, 0);
    const da = context.getImageData(0, 0, canvas.width, canvas.height).data;
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage(ib, 0, 0);
    const db = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let changed = 0; let max = 0;
    for (let i = 0; i < da.length; i += 4) {
      const diff = Math.abs(da[i] - db[i]) + Math.abs(da[i + 1] - db[i + 1]) + Math.abs(da[i + 2] - db[i + 2]);
      if (diff > 6) changed += 1;
      if (diff > max) max = diff;
    }
    return { pct: changed / (ia.width * ia.height), max };
  }, [a.toString('base64'), b.toString('base64')]);
}

test('post passthrough is a color and format identity', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Post Identity');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  await expect(canvas).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); (window as any).__RE_UI__.getState().clearSelection(); });
  await page.waitForTimeout(5000);
  const shoot = async () => Buffer.from(await page.evaluate(async () => { const blob = await (window as any).__RE_RUNTIME__.screenshot(); const bytes = new Uint8Array(await blob.arrayBuffer()); let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte); return btoa(binary); }), 'base64');
  const baseline = await shoot();
  const assertIdentity = async (a: Buffer, b: Buffer) => { const result = await pixelDiff(page, a, b); expect(result.pct).toBeLessThan(0.001); expect(result.max).toBeLessThan(128); };
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = (window as any).__RE_CUSTOM__.defaultPostPreset('passthrough'); s.updateCustomShaders([shader]); (window as any).__POST_ID_SHADER__ = shader; });
  await page.waitForTimeout(1500);
  const assetOnly = await shoot();
  await assertIdentity(baseline, assetOnly);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.assignPostShader({ shaderId: (window as any).__POST_ID_SHADER__.id, enabled: true, values: {} }); });
  await page.waitForTimeout(1500);
  const passthrough = await shoot();
  await assertIdentity(baseline, passthrough);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { draft.postShaders = []; }); });
  await page.waitForTimeout(1500);
  const removed = await shoot();
  await assertIdentity(baseline, removed);
});
