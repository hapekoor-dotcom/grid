import { expect, test } from '@playwright/test';

test('floor visibility only toggles the floor node', async ({ page }) => {
  await page.goto('/?inputDebug=1');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(900);
  const value = async (key: string) => page.locator('.input-debug-state > div').filter({ hasText: key }).locator('b').innerText();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Hide floor/ }).click();
  await page.waitForTimeout(300);
  expect(await value('lastChange')).toBe('room.floor.visible');
  expect(await value('lastDirty')).toBe('VISIBILITY');
  expect(await value('lastAction')).toBe('floorNode.enabled = false');
  expect(await value('lastRebuild')).toBe('false');
  expect(await value('materialSynced')).toBe('false');
  expect(await value('shaderSynced')).toBe('false');
  await page.getByRole('button', { name: /Show floor/ }).click();
  await page.waitForTimeout(300);
  expect(await value('lastAction')).toBe('floorNode.enabled = true');
  expect(await value('lastRebuild')).toBe('false');
});
