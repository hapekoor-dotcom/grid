import { expect, test, type Page } from '@playwright/test';

async function pixelDiff(page: Page, a: Buffer, b: Buffer): Promise<number> {
  return page.evaluate(async ([left, right]) => {
    const load = (base64: string) => new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = reject;
      image.src = `data:image/png;base64,${base64}`;
    });
    const [ia, ib] = await Promise.all([load(left), load(right)]);
    const width = Math.min(ia.width, ib.width);
    const height = Math.min(ia.height, ib.height);
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const context = canvas.getContext('2d')!;
    context.drawImage(ia, 0, 0);
    const da = context.getImageData(0, 0, width, height).data;
    context.clearRect(0, 0, width, height);
    context.drawImage(ib, 0, 0);
    const db = context.getImageData(0, 0, width, height).data;
    let changed = 0;
    for (let i = 0; i < da.length; i += 4) {
      if (Math.abs(da[i] - db[i]) + Math.abs(da[i + 1] - db[i + 1]) + Math.abs(da[i + 2] - db[i + 2]) > 12) changed += 1;
    }
    return changed / (width * height);
  }, [a.toString('base64'), b.toString('base64')]);
}

test('fresh box twist and noise deform, disable restores, re-enable deforms', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Geometry Lifecycle');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Box' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  await expect(canvas).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => { const state = (window as any).__RE_STORE__.getState(); const object = state.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([object.id]); });
  await page.waitForTimeout(900);
  const baseline = await canvas.screenshot();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [{ id: 'twist', type: 'twist', enabled: true, params: { amount: 720, axis: 'y', falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, start: -10, end: 10, animate: false } }];
    });
  });
  await page.waitForTimeout(800);
  const twisted = await canvas.screenshot();
  expect(await pixelDiff(page, baseline, twisted)).toBeGreaterThan(0.003);
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers.push({ id: 'noise', type: 'noiseDisplace', enabled: true, params: { strength: 2, scale: 2, speed: 0, seed: 1, maskX: true, maskY: true, maskZ: true } });
    });
  });
  await page.waitForTimeout(800);
  const noisy = await canvas.screenshot();
  expect(await pixelDiff(page, twisted, noisy)).toBeGreaterThan(0.005);
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.type === 'model'); object.modifiers.forEach((modifier: any) => { modifier.enabled = false; }); });
  });
  await page.waitForTimeout(800);
  const disabled = await canvas.screenshot();
  expect(await pixelDiff(page, noisy, disabled)).toBeGreaterThan(0.01);
  expect(await pixelDiff(page, baseline, disabled)).toBeLessThan(0.02);
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.type === 'model'); object.modifiers.forEach((modifier: any) => { modifier.enabled = true; }); });
  });
  await page.waitForTimeout(800);
  const enabled = await canvas.screenshot();
  expect(await pixelDiff(page, disabled, enabled)).toBeGreaterThan(0.01);
});
