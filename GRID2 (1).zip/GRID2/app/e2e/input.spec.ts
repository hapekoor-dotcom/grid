import { expect, test } from '@playwright/test';

test('left mouse interactions release ownership after 50 cycles', async ({ page }) => {
  test.setTimeout(120_000);
  const stateValue = async (key: string) => page.locator('.input-debug-state > div').filter({ hasText: key }).locator('b').innerText();
  await page.goto('/?inputDebug=1');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="plan"]').click();
  await page.locator('.plan-object[aria-label="Focus Flex 01"]').click({ force: true });
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(900);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  await expect(canvas).toBeVisible();
  const box = await canvas.boundingBox();
  expect(box).not.toBeNull();
  const debug = page.locator('.input-debug');
  await expect(debug).toBeVisible();
  // One camera drag, then repeated object/empty selection clicks.
  await page.mouse.move(box!.x + box!.width * 0.55, box!.y + box!.height * 0.5);
  await page.mouse.down();
  await page.mouse.move(box!.x + box!.width * 0.57, box!.y + box!.height * 0.52, { steps: 6 });
  expect(await stateValue('cameraDragging')).toBe('false');
  await page.mouse.up();
  await page.mouse.move(box!.x + box!.width * 0.5, box!.y + box!.height * 0.5);
  await page.mouse.down({ button: 'right' });
  await page.mouse.move(box!.x + box!.width * 0.53, box!.y + box!.height * 0.52, { steps: 6 });
  expect(await stateValue('cameraDragging')).toBe('true');
  await page.mouse.up({ button: 'right' });
  await expect.poll(() => stateValue('cameraDragging')).toBe('false');
  for (let index = 0; index < 50; index += 1) {
    await page.mouse.click(box!.x + box!.width * (index % 2 === 0 ? 0.35 : 0.65), box!.y + box!.height * (index % 2 === 0 ? 0.4 : 0.7));
    await page.waitForTimeout(20);
  }
  await expect(debug).toBeVisible();
  expect(await stateValue('pointerOwner')).toBe('NONE');
  expect(await stateValue('leftButtonDown')).toBe('false');
  expect(await stateValue('buttons')).toBe('0');
});

test('escape and visibility reset a held pointer', async ({ page }) => {
  await page.goto('/?inputDebug=1');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(900);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  const box = await canvas.boundingBox();
  await page.mouse.move(box!.x + box!.width * 0.5, box!.y + box!.height * 0.5);
  await page.mouse.down();
  await page.keyboard.press('Escape');
  await page.mouse.up();
  const debug = page.locator('.input-debug');
  const owner = async () => page.locator('.input-debug-state > div').filter({ hasText: 'pointerOwner' }).locator('b').innerText();
  await expect(debug).toBeVisible();
  expect(await owner()).toBe('NONE');
  await page.evaluate(() => Object.defineProperty(document, 'hidden', { configurable: true, value: true }));
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  expect(await owner()).toBe('NONE');
});
