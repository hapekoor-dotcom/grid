import { expect, test } from '@playwright/test';

test('shared Look RD remains shared and Make Unique diverges', async ({ page }) => {
  test.setTimeout(180_000);
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('RD Look');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.updateReactionDiffusion({ enabled: true, resolution: 64, iterations: 4 });
    store.mutate((draft: any) => {
      const base = draft.objects.find((entry: any) => entry.type === 'model');
      draft.looks = [{ id: 'look_rd', name: 'RD Shared', material: {}, createdAt: '', modifiers: [
        { id: 'look_attractor', type: 'attractorField', enabled: true, params: { strength: 1, radius: 4, falloff: 1, pointX: 3, pointY: 0, pointZ: 4, mode: 'attract' } },
        { id: 'rd_shared', type: 'reactionSurface', enabled: true, params: { emission: 1, color: '#42e8ff', colorB: '#ff2bd6', opacity: 0, baseColor: 0, roughness: 0, metallic: 0, mapping: 'auto', output: 'scalar' }, modulators: { emission: { sourceId: 'look_attractor', sourceType: 'modifier', output: 'distance', amount: 0.1, offset: 0, enabled: true } } },
      ] }];
      base.lookId = 'look_rd';
      for (let index = 1; index < 10; index += 1) {
        draft.objects.push({ ...structuredClone(base), id: `sphere_${index}`, name: `Sphere ${index}`, position: { x: (index % 5) * 1.5 - 3, z: Math.floor(index / 5) * 1.5 - 0.75 } });
      }
    });
  });
  await page.evaluate(() => (window as any).__RE_STORE__.getState().addFieldLink({ id: 'field_look', source: 'reaction', output: 'gradient', modifierId: 'rd_shared', slot: 'field' }));
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(900);
  await expect(page.locator('.input-debug-renderer')).toContainText(/RD consumers10/);
  const before = await page.evaluate(() => {
    const project = (window as any).__RE_STORE__.getState().projects[0];
    return project.objects.map((object: any) => object.lookId);
  });
  expect(new Set(before).size).toBe(1);
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.makeLookUnique(store.projects[0].objects[0].id);
  });
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => {
    const state = (window as any).__RE_STORE__.getState();
    const project = state.projects[0];
    const unique = project.objects[0];
    const original = project.looks.find((look: any) => look.id === 'look_rd');
    const uniqueLook = project.looks.find((look: any) => look.id === unique.lookId);
    const originalRd = original.modifiers.find((modifier: any) => modifier.type === 'reactionSurface');
    const uniqueRd = uniqueLook.modifiers.find((modifier: any) => modifier.type === 'reactionSurface');
    const originalAttractor = original.modifiers.find((modifier: any) => modifier.type === 'attractorField');
    const uniqueAttractor = uniqueLook.modifiers.find((modifier: any) => modifier.type === 'attractorField');
    return { uniqueLookId: unique.lookId, looks: project.looks.length, originalEmission: originalRd.params.emission, uniqueEmission: uniqueRd.params.emission, originalSource: originalRd.modulators?.emission?.sourceId, uniqueSource: uniqueRd.modulators?.emission?.sourceId, originalPoint: originalAttractor.params.pointX, uniquePoint: uniqueAttractor.params.pointX, uniqueAttractorId: uniqueAttractor.id, originalField: project.fieldLinks.find((link: any) => link.id === 'field_look')?.modifierId, uniqueField: project.fieldLinks.find((link: any) => link.id !== 'field_look' && link.slot === 'field')?.modifierId, uniqueRdId: uniqueRd.id };
  });
  expect(after.looks).toBe(2);
  expect(after.uniqueLookId).not.toBe('look_rd');
  expect(after.uniqueEmission).toBe(after.originalEmission);
  expect(after.originalSource).toBe('look_attractor');
  expect(after.uniqueSource).not.toBe('look_attractor');
  expect(after.uniqueSource).toBe(after.uniqueAttractorId);
  expect(after.originalField).toBe('rd_shared');
  expect(after.uniqueField).toBe(after.uniqueRdId);
  expect(after.uniquePoint).toBe(after.originalPoint);
});
