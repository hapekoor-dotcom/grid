import { expect, test, type Page } from '@playwright/test';

async function shot(page: Page) {
  return Buffer.from(await page.evaluate(async () => {
    const blob = await (window as any).__RE_RUNTIME__.screenshot();
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }), 'base64');
}

async function diff(page: Page, a: Buffer, b: Buffer) {
  return page.evaluate(async ([left, right]) => {
    const load = (base64: string) => new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image(); image.onload = () => resolve(image); image.onerror = reject; image.src = `data:image/png;base64,${base64}`;
    });
    const [ia, ib] = await Promise.all([load(left), load(right)]);
    const canvas = document.createElement('canvas'); canvas.width = ia.width; canvas.height = ia.height;
    const context = canvas.getContext('2d')!;
    context.drawImage(ia, 0, 0);
    const da = context.getImageData(0, 0, canvas.width, canvas.height).data;
    context.clearRect(0, 0, canvas.width, canvas.height); context.drawImage(ib, 0, 0);
    const db = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let changed = 0; let r = 0; let g = 0; let blue = 0;
    for (let i = 0; i < da.length; i += 4) {
      if (Math.abs(da[i] - db[i]) + Math.abs(da[i + 1] - db[i + 1]) + Math.abs(da[i + 2] - db[i + 2]) > 6) changed += 1;
      r += db[i]; g += db[i + 1]; blue += db[i + 2];
    }
    const pixels = da.length / 4;
    return { pct: changed / pixels, avg: [r / pixels, g / pixels, blue / pixels] };
  }, [a.toString('base64'), b.toString('base64')]);
}

async function setup(page: Page, name: string) {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill(name);
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Box' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); (window as any).__RE_RUNTIME__.frameSelection([o.id]); (window as any).__RE_UI__.getState().clearSelection(); });
  await page.waitForTimeout(5000);
}

test('mesh shader creation does not mutate and failed shaders keep last working material', async ({ page }) => {
  test.setTimeout(120_000);
  await setup(page, 'Mesh Shader Safety');
  const baseline = await shot(page);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const base = (window as any).__RE_CUSTOM__.defaultMeshShader(); const shader = { ...base, vertex: 'p += normal * uStrength;', fragment: 'emission += uColor * uStrength;' }; shader.lastWorking = { vertex: shader.vertex, fragment: shader.fragment }; s.updateCustomShaders([shader]); (window as any).__MESH_SHADER__ = shader; });
  await page.waitForTimeout(1200);
  expect((await diff(page, baseline, await shot(page))).pct).toBeLessThan(0.001);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); s.assignShader({ objectId: o.id }, { shaderId: (window as any).__MESH_SHADER__.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues((window as any).__MESH_SHADER__) }); });
  await page.waitForTimeout(1500);
  const assigned = await shot(page);
  expect((await diff(page, baseline, assigned)).pct).toBeGreaterThan(0.001);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = s.projects[0].customShaders[0]; s.updateCustomShaders([{ ...shader, vertex: 'this is invalid glsl' }]); });
  await page.waitForTimeout(1200);
  const broken = await shot(page);
  expect((await diff(page, assigned, broken)).pct).toBeLessThan(0.002);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { draft.objects[0].shaders = []; }); });
  await page.waitForTimeout(1200);
  expect((await diff(page, baseline, await shot(page))).pct).toBeLessThan(0.001);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = { ...(window as any).__RE_CUSTOM__.defaultFullMeshShader(), fragment: 'precision highp float; uniform vec3 uColor; void main(void) { gl_FragColor = vec4(uColor, 1.0); }' }; shader.lastWorking = { vertex: shader.vertex, fragment: shader.fragment }; s.updateCustomShaders([...s.projects[0].customShaders, shader]); const o = s.projects[0].objects.find((entry: any) => entry.type === 'model'); s.assignShader({ objectId: o.id }, { shaderId: shader.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues(shader) }); (window as any).__FULL_SHADER__ = shader; });
  await page.waitForTimeout(1200);
  const full = await shot(page);
  expect((await diff(page, baseline, full)).pct).toBeGreaterThan(0.001);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = s.projects[0].customShaders.find((entry: any) => entry.id === (window as any).__FULL_SHADER__.id); s.updateCustomShaders(s.projects[0].customShaders.map((entry: any) => entry.id === shader.id ? { ...entry, vertex: 'invalid glsl' } : entry)); });
  await page.waitForTimeout(1200);
  expect((await diff(page, full, await shot(page))).pct).toBeLessThan(0.002);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { draft.objects[0].shaders = []; }); });
  await page.waitForTimeout(1200);
  expect((await diff(page, baseline, await shot(page))).pct).toBeLessThan(0.001);
  await page.evaluate(() => (window as any).__RE_STORE__.getState().createNewProject('Clean Project B'));
  await page.locator('button[data-mode="3d"]').click().catch(() => {});
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(3000);
  const clean = await diff(page, baseline, await shot(page));
  expect(clean.avg[0]).toBeLessThan(clean.avg[1] + 20);
  expect(clean.avg[2]).toBeLessThan(clean.avg[1] + 20);
});

test('invalid post bypasses and feedback never turns the viewport pink', async ({ page }) => {
  test.setTimeout(120_000);
  await setup(page, 'Post Shader Safety');
  const baseline = await shot(page);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = { ...(window as any).__RE_CUSTOM__.defaultPostPreset('passthrough'), fragment: 'invalid glsl' }; s.updateCustomShaders([shader]); s.assignPostShader({ shaderId: shader.id, enabled: true, values: {} }); });
  await page.waitForTimeout(1200);
  expect((await diff(page, baseline, await shot(page))).pct).toBeLessThan(0.001);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); const shader = (window as any).__RE_CUSTOM__.defaultPostPreset('feedback'); s.updateCustomShaders([...s.projects[0].customShaders, shader]); s.assignPostShader({ id: 'pass_feedback', shaderId: shader.id, enabled: true, values: (window as any).__RE_CUSTOM__.defaultValues(shader) }); });
  await page.waitForTimeout(1500);
  const feedback = await shot(page);
  const result = await diff(page, baseline, feedback);
  const baselineAvg = (await diff(page, baseline, baseline)).avg;
  expect(result.avg[1]).toBeGreaterThan(baselineAvg[1] * 0.3);
  expect(result.avg[0]).toBeLessThan(result.avg[1] + 20);
  expect(result.avg[2]).toBeLessThan(result.avg[1] + 20);
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { draft.postShaders = []; }); });
  await page.waitForTimeout(1200);
  expect((await diff(page, baseline, await shot(page))).pct).toBeLessThan(0.001);
});
