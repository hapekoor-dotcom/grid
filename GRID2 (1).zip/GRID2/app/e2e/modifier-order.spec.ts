import { expect, test } from '@playwright/test';

test('geometry modifier order changes runtime output', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Order');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [
        { id: 'domain', type: 'domainWarp', enabled: true, params: { strength: 0.9, scale: 1.4, speed: 0, octaves: 3, lacunarity: 2, persistence: 0.5, seed: 2, axis: 'z' } },
        { id: 'twist', type: 'twist', enabled: true, params: { amount: 90, axis: 'y', falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, start: -10, end: 10, animate: false } },
      ];
    });
  });
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(900);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  const first = await canvas.screenshot();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [object.modifiers[1], object.modifiers[0]];
    });
  });
  await page.waitForTimeout(600);
  const second = await canvas.screenshot();
  expect(first.equals(second)).toBe(false);
});

test('spherize and noise displacement order changes runtime output', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Order 2');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [
        { id: 'spherize', type: 'spherize', enabled: true, params: { amount: 0.85, radius: 0.5 } },
        { id: 'noise', type: 'noiseDisplace', enabled: true, params: { strength: 0.5, scale: 2.2, speed: 0, seed: 4, maskX: true, maskY: true, maskZ: true } },
      ];
    });
  });
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(900);
  const canvas = page.locator('canvas[aria-label^="3D scene"]');
  const first = await canvas.screenshot();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [object.modifiers[1], object.modifiers[0]];
    });
  });
  await page.waitForTimeout(600);
  const second = await canvas.screenshot();
  expect(first.equals(second)).toBe(false);
});
