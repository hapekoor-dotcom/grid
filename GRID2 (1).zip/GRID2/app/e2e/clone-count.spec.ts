import { expect, test } from '@playwright/test';

test('200 radial clones stay runtime entities', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Clones');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [{ id: 'clones', type: 'radialClone', enabled: true, params: { count: 200, radius: 6, angleOffset: 0, rotationFollow: true, scaleVariation: 0.2, orbit: false, orbitSpeed: 0.2, pattern: 'sphere', height: 0, spacing: 1.5, phase: 0, randomness: 0.1, scaleProgression: 0, pulse: 0, pulseSpeed: 1 } }];
    });
  });
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(1500);
  await expect(page.locator('.input-debug-renderer')).toContainText(/Clone instances200/);
  await expect(page.locator('.input-debug-state > div').filter({ hasText: 'pointerOwner' }).locator('b')).toHaveText('NONE');
  await expect(page.locator('.react-object-card')).toHaveCount(0);
});
