import path from 'node:path';
import { expect, test } from '@playwright/test';

test('empty scene imports a model and lights it without a room', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Empty scene');
  await page.getByRole('button', { name: 'Create project' }).click();

  await expect(page.locator('.plan-svg')).toBeVisible();
  await expect(page.locator('button[data-mode="patch"]')).toHaveCount(0);
  await expect(page.locator('body')).not.toContainText('Set up your venue');

  await page.getByRole('button', { name: 'Add object' }).click();
  await page.getByRole('menuitem', { name: /Spot Light/ }).click();
  await expect(page.locator('.plan-object[aria-label="Spot Light"]')).toHaveCount(1);

  const [chooser] = await Promise.all([
    page.waitForEvent('filechooser'),
    page.getByRole('button', { name: /Import 3D Model/ }).click(),
  ]);
  await chooser.setFiles(path.resolve(process.cwd(), 'public/assets/models/abstract-loop.glb'));
  await expect(page.locator('.plan-object[aria-label="abstract-loop"]')).toHaveCount(1, { timeout: 15_000 });

  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible();
  await expect(page.getByRole('button', { name: /^View/ })).toBeVisible();
});

test('Focus Flex keeps advanced controls without DMX fields', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="plan"]').click();
  await page.locator('.plan-object[aria-label="Focus Flex 01"]').click({ force: true });

  const panel = page.locator('.right-panel');
  await expect(panel).toContainText('Advanced Fixture');
  await expect(panel).toContainText('Visible in 3D');
  await expect(panel).toContainText('Light enabled');
  await expect(panel).toContainText('Pan / Tilt');
  await expect(panel).not.toContainText('DMX');
  await expect(panel).not.toContainText('Universe');
  await expect(panel).not.toContainText('Address');
});
