import { expect, test } from '@playwright/test';

async function setup(page: any) {
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('RD');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(500);
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.updateReactionDiffusion({ enabled: true, resolution: 128, iterations: 8 });
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [
        { id: 'rd_surface', type: 'reactionSurface', enabled: true, params: { emission: 2, color: '#42e8ff', mapping: 'auto' } },
        { id: 'rd_displace', type: 'reactionDisplace', enabled: true, params: { amount: 0.4, mapping: 'auto' } },
      ];
    });
  });
  await page.evaluate(() => (window as any).__RE_STORE__.getState().addFieldLink({ id: 'field_rd', source: 'reaction', output: 'gradient', modifierId: 'rd_displace', slot: 'field' }));
  await page.waitForTimeout(900);
}

const renderer = (page: any) => page.locator('.input-debug-renderer');

test('GPU reaction diffusion evolves, keeps state on parameter edits and resets explicitly', async ({ page }) => {
  test.setTimeout(180_000);
  await setup(page);
  await expect(renderer(page)).toContainText('VALID');
  await expect(renderer(page)).toContainText(/RD consumers2/);
  await expect(renderer(page)).toContainText(/RD GPU readbacks\/frame0/);
  const first = await page.locator('canvas[aria-label^="3D scene"]').screenshot();
  const readNumbers = async () => {
    const text = await renderer(page).innerText();
    const match = text.match(/RD steps \/ resets\s*(\d+) \/ (\d+)/);
    return { steps: Number(match?.[1] || 0), resets: Number(match?.[2] || 0) };
  };
  const before = await readNumbers();
  expect(before.steps).toBeGreaterThan(0);
  await page.waitForTimeout(900);
  const second = await page.locator('canvas[aria-label^="3D scene"]').screenshot();
  expect(first.equals(second)).toBe(false);
  const afterEvolution = await readNumbers();
  expect(afterEvolution.steps).toBeGreaterThan(before.steps);
  await page.evaluate(() => (window as any).__RE_STORE__.getState().updateReactionDiffusion({ feed: 0.036 }));
  await page.waitForTimeout(400);
  expect((await readNumbers()).resets).toBe(afterEvolution.resets);
  await page.evaluate(() => (window as any).__RE_STORE__.getState().resetReactionDiffusion());
  await page.waitForTimeout(500);
  expect((await readNumbers()).resets).toBe(afterEvolution.resets + 1);
  const box = await page.locator('canvas[aria-label^="3D scene"]').boundingBox();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Paint Reaction Diffusion/ }).click();
  await page.mouse.click(box!.x + box!.width * 0.5, box!.y + box!.height * 0.5);
  await page.waitForTimeout(500);
  await expect(renderer(page)).toContainText(/RD injections1/);
  await expect(page.locator('.input-debug-state > div').filter({ hasText: 'pointerOwner' }).locator('b')).toHaveText('NONE');
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(900);
  const saved = await page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].reactionDiffusion);
  expect(saved.enabled).toBe(true);
  expect(saved.feed).toBe(0.036);
  await expect(page.locator('.input-debug-state > div').filter({ hasText: 'pointerOwner' }).locator('b')).toHaveText('NONE');
});
