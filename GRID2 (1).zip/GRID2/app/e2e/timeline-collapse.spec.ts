import { expect, test } from '@playwright/test';

test('timeline stays collapsed while selecting and switching modes', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="plan"]').click();
  const timeline = page.locator('.timeline-panel');
  await expect(timeline).toBeVisible();
  expect(await timeline.evaluate((el) => el.clientHeight)).toBeLessThanOrEqual(40);
  await page.locator('.plan-object[aria-label="Focus Flex 01"]').click({ force: true });
  expect(await timeline.evaluate((el) => el.clientHeight)).toBeLessThanOrEqual(40);
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(500);
  expect(await timeline.evaluate((el) => el.clientHeight)).toBeLessThanOrEqual(40);
});
