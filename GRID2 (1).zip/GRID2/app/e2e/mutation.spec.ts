import { expect, test } from '@playwright/test';

test('mutation engine applies keeps reverts again and branches', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Mutation');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    const o = s.projects[0].objects.find((entry: any) => entry.type === 'model');
    s.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.id === o.id);
      object.modifiers = [
        { id: 'tw', type: 'twist', enabled: true, params: { amount: 180, axis: 'y', falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, start: -10, end: 10, animate: false } },
        { id: 'no', type: 'noiseDisplace', enabled: true, params: { strength: 0.4, scale: 2, speed: 0.3, seed: 2, maskX: true, maskY: true, maskZ: true } },
      ];
    });
  });
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(2500);
  await page.getByRole('button', { name: 'MUTATE', exact: true }).click();
  await expect(page.locator('.mutation-id')).toBeVisible();
  const firstSeed = await page.locator('.mutation-id').innerText();
  await page.getByRole('button', { name: 'Keep', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].mutation?.accepted.length)).toBe(1);
  await page.getByRole('button', { name: 'MUTATE', exact: true }).click();
  await page.getByRole('button', { name: 'Again', exact: true }).click();
  const secondSeed = await page.locator('.mutation-id').innerText();
  expect(secondSeed).not.toBe(firstSeed);
  await page.getByRole('button', { name: 'Revert', exact: true }).click();
  await expect(page.locator('.mutation-id')).toHaveCount(0);
  await page.getByRole('button', { name: 'MUTATE', exact: true }).click();
  await page.getByRole('button', { name: 'Branch', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].mutation?.accepted.length)).toBe(2);
  const branch = await page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].mutation?.branchId);
  expect(branch).toBeTruthy();
  await page.waitForTimeout(1000);
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);
  expect(await page.evaluate(() => (window as any).__RE_STORE__.getState().projects[0].mutation?.accepted.length)).toBe(2);
});
