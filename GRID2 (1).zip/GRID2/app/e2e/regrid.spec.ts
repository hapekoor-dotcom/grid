import { expect, test, type Page } from '@playwright/test';

async function reset(page: Page) {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
}

async function openDemo(page: Page) {
  await reset(page);
  await page.getByRole('button', { name: /Explore demo/ }).click();
  await expect(page.locator('.plan-svg')).toBeVisible();
}

test.describe('RE:GRID core flows', () => {
  test('A · create a project, draw a stage, add equipment, undo and persist', async ({ page }) => {
    await reset(page);
    await page.getByPlaceholder('Например, Клуб «Платформа»').fill('E2E · новый зал');
    await page.getByRole('button', { name: 'Создать проект' }).click();
    await expect(page.locator('.plan-svg')).toBeVisible();
    expect(await page.locator('.plan-object').count()).toBe(1);

    await page.locator('[data-tool="stage"]').click();
    const box = await page.locator('.plan-svg').boundingBox();
    expect(box).not.toBeNull();
    await page.mouse.move(box!.x + box!.width * 0.4, box!.y + box!.height * 0.22);
    await page.mouse.down();
    await page.mouse.move(box!.x + box!.width * 0.7, box!.y + box!.height * 0.48, { steps: 8 });
    await page.mouse.up();
    await expect(page.locator('.plan-object[aria-label="Сцена"]')).toHaveCount(1);

    await page.getByRole('textbox', { name: 'Поиск оборудования' }).fill('Focus Flex');
    await page.locator('.catalog-row[data-device-id="snl-444"]').first().click();
    await expect(page.locator('.plan-object[aria-label*="Focus Flex"]')).toHaveCount(1);
    expect(await page.locator('.plan-object').count()).toBe(3);

    await page.keyboard.press('Control+z');
    await expect(page.locator('.plan-object')).toHaveCount(2);
    await page.keyboard.press('Control+Shift+z');
    await expect(page.locator('.plan-object')).toHaveCount(3);

    await page.keyboard.press('Control+s');
    await page.waitForTimeout(900);
    await page.reload({ waitUntil: 'networkidle' });
    await expect(page.locator('.plan-svg')).toBeVisible();
    await expect(page.locator('.plan-object')).toHaveCount(3);
    await expect(page.getByText('E2E · новый зал').first()).toBeVisible();
  });

  test('B · technical patch, power summary and diagnostics', async ({ page }) => {
    await openDemo(page);
    expect(await page.locator('.plan-object').count()).toBe(38);
    const focusId = await page.locator('.plan-object[aria-label^="Focus Flex 01"]').getAttribute('data-object-id');
    expect(focusId).toBeTruthy();

    await page.locator('[data-mode="patch"]').click();
    await expect(page.locator('.patch-workspace')).toBeVisible();
    const row = page.locator(`tr[data-object-id="${focusId}"]`);
    await expect(row).toContainText('Focus Flex 01');
    await expect(row).toContainText('Standard RGBW');
    await expect(row).toContainText('Swisson XND-8');
    await expect(page.locator('tr[data-object-id]').filter({ hasText: 'Focus Flex' })).toHaveCount(4);
    await expect(page.locator('.universe-card')).toHaveCount(2);
    await expect(page.getByText('U1').first()).toBeVisible();
    await expect(page.getByText('U2').first()).toBeVisible();

    await page.locator('.patch-tab', { hasText: 'Питание' }).click();
    await expect(page.getByText(/461\s?Вт/).first()).toBeVisible();
    await expect(page.getByText('Распределитель сцены · выход 1')).toBeVisible();
    await expect(page.getByText('без мощности').first()).toBeVisible();

    await page.locator('.patch-tab', { hasText: 'Проверки' }).click();
    await expect(page.locator('.diagnostic-row')).toHaveCount(41);
  });

  test('B2 · manual DMX address conflict appears on the plan and in diagnostics', async ({ page }) => {
    await openDemo(page);
    const focusOne = page.locator('.plan-object[aria-label^="Focus Flex 01"] [data-testid="object-hit"]');
    await focusOne.click();
    const address = page.getByRole('textbox', { name: 'DMX-адрес' });
    await address.fill('20');
    await address.press('Enter');
    const focusTwo = page.locator('.plan-object[aria-label^="Focus Flex 02"] [data-testid="object-hit"]');
    await focusTwo.click();
    await page.getByRole('textbox', { name: 'DMX-адрес' }).fill('1');
    await page.getByRole('textbox', { name: 'DMX-адрес' }).press('Enter');
    await expect(page.locator('.plan-object[aria-label^="Focus Flex 02"] [data-ui="issue"]')).toHaveCount(1);
    await page.getByRole('button', { name: /Проверки/ }).first().click();
    await expect(page.locator('.diagnostics-drawer')).toContainText('перекрывает');
  });

  test('C/D · 3D scene and virtual lighting control', async ({ page }) => {
    await openDemo(page);
    await page.locator('[data-mode="3d"]').click();
    await expect(page.locator('.viewport3d canvas')).toBeVisible();
    await page.waitForTimeout(1800);
    await expect(page.locator('.viewport-loading')).toHaveCount(0);
    await page.getByLabel('Качество 3D').selectOption('medium');
    await page.waitForTimeout(500);
    const pngDownload = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Снимок PNG' }).click();
    const png = await pngDownload;
    expect(png.suggestedFilename()).toContain('.png');

    await page.locator('[data-mode="light"]').click();
    await expect(page.locator('.fixture-row')).toHaveCount(26);
    await page.locator('.fixture-row', { hasText: 'Focus Flex 01' }).click();
    await expect(page.locator('.light-controls')).toBeVisible();
    await page.getByRole('button', { name: 'Синий', exact: true }).click();
    await expect(page.locator('.light-controls').getByText('#245BFF')).toBeVisible();
    const intensity = page.locator('input[aria-label="Интенсивность"]');
    await intensity.evaluate((element) => {
      const input = element as HTMLInputElement;
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, '50');
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
    await expect(page.locator('.light-controls').getByText('50%').first()).toBeVisible();
    await page.getByRole('textbox', { name: 'Название пресета' }).fill('E2E-пресет');
    await page.getByRole('button', { name: 'Сохранить', exact: true }).click();
    await expect(page.locator('.preset-list').last()).toContainText('E2E-пресет');

    await page.locator('[data-mode="3d"]').click();
    await page.waitForTimeout(1000);
    await expect(page.locator('.viewport3d canvas')).toBeVisible();
  });

  test('E · project persistence restores scene state', async ({ page }) => {
    await openDemo(page);
    const name = await page.locator('.project-title-input').inputValue();
    await page.locator('.mode-tab', { hasText: 'Свет' }).click();
    await page.locator('.fixture-row', { hasText: 'Focus Flex 02' }).click();
    await page.getByRole('button', { name: 'Магента', exact: true }).click();
    await page.keyboard.press('Control+s');
    await page.waitForTimeout(800);
    await page.reload({ waitUntil: 'networkidle' });
    await expect(page.locator('.plan-svg')).toBeVisible();
    await page.locator('.mode-tab', { hasText: 'Свет' }).click();
    await page.locator('.fixture-row', { hasText: 'Focus Flex 02' }).click();
    await expect(page.locator('.light-controls').getByText('#FF35C8')).toBeVisible();
    await expect(page.locator('.project-chip .project-name')).toHaveText(name);
  });

  test('exports produce real files', async ({ page }) => {
    await openDemo(page);
    await page.getByRole('button', { name: /Экспорт/ }).first().click();
    await expect(page.getByRole('dialog', { name: 'Экспорт проекта' })).toBeVisible();
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: /Проект JSON/ }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toContain('.json');
    const svgPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: /2D-план SVG/ }).click();
    const svg = await svgPromise;
    expect(svg.suggestedFilename()).toContain('.svg');
  });


  test('catalog starts with power, groups closed and only one open', async ({ page }) => {
    await openDemo(page);
    const heads = page.locator('.catalog-group-head');
    const first = heads.first();
    await expect(first).toContainText('Розетки');
    await expect(page.locator('.catalog-group-head[aria-expanded="true"]')).toHaveCount(0);
    await first.click();
    await expect(page.locator('.catalog-group-head[aria-expanded="true"]')).toHaveCount(1);
    await heads.nth(1).click();
    await expect(page.locator('.catalog-group-head[aria-expanded="true"]')).toHaveCount(1);
    await expect(first).toHaveAttribute('aria-expanded', 'false');
  });

  test('panel buttons hide both panels without killing the canvas', async ({ page }) => {
    await openDemo(page);
    await page.getByRole('button', { name: 'Скрыть каталог' }).click();
    await expect(page.locator('.left-panel')).toHaveCount(0);
    await page.getByRole('button', { name: 'Скрыть инспектор' }).click();
    await expect(page.locator('.right-panel')).toHaveCount(0);
    await expect(page.locator('.plan-svg')).toBeVisible();
    const box = await page.locator('.center-region').boundingBox();
    expect(box?.width || 0).toBeGreaterThan(1200);
    await expect(page.getByRole('button', { name: 'Показать каталог' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Показать инспектор' })).toBeVisible();
    await page.getByRole('button', { name: 'Показать каталог' }).click();
    await expect(page.locator('.left-panel')).toHaveCount(1);
  });

  test('3D auto-collapses the catalog at 1366 and restores it on return', async ({ page }) => {
    await page.setViewportSize({ width: 1366, height: 768 });
    await openDemo(page);
    await expect(page.locator('.left-panel')).toHaveCount(1);
    await page.locator('[data-mode="3d"]').click();
    await expect(page.locator('.left-panel')).toHaveCount(0);
    await page.locator('[data-mode="plan"]').click();
    await expect(page.locator('.left-panel')).toHaveCount(1);
    await page.locator('[data-mode="3d"]').click();
    await expect(page.locator('.left-panel')).toHaveCount(0);
    await page.getByRole('button', { name: 'Показать каталог' }).click();
    await expect(page.locator('.left-panel')).toHaveCount(1);
    await page.locator('[data-mode="light"]').click();
    await expect(page.locator('.left-panel')).toHaveCount(1);
    await page.locator('[data-mode="plan"]').click();
    await expect(page.locator('.left-panel')).toHaveCount(1);
  });

  test('bar segment editing changes state and clears the active preset', async ({ page }) => {
    await page.setViewportSize({ width: 1366, height: 768 });
    await openDemo(page);
    await page.locator('[data-mode="light"]').click();
    await page.locator('.fixture-row', { hasText: 'UBL12H 01' }).click();
    await expect(page.getByText('Секции ·')).toBeVisible();
    const first = page.getByRole('button', { name: 'Сегмент 1' });
    await expect(first).toHaveAttribute('aria-pressed', 'true');
    await first.click();
    await expect(first).toHaveAttribute('aria-pressed', 'false');
    await expect(page.locator('.lq-preset[aria-pressed="true"]')).toHaveCount(0);
  });

  test('photo render produces a separate high-resolution PNG', async ({ page }) => {
    test.setTimeout(180_000);
    await openDemo(page);
    await page.locator('[data-mode="3d"]').click();
    await page.waitForTimeout(2200);
    await page.getByRole('button', { name: 'Фото-рендер' }).click();
    await expect(page.getByRole('dialog', { name: 'Фото-рендер' })).toBeVisible();
    await page.locator('#photo-scale').selectOption('1');
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Рендерить PNG' }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toContain('-photo-1x.png');
    await expect(page.getByRole('dialog', { name: 'Фото-рендер' })).toHaveCount(0);
  });

  test('wall tool, layers and cable waypoint editing', async ({ page }) => {
    await reset(page);
    await page.getByRole('button', { name: 'Создать проект' }).click();
    await page.locator('[data-tool="wall"]').click();
    const box = await page.locator('.plan-svg').boundingBox();
    await page.mouse.move(box!.x + box!.width * 0.45, box!.y + box!.height * 0.4);
    await page.mouse.down();
    await page.mouse.move(box!.x + box!.width * 0.65, box!.y + box!.height * 0.4, { steps: 6 });
    await page.mouse.up();
    await expect(page.locator('.plan-object[aria-label^="Стена"]')).toHaveCount(1);
    await expect(page.locator('.inspector-body')).toContainText('Планировочный объект');

    await page.getByRole('button', { name: 'Слои', exact: true }).click();
    await page.getByRole('button', { name: 'Мебель и стены' }).click();
    await expect(page.locator('.plan-object[aria-label^="Стена"]')).toHaveCount(0);
    await page.getByRole('button', { name: 'Мебель и стены' }).click();
    await expect(page.locator('.plan-object[aria-label^="Стена"]')).toHaveCount(1);
    await page.getByRole('button', { name: 'Слои', exact: true }).click();

    // Add a DMX node and a fixture, move them apart, then connect out1 → dmxIn.
    const search = page.getByRole('textbox', { name: 'Поиск оборудования' });
    await search.fill('XND-8');
    await page.locator('.catalog-row[data-device-id="xnd8"]').first().click();
    await page.getByRole('textbox', { name: 'Позиция X' }).fill('-2');
    await page.getByRole('textbox', { name: 'Позиция X' }).press('Enter');
    await page.getByRole('textbox', { name: 'Позиция Z' }).fill('1');
    await page.getByRole('textbox', { name: 'Позиция Z' }).press('Enter');
    await search.fill('Focus Flex');
    await page.locator('.catalog-row[data-device-id="snl-444"]').first().click();
    await page.getByRole('textbox', { name: 'Позиция X' }).fill('2');
    await page.getByRole('textbox', { name: 'Позиция X' }).press('Enter');
    await page.getByRole('textbox', { name: 'Позиция Z' }).fill('1');
    await page.getByRole('textbox', { name: 'Позиция Z' }).press('Enter');

    const xndId = await page.locator('.plan-object[aria-label="Swisson XND-8"]').getAttribute('data-object-id');
    const focusId = await page.locator('.plan-object[aria-label="Focus Flex"]').getAttribute('data-object-id');
    expect(xndId).toBeTruthy();
    expect(focusId).toBeTruthy();
    await page.locator('[data-tool="cable"]').click();
    await page.locator(`[data-port-id="out1"][data-object-id="${xndId}"]`).dispatchEvent('pointerdown');
    await page.locator(`[data-port-id="dmxIn"][data-object-id="${focusId}"]`).dispatchEvent('pointerdown');
    await expect(page.locator('.plan-cable')).toHaveCount(1);

    await page.locator('[data-mode="patch"]').click();
    await expect(page.locator('.patch-tab', { hasText: 'DMX-патч' })).toBeVisible();
    await expect(page.locator(`tr[data-object-id="${focusId}"]`)).toContainText('Swisson XND-8');
    await expect(page.locator(`tr[data-object-id="${focusId}"]`)).toContainText('в патче');
    await page.locator('.patch-tab', { hasText: 'Подключения' }).click();
    await page.getByRole('button', { name: 'Открыть' }).first().click();
    await expect(page.getByText('Добавить изгиб')).toBeVisible();
    await page.getByRole('button', { name: 'Добавить изгиб' }).click();
    await expect(page.locator('.right-panel .panel-body')).toContainText('Изгибы');
    await expect(page.locator('.right-panel .panel-body')).toContainText('1');
  });
});
