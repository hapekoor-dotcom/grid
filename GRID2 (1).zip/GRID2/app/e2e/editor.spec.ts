import { expect, test, type Page } from '@playwright/test';

async function openDemo(page: Page) {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible();
  await page.locator('button[data-mode="plan"]').click();
  await expect(page.locator('.plan-svg')).toBeVisible();
}

test('fixture marker selects a fixture and opens its inspector', async ({ page }) => {
  await openDemo(page);
  await page.locator('.plan-object[aria-label="Focus Flex 01"]').click({ force: true });
  await expect(page.locator('.right-panel')).toContainText('Fixture');
  await expect(page.locator('.right-panel')).toContainText('Light');
  await expect(page.locator('.inspector-more > summary')).toBeVisible();

  await page.mouse.click(620, 620, { button: 'right' });
  await expect(page.locator('.context-menu')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.locator('.context-menu')).toHaveCount(0);
});

test('room inspector is structured and the workspace does not overflow at 1366', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 });
  await openDemo(page);
  await page.locator('.plan-object[aria-label="Main hall"]').dispatchEvent('pointerdown');
  await expect(page.locator('.right-panel')).toContainText('Dimensions');
  await expect(page.locator('.right-panel')).toContainText('Position');
  await expect(page.locator('.right-panel')).toContainText('Appearance');
  await expect(page.locator('.right-panel')).toContainText('Wall height');
  await expect(page.locator('.right-panel')).not.toContainText('Mounting');
  await expect(page.locator('.right-panel .panel-body')).toHaveCount(1);
  await expect(page.locator('.inspector-more > summary')).toBeVisible();

  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(1);
});

test('add menu creates a stage and selects it', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('E2E venue');
  await page.getByRole('button', { name: 'Create project' }).click();
  await expect(page.locator('.plan-svg')).toBeVisible();
  await page.getByRole('button', { name: 'Add object' }).click();
  await page.getByRole('menuitem', { name: /Stage/ }).click();
  const box = await page.locator('.plan-svg').boundingBox();
  expect(box).not.toBeNull();
  await page.mouse.move(box!.x + box!.width * 0.35, box!.y + box!.height * 0.35);
  await page.mouse.down();
  await page.mouse.move(box!.x + box!.width * 0.6, box!.y + box!.height * 0.55, { steps: 8 });
  await page.mouse.up();
  await expect(page.locator('.plan-object[aria-label="Stage"]')).toHaveCount(1);
  await expect(page.locator('.right-panel')).toContainText('Stage');
});
