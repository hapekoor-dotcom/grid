import { expect, test } from '@playwright/test';

test('TAA is explicit and history resets only for teleports', async ({ page }) => {
  await page.goto('/?inputDebug=1');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible();
  await page.waitForTimeout(900);
  const value = async (key: string) => page.locator('.input-debug-state > div').filter({ hasText: key }).locator('b').innerText();
  await page.getByRole('button', { name: /View/ }).click();
  await page.locator('.viewport-view-field select').selectOption('high');
  await page.waitForTimeout(500);
  expect(await value('aaMode')).toBe('taa');
  test.skip(await value('taaEnabled') === 'false', 'Headless software renderer disables TAA by design');
  const before = Number(await value('taaHistoryResets'));
  await page.getByRole('button', { name: /Hide floor|Show floor/ }).click();
  await page.waitForTimeout(300);
  expect(Number(await value('taaHistoryResets'))).toBe(before);
  await page.keyboard.press('f');
  await page.waitForTimeout(300);
  expect(Number(await value('taaHistoryResets'))).toBeGreaterThan(before);
  expect(await value('taaLastResetReason')).toBe('camera-teleport');
});
