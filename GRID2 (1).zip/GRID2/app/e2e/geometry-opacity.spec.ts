import { expect, test, type Page } from '@playwright/test';

async function redPixels(page: Page): Promise<number> {
  const buffer = await page.locator('canvas[aria-label^="3D scene"]').screenshot();
  return page.evaluate(async (base64) => {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = reject; i.src = `data:image/png;base64,${base64}`; });
    const canvas = document.createElement('canvas'); canvas.width = image.width; canvas.height = image.height;
    const context = canvas.getContext('2d')!; context.drawImage(image, 0, 0);
    const data = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let count = 0;
    for (let i = 0; i < data.length; i += 4) if (data[i] > 60 && data[i] > data[i + 1] + 20 && data[i] > data[i + 2] + 20) count += 1;
    return count;
  }, buffer.toString('base64'));
}

test('geometry displacement never makes an opaque material see-through', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Opacity Safety');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Box' }).first().click();
  await page.evaluate(() => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { const o = draft.objects.find((entry: any) => entry.type === 'model'); o.material = { color: '#ff2020' }; }); });
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(1800);
  const baseline = await redPixels(page);
  expect(baseline).toBeGreaterThan(100);
  const modifiers = [
    ['noiseDisplace', { strength: 0.6, scale: 2, speed: 0, seed: 1, maskX: true, maskY: true, maskZ: true }],
    ['spherize', { amount: 1.2, radius: 1.5 }],
    ['twist', { amount: 360, axis: 'y', falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, start: -10, end: 10, animate: false }],
    ['fbmDisplace', { strength: 0.5, scale: 2, speed: 0, octaves: 4, seed: 1, maskX: true, maskY: true, maskZ: true }],
    ['melt', { amount: 0.6, threshold: 0.2, axis: 'y', speed: 0 }],
  ] as const;
  for (const [type, params] of modifiers) {
    await page.evaluate(({ type, params }) => { const s = (window as any).__RE_STORE__.getState(); s.mutate((draft: any) => { const o = draft.objects.find((entry: any) => entry.type === 'model'); o.modifiers = [{ id: type, type, enabled: true, params }]; }); }, { type, params });
    await page.waitForTimeout(700);
    expect(await redPixels(page), `${type} became transparent`).toBeGreaterThan(baseline * 0.35);
  }
});
