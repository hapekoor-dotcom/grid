import { expect, test } from '@playwright/test';

test('settings and post dialogs do not break viewport LMB', async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto('/?inputDebug=1');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('LMB UI');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(600);
  if (!(await page.locator('.sidebar-settings').isVisible().catch(() => false))) await page.locator('.panel-toggle--left').click();
  await page.locator('.sidebar-settings').click();
  await page.getByRole('button', { name: 'Done' }).click();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post FX stack/ }).click();
  await page.getByRole('button', { name: 'Done' }).click();
  await page.evaluate(() => {
    const store = (window as any).__RE_STORE__.getState();
    store.mutate((draft: any) => {
      const object = draft.objects.find((entry: any) => entry.type === 'model');
      object.modifiers = [{ id: 'twist', type: 'twist', enabled: true, params: { amount: 40, axis: 'y', falloff: 1, pivotX: 0, pivotY: 0, pivotZ: 0, start: -10, end: 10, animate: false } }];
    });
  });
  if (!(await page.locator('.sidebar-settings').isVisible().catch(() => false))) await page.locator('.panel-toggle--left').click();
  await page.locator('.panel-toggle--right').click().catch(() => {});
  await page.getByRole('button', { name: 'Graph', exact: true }).click();
  await page.getByRole('button', { name: 'Done' }).click();
  const box = await page.locator('canvas[aria-label^="3D scene"]').boundingBox();
  await page.mouse.click(box!.x + box!.width * 0.5, box!.y + box!.height * 0.5);
  await page.waitForTimeout(200);
  await page.mouse.click(box!.x + box!.width * 0.5, box!.y + box!.height * 0.9);
  await expect(page.locator('.input-debug-state > div').filter({ hasText: 'pointerOwner' }).locator('b')).toHaveText('NONE');
  await expect(page.locator('.input-debug-state > div').filter({ hasText: 'buttons' }).locator('b')).toHaveText('0');
});
