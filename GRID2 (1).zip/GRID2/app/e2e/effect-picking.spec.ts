import { expect, test } from '@playwright/test';

async function setup(page: any, name: string) {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill(name);
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Box' }).first().click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
  await page.waitForTimeout(2500);
}

test('extreme deformation is clickable outside the original mesh bounds', async ({ page }) => {
  test.setTimeout(120_000);
  await setup(page, 'Effect Pick');
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    const o = s.projects[0].objects.find((entry: any) => entry.type === 'model');
    s.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.id === o.id); object.modifiers = [{ id: 'sph', type: 'spherize', enabled: true, params: { amount: 5, radius: 5 } }]; });
    (window as any).__RE_RUNTIME__.frameSelection([o.id]);
    (window as any).__RE_UI__.getState().clearSelection();
  });
  await page.waitForTimeout(1500);
  const debug = await page.evaluate(() => (window as any).__RE_RUNTIME__.getPickingDebug());
  const bound = debug.bounds[0];
  expect(bound.effective[0]).toBeGreaterThan(bound.original[0] * 2);
  const box = (await page.locator('canvas[aria-label^="3D scene"]').boundingBox())!;
  const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
  const x = box.x + box.width * 0.6;
  const y = box.y + box.height * 0.5;
  await page.mouse.click(x, y);
  await page.waitForTimeout(300);
  const selected = await page.evaluate(() => (window as any).__RE_UI__.getState().selectedIds);
  expect(selected.length).toBe(1);
  const picks = await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug());
  expect(['picker', 'effective-bounds', 'ray-fallback']).toContain(picks.pickMethod);
  expect(picks.hoverId).toBeTruthy();
});

test('clicking any procedural clone selects the parent object', async ({ page }) => {
  test.setTimeout(120_000);
  await setup(page, 'Clone Pick');
  await page.evaluate(() => {
    const s = (window as any).__RE_STORE__.getState();
    const o = s.projects[0].objects.find((entry: any) => entry.type === 'model');
    s.mutate((draft: any) => { const object = draft.objects.find((entry: any) => entry.id === o.id); object.modifiers = [{ id: 'clone', type: 'radialClone', enabled: true, params: { count: 200, radius: 6, spacing: 1.5, height: 0, phase: 0, pattern: 'ring', orbit: false, orbitSpeed: 0.2, scaleVariation: 0, rotationFollow: true, scaleProgression: 0, pulse: 0, pulseSpeed: 1, randomness: 0 } }]; });
    (window as any).__RE_RUNTIME__.frameSelection([o.id]);
    (window as any).__RE_UI__.getState().clearSelection();
  });
  await page.waitForTimeout(2500);
  const debug = await page.evaluate(() => (window as any).__RE_RUNTIME__.getPickingDebug());
  const bound = debug.bounds[0];
  const box = (await page.locator('canvas[aria-label^="3D scene"]').boundingBox())!;
  const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
  const x = clamp(bound.minX + (bound.maxX - bound.minX) * 0.12, box.x + 30, box.x + box.width - 30);
  const y = clamp(bound.minY + (bound.maxY - bound.minY) * 0.5, box.y + 30, box.y + box.height - 30);
  await page.mouse.click(x, y);
  await page.waitForTimeout(300);
  const selected = await page.evaluate(() => (window as any).__RE_UI__.getState().selectedIds);
  expect(selected.length).toBe(1);
  expect((await page.evaluate(() => (window as any).__RE_RUNTIME__.getInputDebug().cloneCount))).toBe(200);
});
