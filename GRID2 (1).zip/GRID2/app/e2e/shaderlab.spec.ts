import path from 'node:path';
import { expect, test } from '@playwright/test';

test('custom mesh shader compiles and assigns', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Shader Lab');
  await page.getByRole('button', { name: 'Create project' }).click();
  const [chooser] = await Promise.all([
    page.waitForEvent('filechooser'),
    page.getByRole('button', { name: /Import 3D Model/ }).click(),
  ]);
  await chooser.setFiles(path.resolve(process.cwd(), 'public/assets/models/abstract-loop.glb'));
  await expect(page.locator('.plan-object[aria-label="abstract-loop"]')).toHaveCount(1, { timeout: 15000 });
  const material = page.locator('.section-toggle').filter({ hasText: 'Material' }).first();
  if (await material.count() && await material.getAttribute('aria-expanded') === 'false') await material.click();
  await page.getByRole('button', { name: 'Shader Lab' }).click();
  await page.getByRole('button', { name: /PBR Mesh/ }).click();
  await expect(page.getByLabel('vertex shader source')).toBeVisible();
  await page.getByRole('button', { name: 'Compile' }).click();
  await expect(page.locator('.shader-status')).toHaveText('Valid');
  await page.getByRole('button', { name: /Assign to/ }).click();
  await expect(page.getByText('Custom shaders')).toBeVisible();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
});

test('full custom mesh shader compiles and renders', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Project name' }).fill('Full Custom');
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.locator('.primitive-button').filter({ hasText: 'Sphere' }).first().click();
  const material = page.locator('.section-toggle').filter({ hasText: 'Material' }).first();
  if (await material.count() && await material.getAttribute('aria-expanded') === 'false') await material.click();
  await page.getByRole('button', { name: 'Shader Lab' }).click();
  await page.getByRole('button', { name: /Full Custom Mesh/ }).click();
  await page.getByRole('button', { name: 'Compile' }).click();
  await expect(page.locator('.shader-status')).toHaveText('Valid');
  await page.getByRole('button', { name: /Assign to/ }).click();
  await page.locator('button[data-mode="3d"]').click();
  await expect(page.locator('canvas[aria-label^="3D scene"]')).toBeVisible({ timeout: 30000 });
});

test('scene post stack supports multiple ordered passes', async ({ page }) => {
  test.setTimeout(180_000);
  await page.goto('/?inputDebug=1');
  await page.getByRole('button', { name: 'Explore demo' }).click();
  await page.locator('button[data-mode="3d"]').click();
  await page.waitForTimeout(700);
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post Shader Lab/ }).click();
  await page.getByRole('button', { name: /\+ Post \/ Fullscreen/ }).click();
  await expect(page.locator('.shader-context-badge')).toHaveText('POST / FULLSCREEN');
  await page.getByRole('button', { name: 'Feedback', exact: true }).click();
  await page.getByRole('button', { name: 'Compile' }).click();
  await page.getByRole('button', { name: /Add to Post Stack/ }).click();
  await expect(page.locator('.input-debug-renderer')).toContainText('renderer');
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post FX stack/ }).click();
  await expect(page.locator('.post-fx-row')).toHaveCount(1);
  await page.getByRole('button', { name: '+ Add Post Shader' }).click();
  await page.getByRole('button', { name: /\+ Post \/ Fullscreen/ }).click();
  await page.getByRole('button', { name: 'RGB Split', exact: true }).click();
  await page.getByRole('button', { name: 'Compile' }).click();
  await page.getByRole('button', { name: /Add to Post Stack/ }).click();
  await expect(page.locator('.post-fx-row')).toHaveCount(2);
  await expect(page.locator('.post-fx-row').nth(1)).toContainText('RGB Split');
  await page.getByLabel('Move up').last().click();
  await expect(page.locator('.post-fx-row').nth(0)).toContainText('RGB Split');
  await page.getByRole('button', { name: 'Duplicate' }).first().click();
  await expect(page.locator('.post-fx-row')).toHaveCount(3);
  await page.getByRole('button', { name: 'Delete' }).first().click();
  await expect(page.locator('.post-fx-row')).toHaveCount(2);
  await page.getByRole('button', { name: 'Done' }).click();
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('button[data-mode="3d"]').click();
  await page.getByRole('button', { name: /View/ }).click();
  await page.getByRole('button', { name: /Post FX stack/ }).click();
  await expect(page.locator('.post-fx-row')).toHaveCount(2);
  await expect(page.locator('.post-fx-row').nth(0)).toContainText('RGB Split');
  await expect(page.locator('.input-debug-renderer')).toContainText('Post passes');
});

