/*
 * Builds the normalized RE:GRID equipment catalog from the evidence-backed
 * Rig Grid dataset (bundled under scripts/legacy-data). Manufacturer evidence is never invented here: unknown
 * values stay null and every device keeps its verification status and sources.
 */
import fs from 'node:fs';
import path from 'node:path';

const SOURCE = path.resolve(import.meta.dirname, 'legacy-data');
const OUT = path.resolve(import.meta.dirname, '../src/data/catalog.json');

const verificationFiles = [
  'verified-light-a.json',
  'verified-light-b.json',
  'verified-control-power.json',
  'verified-video.json',
  'corrections-light-fixtures.json',
  'corrections-effects.json',
  'corrections-controls.json',
  'corrections-video.json',
];

const read = (file) => JSON.parse(fs.readFileSync(path.join(SOURCE, file), 'utf8'));

const researched = read('catalog-researched.json');
const shortNames = read('catalog-short-names.json');
const evidence = {};
for (const file of verificationFiles) {
  for (const [id, patch] of Object.entries(read(file))) {
    evidence[id] = { ...(evidence[id] || {}), ...patch };
  }
}

/* ------------------------------------------------------------------ */
/* Planning-only equipment: stage, rigging and furniture.               */
/* Sizes are explicit planning defaults, never manufacturer claims.     */
/* ------------------------------------------------------------------ */

const planning = (overrides) => ({
  consumes: false,
  dmx: false,
  watts: null,
  wattsBasis: 'unknown',
  powerLink: false,
  verificationStatus: 'generic',
  planning: true,
  modes: [],
  signalPorts: [],
  powerPortDefinitions: [],
  ...overrides,
});

const BASE = [
  planning({
    id: 'outlet',
    name: 'Сеть 230 В',
    shortName: 'Сеть 230 В',
    category: 'power',
    kind: 'outlet',
    sourceType: true,
    outputs: 4,
    consumes: false,
    powerRole: 'source',
    dims: { w: 0.12, d: 0.1, h: 0.08, source: 'planning' },
    planSize: { w: 0.22, d: 0.16 },
    notes: ['Один выход питания. Задайте ID линии, фазу и бюджет мощности. Значения вводятся вручную и не являются сертификатом электрической безопасности.'],
    catalogSubtitle: 'Источник · 4 выхода · лимит задаётся вручную',
  }),
  planning({
    id: 'wall-outlet',
    name: 'Розетка',
    shortName: 'Розетка',
    category: 'power',
    kind: 'outlet',
    sourceType: true,
    outputs: 1,
    powerRole: 'source',
    hidden: true,
    dims: { w: 0.12, d: 0.1, h: 0.08, source: 'planning' },
    planSize: { w: 0.16, d: 0.12 },
  }),
  planning({
    id: 'distro',
    name: 'Распределитель питания',
    shortName: 'Распределитель',
    category: 'power',
    kind: 'distro',
    consumes: true,
    outputs: 4,
    watts: 0,
    dims: { w: 0.55, d: 0.35, h: 0.32, source: 'planning' },
    planSize: { w: 1.0, d: 0.7 },
    catalogSubtitle: '4 выхода · распределение по фазам',
    notes: ['Число выходов меняется в инспекторе. Наследует фазу источника. Сумма нагрузки по выходам не заменяет проверку автомата и кабеля.'],
  }),
  planning({
    id: 'battery',
    name: 'АКБ / инвертор',
    shortName: 'АКБ',
    category: 'power',
    kind: 'battery',
    sourceType: true,
    outputs: 1,
    powerRole: 'source',
    dims: { w: 0.4, d: 0.28, h: 0.25, source: 'planning' },
    planSize: { w: 0.7, d: 0.5 },
    notes: ['Укажите максимальную выходную мощность и полезную ёмкость Wh. Это разные величины; запас по Wh не подтверждает допустимый ток.'],
  }),
  planning({
    id: 'xnd8',
    name: 'Swisson XND-8',
    shortName: 'Swisson XND-8',
    category: 'network',
    kind: 'node',
    consumes: true,
    dmx: true,
    ethernet: true,
    watts: 11,
    wattsBasis: 'typical',
    dims: { w: 0.48, d: 0.3, h: 0.09, source: 'planning' },
    planSize: { w: 1.1, d: 0.7 },
    outputs: 8,
    catalogSubtitle: '8 портов · Art-Net / sACN',
    sourceUrls: ['https://www.swisson.com/site/assets/files/1238/um_xnd-8-d0-len-v01-05-1.pdf'],
    notes: ['Восемь DMX-портов переключаются IN/OUT; в проекте по умолчанию выходы. 11 W — типичная мощность, максимум не указан.'],
    signalPorts: [
      { id: 'ethernetIn', type: 'ethernet', out: false, connector: 'RJ45 etherCON', label: 'LAN' },
      { id: 'out1', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U1', universeIndex: 0 },
      { id: 'out2', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U2', universeIndex: 1 },
      { id: 'out3', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U3', universeIndex: 2 },
      { id: 'out4', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U4', universeIndex: 3 },
      { id: 'out5', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U5', universeIndex: 4 },
      { id: 'out6', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U6', universeIndex: 5 },
      { id: 'out7', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U7', universeIndex: 6 },
      { id: 'out8', type: 'dmx', out: true, connector: 'DMX: вариант 3-pin / 5-pin / RJ45', label: 'U8', universeIndex: 7 },
    ],
    powerPortDefinitions: [
      { id: 'powerIn', out: false, connector: 'powerCON' },
      { id: 'powerOut', out: true, connector: 'powerCON' },
    ],
  }),
  planning({
    id: 'splitter',
    name: 'DMX-сплиттер',
    shortName: 'DMX-сплиттер',
    category: 'network',
    kind: 'splitter',
    consumes: true,
    dmx: true,
    outputs: 4,
    planSize: { w: 1.0, d: 0.6 },
    catalogSubtitle: '2 входа · 4 выхода',
    notes: ['Типовой блок. Укажите модель, мощность и физические разъёмы в инспекторе.'],
    signalPorts: [
      { id: 'dmxA', type: 'dmx', out: false, connector: 'XLR 5-pin', label: 'A' },
      { id: 'dmxB', type: 'dmx', out: false, connector: 'XLR 5-pin', label: 'B' },
      { id: 'out1', type: 'dmx', out: true, connector: 'XLR 5-pin', label: '1' },
      { id: 'out2', type: 'dmx', out: true, connector: 'XLR 5-pin', label: '2' },
      { id: 'out3', type: 'dmx', out: true, connector: 'XLR 5-pin', label: '3' },
      { id: 'out4', type: 'dmx', out: true, connector: 'XLR 5-pin', label: '4' },
    ],
    dualInput: true,
  }),
  planning({
    id: 'receiver',
    name: 'Беспроводной DMX-ресивер',
    shortName: 'DMX-ресивер',
    category: 'network',
    kind: 'receiver',
    consumes: true,
    dmx: true,
    outputs: 1,
    planSize: { w: 0.55, d: 0.45 },
    notes: ['Радиоканал отображается пунктиром. Совместимость радиосистем указывается вручную.'],
    signalPorts: [
      { id: 'wirelessIn', type: 'wireless', out: false, connector: 'Wireless', label: 'RX' },
      { id: 'dmxOut', type: 'dmx', out: true, connector: 'XLR 5-pin', label: 'DMX' },
    ],
  }),
  planning({
    id: 'transmitter',
    name: 'Беспроводной DMX-передатчик',
    shortName: 'DMX-передатчик',
    category: 'network',
    kind: 'transmitter',
    consumes: true,
    dmx: true,
    outputs: 1,
    planSize: { w: 0.55, d: 0.45 },
    signalPorts: [
      { id: 'dmxIn', type: 'dmx', out: false, connector: 'XLR 5-pin', label: 'DMX' },
      { id: 'wirelessOut', type: 'wireless', out: true, connector: 'Wireless', label: 'TX' },
    ],
  }),
  planning({
    id: 'switch',
    name: 'Ethernet-коммутатор',
    shortName: 'Коммутатор',
    category: 'network',
    kind: 'switch',
    consumes: true,
    ethernet: true,
    outputs: 4,
    planSize: { w: 1.0, d: 0.55 },
    catalogSubtitle: '4 порта',
    signalPorts: [
      { id: 'ethernetIn', type: 'ethernet', out: false, connector: 'RJ45', label: 'IN' },
      { id: 'ethernet1', type: 'ethernet', out: true, connector: 'RJ45', label: '1' },
      { id: 'ethernet2', type: 'ethernet', out: true, connector: 'RJ45', label: '2' },
      { id: 'ethernet3', type: 'ethernet', out: true, connector: 'RJ45', label: '3' },
      { id: 'ethernet4', type: 'ethernet', out: true, connector: 'RJ45', label: '4' },
    ],
  }),
  planning({
    id: 'console',
    name: 'Пульт управления светом',
    shortName: 'Пульт',
    category: 'control',
    kind: 'console',
    consumes: true,
    dmx: true,
    ethernet: true,
    usb: true,
    outputs: 2,
    planSize: { w: 1.6, d: 0.9 },
    catalogSubtitle: 'Типовой пульт · 2 DMX-выхода',
    notes: ['Типовой пульт. Укажите модель, число DMX-выходов и мощность. Это не заявление о поддержке конкретного протокола.'],
    signalPorts: [
      { id: 'dmxOut1', type: 'dmx', out: true, connector: 'XLR 5-pin', label: 'U1', universeIndex: 0 },
      { id: 'dmxOut2', type: 'dmx', out: true, connector: 'XLR 5-pin', label: 'U2', universeIndex: 1 },
      { id: 'ethernet', type: 'ethernet', out: true, connector: 'RJ45', label: 'LAN' },
      { id: 'usb', type: 'usb', out: true, connector: 'USB-A', label: 'USB' },
    ],
  }),
  planning({
    id: 'laptop',
    name: 'Ноутбук',
    shortName: 'Ноутбук',
    category: 'control',
    kind: 'laptop',
    consumes: true,
    internalBattery: true,
    ethernet: true,
    video: true,
    usb: true,
    planSize: { w: 0.7, d: 0.5 },
    notes: ['Типовой ноутбук. Порты могут требовать адаптеров; укажите фактические выходы.'],
    signalPorts: [
      { id: 'ethernet', type: 'ethernet', out: true, connector: 'RJ45', label: 'LAN' },
      { id: 'usb', type: 'usb', out: true, connector: 'USB-A/C', label: 'USB' },
      { id: 'video', type: 'video', out: true, connector: 'HDMI', label: 'HDMI' },
    ],
  }),
  planning({
    id: 'computer',
    name: 'Компьютер',
    shortName: 'Компьютер',
    category: 'control',
    kind: 'computer',
    consumes: true,
    ethernet: true,
    video: true,
    usb: true,
    planSize: { w: 0.45, d: 0.45 },
    signalPorts: [
      { id: 'ethernet', type: 'ethernet', out: true, connector: 'RJ45', label: 'LAN' },
      { id: 'usb', type: 'usb', out: true, connector: 'USB-A', label: 'USB' },
      { id: 'video', type: 'video', out: true, connector: 'HDMI', label: 'HDMI' },
    ],
  }),
  planning({
    id: 'video-mixer',
    name: 'Видеомикшер',
    shortName: 'Видеомикшер',
    category: 'video',
    kind: 'mixer',
    consumes: true,
    video: true,
    outputs: 2,
    planSize: { w: 1.0, d: 0.65 },
    signalPorts: [
      { id: 'videoIn1', type: 'video', out: false, connector: 'HDMI', label: '1' },
      { id: 'videoIn2', type: 'video', out: false, connector: 'HDMI', label: '2' },
      { id: 'videoOut', type: 'video', out: true, connector: 'HDMI', label: 'PGM' },
    ],
  }),
  planning({
    id: 'truss-2m',
    name: 'Ферма, секция 2 м',
    shortName: 'Ферма 2 м',
    category: 'rigging',
    kind: 'truss',
    dims: { w: 2, d: 0.29, h: 0.29, source: 'planning' },
    planSize: { w: 2, d: 0.29 },
    catalogSubtitle: 'Условная секция 290 мм',
    notes: ['Габарит и масса условные. Для расчёта подвеса нужны данные конкретной фермы и проекта конструктора.'],
    loadKg: null,
  }),
  planning({
    id: 'truss-3m',
    name: 'Ферма, секция 3 м',
    shortName: 'Ферма 3 м',
    category: 'rigging',
    kind: 'truss',
    dims: { w: 3, d: 0.29, h: 0.29, source: 'planning' },
    planSize: { w: 3, d: 0.29 },
    catalogSubtitle: 'Условная секция 290 мм',
    notes: ['Габарит и масса условные. Для расчёта подвеса нужны данные конкретной фермы и проекта конструктора.'],
    loadKg: null,
  }),
  planning({
    id: 'truss-tower',
    name: 'Ферма-башня 3 м',
    shortName: 'Башня 3 м',
    category: 'rigging',
    kind: 'trussTower',
    dims: { w: 0.3, d: 0.3, h: 3, source: 'planning' },
    planSize: { w: 0.3, d: 0.3 },
    catalogSubtitle: 'Условная вертикальная опора',
    notes: ['Конструкция и устойчивость не рассчитываются. Условный планировочный объект.'],
  }),
  planning({
    id: 'stage-deck',
    name: 'Сценический подиум 2 × 1 м',
    shortName: 'Подиум 2 × 1',
    category: 'stage',
    kind: 'stage',
    dims: { w: 2, d: 1, h: 0.4, source: 'planning' },
    planSize: { w: 2, d: 1 },
    catalogSubtitle: 'Высота 0,4 м',
    notes: ['Планировочный габарит. Несущая способность и ограждения не проверяются.'],
  }),
  planning({
    id: 'stage-deck-1',
    name: 'Сценический подиум 1 × 1 м',
    shortName: 'Подиум 1 × 1',
    category: 'stage',
    kind: 'stage',
    dims: { w: 1, d: 1, h: 0.2, source: 'planning' },
    planSize: { w: 1, d: 1 },
    catalogSubtitle: 'Высота 0,2 м',
  }),
  planning({
    id: 'riser',
    name: 'Райзер / ступень',
    shortName: 'Райзер',
    category: 'stage',
    kind: 'stage',
    dims: { w: 1.2, d: 0.6, h: 0.2, source: 'planning' },
    planSize: { w: 1.2, d: 0.6 },
    catalogSubtitle: 'Высота 0,2 м',
  }),
  planning({
    id: 'curtain',
    name: 'Сценический задник',
    shortName: 'Задник',
    category: 'stage',
    kind: 'curtain',
    dims: { w: 6, d: 0.08, h: 5, source: 'planning' },
    planSize: { w: 6, d: 0.08 },
    catalogSubtitle: 'Ширма 6 × 5 м',
    notes: ['Условная ширма. Материал, огнезащита и крепление не проверяются.'],
  }),
  planning({
    id: 'table',
    name: 'Стол',
    shortName: 'Стол',
    category: 'stage',
    kind: 'table',
    dims: { w: 1.2, d: 0.8, h: 0.75, source: 'planning' },
    planSize: { w: 1.2, d: 0.8 },
  }),
  planning({
    id: 'chair',
    name: 'Стул',
    shortName: 'Стул',
    category: 'stage',
    kind: 'chair',
    dims: { w: 0.5, d: 0.5, h: 0.9, source: 'planning' },
    planSize: { w: 0.5, d: 0.5 },
  }),
  planning({
    id: 'barricade',
    name: 'Ограждение',
    shortName: 'Ограждение',
    category: 'stage',
    kind: 'barricade',
    dims: { w: 2, d: 0.1, h: 1.1, source: 'planning' },
    planSize: { w: 2, d: 0.1 },
    catalogSubtitle: 'Секция 2 м',
  }),
];

const genericKinds = {
  par: ['LED PAR', 'par', 'Свет'],
  head: ['Moving Head Wash', 'head', 'Свет'],
  spot: ['Moving Head Spot', 'spot', 'Свет'],
  beam: ['Moving Head Beam', 'beam', 'Свет'],
  pixel: ['Пиксельный бар', 'pixel', 'Свет'],
  strobe: ['Стробоскоп', 'strobe', 'Свет'],
  blinder: ['Блайндер', 'blinder', 'Свет'],
  bar: ['LED-бар', 'bar', 'Свет'],
  laser: ['Лазер', 'laser', 'Свет'],
  mirrorball: ['Зеркальный шар', 'mirrorball', 'Свет'],
};

for (const [kind, [name, uiKind, category]] of Object.entries(genericKinds)) {
  BASE.push(
    planning({
      id: `generic-${kind}`,
      name,
      shortName: name,
      category: 'light',
      kind: uiKind,
      generic: true,
      dmx: true,
      consumes: true,
      modes: [],
      hidden: false,
      planSize: defaultPlanSize(uiKind),
      catalogSubtitle: 'Без модели · профиль не задан',
      notes: ['Блок без конкретной модели. DMX-режим и разъёмы неизвестны, пока вы не укажете их вручную.'],
    }),
  );
}
for (const [kind, name] of Object.entries({ haze: 'Хейзер', fog: 'Дым-машина', confetti: 'Конфетти', snow: 'Снег', bubble: 'Мыльные пузыри', co2: 'CO₂-эффект', flame: 'Огненный эффект' })) {
  BASE.push(
    planning({
      id: `generic-${kind}`,
      name,
      shortName: name,
      category: 'effects',
      kind: kind === 'haze' ? 'haze' : kind === 'fog' ? 'fog' : kind,
      generic: true,
      dmx: true,
      consumes: true,
      modes: [],
      planSize: defaultPlanSize(kind),
      catalogSubtitle: 'Без модели · профиль не задан',
      notes: ['Блок без конкретной модели. Укажите модель, DMX-режим и потребление по документации.'],
    }),
  );
}
BASE.push(
  planning({
    id: 'generic-ledwall',
    name: 'LED-стена',
    shortName: 'LED-стена',
    category: 'video',
    kind: 'ledwall',
    generic: true,
    consumes: true,
    video: true,
    planSize: { w: 3, d: 0.15 },
    dims: { w: 3, d: 0.15, h: 2, source: 'planning' },
    catalogSubtitle: 'Без модели · условный модуль',
    notes: ['Укажите суммарную максимальную мощность всех кабинетов. Видеопроцессор и транспорт согласуются отдельно.'],
  }),
  planning({
    id: 'generic-tv',
    name: 'Телевизор / монитор',
    shortName: 'Телевизор',
    category: 'video',
    kind: 'tv',
    generic: true,
    consumes: true,
    video: true,
    planSize: { w: 1.2, d: 0.1 },
    dims: { w: 1.2, d: 0.1, h: 0.7, source: 'planning' },
  }),
  planning({
    id: 'generic-projector',
    name: 'Проектор',
    shortName: 'Проектор',
    category: 'video',
    kind: 'projector',
    generic: true,
    consumes: true,
    video: true,
    planSize: { w: 0.4, d: 0.35 },
    dims: { w: 0.4, d: 0.35, h: 0.2, source: 'planning' },
  }),
  planning({
    id: 'generic-processor',
    name: 'Видеопроцессор LED',
    shortName: 'Видеопроцессор',
    category: 'video',
    kind: 'processor',
    generic: true,
    consumes: true,
    video: true,
    planSize: { w: 0.9, d: 0.55 },
  }),
);

/* ------------------------------------------------------------------ */
/* Normalization helpers                                              */
/* ------------------------------------------------------------------ */

const CATEGORY_MAP = {
  light: 'light',
  effect: 'effects',
  node: 'network',
  power: 'power',
  input: 'control',
  video: 'video',
  rigging: 'rigging',
  stage: 'stage',
};

const KIND_MAP = {
  light: {
    head: 'head', wash: 'head', beam: 'beam', spot: 'spot', par: 'par', bar: 'bar',
    pixel: 'pixel', strobe: 'strobe', blinder: 'blinder', laser: 'laser', mirrorball: 'mirrorball',
    effectlight: 'effectlight', flood: 'flood', decor: 'decor', panel: 'panel', motor: 'motor',
    other: 'other',
  },
  effect: { haze: 'haze', fog: 'fog', snow: 'snow', bubble: 'bubble', co2: 'co2', confetti: 'confetti', flame: 'flame', fan: 'fan', other: 'effect' },
  power: { outlet: 'outlet', distro: 'distro', battery: 'battery', 'battery-extension': 'battery', powerbank: 'battery', powerstation: 'battery', generator: 'generator', solar: 'solar', dimmer: 'dimmer', other: 'power' },
  node: { node: 'node', splitter: 'splitter', switch: 'switch', receiver: 'receiver', transmitter: 'transmitter', interface: 'interface', other: 'node' },
  input: { console: 'console', laptop: 'laptop', computer: 'computer', mixer: 'mixer', interface: 'interface', phone: 'phone', tablet: 'tablet', controller: 'controller', player: 'player', camera: 'camera', other: 'controller' },
  video: { ledwall: 'ledwall', tv: 'tv', projector: 'projector', processor: 'processor', camera: 'camera', mixer: 'mixer', other: 'video' },
};

function defaultPlanSize(kind) {
  const sizes = {
    head: { w: 0.55, d: 0.5 }, beam: { w: 0.5, d: 0.45 }, spot: { w: 0.55, d: 0.5 },
    par: { w: 0.4, d: 0.35 }, bar: { w: 1.05, d: 0.14 }, pixel: { w: 1.05, d: 0.12 },
    strobe: { w: 0.65, d: 0.2 }, blinder: { w: 0.55, d: 0.3 }, laser: { w: 0.28, d: 0.22 },
    mirrorball: { w: 0.32, d: 0.32 }, effectlight: { w: 0.45, d: 0.35 }, flood: { w: 0.45, d: 0.3 },
    decor: { w: 0.4, d: 0.3 }, panel: { w: 0.55, d: 0.15 }, motor: { w: 0.2, d: 0.2 },
    other: { w: 0.4, d: 0.35 }, haze: { w: 0.55, d: 0.45 },
    fog: { w: 0.55, d: 0.45 }, snow: { w: 0.45, d: 0.35 }, bubble: { w: 0.45, d: 0.35 },
    co2: { w: 0.45, d: 0.35 }, confetti: { w: 0.45, d: 0.35 }, flame: { w: 0.4, d: 0.3 },
    fan: { w: 0.4, d: 0.35 }, effect: { w: 0.5, d: 0.4 }, node: { w: 0.7, d: 0.4 }, splitter: { w: 0.6, d: 0.4 },
    switch: { w: 0.6, d: 0.4 }, receiver: { w: 0.45, d: 0.35 }, transmitter: { w: 0.45, d: 0.35 },
    interface: { w: 0.6, d: 0.4 }, console: { w: 1.3, d: 0.8 }, laptop: { w: 0.6, d: 0.45 },
    computer: { w: 0.4, d: 0.4 }, mixer: { w: 1.0, d: 0.65 }, phone: { w: 0.3, d: 0.2 },
    tablet: { w: 0.4, d: 0.3 }, controller: { w: 0.5, d: 0.4 }, outlet: { w: 0.22, d: 0.16 },
    distro: { w: 0.9, d: 0.65 }, battery: { w: 0.6, d: 0.45 }, generator: { w: 1.2, d: 0.8 },
    solar: { w: 1.6, d: 0.9 }, dimmer: { w: 0.6, d: 0.4 }, player: { w: 0.45, d: 0.3 },
    power: { w: 0.5, d: 0.4 }, ledwall: { w: 3, d: 0.15 },
    tv: { w: 1.2, d: 0.1 }, projector: { w: 0.4, d: 0.35 }, processor: { w: 0.9, d: 0.55 },
    camera: { w: 0.3, d: 0.3 }, video: { w: 0.5, d: 0.4 }, truss: { w: 2, d: 0.29 },
    trussTower: { w: 0.3, d: 0.3 }, stage: { w: 2, d: 1 }, curtain: { w: 6, d: 0.08 },
    table: { w: 1.2, d: 0.8 }, chair: { w: 0.5, d: 0.5 }, barricade: { w: 2, d: 0.1 },
  };
  return sizes[kind] || { w: 0.5, d: 0.4 };
}

function defaultDims(kind) {
  const plan = defaultPlanSize(kind);
  const heights = {
    head: 0.55, beam: 0.55, spot: 0.55, par: 0.3, bar: 0.18, pixel: 0.12, strobe: 0.3,
    effectlight: 0.3, flood: 0.25, decor: 0.4, panel: 0.55, motor: 0.15, fan: 0.4,
    blinder: 0.25, laser: 0.2, mirrorball: 0.32, node: 0.09, splitter: 0.09, switch: 0.08,
    console: 0.15, laptop: 0.03, computer: 0.45, outlet: 0.08, distro: 0.32, battery: 0.3,
    ledwall: 2, tv: 0.7, projector: 0.2, processor: 0.1, haze: 0.3, fog: 0.3, stage: 0.4,
    curtain: 5, table: 0.75, chair: 0.9, barricade: 1.1, truss: 0.29, trussTower: 3,
  };
  return { w: plan.w, d: plan.d, h: heights[kind] || 0.4, source: 'planning' };
}

const BRANDS = [
  'American DJ', 'ADJ', 'Chauvet DJ', 'Chauvet', 'Eurolite', 'Showtec', 'Swisson', 'EcoFlow',
  'Beamz', 'Martin', 'SGM', 'Kupo', 'Shehds', 'Equinox', 'Laserworld', 'Stariville', 'HQ Power',
  'Neewer', 'Gold', 'GS Industry', 'Appolo', 'Wolfmix', 'Philips', 'Aurora', 'Antari', 'Look Solutions',
];
function brandOf(name, short) {
  const hay = `${name} ${short}`;
  return BRANDS.find((b) => new RegExp(`(^|\\s)${b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\s|$)`, 'i').test(hay)) || null;
}

function inferCapabilities(device, kind, category) {
  if (category !== 'light' && category !== 'effects') {
    return { dimmer: false, color: false, pan: false, tilt: false, zoom: false, strobe: false, focus: false };
  }
  const moving = ['head', 'beam', 'spot'].includes(kind);
  const color = ['head', 'beam', 'spot', 'par', 'bar', 'pixel', 'blinder', 'other', 'strobe'].includes(kind);
  const effect = category === 'effects';
  return {
    dimmer: effect ? true : true,
    color: color && !['strobe'].includes(kind),
    pan: moving,
    tilt: moving,
    zoom: moving || kind === 'par' || kind === 'beam' || kind === 'spot',
    strobe: !effect || kind === 'strobe',
    focus: moving,
  };
}

function defaultBeamAngle(kind) {
  if (kind === 'beam') return 4;
  if (kind === 'spot') return 14;
  if (kind === 'head') return 20;
  if (kind === 'par') return 24;
  if (kind === 'bar' || kind === 'pixel') return 40;
  if (kind === 'strobe' || kind === 'blinder') return 70;
  return 30;
}

function normalizePorts(device, category, kind) {
  const signalPorts = Array.isArray(device.signalPorts) ? device.signalPorts.map((p, i) => ({
    id: p.id || `signal${i + 1}`,
    type: p.type || 'dmx',
    direction: p.out ? 'out' : 'in',
    configurable: !!p.configurableDirection,
    connector: p.connector || '',
    label: p.label || '',
    universeIndex: Number.isInteger(p.universeIndex) ? p.universeIndex : undefined,
    powerOnly: !!p.powerOnly,
    derived: false,
  })) : [];

  // Signal ports are largely documented. Fall back only where a direction is
  // obvious from the device class, and flag the port as derived.
  const has = (type) => signalPorts.some((p) => p.type === type);
  if (device.dmx && !has('dmx') && !has('wireless')) {
    if (kind === 'console') {
      const count = Math.max(1, Number(device.outputs) || 1);
      for (let i = 0; i < count; i++) signalPorts.push({ id: `dmxOut${i + 1}`, type: 'dmx', direction: 'out', connector: device.dmxConnector || '', label: `U${i + 1}`, derived: true });
    } else if (kind === 'node') {
      for (let i = 0; i < Math.max(1, Number(device.outputs) || 1); i++) signalPorts.push({ id: `out${i + 1}`, type: 'dmx', direction: 'out', connector: device.dmxConnector || '', label: `U${i + 1}`, universeIndex: i, derived: true });
    } else if (device.dmxPhysical === false) {
      signalPorts.push({ id: 'wirelessIn', type: 'wireless', direction: 'in', connector: device.wirelessProtocol || 'Wireless', label: 'RX', derived: true });
    } else {
      signalPorts.push({ id: 'dmxIn', type: 'dmx', direction: 'in', connector: device.dmxConnector || '', label: '', derived: true });
      signalPorts.push({ id: 'dmxOut', type: 'dmx', direction: 'out', connector: device.dmxConnector || '', label: '', derived: true });
    }
  }
  if (device.ethernet && !has('ethernet')) {
    signalPorts.push({ id: 'ethernetIn', type: 'ethernet', direction: kind === 'console' || kind === 'laptop' || kind === 'computer' ? 'bi' : 'in', connector: 'RJ45', label: 'LAN', derived: true });
    if (kind === 'node' && device.ethernetOut) signalPorts.push({ id: 'ethernetOut', type: 'ethernet', direction: 'out', connector: 'RJ45', label: 'LAN', derived: true });
  }
  if (device.usb && !has('usb')) signalPorts.push({ id: 'usb', type: 'usb', direction: 'bi', connector: 'USB', label: 'USB', derived: true });
  if (device.video && !has('video')) signalPorts.push({ id: 'videoOut', type: 'video', direction: 'out', connector: device.videoConnector || 'HDMI', label: 'VIDEO', derived: true });

  let powerPorts = Array.isArray(device.powerPortDefinitions) ? device.powerPortDefinitions.map((p, i) => ({
    id: p.id || `power${i + 1}`,
    type: 'power',
    direction: p.out ? 'out' : 'in',
    configurable: !!p.configurableDirection,
    connector: p.connector || device.powerConnector || '',
    label: p.label || '',
    domain: p.powerDomain === 'dc' ? 'dc' : (p.type === 'usb' ? 'dc' : 'ac'),
    maxWatts: Number.isFinite(p.maxOutputWatts) ? p.maxOutputWatts : undefined,
    derived: false,
  })) : [];
  powerPorts = powerPorts.filter((p) => p.id !== 'usbPower');
  const isSource = ['outlet', 'distro', 'battery', 'generator', 'solar'].includes(kind) || device.powerRole === 'source';
  const hasPower = powerPorts.length > 0;
  if (!hasPower && (device.consumes || isSource)) {
    if (kind === 'outlet' || kind === 'battery' || kind === 'generator' || kind === 'solar') {
      const count = kind === 'outlet' ? Math.max(1, Number(device.outputs) || 1) : 1;
      for (let i = 0; i < count; i++) powerPorts.push({ id: `power${i + 1}`, type: 'power', direction: 'out', connector: device.powerConnector || 'AC', label: kind === 'battery' || kind === 'solar' ? 'DC' : `L${i + 1}`, domain: kind === 'battery' || kind === 'solar' ? 'dc' : 'ac', derived: true });
    } else if (kind === 'distro') {
      for (let i = 0; i < Math.max(1, Number(device.outputs) || 4); i++) powerPorts.push({ id: `power${i + 1}`, type: 'power', direction: 'out', connector: 'AC', label: `${i + 1}`, domain: 'ac', derived: true });
    } else if (!device.usbPowered && device.powerInput !== false) {
      powerPorts.push({ id: 'powerIn', type: 'power', direction: 'in', connector: device.powerConnector || 'Power', domain: 'ac', derived: true });
      if (device.powerLink) powerPorts.push({ id: 'powerOut', type: 'power', direction: 'out', connector: device.powerConnector || 'Power', domain: 'ac', derived: true });
    }
  }
  // A consuming distro also needs its own feed.
  if (kind === 'distro' && !powerPorts.some((p) => p.direction !== 'out')) {
    powerPorts.unshift({ id: 'powerIn', type: 'power', direction: 'in', connector: 'AC', domain: 'ac', derived: true });
  }
  if (device.powerLink && !powerPorts.some((p) => p.direction === 'out') && !['outlet', 'distro', 'battery', 'generator', 'solar'].includes(kind)) {
    powerPorts.push({ id: 'powerOut', type: 'power', direction: 'out', connector: device.powerConnector || 'Power', domain: 'ac', derived: true });
  }
  return { signalPorts, powerPorts };
}

function normalizeModes(device) {
  if (!Array.isArray(device.modes)) return [];
  return device.modes
    .filter((m) => Number.isInteger(m.channels) && m.channels >= 1 && m.channels <= 512)
    .map((m, i) => ({ id: m.id || `${m.channels}ch`, label: m.label || `${m.channels} CH`, channels: m.channels }));
}

function normalizeOne(raw) {
  const category = CATEGORY_MAP[raw.category] || raw.category || 'light';
  const kind = KIND_MAP[raw.category]?.[raw.kind] || KIND_MAP[category]?.[raw.kind] || raw.kind || 'other';
  const short = shortNames[raw.id] || raw.shortName || raw.catalogTitle || raw.name || raw.id;
  const modes = normalizeModes(raw);
  const defaultMode = modes.find((m) => m.id === raw.defaultModeId)
    || modes.find((m) => m.channels === raw.default)
    || modes[0]
    || null;
  const verification = raw.verification || (raw.verificationStatus === 'generic'
    ? { status: 'generic', sources: raw.sourceUrls || [], missingFields: [] }
    : modes.length
      ? { status: 'partial', sources: raw.manuals || (raw.source ? [raw.source] : []), missingFields: ['modes', 'connectors', 'watts'] }
      : { status: 'unresolved', sources: raw.manuals || (raw.source ? [raw.source] : []), missingFields: ['model', 'modes', 'connectors', 'watts'] });
  const photometry = raw.photometry || null;
  let dims = defaultDims(kind);
  if (photometry?.dimensionsMm?.length === 3) {
    dims = { w: photometry.dimensionsMm[0] / 1000, h: photometry.dimensionsMm[1] / 1000, d: photometry.dimensionsMm[2] / 1000, source: 'manufacturer' };
  } else if (raw.dims) {
    dims = { ...raw.dims };
  }
  const { signalPorts, powerPorts } = normalizePorts(raw, category, kind);
  const isSource = ['outlet', 'battery', 'generator', 'solar'].includes(kind) || raw.powerRole === 'source';
  const consumes = typeof raw.consumes === 'boolean' ? raw.consumes : !['outlet', 'battery', 'generator', 'solar', 'distro'].includes(kind);
  const name = raw.name || short;
  return {
    id: raw.id,
    name,
    shortName: short,
    brand: raw.brand || brandOf(name, short),
    category,
    kind,
    rawKind: raw.kind || '',
    generic: !!raw.generic,
    hidden: !!(raw.hidden || raw.catalogHidden || raw.requiresDmxProfile),
    requiresProfile: !!raw.requiresDmxProfile,
    sourceType: isSource,
    sourceUrls: [...new Set([
      ...(raw.manuals || []),
      ...(verification?.sources || []),
      ...(raw.sourceUrls || []),
      ...(raw.manufacturerSource ? [raw.manufacturerSource] : []),
      ...(raw.source ? [raw.source] : []),
    ].filter(Boolean))],
    verification: {
      status: raw.verificationStatus || verification?.status || 'partial',
      note: verification?.note || (Array.isArray(raw.notes) ? raw.notes.join(' ') : raw.notes) || '',
      missingFields: verification?.missingFields || [],
      checkedAt: verification?.checkedAt || null,
      checkedFields: verification?.checkedFields || raw.verifiedFields || [],
    },
    notes: Array.isArray(raw.notes) ? raw.notes : raw.notes ? [raw.notes] : [],
    modes,
    defaultModeId: defaultMode?.id || null,
    defaultChannels: defaultMode?.channels || null,
    dmx: !!raw.dmx,
    dmxPhysical: raw.dmxPhysical !== false,
    wirelessProtocol: raw.wirelessProtocol || null,
    dmxConnector: raw.dmxConnector || '',
    powerConnector: raw.powerConnector || '',
    watts: Number.isFinite(raw.watts) ? raw.watts : null,
    wattsBasis: raw.wattsBasis || (Number.isFinite(raw.watts) ? 'unknown' : 'unknown'),
    consumes,
    powerLink: !!raw.powerLink,
    internalBattery: !!raw.internalBattery || !!raw.hasBattery,
    usbPowered: !!raw.usbPowered,
    ethernet: !!raw.ethernet,
    usb: !!raw.usb,
    video: !!raw.video,
    videoConnector: raw.videoConnector || '',
    colorSystem: raw.colorSystem || '',
    protocols: raw.protocols || [],
    capabilities: inferCapabilities(raw, kind, category),
    beamAngle: photometry?.beamAngleDegrees?.length ? { min: photometry.beamAngleDegrees[0], max: photometry.beamAngleDegrees[1] } : { min: defaultBeamAngle(kind), max: defaultBeamAngle(kind) },
    panRange: photometry?.panDegrees?.[0] || (['head', 'beam', 'spot'].includes(kind) ? 540 : 0),
    tiltRange: photometry?.tiltDegrees || (['head', 'beam', 'spot'].includes(kind) ? 270 : 0),
    lensCount: photometry?.leds?.count || (kind === 'bar' ? 6 : kind === 'pixel' ? 8 : kind === 'head' ? 7 : 1),
    dims,
    weightKg: raw.weightKg || photometry?.massKg || null,
    planSize: raw.planSize || { w: Math.max(0.24, dims.w), d: Math.max(0.16, dims.d) },
    signalPorts,
    powerPorts,
    loadKg: raw.loadKg ?? null,
    catalogSubtitle: raw.catalogSubtitle || '',
    powerRole: raw.powerRole || '',
    planning: !!raw.planning,
  };
}

const byId = new Map();
for (const device of researched) byId.set(device.id, { ...device, ...(evidence[device.id] || {}) });
for (const device of BASE) byId.set(device.id, { ...device, ...(evidence[device.id] || {}) });

// Explicit aliases from the old catalog keep legacy references resolvable.
const aliases = { 'snl-499': ['ubl12h'], 'snl-444': ['focusflex'] };
for (const [original, list] of Object.entries(aliases)) {
  const base = byId.get(original);
  if (!base) continue;
  for (const alias of list) {
    if (!byId.has(alias)) byId.set(alias, { ...base, id: alias, hidden: true, aliasOf: original });
  }
}

const devices = [...byId.values()].map(normalizeOne);
const visible = devices.filter((d) => !d.hidden);
const categories = [
  { id: 'light', label: 'Свет' },
  { id: 'effects', label: 'Эффекты' },
  { id: 'rigging', label: 'Конструкции' },
  { id: 'stage', label: 'Сцена' },
  { id: 'power', label: 'Питание' },
  { id: 'network', label: 'DMX и сеть' },
  { id: 'control', label: 'Управление' },
  { id: 'video', label: 'Видео' },
];
const groupsByCategory = {
  light: ['head', 'beam', 'spot', 'par', 'bar', 'pixel', 'strobe', 'blinder', 'laser', 'effectlight', 'flood', 'panel', 'decor', 'mirrorball', 'motor', 'other'],
  effects: ['haze', 'fog', 'snow', 'bubble', 'co2', 'confetti', 'flame', 'fan', 'effect'],
  rigging: ['truss', 'trussTower'],
  stage: ['stage', 'curtain', 'table', 'chair', 'barricade'],
  power: ['outlet', 'distro', 'battery', 'dimmer', 'generator', 'solar', 'power'],
  network: ['node', 'splitter', 'switch', 'receiver', 'transmitter', 'interface'],
  control: ['console', 'laptop', 'computer', 'controller', 'interface', 'player', 'mixer', 'phone', 'tablet'],
  video: ['ledwall', 'tv', 'projector', 'processor', 'mixer', 'camera', 'video'],
};
const groupLabels = {
  head: 'Moving heads', beam: 'Beam', spot: 'Spot', par: 'PAR и заливка', bar: 'LED-бары',
  pixel: 'Пиксельные бары', strobe: 'Стробоскопы', blinder: 'Блайндеры', laser: 'Лазеры',
  mirrorball: 'Зеркальные шары', effectlight: 'Проекторы и эффекты', flood: 'Заливка',
  panel: 'Панели', decor: 'Декор', motor: 'Моторы', other: 'Другое', haze: 'Хейзеры', fog: 'Дым-машины',
  snow: 'Снег', bubble: 'Пузыри', co2: 'CO₂', confetti: 'Конфетти', flame: 'Огонь',
  fan: 'Вентиляторы', effect: 'Другое', truss: 'Фермы', trussTower: 'Опоры', stage: 'Подиумы', curtain: 'Задники',
  table: 'Столы', chair: 'Стулья', barricade: 'Ограждения', outlet: 'Розетки и сеть',
  distro: 'Распределители', battery: 'АКБ', dimmer: 'Диммеры', generator: 'Генераторы', solar: 'Солнечные панели',
  power: 'Другое', node: 'DMX-ноды', splitter: 'Сплиттеры', switch: 'Коммутаторы',
  receiver: 'Ресиверы', transmitter: 'Трансмиттеры', interface: 'Интерфейсы',
  console: 'Пульты', laptop: 'Ноутбуки', computer: 'Компьютеры', controller: 'Контроллеры', player: 'Медиаплееры',
  mixer: 'Микшеры', phone: 'Телефоны', tablet: 'Планшеты', ledwall: 'LED-стены', tv: 'Экраны',
  projector: 'Проекторы', processor: 'Процессоры', camera: 'Камеры', video: 'Другое',
};
const groups = categories.flatMap((category) => {
  const kinds = groupsByCategory[category.id] || [];
  const counters = Object.fromEntries(kinds.map((k) => [k, 0]));
  for (const d of visible.filter((d) => d.category === category.id)) counters[d.kind] = (counters[d.kind] || 0) + 1;
  return kinds.filter((k) => counters[k]).map((kind) => ({ id: `${category.id}.${kind}`, category: category.id, kind, label: groupLabels[kind] || kind, count: counters[kind] }));
});

const output = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  note: 'Характеристики перенесены из проверяемого каталога Rig Grid. Неподтверждённые значения не заполняются оценками; planning = условный габарит для планировки.',
  categories,
  groups,
  devices,
};

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(output, null, 1));
console.log(`catalog: ${devices.length} devices (${visible.length} visible), ${groups.length} groups -> ${OUT}`);
console.log('hidden:', devices.filter((d) => d.hidden).length, 'verified:', devices.filter((d) => d.verification.status === 'verified').length);
