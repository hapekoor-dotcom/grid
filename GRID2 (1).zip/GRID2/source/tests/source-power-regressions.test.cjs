const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../dist/core.js');

// These fixtures deliberately do not import the generated equipment catalog.
// They exercise electrical topology and documented-limit semantics independently.
const ac = id => ({ id, type: 'power', out: true, powerDomain: 'ac' });
const dc = (id, maxOutputWatts) => ({ id, type: 'power', out: true, powerDomain: 'dc', maxOutputWatts });
const usb = (id, maxOutputWatts) => ({ id, type: 'usb', out: true, powerOnly: true, powerDomain: 'dc', maxOutputWatts });
const supply = (id, powerPorts, signalPorts = [], sourceLimits = []) => ({
  id, name: id, kind: 'powerstation', powerRole: 'source', consumes: false, watts: 0,
  spec: { powerPortDefinitions: powerPorts, signalPorts, sourceLimits },
});
const consumer = (id, watts, extra = {}) => ({ id, name: id, kind: 'light', consumes: true, watts, wattsBasis: 'maximum', ...extra });
const edge = (from, port, to, type = 'power', extra = {}) => ({ id: `${from}:${port}:${to}`, from, port, to, toPort: type === 'usb' ? 'usbIn' : 'powerIn', type, ...extra });
const group = (ports, watts, id = 'rated') => ({ id, ports, watts });
const branch = (result, source, phase) => result.branches.find(b => b.source === source && b.phase === phase);

test('unknown power warning identifies only affected devices by name and number', () => {
  const state = {
    nodes: [supply('source', [ac('out1')]), consumer('unknown', null, { name: 'ASUS', number: 2 }), consumer('known', 50, { name: 'Known device' })],
    edges: [edge('source', 'out1', 'unknown'), edge('unknown', 'powerOut', 'known')],
  };
  const warning = Core.power(state).issues.find(message => message.includes('неизвестна мощность'));
  assert.ok(warning.includes('ASUS №02'));
  assert.ok(!warning.includes('Known device'));
});

function delta() {
  return supply('delta', [ac('ac1'), ac('ac2'), ac('ac3'), ac('ac4'), dc('dc1', 37.8), dc('dc2', 37.8), dc('car', 126)], [usb('usbC', 100)], [
    group(['ac1', 'ac2', 'ac3', 'ac4'], 2400, 'ac'),
    group(['dc1', 'dc2', 'car'], 126, 'dc'),
  ]);
}
function generator() {
  return supply('generator', [ac('ac1'), dc('battery')], [], [group(['ac1', 'battery'], 1800, 'shared')]);
}

test('AC, auxiliary DC and USB keep their separate documented limits', () => {
  const state = { nodes: [delta(), consumer('lights', 2400), consumer('dcLoad', 126), consumer('laptop', 100, { usbPowered: true })], edges: [edge('delta', 'ac1', 'lights'), edge('delta', 'car', 'dcLoad'), edge('delta', 'usbC', 'laptop', 'usb')] };
  let p = Core.power(state);
  assert.equal(branch(p, 'delta', 'L1').limit, 2400);
  assert.equal(branch(p, 'delta', 'DC').watts, 226);
  assert.equal(branch(p, 'delta', 'DC').limit, null, '126 W does not cap unrelated USB outputs');
  assert.deepEqual(p.groups.map(g => [g.id, g.watts, g.overload]), [['ac', 2400, false], ['dc', 126, false]]);
  assert.deepEqual(p.issues, []);
  state.nodes.find(n => n.id === 'dcLoad').watts = 127;
  p = Core.power(state);
  assert.equal(p.groups.find(g => g.id === 'dc').overload, true);
  assert.equal(p.groups.find(g => g.id === 'ac').overload, false);
  assert.equal(branch(p, 'delta', 'DC').overload, true);
  assert.equal(branch(p, 'delta', 'L1').overload, false);
});

test('all AC sockets share one inverter capacity', () => {
  const state = { nodes: [delta(), consumer('a', 1300), consumer('b', 1101)], edges: [edge('delta', 'ac1', 'a'), edge('delta', 'ac2', 'b')] };
  const p = Core.power(state);
  assert.equal(p.groups.find(g => g.id === 'ac').watts, 2401);
  assert.equal(branch(p, 'delta', 'L1').overload, true);
  assert.match(p.issues.join('\n'), /2401 W > 2400 W/);
});

test('generator AC and DC share a combined limit even below each phase limit', () => {
  const state = { nodes: [generator(), consumer('acLoad', 1000), consumer('dcLoad', 800)], edges: [edge('generator', 'ac1', 'acLoad'), edge('generator', 'battery', 'dcLoad')] };
  let p = Core.power(state);
  assert.deepEqual(p.issues, []);
  state.nodes[2].watts = 900;
  p = Core.power(state);
  assert.equal(p.groups[0].watts, 1900);
  assert.equal(p.groups[0].overload, true);
  assert.equal(branch(p, 'generator', 'L1').overload, true);
  assert.equal(branch(p, 'generator', 'DC').overload, true);
  assert.match(p.issues.join('\n'), /общий лимит выходов 1900 W > 1800 W/);
  state.edges[1].detached = true;
  p = Core.power(state);
  assert.equal(p.groups[0].watts, 1000);
  assert.equal(p.groups[0].overload, false);
});

test('user phase budgets can reduce, but cannot raise, hardware limits', () => {
  const source = generator();
  source.limits = { L1: 5000 };
  const state = { nodes: [source, consumer('load', 1900)], edges: [edge(source.id, 'ac1', 'load')] };
  let b = branch(Core.power(state), source.id, 'L1');
  assert.equal(b.limit, 1800);
  assert.equal(b.userLimit, 5000);
  assert.equal(b.hardwareLimit, 1800);
  assert.equal(b.overload, true);
  source.limits.L1 = 1000;
  state.nodes[1].watts = 1100;
  b = branch(Core.power(state), source.id, 'L1');
  assert.equal(b.limit, 1000);
  assert.equal(b.overload, true);
});

test('USB power-bank outputs count toward their shared 15 W rating', () => {
  const source = supply('bank', [], [usb('usb1', 15), usb('usb2', 15)], [group(['usb1', 'usb2'], 15)]);
  const state = { nodes: [source, consumer('phone1', 8, { usbPowered: true }), consumer('phone2', 7, { usbPowered: true })], edges: [edge('bank', 'usb1', 'phone1', 'usb'), edge('bank', 'usb2', 'phone2', 'usb')] };
  let p = Core.power(state);
  assert.deepEqual(Core.sourcePhases(source), ['DC']);
  assert.deepEqual(p.issues, []);
  assert.equal(p.groups[0].watts, 15);
  assert.equal(p.links.length, 2);
  state.nodes[2].watts = 8;
  p = Core.power(state);
  assert.equal(p.groups[0].watts, 16);
  assert.equal(p.groups[0].overload, true);
  assert.equal(branch(p, 'bank', 'DC').overload, true);
});

test('USB data cables are not treated as power feeds', () => {
  const source = supply('bank', [], [usb('usb1', 15)], [group(['usb1'], 15)]);
  const state = { nodes: [source, consumer('selfPoweredController', 100, { internalBattery: true })], edges: [edge('bank', 'usb1', 'selfPoweredController', 'usb')] };
  const p = Core.power(state);
  assert.equal(p.groups[0].watts, 0);
  assert.equal(p.links.length, 0);
  assert.equal(Core.root(state, 'selfPoweredController', 'power'), null);
});

test('USB-powered device accepts its explicit power-type USB-C inlet', () => {
  const source = supply('bank', [], [usb('usbC', 60)], [group(['usbC'], 60)]);
  const device = consumer('monitor', 30, { usbPowered: true, spec: { powerPortDefinitions: [{ id: 'usbPowerIn', out: false, connector: 'USB-C', powerDomain: 'dc' }] } });
  const feed = edge('bank', 'usbC', 'monitor', 'power', { toPort: 'usbPowerIn' });
  const state = { nodes: [source, device], edges: [feed] };
  const p = Core.power(state);
  assert.deepEqual(Core.root(state, 'monitor', 'power'), { source: 'bank', port: 'usbC', phase: 'DC' });
  assert.equal(p.groups[0].watts, 30);
  assert.equal(p.links[0].watts, 30);
  assert.deepEqual(p.issues, []);
});

test('an explicit power feed takes precedence over a simultaneous USB data connection', () => {
  const wall = supply('adapter', [dc('dcOut', 60)], [], [group(['dcOut'], 60)]);
  const bank = supply('bank', [], [usb('usbC', 60)], [group(['usbC'], 60)]);
  const device = consumer('monitor', 30, { usbPowered: true });
  const data = edge('bank', 'usbC', 'monitor', 'usb');
  const power = edge('adapter', 'dcOut', 'monitor');
  const state = { nodes: [wall, bank, device], edges: [data, power] };
  let p = Core.power(state);
  assert.equal(Core.root(state, 'monitor', 'power').source, 'adapter');
  assert.equal(p.groups.find(g => g.source === 'adapter').watts, 30);
  assert.equal(p.groups.find(g => g.source === 'bank').watts, 0);
  assert.deepEqual(p.links.map(l => l.id), [power.id]);
  power.detached = true;
  p = Core.power(state);
  assert.equal(Core.root(state, 'monitor', 'power').source, 'bank');
  assert.equal(p.groups.find(g => g.source === 'bank').watts, 30);
  assert.deepEqual(p.links.map(l => l.id), [data.id]);
});

test('USB-powered devices without either power or USB supply report missing power', () => {
  const device = consumer('monitor', 30, { usbPowered: true, spec: { powerPortDefinitions: [{ id: 'usbPowerIn', out: false, connector: 'USB-C', powerDomain: 'dc' }] } });
  const state = { nodes: [device], edges: [] };
  assert.deepEqual(Core.power(state).issues, ['monitor: нет питания']);
  device.internalBattery = true;
  assert.deepEqual(Core.power(state).issues, []);
});

test('USB loads behind a powered hub retain the original source port', () => {
  const source = supply('bank', [], [usb('usb1', 15)], [group(['usb1'], 15)]);
  const hub = consumer('hub', 3, { kind: 'interface', usbPowered: true });
  const state = { nodes: [source, hub, consumer('controller', 12, { usbPowered: true })], edges: [edge('bank', 'usb1', 'hub', 'usb'), edge('hub', 'usbOut', 'controller', 'usb')] };
  const p = Core.power(state);
  assert.equal(p.groups[0].watts, 15);
  assert.equal(p.groups[0].overload, false);
  assert.deepEqual(Core.root(state, 'controller', 'power'), { source: 'bank', port: 'usb1', phase: 'DC' });
  assert.equal(p.links.find(l => l.id === state.edges[0].id).watts, 15);
  assert.equal(p.links.find(l => l.id === state.edges[1].id).watts, 12);
});

test('per-port limits remain enforced independently of a larger aggregate budget', () => {
  const source = supply('bank', [], [usb('usb1', 10)], [group(['usb1'], 100)]);
  source.outputLimits = { usb1: 500 };
  const state = { nodes: [source, consumer('phone', 12, { usbPowered: true })], edges: [edge('bank', 'usb1', 'phone', 'usb')] };
  let p = Core.power(state);
  assert.equal(p.groups[0].overload, false);
  assert.equal(p.links[0].limit, 10);
  assert.equal(p.links[0].hardwareLimit, 10);
  assert.equal(p.links[0].overload, true);
  source.outputLimits.usb1 = 8;
  p = Core.power(state);
  assert.equal(p.links[0].limit, 8);
});

test('distribution branches include downstream USB consumers exactly once', () => {
  const source = supply('source', [ac('ac1')], [], [group(['ac1'], 200)]);
  const distro = { id: 'distro', name: 'distro', kind: 'distro', watts: 0, totalLimit: 200 };
  const controller = consumer('controller', 20, { kind: 'console' });
  const phone = consumer('phone', 10, { usbPowered: true });
  const state = { nodes: [source, distro, controller, phone], edges: [edge('source', 'ac1', 'distro'), edge('distro', 'powerOut1', 'controller'), edge('controller', 'usbOut', 'phone', 'usb')] };
  const p = Core.power(state);
  assert.equal(p.groups[0].watts, 30);
  assert.equal(p.links[0].watts, 30);
  assert.equal(p.links[1].watts, 30);
  assert.equal(p.links[2].watts, 10);
  assert.deepEqual(p.issues, []);
});

test('an independently powered source is a boundary, its charger input is counted upstream', () => {
  const gen = generator(), station = delta();
  Object.assign(station, { consumes: true, watts: 200, wattsBasis: 'user' });
  const state = { nodes: [gen, station, consumer('light', 1000)], edges: [edge('generator', 'ac1', 'delta'), edge('delta', 'ac1', 'light')] };
  const p = Core.power(state);
  assert.equal(p.groups.find(g => g.source === 'generator').watts, 200);
  assert.equal(p.groups.find(g => g.source === 'delta' && g.id === 'ac').watts, 1000);
  assert.equal(p.links[0].watts, 200);
  assert.equal(p.links[1].watts, 1000);
  assert.deepEqual(Core.downstream(state, 'generator').map(n => n.id), ['generator', 'delta']);
});

test('unknown loads remain unknown inside an otherwise verified source group', () => {
  const source = supply('bank', [], [usb('usb1', 15)], [group(['usb1'], 15)]);
  const p = Core.power({ nodes: [source, consumer('unknownPhone', null, { usbPowered: true })], edges: [edge('bank', 'usb1', 'unknownPhone', 'usb')] });
  assert.equal(p.groups[0].unknown, 1);
  assert.equal(p.groups[0].watts, 0);
  assert.match(p.issues.join('\n'), /неизвестна мощность: unknownPhone/);
  assert.doesNotMatch(p.issues.join('\n'), /задай допустимую мощность/);
});

test('configurable USB-C input does not create an extra source output phase', () => {
  const p = { ...usb('usbC', 60), configurableDirection: true };
  const source = supply('station', [ac('ac1')], [p], [group(['ac1'], 100)]);
  source.portDirections = { usbC: false };
  assert.deepEqual(Core.sourcePhases(source), ['L1']);
  source.portDirections.usbC = true;
  assert.deepEqual(Core.sourcePhases(source), ['L1', 'DC']);
});

test('controller output capacity blocks addresses beyond its physical channel range', () => {
  const controller = { id: 'controller', name: 'Obey4', kind: 'console', universes: [1], spec: { outputChannels: 16 } };
  const fixture = (id, channels, extra = {}) => ({ id, name: id, kind: 'wash', dmx: true, channels, ...extra });
  const state = { nodes: [controller, fixture('a', 8), fixture('b', 8)], edges: [edge('controller', 'dmx1', 'a', 'dmx'), edge('a', 'dmxOut', 'b', 'dmx')] };
  assert.deepEqual(Core.patch(state).issues, []);
  state.nodes.push(fixture('c', 1));
  state.edges.push(edge('b', 'dmxOut', 'c', 'dmx'));
  let p = Core.patch(state);
  assert.equal(p.rows.find(r => r.id === 'c').address, 17);
  assert.match(p.issues.join('\n'), /превышают 16 каналов Obey4/);
  controller.spec.outputChannels = null;
  assert.deepEqual(Core.patch(state).issues, [], 'unknown capacity does not invent a channel restriction');
});

test('manual addresses obey controller capacity too', () => {
  const controller = { id: 'controller', name: 'Controller', kind: 'console', universes: [1], spec: { outputChannels: 16 } };
  const f = { id: 'f', name: 'f', dmx: true, channels: 1, manual: 16 };
  const state = { nodes: [controller, f], edges: [edge('controller', 'dmx1', 'f', 'dmx')] };
  assert.deepEqual(Core.patch(state).issues, []);
  f.channels = 2;
  assert.match(Core.patch(state).issues.join('\n'), /адреса 16–17 превышают 16/);
});

test('splitter input B follows the documented explicit input port ID', () => {
  const source = { id: 'node', name: 'node', kind: 'node', universes: [1, 2] };
  const splitter = { id: 'splitter', kind: 'splitter', splitRouting: { dmx1: 'B' }, spec: { signalPorts: [{ id: 'dmxIn', type: 'dmx', out: false }, { id: 'dmxIn2', type: 'dmx', out: false }, { id: 'dmx1', type: 'dmx', out: true }] } };
  const f = { id: 'f', name: 'f', dmx: true, channels: 5 };
  const state = { nodes: [source, splitter, f], edges: [edge('node', 'dmx1', 'splitter', 'dmx', { toPort: 'dmxIn' }), edge('node', 'dmx2', 'splitter', 'dmx', { toPort: 'dmxIn2' }), edge('splitter', 'dmx1', 'f', 'dmx')] };
  assert.equal(Core.patch(state).rows[0].root.universe, 2);
  assert.deepEqual(Core.patch(state).issues, []);
});
