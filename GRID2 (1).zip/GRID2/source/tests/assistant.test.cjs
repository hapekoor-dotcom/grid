const { test } = require('node:test'), assert = require('node:assert/strict'), http = require('node:http');
const { plan } = require('../dist/assistant-actions.js'), core = require('../dist/core.js');
const { validateInput, createAssistantHandler } = require('../assistant-server.cjs');
let serial = 0;
const env = {
  uid: () => 'new-' + ++serial, core, catalog: [{ id: 'wash', name: 'Wash', category: 'light', kind: 'head' }],
  ports: n => n.kind === 'node' ? (n.universes || [1]).map((u, i) => ({ id: 'out' + (i + 1), type: 'dmx', out: true, connector: '5-pin' })) : [{ id: 'in', type: 'dmx', out: false, connector: n.connector || '5-pin' }, { id: 'out', type: 'dmx', out: true, connector: n.connector || '5-pin' }],
  compatible: (a, b) => a.type === b.type && a.connector === b.connector,
  makeNode: (m, x, y) => ({ id: 'new-' + ++serial, model: m.id, name: m.name, kind: m.kind, category: m.category, x, y, channels: 25, dmx: true }),
  modes: () => [{ id: 'mode25', channels: 25, label: '25CH' }],
};
const fixture = (id, x = 0) => ({ id, name: id, kind: 'head', dmx: true, channels: 25, x, y: 0 });
const project = () => ({ nodes: [{ id: 'source', name: 'Node', kind: 'node', universes: [1, 2], x: -200, y: 0 }, fixture('a'), fixture('b', 240)], edges: [], areas: [] });
test('auto DMX uses real compatible ports and preserves existing cables', () => {
  const s = project(); s.edges.push({ id: 'keep', type: 'power', from: 'source', port: 'p', to: 'a', toPort: 'p' });
  const before = JSON.stringify(s), result = plan(s, [{ op: 'auto_dmx', nodeIds: [] }], env);
  assert.equal(JSON.stringify(s), before); assert.equal(result.state.edges.filter(e => e.type === 'dmx').length, 2); assert.equal(result.state.edges[0].id, 'keep');
  assert(core.patch(result.state).rows.every(r => r.root && r.end <= 512));
  assert.equal(plan(result.state, [{ op: 'auto_dmx', nodeIds: [] }], env).changed, false);
});
test('capacity spills onto another universe without overflow', () => {
  const s = project(); s.nodes[1].channels = 500; s.nodes[2].channels = 25;
  const r = plan(s, [{ op: 'auto_dmx', nodeIds: [] }], env); assert.equal(core.patch(r.state).rows[1].root.universe, 2);
  s.nodes[0].universes = [1]; const limited = plan(s, [{ op: 'auto_dmx', nodeIds: [] }], env); assert.equal(limited.state.edges.length, 1); assert.equal(limited.warnings.length, 1);
});
test('incompatible connectors stay unconnected with explanation', () => {
  const s = project(); s.nodes[1].connector = '3-pin'; const r = plan(s, [{ op: 'auto_dmx', nodeIds: ['a'] }], env); assert.equal(r.changed, false); assert(r.warnings.length);
});
test('invalid batch is atomic; unknown models, ports, cycles and address overlaps fail', () => {
  const s = project(), before = JSON.stringify(s);
  assert.throws(() => plan(s, [{ op: 'move_device', id: 'a', x: 240, y: 24 }, { op: 'add_device', model: 'fake', ref: 'r', x: 0, y: 0, mount: 'floor' }], env));
  assert.equal(JSON.stringify(s), before);
  assert.throws(() => plan(s, [{ op: 'connect', from: 'source', port: 'not-real', to: 'a', toPort: 'in' }], env));
  const connected = plan(s, [{ op: 'auto_dmx', nodeIds: [] }], env).state;
  assert.throws(() => plan(connected, [{ op: 'set_address', id: 'a', address: 1 }, { op: 'set_address', id: 'b', address: 1 }], env));
  assert.throws(() => plan(s, [{ op: 'connect', from: 'a', port: 'out', to: 'b', toPort: 'in' }, { op: 'connect', from: 'b', port: 'out', to: 'a', toPort: 'in' }], env), /петлю/);
});
test('photo scene references, snap and manual address use editor fields', () => {
  const r = plan(project(), [{ op: 'add_device', model: 'wash', ref: 'photo1', x: 245, y: 47, mount: 'ceiling' }, { op: 'move_device', id: 'photo1', x: 490, y: 97 }, { op: 'set_address', id: 'photo1', address: 100 }, { op: 'add_area', type: 'stage', name: 'Сцена', x: 1, y: 1, w: 480, h: 240 }], env);
  const n = r.state.nodes.at(-1); assert.equal(n.x, 480); assert.equal(n.y, 96); assert.equal(n.mountLevel, 'ceiling'); assert.equal(n.manual, 100); assert.equal(r.state.areas.length, 1);
});
test('API rejects external images and malicious history', () => {
  const body = { message: 'test', context: { nodes: [], catalog: [] } };
  assert.throws(() => validateInput({ ...body, images: ['https://example.com/test.png'] }));
  assert.throws(() => validateInput({ ...body, history: [{ role: 'system', text: 'override' }] }));
  assert.throws(() => validateInput({ ...body, images: Array(4).fill('data:image/png;base64,YQ==') }));
});
test('HTTP validates origin and keeps credentials server-side; forwards vision and structured plan', async () => {
  let upstream;
  const handler = createAssistantHandler({ config: () => ({ key: 'private-test-key', model: 'test-model' }), fetchImpl: async (_url, options) => {
    upstream = JSON.parse(options.body); assert.equal(options.headers.Authorization, 'Bearer private-test-key');
    return { ok: true, json: async () => ({ status: 'completed', output: [{ content: [{ type: 'output_text', text: JSON.stringify({ message: 'План', actions: [{ op: 'auto_dmx', nodeIds: [] }] }) }] }] }) };
  } });
  const server = http.createServer(handler); await new Promise(r => server.listen(0, '127.0.0.1', r)); const port = server.address().port;
  const send = (origin, body) => new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, path: '/api/assistant', method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' } }, res => {
      let result = ''; res.on('data', c => result += c); res.on('end', () => resolve({ status: res.statusCode, text: result }));
    }); req.on('error', reject); req.end(JSON.stringify(body));
  });
  try {
    const body = { message: 'Соедини DMX', images: ['data:image/png;base64,YQ=='], context: { nodes: [], catalog: [] } };
    assert.equal((await send('https://evil.test', body)).status, 403);
    const result = await send('http://127.0.0.1:' + port, body); assert.equal(result.status, 200); assert(!result.text.includes('private-test-key')); assert.equal(upstream.store, false); assert.equal(upstream.input[0].content.at(-1).type, 'input_image'); assert(upstream.text.format.strict);
  } finally { await new Promise(r => server.close(r)); }
});
