const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const stub={addEventListener(){},style:{setProperty(){}},classList:{remove(){},toggle(){}},setAttribute(){}};
const context=vm.createContext({document:{querySelector:()=>stub,querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},console,URL,setTimeout,clearTimeout});
vm.runInContext(fs.readFileSync('dist/core.js','utf8')+fs.readFileSync('dist/catalog.js','utf8')+fs.readFileSync('dist/app.js','utf8').replace(/init\(\);\s*$/,''),context);
const data=JSON.parse(fs.readFileSync('dist/catalog-researched.json'));context.inputCatalog=data;
const result=vm.runInContext(`catalog.push(...inputCatalog);state={nodes:[],edges:[]};let checked=0;for(const m of catalog){const n=makeNode(m);n.outputs=Math.max(1,n.outputs);state.nodes=[n];const s=size(n);if(s.h!==(['snl-508','snl-517'].includes(n.model)?216:['snl-368','snl-127','snl-516'].includes(n.model)?144:n.model==='wall-outlet'?72:n.kind==='battery'?120:n.kind==='outlet'?(Math.min(4,n.outputs)+3)*24:n.kind==='flame'?144:168))throw Error(m.name+' exceeds seven-cell height');if(s.w%24||s.h%24)throw Error(m.name+' dimensions');for(const p of ports(n)){if(p.x%((p.dy===1||p.rack)?12:24)||p.y%((p.dy===1||p.rack)?12:24)||p.x<0||p.y<0||p.x>s.w||p.y>s.h)throw Error(m.name+' port '+p.id)}checked++}const source=makeNode(catalog.find(m=>m.id==='outlet'));source.outputs=16;state.nodes=[source];if(ports(source).some(p=>p.y>size(source).h))throw Error('source outputs overflow');checked`,context);
assert.equal(result,BASE_COUNT()+data.length);console.log('PASS: '+result+' catalog templates: grid sizes, all port coordinates, max-output source bounds');
function BASE_COUNT(){return vm.runInContext('BASE_CATALOG.length',context)}

vm.runInContext(`for(const m of catalog){const n=makeNode(m);n.width=24;n.height=24;state.nodes=[n];const s=size(n);for(const p of ports(n)){if(p.x%((p.dy===1||p.rack)?12:24)||p.y%((p.dy===1||p.rack)?12:24)||p.x<0||p.y<0||p.x>s.w||p.y>s.h)throw Error(m.name+' resized port overflow')}}`,context);
console.log('PASS: all templates clamp undersized cards to their port bounds');
vm.runInContext(`prepareCatalog();for(const m of catalog){if(m.catalogHidden)continue;if(!m.generic&&!m.catalogSubtitle)throw Error(m.name+' missing subtitle');if(/S&L|карточка проката|производитель/.test(m.catalogSubtitle))throw Error('provenance in subtitle');const n=makeNode(m);n.width=24;n.height=24;state.nodes=[n];const s=size(n);for(const p of ports(n))if(p.x>s.w||p.y>s.h)throw Error(m.name+' prepared ports overflow')}
if(catalog.find(m=>m.id==='snl-370').kind!=='phone')throw Error('phone classification');
if(!catalog.find(m=>m.id==='snl-515').video)throw Error('TV HDMI');
const splitter=makeNode(catalog.find(m=>m.id==='snl-345'));state.nodes=[splitter];if(ports(splitter).filter(p=>p.type==='video'&&p.out).length!==4)throw Error('HDMI output count');
if(catalog.find(m=>m.id==='snl-382').catalogSubtitle!=='10 000 mAh')throw Error('Denver subtitle');`,context);
console.log('PASS: prepared catalog subtitles, phone classification, video ports and minimum card dimensions');
