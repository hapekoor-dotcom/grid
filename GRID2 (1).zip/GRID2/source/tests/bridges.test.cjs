const assert=require('node:assert/strict'),{bridged}=require('../dist/core.js');
const horizontal=[{x:0,y:24},{x:96,y:24}],crossing=[[{x:48,y:0},{x:48,y:48}]];
assert.match(bridged(horizontal,crossing),/L43,24 Q48,14 53,24/);
assert.match(bridged([...horizontal].reverse(),crossing),/L53,24 Q48,14 43,24/);
assert.equal(bridged(horizontal,[[{x:0,y:30},{x:96,y:30}]]),'M0,24 L96,24');
assert.equal(bridged(horizontal,[[{x:0,y:24},{x:0,y:48}]]),'M0,24 L96,24');
assert.equal((bridged(horizontal,[...crossing,...crossing]).match(/Q/g)||[]).length,1);
console.log('PASS: crossing bridge, reversed route, parallel lines, endpoints, duplicate crossings');
