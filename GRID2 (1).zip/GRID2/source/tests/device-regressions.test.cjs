// Regressions from the user's actual fixture workflows, pinned to independent manuals.
// Original Freedom Stick: https://www.chauvetdj.com/wp-content/uploads/2016/01/Freedom_Stick_UM_Rev5.pdf
// NEC ME403U/ME383W: manufacturer's terminal-panel drawings; Philips Tempo RVP351 is a lamp floodlight.
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const {test}=require('node:test');
const dist=path.resolve(__dirname,'../dist');

async function harness(){
 const elements=new Map(),storage=new Map();
 const el=selector=>{if(!elements.has(selector))elements.set(selector,{innerHTML:'',textContent:'',hidden:false,value:'',dataset:{},style:{setProperty(){}},classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){},focus(){},getBoundingClientRect(){return{left:0,top:0,width:1400,height:900}},querySelector(){return el(selector+' child')},querySelectorAll(){return[]}});return elements.get(selector)};
 const all=selector=>{if(!/^\[data-(?:add|model-choice|choose-model)\]$/.test(selector))return[];const attr=selector.slice(1,-1),key=attr.slice(5).replace(/-([a-z])/g,(_,v)=>v.toUpperCase()),found=[];for(const container of [...elements.values()])for(const match of container.innerHTML.matchAll(new RegExp(attr+'="([^"]+)"','g'))){const button=el('['+attr+'="'+match[1]+'"]');button.dataset[key]=match[1];if(!found.includes(button))found.push(button)}return found};
 const context=vm.createContext({document:{querySelector:el,querySelectorAll:all,addEventListener(){}},window:{addEventListener(){}},console,URL,setTimeout,clearTimeout,requestAnimationFrame:()=>0,cancelAnimationFrame(){},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},fetch:async url=>{const file=path.resolve(dist,String(url).split('?')[0]);assert.ok(file.startsWith(dist+path.sep));return{ok:fs.existsSync(file),json:async()=>JSON.parse(fs.readFileSync(file,'utf8'))}}});
 context.matchMedia=()=>({matches:false});
 for(const name of ['core.js','catalog.js','symbols.js','verification.js','workspace-ui.js','app.js'])vm.runInContext(fs.readFileSync(path.join(dist,name),'utf8').replace(/init\(\);\s*$/,''),context,{filename:name});
 context.inputCatalog=JSON.parse(fs.readFileSync(path.join(dist,'catalog-researched.json'),'utf8'));
 await vm.runInContext(`(async()=>{for(const raw of inputCatalog){if(!raw.id||!categories[raw.category])continue;const existing=catalog.find(m=>m.name.toLowerCase().replace(/\\W/g,'')===raw.name.toLowerCase().replace(/\\W/g,''));if(existing){if(raw.source)existing.rentalSource=raw.source;continue}const kind=raw.kind||'par';catalog.push({...raw,kind,notes:Array.isArray(raw.notes)?raw.notes.join(' '):raw.notes,manual:raw.manual||raw.manufacturerSource||raw.manuals?.[0],label:raw.label||kind.toUpperCase(),dmx:raw.dmx===true,consumes:raw.consumes??true})}await loadVerification();prepareCatalog();finishVerifiedCatalog();state={version:4,nodes:[],edges:[]}})()`,context);
 const run=source=>vm.runInContext(source,context);
 const json=source=>JSON.parse(JSON.stringify(run(source)));
 return{run,json,html:selector=>el(selector).innerHTML};
}

(async()=>{
 const {run,json,html}=await harness();
 await test('cable selection preserves wiring and dims only the other cables',()=>{
  const result=json(`(()=>{state=demo();ensureNumbers();const before=JSON.stringify(state),id=state.edges[0].id;selectCable(id);return{unchanged:before===JSON.stringify(state),selectedEdge,pending,count:state.edges.length,id}})()`);
  assert.equal(result.unchanged,true);assert.equal(result.selectedEdge,result.id);assert.equal(result.pending,null);
  const markup=html('#activeWires');assert.equal((markup.match(/class="cable-group" opacity="0.2"/g)||[]).length,result.count-1);assert.equal((markup.match(/class="cable-group" opacity="1"/g)||[]).length,1);
 });
 await test('a connected port disconnects its own end, with undo restoring the complete project',()=>{
  const result=json(`(()=>{state=demo();ensureNumbers();const before=JSON.stringify(state),edge=state.edges.find(e=>e.type==='dmx'),count=state.edges.length;activatePort({dataset:{node:edge.to,port:edge.toPort}});const moved={count:state.edges.length,anchor:pending.node,port:pending.port};undo();return{before,count,from:edge.from,port:edge.port,moved,restored:JSON.stringify(state)}})()`);
  assert.equal(result.moved.count,result.count-1);assert.equal(result.moved.anchor,result.from);assert.equal(result.moved.port,result.port);assert.equal(result.restored,result.before);
 });
 await test('hidden existing model remains selectable in fixture properties',()=>{
  const markup=run(`deviceModelField(makeNode(catalog.find(m=>m.id==='focusflex')),catalog.find(m=>m.id==='focusflex'))`);
  assert.match(markup,/<option value="focusflex" selected>/);
 });
 await test('catalog face layouts retain every port and keep non-power height at seven cells',()=>{
  const rows=json(`catalog.filter(m=>!m.catalogHidden).map(m=>{const n=makeNode(m);return{id:m.id,kind:n.kind,category:n.category,size:size(n),ports:ports(n),face:preservedFace(n)?null:panelDrawing(n)}})`);
  for(const row of rows){
   if(row.category!=='power'&&!['bar','pixel'].includes(row.kind))assert.equal(row.size.h,['snl-508','snl-517'].includes(row.id)?216:row.kind==='flame'||['snl-127','snl-516'].includes(row.id)?144:168,row.id);
   for(const p of row.ports)assert.ok(p.x>=0&&p.y>=0&&p.x<=row.size.w&&p.y<=row.size.h,row.id+' '+p.id);
   if(row.face)assert.doesNotMatch(row.face,/NaN|undefined|(?:width|height|r)="-/,row.id);
  }
 });
 await test('console trims empty side columns but retains columns with side ports',()=>{
  const sizes=json(`(()=>{const m={id:'layout-test',kind:'console',category:'input',powerInput:false,dmx:true,signalPorts:[{id:'usbIn',type:'usb',out:false},{id:'out1',type:'dmx',out:true}]};const n=makeNode(m);const compact=size(n).w;n.spec={...m,signalPorts:[...m.signalPorts,{id:'auxIn',type:'control',out:false},{id:'auxOut',type:'ethernet',out:true}]};return [compact,size(n).w]})()`);
  assert.deepEqual(sizes,[144,192]);
 });
 await test('Delta Max has a station face without losing its source role or ports',()=>{
  const value=json(`(()=>{const n=makeNode(catalog.find(m=>m.id==='snl-368'));return{kind:n.kind,source:isSource(n),ports:ports(n).length,face:panelDrawing(n)}})()`);
  assert.equal(value.kind,'powerstation');assert.equal(value.source,true);assert.equal(value.ports,8);assert.match(value.face,/<svg/);
 });
 await test('power sidebar contains only the generic power block',()=>{
  run("$('#search').value='';renderCatalog()");
  const power=html('#catalogTree').split('<details')[0];
  assert.ok(power.includes('data-add="outlet"'));
  assert.equal((power.match(/data-add=/g)||[]).length,1);
  assert.ok(!power.includes('<summary>'));
  assert.ok(!/EcoFlow|Power Bank|АКБ/.test(power));
 });
 await test('XPD paired rows share eight ports and block the opposite connected route',()=>{
 const result=json(`(()=>{const n=makeNode(catalog.find(m=>m.id==='snl-508'));state={nodes:[n],edges:[]};const initial=displayPorts(n).filter(p=>p.out&&p.type==='dmx');n.splitRouting.out1='B';state.edges=[{id:'test',from:n.id,port:'out1',type:'dmx',to:'fixture'}];const pair=displayPorts(n).filter(p=>p.id==='out1');return {initial:initial.length,physical:ports(n).filter(p=>p.out&&p.type==='dmx').length,pair,y:ports(n).find(p=>p.id==='out1').y,h:size(n).h}})()`);
 assert.equal(result.initial,16);assert.equal(result.physical,8);
 assert.equal(result.pair.find(p=>p.route==='A').blocked,true);assert.equal(result.pair.find(p=>p.route==='B').blocked,false);assert.equal(result.y,result.h-24);
 });
 await test('visualizer placement survives project reload without moving the diagram',()=>{
 const result=json(`(()=>{const n=makeNode(catalog.find(m=>m.id==='snl-444'),96,144);n.mountLevel='ceiling';const restored=normalize(JSON.parse(JSON.stringify({nodes:[n],edges:[]}))).nodes[0];return{level:restored.mountLevel,x:restored.x,y:restored.y}})()`);
 assert.deepEqual(result,{level:'ceiling',x:96,y:144});
 });
 await test('Delta exposes four AC outputs on the right',()=>{
 const ps=json("ports(makeNode(catalog.find(m=>m.id==='snl-368')))");
 const outs=ps.filter(p=>p.out);
 assert.deepEqual(outs.map(p=>p.id),['powerOut1','powerOut2','powerOut3','powerOut4']);
 for(const p of outs){assert.equal(p.x,264);assert.equal(p.dx,1);}
 });
 await test('catalog fallback symbols retain their original artwork and valid tight viewports',()=>{
  const rows=json(`catalog.filter(m=>!m.catalogHidden).map(m=>m.kind).filter((k,i,a)=>a.indexOf(k)===i).filter(k=>k!=='generator').map(kind=>({kind,original:fixtureSymbol(kind),panel:catalogPanelSymbol(kind)}))`);
  for(const row of rows){
   const contents=svg=>svg.slice(svg.indexOf('>')+1);
   assert.equal(contents(row.panel),contents(row.original),row.kind+' artwork changed');
   const box=row.panel.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);
   assert.ok(box.every(Number.isFinite)&&box[2]>0&&box[3]>0,row.kind+' invalid viewport');
  }
 });
 await test('pixel bars use the LED-bar chassis in both orientations',()=>{
  const result=json(`(()=>{const n=makeNode(catalog.find(m=>m.kind==='pixel'&&!m.catalogHidden));const vertical=size(n),drawing=pixelFace(n);n.rotation=180;return{vertical,horizontal:size(n),drawing,ports:ports(n)}})()`);
  assert.deepEqual(result.vertical,{w:72,h:168});assert.deepEqual(result.horizontal,{w:168,h:72});
  assert.equal((result.drawing.match(/class="lens"/g)||[]).length,16);
  for(const p of result.ports)assert.ok(p.x>=0&&p.x<=168&&p.y>=0&&p.y<=72);
 });
 await test('DMX source output panels reserve the bottom row without changing port identity',()=>{
  const rows=json(`catalog.filter(m=>!m.catalogHidden&&['splitter','node','interface','switch'].includes(m.kind)).map(m=>{const n=makeNode(m);return{id:m.id,h:size(n).h,kind:n.kind,ports:ports(n)}})`);
  for(const row of rows)for(const p of row.ports.filter(p=>p.out&&p.type===(row.kind==='switch'?'ethernet':'dmx'))){if(row.id==='snl-127'&&p.id==='dmxThru'){assert.equal(p.dx,1);assert.equal(p.dy,0);continue}assert.equal(p.y,row.h-(['snl-508','snl-517'].includes(row.id)?72:24),row.id+' '+p.id);assert.equal(p.dy,1,row.id+' '+p.id);}
 });
 await test('every catalog model creates a short model name rather than a fixture-type title',()=>{
  const rows=json(`catalog.filter(m=>!m.catalogHidden).map(m=>{const n=makeNode(m);return{id:m.id,generic:m.generic,name:shortModelName(m),nodeName:n.name}})`);
  for(const row of rows){assert.ok(row.name.trim(),row.id+' empty name');assert.ok(row.name.trim().split(/\s+/).length<=2,row.id+' too many words: '+row.name);assert.equal(row.nodeName,row.name,row.id+' add uses unshortened rental title');if(!row.generic)assert.ok(!['СВЕТ','Свет','PIXEL','FX','WASH','PAR','BEAM'].includes(row.name),row.id+' uses category instead of model')}
  assert.equal(run(`shortModelName(catalog.find(m=>m.id==='snl-227'))`),'ADJ Inno');
 });
 await test('every concrete fixture advertised as DMX has a usable documented initial footprint',()=>{
  const rows=json(`catalog.filter(m=>!m.catalogHidden&&!m.generic&&['light','effect'].includes(m.category)&&m.dmx===true).map(m=>{const n=makeNode(m);return{id:m.id,name:m.name,modes:modes(m),modeId:n.modeId,channels:n.channels,requiresDmxProfile:m.requiresDmxProfile,issues:RigCore.patch({nodes:[n],edges:[]}).issues}})`);
  const failures=[];
  for(const row of rows){if(row.requiresDmxProfile&&!row.modes.length){if(row.channels!==null)failures.push(row.id+' guesses an unresolved footprint');if(!row.issues.some(v=>/режим|профил|канал/i.test(v)))failures.push(row.id+' unresolved profile does not block patch');continue}if(!row.modes.length){failures.push(row.id+' is advertised as DMX without a profile or explicit setup gate');continue}if(!Number.isInteger(row.channels)||row.channels<1||row.channels>512)failures.push(row.id+' unusable initial footprint');if(!row.modes.some(m=>m.id===row.modeId&&m.channels===row.channels))failures.push(row.id+' initial mode is not one of its profiles')}
  assert.deepEqual(failures,[]);
 });
 await test('rendered Shehds and Tempo card titles identify their model',()=>{
  for(const id of ['snl-485','snl-164']){
   run(`state={nodes:[makeNode(catalog.find(m=>m.id==='${id}'))],edges:[]};routeCache=null;renderNodes()`);
   const title=html('#nodes').match(/class="fixture-type"[^>]*>([^<]*)</)?.[1];
   assert.ok(title,id+' rendered title');assert.ok(!/^(?:СВЕТ|Свет|PAR|FX)$/.test(title),id+' generic title');assert.ok(title.split(/\s+/).length<=2,id+' title length');
  }
 });
 await test('saved default rental names migrate but user names survive',()=>{
  const out=json(`(()=>{const m=catalog.find(m=>m.id==='snl-227');const old={...makeNode(m),name:'ADJ Inno Roll HP 80W LED Scanner + UC 3 kontroller',label:'FX'};const custom={...makeNode(m),name:'Левая стойка',label:'FX'};delete old.nameChoice;delete custom.nameChoice;return normalize({nodes:[old,custom],edges:[]}).nodes.map(n=>n.name)})()`);
  assert.equal(out[0],'ADJ Inno');assert.equal(out[1],'Левая стойка');
 });
 await test('original Freedom Stick has documented profiles and radio/DC connectors, not X4 USB or XLR',()=>{
  const result=json(`(()=>{const m=catalog.find(m=>m.id==='snl-520'),n=makeNode(m);state={nodes:[n],edges:[]};return{mode:n.channels,modes:modes(m).map(v=>v.channels).sort((a,b)=>a-b),battery:n.internalBattery,ports:ports(n)}})()`);
  assert.deepEqual(result.modes,[3,8,48,50]);assert.equal(result.mode,8);assert.equal(result.battery,true);
  assert.equal(result.ports.filter(p=>p.type==='usb').length,0,'original stick has no USB socket');
  assert.equal(result.ports.filter(p=>p.type==='dmx').length,0,'original stick DMX I/O is wireless');
  assert.ok(result.ports.some(p=>p.type==='wireless'&&!p.out),'D-Fi receive path');
  assert.ok(result.ports.some(p=>p.type==='power'&&!p.out&&/DC|15\s*V/i.test(p.connector)),'15 V DC charging inlet');
  assert.equal(result.ports.filter(p=>p.type==='power'&&p.out).length,0,'no power pass-through');
 });
 await test('old erroneous Freedom USB cable remains reviewable without inventing a physical USB port',()=>{
  const result=json(`(()=>{const pc=makeNode(catalog.find(m=>m.id==='laptop')),n=makeNode(catalog.find(m=>m.id==='snl-520'));n.usbPowered=true;n.usb=true;n.internalBattery=false;n.legacyPorts=[{id:'usbIn',type:'usb',out:false,legacy:true}];const edge={id:'old-usb',from:pc.id,port:'usbOut',to:n.id,toPort:'usbIn',type:'usb'};const restored=normalize({nodes:[pc,n],edges:[edge]});state=restored;return{ports:ports(restored.nodes[1]),edges:restored.edges,battery:restored.nodes[1].internalBattery}})()`);
  assert.equal(result.edges.length,1,'never discard the user cable');assert.equal(result.edges[0].needsReview,true,'detached cable needs attention');
  assert.equal(result.ports.filter(p=>p.type==='usb').length,0,'do not reinstate a phantom USB as legacy port');assert.equal(result.battery,true);
 });
 await test('unconfigured pixel card offers model selection instead of an unusable ? CH dropdown',()=>{
  run(`state={nodes:[makeNode(catalog.find(m=>m.id==='generic-pixel'))],edges:[]};routeCache=null;renderNodes()`);
  assert.doesNotMatch(html('#nodes'),/\?\s*CH/);assert.match(html('#nodes'),/Выб(?:рать|ери|ор) модель/);
  assert.equal(run(`typeof document.querySelector('[data-choose-model="'+state.nodes[0].id+'"]').onclick`),'function','the visible choose-model action must be bound');
 });
 await test('catalog only offers concrete models outside power and hides unresolved DMX profiles',()=>{
  run(`state={nodes:[],edges:[]};renderCatalog()`);
  assert.doesNotMatch(html('#catalogTree'),/data-add="generic-|Добавить без модели/);
  for(const id of ['snl-297','snl-494','snl-477','snl-228'])assert.ok(run(`catalog.find(m=>m.id==='${id}').catalogHidden`));
 });

 await test('an existing generic card chooses its model in place without duplicating the fixture',()=>{
  run(`{const source=makeNode(catalog.find(m=>m.id==='xnd8')),target=makeNode(catalog.find(m=>m.id==='generic-bar'),240,480);target.id='replace-existing';state={nodes:[source,target],edges:[{id:'keep-bar-cable',from:source.id,port:'out1',to:target.id,toPort:'dmxIn',type:'dmx'}]};selected=null;selection.clear();routeCache=null;renderNodes();document.querySelector('[data-choose-model="replace-existing"]').onclick()}`);
  assert.match(html('#modelPicker'),/data-model-choice="snl-499"/);
  run(`document.querySelector('[data-model-choice="snl-499"]').onclick()`);
  const result=json(`({count:state.nodes.length,node:node('replace-existing'),edges:state.edges})`);
  assert.equal(result.count,2,'choosing a model must not add a second fixture');assert.equal(result.node.model,'snl-499');assert.equal(result.node.channels,11);assert.equal(result.node.x,240);assert.equal(result.node.y,480);assert.equal(result.edges.length,1);assert.ok(!result.edges[0].needsReview);
 });
 await test('choosing a real model updates footprint and name while preserving position, size and compatible wiring',()=>{
  const result=json(`(()=>{const source=makeNode(catalog.find(m=>m.id==='xnd8')),n=makeNode(catalog.find(m=>m.id==='generic-pixel'),240,480);n.width=288;n.height=192;const before={id:n.id,x:n.x,y:n.y,width:n.width,height:n.height};state={nodes:[source,n],edges:[{id:'model-cable',from:source.id,port:'out1',to:n.id,toPort:'dmxIn',type:'dmx'}]};changeNodeModel(n,'snl-499');return{before,after:{id:n.id,x:n.x,y:n.y,width:n.width,height:n.height},name:n.name,channels:n.channels,ports:ports(n),edges:state.edges,root:RigCore.root(state,n.id,'dmx')}})()`);
  assert.deepEqual(result.after,result.before);assert.equal(result.channels,11);assert.ok(result.name.includes('UBL'));assert.equal(result.edges.length,1);assert.ok(!result.edges[0].needsReview);assert.equal(result.root.universe,1);
  assert.ok(result.ports.some(p=>p.type==='dmx'&&p.out));assert.ok(result.ports.some(p=>p.type==='power'&&p.out));
 });
 await test('model changes never turn an incompatible cable into a live phantom connector',()=>{
  const result=json(`(()=>{const source=makeNode(catalog.find(m=>m.id==='xnd8')),n=makeNode(catalog.find(m=>m.id==='generic-pixel'));state={nodes:[source,n],edges:[{id:'retained-dmx',from:source.id,port:'out1',to:n.id,toPort:'dmxIn',type:'dmx'}]};changeNodeModel(n,'snl-164');return{ports:ports(n),edges:state.edges,root:RigCore.root(state,n.id,'dmx')}})()`);
  assert.equal(result.edges.length,1);assert.equal(result.edges[0].needsReview,true);assert.equal(result.ports.filter(p=>p.type==='dmx').length,0);assert.equal(result.root,null,'review cable cannot carry modeled DMX');
 });
 await test('one remaining video socket is not sufficient to silently replace HDMI with VGA',()=>{
  const result=json(`(()=>{catalog.push({id:'test-vga-screen',name:'VGA Screen',category:'video',kind:'tv',video:true,signalPorts:[{id:'vgaIn',type:'video',out:false,connector:'VGA / DE-15'}]});const pc=makeNode(catalog.find(m=>m.id==='laptop')),screen=makeNode(catalog.find(m=>m.id==='generic-tv'));state={nodes:[pc,screen],edges:[{id:'old-hdmi',from:pc.id,port:'videoOut',to:screen.id,toPort:'videoIn',type:'video'}]};changeNodeModel(screen,'test-vga-screen');return{edges:state.edges,root:RigCore.root(state,screen.id,'video')}})()`);
  assert.equal(result.edges.length,1);assert.equal(result.edges[0].needsReview,true,'HDMI→VGA requires an explicit converter, not unique-port inference');assert.equal(result.root,null);
 });
 await test('reducing distributor output count preserves removed cables for review instead of rewiring them',()=>{
  const result=json(`(()=>{const d=makeNode(catalog.find(m=>m.id==='distro')),a=makeNode(catalog.find(m=>m.id==='focusflex')),b=makeNode(catalog.find(m=>m.id==='focusflex'));d.outputs=4;state={nodes:[d,a,b],edges:[{id:'first',from:d.id,port:'power1',to:a.id,toPort:'powerIn',type:'power'},{id:'fourth',from:d.id,port:'power4',to:b.id,toPort:'powerIn',type:'power'}]};selected=d.id;renderInspector();const input=document.querySelector('#outputs');input.value='2';input.onchange();const before=JSON.parse(JSON.stringify(state.edges));state=normalize(JSON.parse(JSON.stringify(state)));return{before,after:state.edges}})()`);
  for(const edges of [result.before,result.after]){assert.equal(edges.length,2);assert.equal(edges[0].port,'power1');assert.ok(!edges[0].needsReview);assert.equal(edges[1].port,'power4','never silently reassign the removed physical output');assert.equal(edges[1].needsReview,true);assert.equal(edges[1].detached,true)}
 });
 await test('changing the physical DMX connector updates incompatible wiring immediately and consistently after reload',()=>{
  const result=json(`(()=>{const source=makeNode(catalog.find(m=>m.id==='xnd8')),target=makeNode(catalog.find(m=>m.id==='snl-470'));source.hardwareVariant='5';target.hardwareVariant='us-5pin';syncNodeHardware(source);syncNodeHardware(target);state={nodes:[source,target],edges:[{id:'manual-connector',from:source.id,port:'out1',to:target.id,toPort:'dmxIn',type:'dmx',fromConnector:'5-pin XLR',toConnector:'5-pin XLR'}]};selected=target.id;renderInspector();const select=document.querySelector('#dmxConnector');select.value='3-pin XLR';select.onchange();const before={edge:{...state.edges[0]},root:RigCore.root(state,target.id,'dmx')};state=normalize(JSON.parse(JSON.stringify(state)));return{before,after:{edge:state.edges[0],root:RigCore.root(state,target.id,'dmx')}}})()`);
  for(const stage of [result.before,result.after]){assert.equal(stage.edge.needsReview,true);assert.equal(stage.edge.detached,true);assert.equal(stage.root,null)}
 });
 await test('ordinary RJ45 Ethernet cable connects the ASUS laptop to the XND etherCON socket',()=>{
  const result=json(`(()=>{const pc=makeNode(catalog.find(m=>m.id==='snl-347')),n=makeNode(catalog.find(m=>m.id==='xnd8'));state={nodes:[pc,n],edges:[]};selected=null;pending={node:pc.id,port:'ethernetOut',type:'ethernet'};finishCable(n,ports(n).find(p=>p.id==='ethernetIn'));const before=JSON.parse(JSON.stringify(state.edges));state=normalize(JSON.parse(JSON.stringify(state)));return{before,after:state.edges}})()`);
  for(const edges of [result.before,result.after]){assert.equal(edges.length,1,'RJ45 and etherCON do not require a signal converter');assert.equal(edges[0].type,'ethernet');assert.ok(!edges[0].needsReview)}
 });
 await test('NEC ME403U has video inputs and monitor output; Philips Tempo is a lamp floodlight',()=>{
  const result=json(`(()=>{const video=makeNode(catalog.find(m=>m.id==='snl-512')),lamp=makeNode(catalog.find(m=>m.id==='snl-164'));state={nodes:[video,lamp],edges:[]};return{video:ports(video),lamp:ports(lamp),lampDmx:lamp.dmx}})()`);
  assert.equal(result.video.filter(p=>p.type==='video'&&!p.out&&/HDMI/i.test(p.connector)).length,2,'NEC HDMI IN count');
  assert.ok(result.video.some(p=>p.type==='video'&&p.out&&/VGA|DE-15/i.test(p.connector)),'NEC monitor output');
  assert.equal(result.lampDmx,false);assert.equal(result.lamp.filter(p=>p.type==='dmx'||p.type==='video').length,0,'Tempo cannot invent DMX or HDMI outputs');assert.ok(result.lamp.some(p=>p.type==='power'&&!p.out));
 });
 await test('Epson Computer 2 is one physical VGA socket whose direction survives saving',()=>{
  const result=json(`(()=>{const n=makeNode(catalog.find(m=>m.id==='snl-513'));state={nodes:[n],edges:[]};const initial=ports(n);n.portDirections.vgaIn2=true;const restored=normalize(JSON.parse(JSON.stringify(state)));state=restored;return{initial,restored:ports(restored.nodes[0])}})()`);
  for(const set of [result.initial,result.restored])assert.equal(set.filter(p=>p.type==='video'&&/VGA|DE-15/i.test(p.connector)).length,2,'VGA1 and VGA2, not an invented third monitor socket');
  assert.equal(result.initial.find(p=>p.id==='vgaIn2').out,false);assert.equal(result.restored.find(p=>p.id==='vgaIn2').out,true);
 });
 await test('Feelworld F6 Plus USB-C is power only, with HDMI loop and separate DC output',()=>{
  const result=json(`(()=>{const n=makeNode(catalog.find(m=>m.id==='snl-531'));state={nodes:[n],edges:[]};return ports(n)})()`);
  assert.equal(result.filter(p=>p.type==='usb').length,0);assert.equal(result.filter(p=>p.type==='video').length,2);for(const out of [true,false])assert.ok(result.some(p=>p.type==='video'&&p.out===out&&/HDMI/.test(p.connector)));
  assert.ok(result.some(p=>p.type==='power'&&!p.out&&/USB-C/.test(p.connector)));assert.ok(result.some(p=>p.type==='power'&&!p.out&&p.volts===12));assert.ok(result.some(p=>p.type==='power'&&p.out&&p.volts===8));
 });
 await test('Baseus USB-C output powers the portable monitor through its real DC inlet before and after reload',()=>{
  const result=json(`(()=>{const bank=makeNode(catalog.find(m=>m.id==='snl-434')),screen=makeNode(catalog.find(m=>m.id==='snl-537'));state={nodes:[bank,screen],edges:[]};selected=null;const out=ports(bank).find(p=>p.type==='usb'&&p.out&&p.powerOnly&&/USB-C/.test(p.connector)),input=ports(screen).find(p=>p.type==='power'&&!p.out&&/USB-C/.test(p.connector));pending={node:bank.id,port:out.id,type:out.type};finishCable(screen,input);const before={edges:JSON.parse(JSON.stringify(state.edges)),root:RigCore.root(state,screen.id,'power')};state=normalize(JSON.parse(JSON.stringify(state)));return{sourceId:bank.id,sourcePort:out.id,before,after:{edges:state.edges,root:RigCore.root(state,screen.id,'power')},screenPorts:ports(node(screen.id)),bankPorts:ports(node(bank.id))}})()`);
  for(const stage of [result.before,result.after]){assert.equal(stage.edges.length,1);assert.equal(stage.edges[0].type,'power');assert.ok(!stage.edges[0].detached&&!stage.edges[0].needsReview);assert.equal(stage.root?.source,result.sourceId);assert.equal(stage.root?.port,result.sourcePort);assert.equal(stage.root?.phase,'DC')}
  assert.equal(result.screenPorts.filter(p=>p.type==='power').length,1,'only the physical USB-C power inlet');assert.equal(result.bankPorts.filter(p=>p.type==='power').length,0,'power bank has no invented AC socket');assert.equal(result.screenPorts.filter(p=>p.type==='power'&&p.powerDomain==='ac').length,0);
 });
 await test('selected XND and Focus hardware versions retain their actual connectors after saving',()=>{
  const result=json(`(()=>{const x=makeNode(catalog.find(m=>m.id==='xnd8')),f=makeNode(catalog.find(m=>m.id==='snl-470'));x.hardwareVariant='5';f.hardwareVariant='us-5pin';state={nodes:[x,f],edges:[]};syncNodeHardware(x);syncNodeHardware(f);const before=state.nodes.map(n=>({id:n.id,name:n.name,model:n.model,channels:n.channels,ports:ports(n)}));state=normalize(JSON.parse(JSON.stringify(state)));return{before,after:state.nodes.map(n=>({id:n.id,name:n.name,model:n.model,modelId:model(n).id,channels:n.channels,connector:n.dmxConnector,ports:ports(n)}))}})()`);
  for(const set of [result.before,result.after]){assert.equal(set[0].ports.filter(p=>p.type==='dmx'&&p.out).length,8);assert.ok(set[0].ports.filter(p=>p.type==='dmx').every(p=>/5.pin/.test(p.connector)));assert.equal(set[1].channels,18);assert.equal(set[1].ports.filter(p=>p.type==='dmx').length,2);assert.ok(set[1].ports.filter(p=>p.type==='dmx').every(p=>/5.pin/.test(p.connector)))}
  for(let i=0;i<2;i++){assert.equal(result.after[i].id,result.before[i].id);assert.equal(result.after[i].model,result.before[i].model);assert.equal(result.after[i].modelId,result.before[i].model);assert.equal(result.after[i].name,result.before[i].name);assert.ok(result.after[i].name.split(/\s+/).length<=2);assert.match(result.after[i].connector,/5.pin/)}
 });
 await test('ADJ Inno Roll HP retains documented 9-channel DMX input and output',()=>{
  const result=json(`(()=>{const m=catalog.find(m=>m.id==='snl-227'),n=makeNode(m);state={nodes:[n],edges:[]};return{mode:n.channels,ports:ports(n)}})()`);
  assert.equal(result.mode,9);for(const out of [false,true])assert.ok(result.ports.some(p=>p.type==='dmx'&&p.out===out&&/3.?pin/i.test(p.connector)),out?'DMX OUT':'DMX IN');
 });
 await test('classic cards use square sockets without plug overlays',()=>{
  const result=json(`(()=>{const a=makeNode(catalog.find(m=>m.id==='xnd8')),b=makeNode(catalog.find(m=>m.id==='focusflex'),480,384);state={nodes:[a,b],edges:[{id:'plug-test',type:'dmx',from:a.id,port:'out1',to:b.id,toPort:'dmxIn'}]};routeCache=null;renderNodes();const pa=ports(a).find(p=>p.id==='out1'),pb=ports(b).find(p=>p.id==='dmxIn');return{html:document.querySelector('#nodes').innerHTML,start:cablePosition(a,pa),end:cablePosition(b,pb),radio:plugMarkup(a,{...pa,type:'wireless'},true)}})()`);
  assert.doesNotMatch(result.html,/class="plug-anchor"/);assert.match(result.html,/fixture-content/);assert.equal(result.end.x,480);assert.equal(result.radio,'');
 });
 await test('marquee works in both directions; group copy preserves only internal wiring and supports delete/undo',()=>{
  const result=json(`(()=>{const a=makeNode(catalog.find(m=>m.id==='xnd8'),0,0),b=makeNode(catalog.find(m=>m.id==='focusflex'),480,0),c=makeNode(catalog.find(m=>m.id==='focusflex'),960,0);state={nodes:[a,b,c],edges:[{id:'inside',type:'dmx',from:a.id,port:'out1',to:b.id,toPort:'dmxIn',points:[{x:288,y:288}]},{id:'outside',type:'dmx',from:b.id,port:'dmxOut',to:c.id,toPort:'dmxIn',points:[]}]};history=[];future=[];selection.clear();selected=null;routeCache=null;const forward=[...boxSelection({x:-24,y:-24},{x:700,y:240})],reverse=[...boxSelection({x:700,y:240},{x:-24,y:-24})];forward.forEach(id=>selection.add(id));copySelection();pasteSelection();const pasted=JSON.parse(JSON.stringify(state)),ids=[...selection];deleteSelection();const deleted={nodes:state.nodes.length,edges:state.edges.length};undo();return{forward,reverse,pasted,ids,deleted,restored:{nodes:state.nodes.length,edges:state.edges.length}}})()`);
  assert.equal(result.forward.length,2);assert.deepEqual(result.forward,result.reverse);assert.equal(result.pasted.nodes.length,5);assert.equal(result.pasted.edges.length,3);assert.equal(new Set(result.pasted.nodes.map(n=>n.id)).size,5);const edge=result.pasted.edges[2];assert.ok(result.ids.includes(edge.from)&&result.ids.includes(edge.to));assert.deepEqual(edge.points,[{x:336,y:336}]);assert.deepEqual(result.deleted,{nodes:3,edges:2});assert.deepEqual(result.restored,{nodes:5,edges:3});
 });
 await test('shared cables retain plain routing with exterior endpoints',()=>{
  const result=json(`(()=>{const a=makeNode(catalog.find(m=>m.id==='xnd8'),0,0),b=makeNode(catalog.find(m=>m.id==='focusflex'),480,384);state={nodes:[a,b],edges:[0,1].map(i=>({id:'lane-'+i,type:'dmx',from:a.id,port:'out1',to:b.id,toPort:'dmxIn'}))};routeCache=null;return{paths:routes().map(r=>r.displayPoints),raw:routes().map(r=>RigCore.simplify(r.points)),end:cablePosition(b,ports(b).find(p=>p.id==='dmxIn')),blockX:b.x}})()`);
  assert.deepEqual(result.paths,result.raw);
  for(const path of result.paths){assert.equal(path.at(-1).x,result.blockX);for(let i=1;i<path.length;i++)assert.ok(path[i].x===path[i-1].x||path[i].y===path[i-1].y,'orthogonal lane');}
 });
})().catch(error=>{console.error(error);process.exitCode=1});
