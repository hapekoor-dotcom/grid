const test=require('node:test');
const assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const path=require('node:path');

test('vendored WebGL path tracer and volume material load against the site Three.js',async()=>{
 const module=await import(pathToFileURL(path.resolve(__dirname,'../dist/vendor/three-gpu-pathtracer.js')));
 assert.equal(typeof module.WebGLPathTracer,'function');
 assert.equal(typeof module.FogVolumeMaterial,'function');
});
