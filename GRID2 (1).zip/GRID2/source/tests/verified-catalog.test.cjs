const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {test} = require('node:test');

const dist = path.resolve(__dirname, '../dist');
const stub = {
  addEventListener() {}, setAttribute() {},
  style: {setProperty() {}},
  classList: {remove() {}, toggle() {}, add() {}},
};

async function harness() {
  const context = vm.createContext({
    document: {querySelector: () => stub, querySelectorAll: () => [], addEventListener() {}},
    window: {addEventListener() {}}, console, URL, setTimeout, clearTimeout,
    fetch: async (url) => {
      const name = String(url).split('?')[0];
      const file = path.resolve(dist, name);
      assert.ok(file.startsWith(dist + path.sep), 'Fixture fetch must remain inside dist');
      return {ok: fs.existsSync(file), json: async () => JSON.parse(fs.readFileSync(file, 'utf8'))};
    },
  });
  for (const name of ['core.js', 'catalog.js', 'symbols.js', 'verification.js', 'app.js']) {
    const source = fs.readFileSync(path.join(dist, name), 'utf8');
    vm.runInContext(name === 'app.js' ? source.replace(/init\(\);\s*$/, '') : source, context, {filename: name});
  }
  for (const name of vm.runInContext('verificationFiles', context)) {
    assert.ok(fs.existsSync(path.join(dist, name)), 'Missing verification source: ' + name);
    JSON.parse(fs.readFileSync(path.join(dist, name), 'utf8'));
  }
  context.inputCatalog = JSON.parse(fs.readFileSync(path.join(dist, 'catalog-researched.json'), 'utf8'));
  await vm.runInContext(`(async () => {
    const list=Array.isArray(inputCatalog)?inputCatalog:inputCatalog.entries||inputCatalog.products||[];
    for(const raw of list){
      if(!raw.id||!categories[raw.category])continue;
      const existing=catalog.find(m=>m.name.toLowerCase().replace(/\\W/g,'')===raw.name.toLowerCase().replace(/\\W/g,''));
      if(existing){if(raw.source)existing.rentalSource=raw.source;continue}
      const kind=raw.kind||'par';
      catalog.push({...raw,kind,notes:Array.isArray(raw.notes)?raw.notes.join(' '):raw.notes,
        manual:raw.manual||raw.manufacturerSource||raw.manuals?.[0],
        dmxConnector:(raw.connectors||[]).filter(v=>/DMX/.test(v)).length===1?
          (raw.connectors.find(v=>/DMX/.test(v)).includes('5-pin')?'5-pin XLR':raw.connectors.find(v=>/DMX/.test(v)).includes('3-pin')?'3-pin XLR':''):'',
        label:raw.label||kind.toUpperCase(),dmx:raw.dmx??['light','effect'].includes(raw.category),consumes:raw.consumes??true});
    }
    await loadVerification();
    prepareCatalog();
    finishVerifiedCatalog();
    state={version:4,nodes:[],edges:[]};
  })()`, context);
  return (source) => vm.runInContext(source, context);
}

async function main() {
  const run = await harness();

  await test('saved null mode is restored from the documented default', () => {
    const restored = run(`(() => {
      const m=catalog.find(m=>m.id==='focusflex'),n=makeNode(m);
      n.channels=null;n.modeId=null;n.modeLabel='';
      return normalize({nodes:[n],edges:[]}).nodes[0];
    })()`);
    assert.equal(restored.modeId, 'standard-rgbw-25');
    assert.equal(restored.channels, 25);
    assert.equal(restored.modeChoice, 'default');
  });

  await test('two 25-channel Focus Flex personalities retain different stable IDs', () => {
    const result = run(`(() => {
      const m=catalog.find(m=>m.id==='focusflex'),n=makeNode(m);
      const identities=modes(m).filter(v=>v.channels===25).map(v=>v.id);
      setMode(n,'standard-cmy-25');
      const restored=normalize({nodes:[n],edges:[]}).nodes[0];
      return {identities,restored};
    })()`);
    assert.deepEqual(Array.from(result.identities).sort(), ['standard-cmy-25', 'standard-rgbw-25']);
    assert.equal(result.restored.modeId, 'standard-cmy-25');
    assert.equal(result.restored.channels, 25);
    assert.equal(result.restored.modeChoice, 'user');
  });

  await test('explicit custom channel footprint and manual address survive loading', () => {
    const restored = run(`(() => {
      const n=makeNode(catalog.find(m=>m.id==='focusflex'));
      n.modeId='custom';n.channels=31;n.modeChoice='user';n.modeLabel='Вручную';n.manual=137;
      return normalize({nodes:[n],edges:[]}).nodes[0];
    })()`);
    assert.equal(restored.modeId, 'custom');
    assert.equal(restored.channels, 31);
    assert.equal(restored.manual, 137);
    assert.equal(restored.modeChoice, 'user');
  });

  await test('every final catalog mode has valid footprint and a selectable default', () => {
    const failures = run(`(() => {
      const failures=[];
      for(const m of catalog){
        const mm=modes(m),n=makeNode(m),ids=new Set();
        for(const mode of mm){
          if(!Number.isInteger(mode.channels)||mode.channels<1||mode.channels>512)failures.push(m.id+': invalid footprint');
          if(ids.has(mode.id))failures.push(m.id+': duplicate mode ID '+mode.id);
          ids.add(mode.id);
        }
        if(mm.length&&!mm.some(v=>v.id===n.modeId&&v.channels===n.channels))failures.push(m.id+': unselectable default');
        if(!mm.length&&(n.modeId!==null||n.channels!==null))failures.push(m.id+': invented default');
        if(m.defaultModeId&&!mm.some(v=>v.id===String(m.defaultModeId)))failures.push(m.id+': missing explicit default '+m.defaultModeId);
      }
      return failures;
    })()`);
    assert.deepEqual(Array.from(failures), []);
  });

  await test('unconfirmed DMX capability never turns into a confirmed fixture', () => {
    const result = run(`(() => {
      const unknown=catalog.filter(m=>m.dmx===null);
      return {count:unknown.length,errors:unknown.filter(m=>makeNode(m).dmx).map(m=>m.id)};
    })()`);
    assert.ok(result.count > 0, 'Expected unresolved models in the real rental catalog');
    assert.deepEqual(Array.from(result.errors), []);
  });

  await test('final catalog ports fit snapped card bounds, including minimum resizes and rotations', () => {
    const result = run(`(() => {
      const failures=[];let checked=0;
      for(const m of catalog)for(const rotation of [0,90,180,270])for(const dims of [null,[24,24],[384,288]]){
        const n=makeNode(m);n.rotation=rotation;
        if(dims){n.width=dims[0];n.height=dims[1]}
        state.nodes=[n];const s=size(n),ps=ports(n),seen=new Set();
        if(s.w%G||s.h%G)failures.push(m.id+': card off grid');
        for(const p of ps){
          const q=localPorts(n).find(q=>q.id===p.id);
          if(canRotate(n)&&(p.dx!==(p.out?1:-1)||p.dy!==0||p.x!==(p.out?s.w-G/2:G/2)))failures.push(m.id+': rotated port on wrong side');
          if(!Number.isFinite(p.x)||!Number.isFinite(p.y)||q.x%((q.dy===1||q.rack)?G/2:G)||q.y%((q.dy===1||q.rack)?G/2:G)||p.x<0||p.y<0||p.x>s.w||p.y>s.h)failures.push(m.id+': '+p.id+' outside '+s.w+'×'+s.h+' at '+p.x+','+p.y);
          if(seen.has(p.id))failures.push(m.id+': duplicate port '+p.id);
          if(!colors[p.type])failures.push(m.id+': unsupported cable type '+p.type);
          seen.add(p.id);
        }
        checked++;
      }
      return {failures,checked,count:catalog.length};
    })()`);
    assert.ok(result.count > 100, 'Must validate the researched catalog, not just starter blocks');
    assert.equal(result.checked, result.count * 12);
    assert.deepEqual(Array.from(result.failures), []);
  });

  await test('wireless-only fixtures expose radio input without invented wired DMX ports', () => {
    const result = run(`(() => {
      const fixtures=catalog.filter(m=>m.dmxPhysical===false&&m.wirelessDMX);
      return {count:fixtures.length,errors:fixtures.flatMap(m=>{
        const n=makeNode(m);state.nodes=[n];const ps=ports(n),errors=[];
        if(ps.some(p=>p.type==='dmx'))errors.push(m.id+': invented wired DMX');
        if(!ps.some(p=>p.type==='wireless'&&!p.out))errors.push(m.id+': no radio input');
        return errors;
      })};
    })()`);
    assert.ok(result.count > 0, 'Expected documented wireless-only fixtures');
    assert.deepEqual(Array.from(result.errors), []);
  });

  await test('explicit signal connector definitions produce exact ports, including video inputs and outputs', () => {
    const result = run(`(() => {
      const fixtures=catalog.filter(m=>Array.isArray(m.signalPorts));
      return {count:fixtures.length,videoCount:fixtures.filter(m=>m.signalPorts.some(p=>p.type==='video')).length,errors:fixtures.flatMap(m=>{
        const n=makeNode(m);state.nodes=[n];const actual=ports(n).filter(p=>p.type!=='power');
        const expected=m.id==='snl-368'?[]:m.signalPorts,errors=[];
        if(actual.length!==expected.length)errors.push(m.id+': expected '+expected.length+' signal ports, got '+actual.length);
        for(const p of expected){
          const match=actual.find(a=>a.id===p.id);
          if(!match)errors.push(m.id+': missing '+p.id);
          else if(match.type!==p.type||match.out!==p.out||match.connector!==(p.connector||''))errors.push(m.id+': wrong type, direction or connector '+p.id);
        }
        return errors;
      })};
    })()`);
    assert.ok(result.count > 0, 'Expected verified per-port connector data');
    assert.ok(result.videoCount > 0, 'Expected verified video connector data');
    assert.deepEqual(Array.from(result.errors), []);
  });

  await test('verified ATEM and HDMI distribution models expose the documented video counts', () => {
    const result = run(`JSON.stringify(['snl-327','snl-510','snl-345','snl-489'].map(id=>{
      const n=makeNode(catalog.find(m=>m.id===id));state.nodes=[n];const video=ports(n).filter(p=>p.type==='video');
      return [id,video.filter(p=>!p.out).length,video.filter(p=>p.out).length];
    }))`);
    assert.deepEqual(JSON.parse(result), [
      ['snl-327', 4, 1],
      ['snl-510', 8, 2],
      ['snl-345', 1, 4],
      ['snl-489', 2, 1],
    ]);
  });

  await test('existing HDMI cables migrate to the real HDMI socket when only connector IDs change', () => {
    const result = run(`(() => {
      const source=makeNode(catalog.find(m=>m.id==='laptop'));
      const target=makeNode(catalog.find(m=>m.id==='snl-345'));
      source.id='saved-pc';target.id='saved-splitter';
      const saved={nodes:[source,target],edges:[{id:'saved-hdmi',type:'video',from:source.id,port:'videoOut',to:target.id,toPort:'videoIn'}]};
      const restored=normalize(saved),edge=restored.edges[0];
      state=restored;
      return {nodes:restored.nodes.length,edges:restored.edges.length,targetPort:edge.toPort,needsReview:edge.needsReview,
        reviewIssue:RigCore.patch(restored).issues.some(issue=>/Сохранённый кабель требует сверки/.test(issue)),
        valid:ports(restored.nodes[1]).some(p=>p.id===edge.toPort&&p.type==='video'&&!p.out)};
    })()`);
    assert.equal(result.nodes, 2);
    assert.equal(result.edges, 1);
    assert.equal(result.valid, true);
    assert.equal(result.targetPort, 'hdmiIn1');
    assert.equal(result.needsReview, false);
    assert.equal(result.reviewIssue, false);
  });

  await test('USB-A to USB-C cable is allowed while unrelated connectors still require adapters', () => {
    assert.equal(run("!!connectorsMatch('USB-A','USB-C')"), true);
    assert.equal(run("!!connectorsMatch('USB-C','USB 3.0 Micro-B')"), true);
    assert.equal(run("!!connectorsMatch('3-pin XLR','5-pin XLR')"), false);
    assert.equal(run("!!connectorsMatch('HDMI Type A','VGA')"), false);
  });
}

main().catch(error => {console.error(error);process.exitCode=1;});
