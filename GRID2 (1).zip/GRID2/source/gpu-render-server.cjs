const fs = require('node:fs');
const path = require('node:path');

function getConfig() {
 const env = {};
 try {
  for (const line of fs.readFileSync(path.join(__dirname,'.env.local'),'utf8').split(/\r?\n/)) {
   const entry = line.match(/^(RUNPOD_API_KEY|RUNPOD_RENDER_ENDPOINT)=(.*)$/);
   if (entry) env[entry[1]] = entry[2].trim().replace(/^['"]|['"]$/g,'');
  }
 } catch {}
 return {...env,...Object.fromEntries(['RUNPOD_API_KEY','RUNPOD_RENDER_ENDPOINT'].filter(key=>process.env[key]).map(key=>[key,process.env[key]]))};
}

async function handleGpuRender(req,res,url,{fetchImpl=fetch,config=getConfig}={}) {
 const send=(status,body)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(body))};
 if(req.headers.origin&&req.headers.origin!=='http://'+req.headers.host)return send(403,{error:'Недопустимый источник запроса'});
 const {RUNPOD_API_KEY:key,RUNPOD_RENDER_ENDPOINT:endpoint}=config();
 if(!key||!/^[a-z0-9]+$/i.test(endpoint||''))return send(503,{error:'Настрой RUNPOD_API_KEY и RUNPOD_RENDER_ENDPOINT на локальном сервере'});
 const id=url.searchParams.get('id');
 if(req.method==='GET'&&!id)return send(200,{ready:true});
 if(req.method!=='GET'&&req.method!=='POST')return send(405,{error:'Метод недоступен'});
 if(req.method==='GET'&&!/^[a-z0-9_-]{1,100}$/i.test(id))return send(400,{error:'Некорректный ID задачи'});
 try {
  let body;
  if(req.method==='POST'){
   const chunks=[];
   let size=0;
   for await(const chunk of req){
    size+=chunk.length;
    if(size>9_000_000){send(413,{error:'Сцена превышает лимит очереди рендера'});return}
    chunks.push(chunk);
   }
   let input;
   try{input=JSON.parse(Buffer.concat(chunks))}catch{return send(400,{error:'Некорректный JSON'})}
   body=JSON.stringify({input});
  }
  const action=req.method==='POST'?'run':'status/'+id;
  const response=await fetchImpl('https://api.runpod.ai/v2/'+endpoint+'/'+action,{
   method:req.method,headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},
   body,signal:AbortSignal.timeout(25000)
  });
  if(!response.ok)return send(502,{error:'Runpod вернул HTTP '+response.status});
  const data=await response.json();
  send(200,data);
 }catch{send(502,{error:'Не удалось связаться с Runpod'})}
}
module.exports={handleGpuRender};
