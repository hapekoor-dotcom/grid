const http = require('node:http'), fs = require('node:fs'), path = require('node:path');
const { handleGpuRender } = require('./gpu-render-server.cjs');
const { createAssistantHandler } = require('./assistant-server.cjs');
const root = path.join(__dirname, 'dist'), port = Number(process.env.PORT) || 4173, assistant = createAssistantHandler();
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  if (![ `localhost:${port}`, `127.0.0.1:${port}` ].includes(req.headers.host)) { res.writeHead(403); res.end('Forbidden'); return; }
  let file;
  try {
    const url = new URL(req.url, 'http://localhost');
    const pathname = decodeURIComponent(url.pathname);
    if (pathname === '/api/gpu-render') { void handleGpuRender(req, res, url); return; }
    if (pathname === '/api/assistant') { assistant(req, res); return; }
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end(); return; }
    file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!file.startsWith(root + path.sep) || pathname.split('/').some(p => p.startsWith('.'))) throw Error();
  } catch { res.writeHead(400); res.end('Bad request'); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' }); res.end(req.method === 'HEAD' ? undefined : data);
  });
});
if (require.main === module) server.listen(port, '127.0.0.1', () => console.log(`Rig Grid: http://localhost:${port}\nCtrl+C to stop. No hardware output.`));
module.exports = server;
