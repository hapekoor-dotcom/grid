# Rig Grid
An offline prototype for planning event-lighting connections before a gig. User: a beginner working with S&L Concept and Avolites Titan 19.2. Core equipment: ADJ Focus Flex, ADJ UBL12H, Swisson XND-8. Physical counts are illustrative.
Primary task: arrange fixture blocks as installed, connect power and DMX, calculate a coherent patch. No live Titan/RDM integration and no electrical load certification.
