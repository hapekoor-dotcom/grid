# Rig Grid — local planning workshop

Requires Node.js 18+. The editor has no package dependencies and works without an account or API key. The optional assistant requires an OpenAI API key on the local server.

Windows: double-click `start-local.bat`.
Any OS: run `node start-local.cjs`, then open http://localhost:4173.

Everything is stored in this browser's localStorage. Download JSON before changing browser/device. Import preserves positions, modes, manual addresses and routing. No network packets are sent to physical equipment. The signal test is simulation only.

## Planning model
- Modules and ports snap to 24px grid; Manhattan cable routing avoids module rectangles, rounds corners, offsets shared segments and separates crossings with a dark underlay. Click a cable to add grid waypoints.
- Logical universes are numbered from 1; no Art-Net export mapping is implied. Splitter A/B outputs inherit the selected upstream input. Unknown footprints block complete patch export.
- Power sums stated W across chains. Source phase budgets and output budgets are user-entered. Outlets with the same circuit ID share a budget. A simple distributor inherits its phase; it cannot switch phases. Use a three-phase source and explicitly assign its outputs to L1/L2/L3.
- Unknown load is not zero. Typical W is flagged. Ampere/power-factor, inrush, cable ampacity and mixed-device link safety are not certified. Maximum link count and current ratings are recorded as documentation notes, not automatically applied across mixed chains.
- Battery source max W and usable Wh are distinct. Device internal battery removes the mains input; power bank connector compatibility must be configured from real hardware.

## Catalog provenance
`dist/catalog-researched.json`: S&L device inventory with per-field evidence and manufacturer links where verified. `dist/catalog-audit.json`: crawl coverage/exclusions. Not every device has a manufacturer-verified mode or power rating; missing values stay unset. Cards display the evidence basis. Rental descriptions can conflict with model labels: see notes. Generic equipment entries are templates, not S&L stock claims.

Tests: `node tests/core.test.cjs`.


### Catalog verification

`dist/verified-*.json` holds device-specific corrections, source URLs, checked fields and unresolved fields. `verification.js` applies these before saved projects are restored. A planner default does not read or change the physical fixture setting. Unknown fixture capability is reported in patch validation. Saved connections to superseded port IDs remain visible as review items rather than discarding the project.

Run `node scripts/export-catalog-audit.cjs` to regenerate the downloadable `catalog-sources.txt` and structured `catalog-sources.json`. The report includes generic blocks separately and distinguishes fully checked, partially checked and unidentified models. Run `node --test tests/core.test.cjs tests/catalog.test.cjs tests/verified-catalog.test.cjs` for regression coverage.

## Stage preview

The visualizer uses locally bundled Three.js r170 and requires WebGL 2. Eligible fixtures marked as floor or ceiling are mapped from their diagram centers, preserving relative placement; `mountLevel` selects their mounting height. Generic solid models vary by fixture kind. The existing placement editor is unchanged.

Lighting: floor wash fixtures aim at the nearest visible wall; ceiling fixtures aim at the stage area. Pan and tilt adjust that target. Each fixture uses a shadow-casting spotlight. Curtain, wall, floor and stage meshes stop atmospheric beams at their first intersection; projected gobo textures use the spotlight itself, so they share its shadows. Working light is shadowed, while a faint ambient/environment contribution keeps unlit materials legible. Static shadow maps refresh only after scene or fixture changes.

Rotate and zoom the stage or choose front, perspective and top views. Adjust stage dimensions, haze, working light, master brightness, and each fixture's color, intensity, beam angle, pan and tilt. Palettes, head movement, generic gobo patterns and PNG export are available. Preview settings are saved with the project. Models, haze beams and light pools are illustrative and non-photometric; they do not certify actual fixture geometry, optics or illuminance.

Run `node --test tests/stage-preview.test.cjs` for placement-mapping coverage.

### Помощник в левом сайдбаре

Запуск: `node start-local.cjs` из папки `source` (или `node source/start-local.cjs` из корня).
Если уже работает прежний статический сервер на 4173, останови его Ctrl+C и запусти эту команду один раз. Обновление страницы само по себе не добавит серверный API.

Ключ `OPENAI_API_KEY` читается сервером из `source/.env.local`, вне каталога `dist`. Файл исключён из Git; ключ не отправляется браузеру. Модель по умолчанию `gpt-6.1-sol`, переопределение: `RIG_ASSISTANT_MODEL` в окружении или `.env.local`.

Чат отправляет в OpenAI текст, прикреплённые изображения, актуальную схему и доступный каталог. Фото прикрепляются кнопкой, вставкой или перетаскиванием; до 3 PNG/JPEG/WebP, до 15 МБ каждое, перед отправкой уменьшаются до 1600px. История живёт только в текущей вкладке до перезагрузки. Сервер запрашивает `store:false`.

Изменения сначала представлены планом. «Применить» проверяет план на копии проекта и сохраняет его одним действием истории; Ctrl Z отменяет весь план. Изменение схемы после получения ответа делает план устаревшим. Поддерживаются добавление/перемещение/удаление/переименование приборов, пол/потолок, режим/адрес DMX, поворот баров, подключения, прямоугольные области и автоматические DMX-линии.

Авто-DMX сохраняет существующие кабели, использует только свободные совместимые порты, избегает циклов, учитывает адреса и ёмкость universe. Неопределённые режимы, занятые входы и недостаток выходов объясняются в плане. Фото даёт приблизительную реконструкцию по каталогу, а не фотограмметрию или точное определение моделей. Вывода на оборудование нет.

UI reference: [Agent Chat by serafimcloud](https://21st.dev/@serafimcloud/components/agent-chat), адаптация на обычный JS под существующий интерфейс.

Проверки: `node --test tests/assistant.test.cjs tests/core.test.cjs tests/stage-preview.test.cjs`.
