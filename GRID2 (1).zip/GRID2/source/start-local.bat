@echo off
cd /d "%~dp0"
node start-local.cjs
pause
