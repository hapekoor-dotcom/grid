"""Build a compact GLB chair for the browser from the licensed local source."""
import io
import json
import struct
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'assets/office-chair/office-chair.glb'
destination = ROOT / 'dist/assets/fixtures/event-chair.glb'
data = source.read_bytes()
assert data[:4] == b'glTF' and struct.unpack_from('<I', data, 4)[0] == 2
json_length, json_type = struct.unpack_from('<I4s', data, 12)
assert json_type == b'JSON'
document = json.loads(data[20:20 + json_length])
bin_start = 20 + json_length
bin_length, bin_type = struct.unpack_from('<I4s', data, bin_start)
assert bin_type == b'BIN\0'
binary = data[bin_start + 8:bin_start + 8 + bin_length]
images_by_view = {image['bufferView']: image for image in document.get('images', [])}
packed = bytearray()
for index, view in enumerate(document['bufferViews']):
    offset = view.get('byteOffset', 0)
    content = binary[offset:offset + view['byteLength']]
    if index in images_by_view:
        image = Image.open(io.BytesIO(content))
        image.thumbnail((768, 768), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        image.save(output, format='PNG', optimize=True)
        content = output.getvalue()
    while len(packed) % 4:
        packed.append(0)
    view['byteOffset'] = len(packed)
    view['byteLength'] = len(content)
    packed.extend(content)
while len(packed) % 4:
    packed.append(0)
document['buffers'][0]['byteLength'] = len(packed)
serialized = json.dumps(document, separators=(',', ':')).encode('utf-8')
serialized += b' ' * (-len(serialized) % 4)
result = b'glTF' + struct.pack('<II', 2, 12 + 8 + len(serialized) + 8 + len(packed))
result += struct.pack('<I4s', len(serialized), b'JSON') + serialized
result += struct.pack('<I4s', len(packed), b'BIN\0') + packed
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_bytes(result)
print(f'{source.stat().st_size / 1e6:.1f} MB -> {len(result) / 1e6:.1f} MB: {destination}')
