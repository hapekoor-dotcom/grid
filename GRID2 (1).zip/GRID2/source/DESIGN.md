# Rig Grid editor
Mode: Operate. Visual authority: user's Bitwig Poly Grid screenshot, 2026-11-05.
Compact charcoal modules on a freely pannable grid. Cyan circular DMX ports, coral square power ports. Legend once; port labels in tooltips/ARIA instead of repeated DMX IN/OUT text. Real ADJ photos with optional schematic view. Rotate fixture body and bar geometry, retain horizontal names. Visible cables anchored to edge sockets. Inspector appears only on selection; no permanent right rail.
Canvas supports unrestricted world coordinates, dragging background, wheel zoom at cursor, Fit, and undo/redo. Desktop prioritised, controls usable on narrow screens.

2026-11-05 refinement: schematic optics is default. BAR/WASH at top left, stable per-type number at top right, universe/address at bottom with space. Six circles represent bar optics, seven arranged lenses represent wash. Rotation is inspector/keyboard only. Node test panel previews static color, fade and strobe through the drawn topology, explicitly simulation without physical output. Tests are ephemeral, stopped on topology edits and page hiding.

Local v4: all modules are integer multiples of24px; corner and port coordinates are grid intersections. Orthogonal A* routes, seven-pixel corner rounding, four-pixel shared lanes and crossing underlays. Catalog is grouped by six categories and fixture type. Power overlay replaces photo toggle; phase panel is top-right. Source budgets entered by user; unknown and typical loads stay visibly incomplete. Ethernet yellow, video white, USB lavender, power coral, DMX cyan. Generic shape icons reflect equipment class. No public deployment for this iteration.

Typography: local variable Rubik (300–900), including Cyrillic. Numeric addresses use tabular figures.

Power overlay moved beside phase control, off by default with yellow active state. Disabled overlay excludes power checks and columns from patch. Distributor/source cards show load/budget and refresh while typing. Canvas darkened to #0a0d0e; square DMX sockets, labels align to header's right inset12px. Removed local/prototype status and bottom import/demo/save-status controls per user request.


## Catalog and neutral palette update
Operate surface: neutral black (#090909 canvas, #111 sidebar, #191919 folders, #252525 modules), yellow #e9b65b for primary actions. Cable colors remain semantic.
All categories except power use equipment-type folders with large single-line labels; real models inside, optional unnamed template at the bottom. Power keeps its existing structure.
Catalog labels and metadata are single-line. Keep full original product names in tooltips and inspector. Short display names remove redundant type/brand wording.
Reference: 21st.dev Sidebar by wensity, neutral dark surface and collapsible navigation hierarchy.


## November 2026 workspace revision

Current highest-priority interface rule: the supplied `dashboard-sidebar.tsx` reference defines the navigation shell as-is. Its workspace switcher, 260 px sidebar, grouped navigation, collapsible rows, search entry, bottom settings item, typography, spacing, and selected states take precedence over earlier shell decisions. Existing Rig Grid editor controls and panels adapt to that shell; cable colors and editor behavior remain semantic.

The shell uses near-black neutral surfaces with a warm yellow primary action. Both docked sidebars share a 320 px width and full available height. Each collapses to a 44 px rail containing only its toggle; hidden contents are inert. Panel width transitions respect reduced-motion settings. Tool actions belong in the top navigation; zoom remains available through the canvas wheel and F keyboard shortcut, without bottom controls. The canvas grid uses 50% alpha.

Reference: https://21st.dev/@wensity/components/sidebar — collapsible app sidebar / icon rail interaction; implemented in the existing plain-JavaScript app.

Fixture symbols are fixed-size SVG drawings centered independently of card resizing. LED bars use round lenses, pixel bars use discrete rectangular cells. Card DMX controls use stable personality IDs, including same-footprint RGBW and CMY modes.

## Stage preview

The separate, desktop-focused stage view uses locally bundled Three.js r170 and OrbitControls. Solid generic fixture models vary by equipment kind, with visible lenses, truss framing, haze beams, surface light pools and optional gobo patterns. Diagram centers map proportionally into stage coordinates; `mountLevel` determines floor or ceiling placement. The placement editor keeps its existing behavior.

Neutral dark controls provide front, perspective and top views, orbit/zoom, stage dimensions, haze, ambient light and master intensity. Fixture selection supports color, intensity, beam angle, pan and tilt; palettes, head motion, generic gobos and PNG snapshots support composition review. Models and optics are illustrative, not manufacturer geometry or photometric/lux calculations.

## Assistant, left equipment sidebar

Operate extension, using Agent Chat by serafimcloud on 21st.dev as the interaction reference. It occupies free space below equipment groups, above the existing cable legend. No right-panel changes. Rubik 12px/1.5, heading 13px/500, 1px neutral separators #333, composer #202020 with #484848 border and 6px radius, text #e1e1d8, secondary #b7b7ad. White send/apply controls distinguish chat actions from semantic cable colors. No decorative motion. Energy 1 / rhythm 1 / motion 1: a quiet docked tool, with the live equipment diagram remaining the main focus. File thumbnails support the actual photo input; the chat message area scrolls independently. Draft plans explicitly distinguish proposed changes from applied changes, and the editor undo stack remains the authority.
