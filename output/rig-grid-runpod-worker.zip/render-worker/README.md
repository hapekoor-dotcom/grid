# Rig Grid GPU render worker

Runpod queue worker for one JPEG frame per job. The Rig Grid 3D view exports the current camera, visible geometry, materials and spot lights as a self-contained GLB. Cycles runs with OptiX, adaptive sampling, denoising and a light scattering volume for the room. LED bars use the same spot-light approximation as local tracing. Browser-specific IES shaders are not exported.

## Deploy

From the project root, build and push the worker image to your registry.

```sh
docker build --platform linux/amd64 -t <registry>/<image>:v1 source/render-worker
docker push <registry>/<image>:v1
```

In Runpod, create a queue-based Serverless endpoint from the image. Use an NVIDIA GPU with OptiX support, zero active workers and an execution timeout of at least 1000 seconds. Store the endpoint ID and API key in `source/.env.local` or in the server environment.

```dotenv
RUNPOD_API_KEY=your_key
RUNPOD_RENDER_ENDPOINT=your_endpoint_id
```

Start `node source/start-local.cjs`. In 3D, select the render quality and click **GPU-рендер**. The local server submits the job and polls its status. API credentials stay on the local server. Closing 3D stops polling, but an already queued job continues remotely.

| Level | Width | Maximum samples | Sources per bar by default |
|---|---:|---:|---:|
| Low | 960 | 64 | 1 |
| Medium | 1440 | 192 | 3 |
| Max | 1920 | 512 | 6 |

The queue payload is capped at 9 MB, including Base64. Textures are capped at 512 px for the initial implementation. The worker returns one JPEG in the job output.

Runpod queue API and deployment documentation is available at https://docs.runpod.io/.
